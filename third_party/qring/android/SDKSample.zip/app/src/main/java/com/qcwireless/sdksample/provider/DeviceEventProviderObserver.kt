package com.qcwireless.sdksample.provider

import android.content.Context
import android.database.ContentObserver
import android.net.Uri
import android.os.Handler
import android.os.Looper
import com.elvishew.xlog.XLog
import com.qcwireless.sdksample.R
import com.qcwireless.sdksample.ext.showToast

class DeviceEventProviderObserver(
    private val context: Context
) {
    private val appContext = context.applicationContext
    private var lastEventSequence: Long = 0L
    private var observer: ContentObserver? = null

    fun start() {
        if (observer != null) {
            return
        }
        observer = object : ContentObserver(Handler(Looper.getMainLooper())) {
            override fun onChange(selfChange: Boolean, uri: Uri?) {
                super.onChange(selfChange, uri)
                queryLatestKeyEvent(showToast = true)
            }
        }
        runCatching {
            appContext.contentResolver.registerContentObserver(
                KEY_EVENT_LATEST_URI,
                false,
                observer!!
            )
        }.onSuccess {
            queryLatestKeyEvent(showToast = false)
        }.onFailure {
            XLog.tag(LOG_TAG).e("Failed to register DeviceEventProvider observer", it)
            observer = null
        }
    }

    fun stop() {
        observer?.let {
            appContext.contentResolver.unregisterContentObserver(it)
        }
        observer = null
    }

    private fun queryLatestKeyEvent(showToast: Boolean) {
        runCatching {
            appContext.contentResolver.query(KEY_EVENT_LATEST_URI, null, null, null, null)?.use { cursor ->
                if (!cursor.moveToFirst()) {
                    XLog.tag(LOG_TAG).d("No device key event available")
                    return
                }
                val keyEvent = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_KEY_EVENT))
                val eventTime = cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_EVENT_TIME))
                val eventSequence = cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_EVENT_SEQUENCE))
                if (eventSequence <= lastEventSequence) {
                    return
                }
                lastEventSequence = eventSequence
                val message = appContext.getString(
                    R.string.device_event_provider_key_event,
                    keyEvent,
                    eventSequence,
                    eventTime
                )
                XLog.tag(LOG_TAG).i(message)
                if (showToast) {
                    message.showToast()
                }
            } ?: XLog.tag(LOG_TAG).w("DeviceEventProvider query returned null cursor")
        }.onFailure {
            XLog.tag(LOG_TAG).e("Failed to query DeviceEventProvider", it)
        }
    }

    companion object {
        private const val LOG_TAG = "DeviceEventProvider"
        private const val PROVIDER_AUTHORITY = "com.app.cq.ring.device_event.provider"
        private const val COLUMN_KEY_EVENT = "key_event"
        private const val COLUMN_EVENT_TIME = "event_time"
        private const val COLUMN_EVENT_SEQUENCE = "event_sequence"
        private val KEY_EVENT_LATEST_URI =
            Uri.parse("content://$PROVIDER_AUTHORITY/key_event/latest")
    }
}
