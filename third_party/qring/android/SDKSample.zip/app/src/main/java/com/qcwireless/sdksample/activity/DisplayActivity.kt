package com.qcwireless.sdksample.activity

import android.os.Bundle
import com.oudmon.ble.base.communication.req.BrightnessSettingsReq
import com.oudmon.ble.base.communication.req.DialIndexReq
import com.oudmon.ble.base.communication.req.DisplayClockReq
import com.oudmon.ble.base.communication.req.DisplayOrientationReq
import com.oudmon.ble.base.communication.req.DisplayStyleReq
import com.oudmon.ble.base.communication.req.DisplayTimeReq
import com.oudmon.ble.base.communication.req.PalmScreenReq
import com.qcwireless.sdksample.R
import com.qcwireless.sdksample.databinding.ActivityDisplayBinding

class DisplayActivity : BaseFunctionActivity() {

    private lateinit var binding: ActivityDisplayBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDisplayBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }

    override fun setupViews() {
        super.setupViews()
        binding.titleBar.tvTitle.text = getString(R.string.title_display)
        bindSettingAction(
            binding.fivSetBrightness,
            LOG_TAG,
            "Set Brightness",
            "BrightnessSettingsReq",
            "level=3"
        ) { BrightnessSettingsReq.getWriteInstance(3) }
        bindSettingAction(
            binding.fivGetBrightness,
            LOG_TAG,
            "Get Brightness",
            "BrightnessSettingsReq",
            "read"
        ) { BrightnessSettingsReq.getReadInstance() }
        bindSettingAction(
            binding.fivSetDisplayClock,
            LOG_TAG,
            "Set Display Clock",
            "DisplayClockReq",
            "enable=true"
        ) { DisplayClockReq.getWriteInstance(true) }
        bindSettingAction(
            binding.fivGetDisplayClock,
            LOG_TAG,
            "Get Display Clock",
            "DisplayClockReq",
            "read"
        ) { DisplayClockReq.getReadInstance() }
        bindSettingAction(
            binding.fivSetDisplayOrientation,
            LOG_TAG,
            "Set Display Orientation",
            "DisplayOrientationReq",
            "isPortrait=true, isLeft=true"
        ) { DisplayOrientationReq.getWriteInstance(true, true) }
        bindSettingAction(
            binding.fivGetDisplayOrientation,
            LOG_TAG,
            "Get Display Orientation",
            "DisplayOrientationReq",
            "read"
        ) { DisplayOrientationReq.getReadInstance() }
        bindSettingAction(
            binding.fivSetDisplayStyle,
            LOG_TAG,
            "Set Display Style",
            "DisplayStyleReq",
            "style=0"
        ) { DisplayStyleReq.getWriteInstance(0) }
        bindSettingAction(
            binding.fivGetDisplayStyle,
            LOG_TAG,
            "Get Display Style",
            "DisplayStyleReq",
            "read"
        ) { DisplayStyleReq.getReadInstance() }
        bindSettingAction(
            binding.fivSetDisplayTime,
            LOG_TAG,
            "Set Display Time",
            "DisplayTimeReq",
            "displayTime=1, displayType=0, alpha=100, total=1, curr=0, open=true"
        ) { DisplayTimeReq.getWriteInstanceNew(1, 0, 100, 1, 0, true) }
        bindSettingAction(
            binding.fivGetDisplayTime,
            LOG_TAG,
            "Get Display Time",
            "DisplayTimeReq",
            "read"
        ) { DisplayTimeReq.getReadInstance() }
        bindSettingAction(
            binding.fivSetDialIndex,
            LOG_TAG,
            "Set Dial Index",
            "DialIndexReq",
            "index=0"
        ) { DialIndexReq.getWriteInstance(0) }
        bindSettingAction(
            binding.fivGetDialIndex,
            LOG_TAG,
            "Get Dial Index",
            "DialIndexReq",
            "read"
        ) { DialIndexReq.getReadInstance() }
        bindSettingAction(
            binding.fivSetPalmScreen,
            LOG_TAG,
            "Set Palm Screen",
            "PalmScreenReq",
            "isEnable=true, isLeft=true",
            ::ensureGestureSupported
        ) { PalmScreenReq.getWriteInstance(true, true) }
        bindSettingAction(
            binding.fivGetPalmScreen,
            LOG_TAG,
            "Get Palm Screen",
            "PalmScreenReq",
            "ringRead=true",
            ::ensureGestureSupported
        ) { PalmScreenReq.getRingReadInstance() }
        refreshCachesIfConnected()
    }

    override fun onResume() {
        super.onResume()
        refreshCachesIfConnected()
    }

    companion object {
        private const val LOG_TAG = "Display"
    }
}
