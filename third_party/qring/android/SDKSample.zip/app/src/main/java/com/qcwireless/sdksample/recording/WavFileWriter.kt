package com.qcwireless.sdksample.recording

import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

object WavFileWriter {
    fun writePcmAsWav(
        pcmFile: File,
        wavFile: File,
        sampleRateHz: Int,
        channels: Int,
        bitsPerSample: Int
    ) {
        require(pcmFile.isFile) { "PCM file does not exist: ${pcmFile.absolutePath}" }
        require(sampleRateHz > 0 && channels > 0 && bitsPerSample > 0) {
            "Invalid PCM format"
        }
        wavFile.parentFile?.mkdirs()
        val dataSize = pcmFile.length()
        val blockAlign = channels * bitsPerSample / 8
        BufferedOutputStream(FileOutputStream(wavFile, false)).use { output ->
            output.write("RIFF".toByteArray(Charsets.US_ASCII))
            writeLittleEndianInt(output, (36L + dataSize).toInt())
            output.write("WAVE".toByteArray(Charsets.US_ASCII))
            output.write("fmt ".toByteArray(Charsets.US_ASCII))
            writeLittleEndianInt(output, 16)
            writeLittleEndianShort(output, 1)
            writeLittleEndianShort(output, channels)
            writeLittleEndianInt(output, sampleRateHz)
            writeLittleEndianInt(output, sampleRateHz * blockAlign)
            writeLittleEndianShort(output, blockAlign)
            writeLittleEndianShort(output, bitsPerSample)
            output.write("data".toByteArray(Charsets.US_ASCII))
            writeLittleEndianInt(output, dataSize.toInt())
            BufferedInputStream(FileInputStream(pcmFile)).use { input ->
                val buffer = ByteArray(16 * 1024)
                while (true) {
                    val read = input.read(buffer)
                    if (read <= 0) break
                    output.write(buffer, 0, read)
                }
            }
        }
    }

    private fun writeLittleEndianInt(output: BufferedOutputStream, value: Int) {
        output.write(value and 0xFF)
        output.write(value ushr 8 and 0xFF)
        output.write(value ushr 16 and 0xFF)
        output.write(value ushr 24 and 0xFF)
    }

    private fun writeLittleEndianShort(output: BufferedOutputStream, value: Int) {
        output.write(value and 0xFF)
        output.write(value ushr 8 and 0xFF)
    }
}
