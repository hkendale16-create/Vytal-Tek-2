package com.qcwireless.sdksample.activity

object PressureIntervalOptions {

    fun build(minInterval: Int): IntArray {
        val options = when {
            minInterval <= 5 -> listOf(5, 10, 15, 20)
            minInterval <= 10 -> listOf(10, 15)
            minInterval <= 15 -> listOf(15)
            else -> emptyList()
        } + listOf(20, 30, 60).filter { it >= minInterval }

        return (options.ifEmpty { listOf(minInterval) })
            .distinct()
            .toIntArray()
    }
}
