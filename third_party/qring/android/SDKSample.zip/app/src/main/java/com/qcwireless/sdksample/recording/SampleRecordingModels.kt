package com.qcwireless.sdksample.recording

import com.oudmon.ble.base.recording.RecordingDeviceRecording

data class SampleRecordingFileInfo(
    val deviceFileName: String,
    val absolutePath: String,
    val mimeType: String,
    val sizeBytes: Long,
    val durationMillis: Long,
    val sampleRateHz: Int,
    val channels: Int,
    val bitsPerSample: Int
)

data class SampleRecordingItem(
    val deviceRecording: RecordingDeviceRecording,
    val localFile: SampleRecordingFileInfo?
)
