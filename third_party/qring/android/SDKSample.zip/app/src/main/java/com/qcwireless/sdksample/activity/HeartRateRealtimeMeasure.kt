package com.qcwireless.sdksample.activity

import com.oudmon.ble.base.communication.req.RealTimeHeartRate

object HeartRateRealtimeMeasure {
    const val ACTION_START = 0x01
    const val ACTION_STOP = 0x02
    const val ACTION_CONTINUE = 0x03
    const val CONTINUE_INTERVAL_MS = 2_000L
    const val TIMEOUT_CLOSE_MS = 30_000L

    fun createRequest(type: Int): RealTimeHeartRate {
        return RealTimeHeartRate(type)
    }

    fun isSupported(supportAppMeasure: Boolean): Boolean {
        return supportAppMeasure
    }

    fun getDisplayHeartValue(type: Int, heart: Int): String? {
        return if ((type == ACTION_START || type == ACTION_CONTINUE) && heart > 0) {
            heart.toString()
        } else {
            null
        }
    }
}
