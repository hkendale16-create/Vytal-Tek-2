package com.qcwireless.sdksample.activity

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import com.elvishew.xlog.XLog
import com.oudmon.ble.base.bluetooth.BleOperateManager
import com.oudmon.ble.base.bluetooth.DeviceManager
import com.oudmon.ble.base.communication.ICommandResponse
import com.oudmon.ble.base.communication.LargeDataHandler
import com.oudmon.ble.base.communication.bigData.bean.IntervalHeartRateEntity
import com.oudmon.ble.base.communication.bigData.resp.IIntervalHeartRateCallback
import com.oudmon.ble.base.communication.req.HeartRateSettingReq
import com.oudmon.ble.base.communication.req.ReadHeartRateReq
import com.oudmon.ble.base.communication.req.SugarLipidsSettingReq
import com.oudmon.ble.base.communication.rsp.BaseRspCmd
import com.oudmon.ble.base.communication.rsp.BloodSugarLipidsSettingRsp
import com.oudmon.ble.base.communication.rsp.HeartRateSettingRsp
import com.oudmon.ble.base.communication.rsp.ReadHeartRateRsp
import com.oudmon.ble.base.communication.rsp.RealTimeHeartRateRsp
import com.oudmon.ble.base.communication.rsp.StartHeartRateRsp
import com.oudmon.ble.base.communication.rsp.StopHeartRateRsp
import com.qcwireless.sdksample.R
import com.qcwireless.sdksample.annotation.BleIsConnected
import com.qcwireless.sdksample.databinding.ActivityHeartRateBinding
import com.qcwireless.sdksample.ext.showToast
import com.qcwireless.sdksample.log.BluetoothLogManager
import java.lang.reflect.Modifier
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class HeartRateActivity : BaseFunctionActivity() {
    private lateinit var binding: ActivityHeartRateBinding
    private lateinit var rriBlockAdapter: ArrayAdapter<String>
    private var lastHeartRateSetting: HeartRateSettingRsp? = null
    private val rriBlocks = mutableListOf<LargeDataHandler.RriBlockDescription>()
    private var selectedRriBlockId: Int? = null
    private val realtimeHeartRateHandler = Handler(Looper.getMainLooper())
    private var realtimeHeartRateRequested = false
    private val realtimeHeartRateContinueRunnable = Runnable {
        continueRealtimeHeartRateFromHandler()
    }
    private val realtimeHeartRateTimeoutRunnable = Runnable {
        closeRealtimeHeartRateSession(clearRequested = true, showToast = false, reason = "timeout")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHeartRateBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }

    override fun onResume() {
        super.onResume()
        if (::binding.isInitialized && realtimeHeartRateRequested) {
            resumeRealtimeHeartRateSession()
        }
    }

    override fun onPause() {
        if (::binding.isInitialized && realtimeHeartRateRequested) {
            closeRealtimeHeartRateSession(clearRequested = false, showToast = false, reason = "pause")
        }
        super.onPause()
    }

    override fun onDestroy() {
        realtimeHeartRateHandler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    override fun setupViews() {
        super.setupViews()
        binding.titleBar.tvTitle.text = getString(R.string.qc_text_0041)
        setupRriBlockSpinner()

        binding.fivHeartRateSettingRead.setOnClickListener {
            readHeartRateSetting()
        }

        binding.fivHeartRateSettingWrite.setOnClickListener {
            writeHeartRateSetting(true)
        }

        binding.fivHeartRateSettingOpen.setOnClickListener {
            writeHeartRateSetting(true)
        }

        binding.fivHeartRateSettingClose.setOnClickListener {
            writeHeartRateSetting(false)
        }

        binding.fivStartHeartRatePpg.setOnClickListener {
            startHeartRatePpg()
        }

        binding.fivStopHeartRatePpg.setOnClickListener {
            stopHeartRatePpg()
        }

        binding.fivRriOpen.setOnClickListener {
            setRriAutoMeasure(true)
        }

        binding.fivRriClose.setOnClickListener {
            setRriAutoMeasure(false)
        }

        binding.fivRriBlockIndex.setOnClickListener {
            syncRriBlockList()
        }

        binding.fivRriBlock.setOnClickListener {
            syncSelectedRriBlock()
        }

        bindHealthQueryActions<ReadHeartRateRsp>(
            todayView = binding.fivTodayData,
            singleDayView = binding.fivSingleDayData,
            rangeView = binding.fivRangeData,
            title = getString(R.string.qc_text_0041),
            todayAction = { callback ->
                BleOperateManager.getInstance().getTodayHeartRate(callback)
            },
            singleDayAction = { dayIndex, callback ->
                BleOperateManager.getInstance().getHeartRate(dayIndex, callback)
            },
            rangeAction = { startDayIndex, count, callback ->
                BleOperateManager.getInstance().getHeartRates(startDayIndex, count, callback)
            }
        )

        binding.fivStartMeasureOnce.setOnClickListener {
            startManualHeartRate()
        }

        binding.fivStopMeasureOnce.setOnClickListener {
            stopManualHeartRate()
        }

        binding.fivStartRealtimeHeartRate.setOnClickListener {
            startRealtimeHeartRateSession()
        }

        binding.fivStopRealtimeHeartRate.setOnClickListener {
            closeRealtimeHeartRateSession(clearRequested = true, showToast = true, reason = "button")
        }

        binding.fivContinueRealtimeHeartRate.setOnClickListener {
            continueRealtimeHeartRateSession(showToast = true)
        }


        refreshSupportCache()
        readHeartRateSetting()
    }

    private fun setupRriBlockSpinner() {
        rriBlockAdapter = createRriBlockAdapter(listOf(getString(R.string.rri_no_block)))
        binding.spinnerRriBlockIndex.adapter = rriBlockAdapter
        binding.spinnerRriBlockIndex.isEnabled = false
        binding.spinnerRriBlockIndex.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedRriBlockId = rriBlocks.getOrNull(position)?.blockId
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                selectedRriBlockId = null
            }
        }
    }

    @BleIsConnected
    private fun readHeartRateSetting() {
        commandHandle.executeReqCmd(
            HeartRateSettingReq.getReadInstance(),
            ICommandResponse<HeartRateSettingRsp> { rsp ->
                val success = rsp.status == BaseRspCmd.RESULT_OK
                logHeartRateSettingRsp("readHeartRateSetting", success, rsp)
                if (success) {
                    lastHeartRateSetting = rsp
                    getString(R.string.qc_text_0046).showToast()
                }
            }
        )
    }
    @BleIsConnected
    private fun writeHeartRateSetting(enable: Boolean) {
        val req = HeartRateSettingReq.getWriteInstance(enable, 10, 10, 40, 110)
        commandHandle.executeReqCmd(
            req,
            ICommandResponse<HeartRateSettingRsp> { rsp ->
                val success = rsp.status == BaseRspCmd.RESULT_OK
                logHeartRateSettingRsp("writeHeartRateSetting", success, rsp)
                if (success) {
                    lastHeartRateSetting = rsp
                    getString(R.string.qc_text_0047).showToast()
                }
            }
        )
    }

    @BleIsConnected
    private fun setRriAutoMeasure(enable: Boolean) {
        val actionName = getString(if (enable) R.string.rri_open else R.string.rri_close)
        logRriDetail(
            "[REQ]\naction=$actionName request=SugarLipidsSettingReq.getWriteRriInstance enable=$enable"
        )
        commandHandle.executeReqCmd(
            SugarLipidsSettingReq.getWriteRriInstance(enable),
            ICommandResponse<BloodSugarLipidsSettingRsp> { rsp ->
                val success = rsp.status == BaseRspCmd.RESULT_OK
                logRriSettingRsp(actionName, success, rsp)
                if (success) {
                    "$actionName success".showToast()
                } else {
                    "$actionName fail".showToast()
                }
            }
        )
    }

    @BleIsConnected
    private fun syncRriBlockList() {
        val deviceAddress = getCurrentDeviceAddress()
        val actionName = getString(R.string.rri_block_index)
        logRriDetail(
            "[REQ]\naction=$actionName request=LargeDataHandler.syncRriBlockList deviceAddress=$deviceAddress"
        )
        LargeDataHandler.getInstance().syncRriBlockList(
            deviceAddress,
            object : LargeDataHandler.IRriBlockListCallback {
                override fun onRriBlockList(blockList: MutableList<LargeDataHandler.RriBlockDescription>?) {
                    Log.d("RRITTest", "syncRriBlockList successs")
                    runOnUiThread {
                        val allBlocks = blockList.orEmpty()
                        val validBlocks = allBlocks.filter { it.isValidRriBlock() }
                        updateRriBlockList(validBlocks)
                        logRriBlockList(actionName, allBlocks, validBlocks.size)
                        if (validBlocks.isEmpty()) {
                            getString(R.string.rri_block_index_no_valid_data).showToast()
                        } else {
                            getString(R.string.rri_block_list_synced, validBlocks.size).showToast()
                        }
                    }
                }
            }
        )
    }

    @BleIsConnected
    private fun syncSelectedRriBlock() {
        val blockId = selectedRriBlockId
        if (blockId == null) {
            getString(R.string.rri_select_block_first).showToast()
            logRriDetail("[WARN]\naction=${getString(R.string.rri_block)} message=no selected RRI block")
            return
        }

        val deviceAddress = getCurrentDeviceAddress()
        val actionName = getString(R.string.rri_block)
        logRriDetail(
            "[REQ]\naction=$actionName request=LargeDataHandler.syncRriBlock deviceAddress=$deviceAddress blockId=$blockId"
        )
        LargeDataHandler.getInstance().syncRriBlock(
            deviceAddress,
            blockId,
            object : LargeDataHandler.IRriBlockSyncCallback {
                override fun onRriBlockProgress(blockId: Int, current: Int, total: Int) {
                    runOnUiThread {
                        logRriBlockProgress(actionName, blockId, current, total)
                    }
                }

                override fun onRriBlockData(
                    blockId: Int,
                    rawBytes: ByteArray?,
                    minuteData: MutableList<LargeDataHandler.RriMinuteData>?
                ) {
                    runOnUiThread {
                        logRriBlockData(actionName, blockId, rawBytes, minuteData.orEmpty())
                    }
                }
            }
        )
        getString(R.string.rri_block_sync_started).showToast()
    }

    @BleIsConnected
    private fun startHeartRatePpg() {
        BleOperateManager.getInstance().manualModeHeartRateRawData(
            ICommandResponse<StopHeartRateRsp> { rsp ->
                logHeartRatePpgDetail(rsp)
            },
            HEART_RATE_PPG_INTERVAL,
            false
        )
        (getString(R.string.heart_rate_ppg_start) + getString(R.string.qc_text_0053)).showToast()
    }

    @BleIsConnected
    private fun stopHeartRatePpg() {
        BleOperateManager.getInstance().manualModeHeartRateRawData(
            ICommandResponse<StopHeartRateRsp> { rsp ->
                if (rsp.status == BaseRspCmd.RESULT_OK) {
                    (getString(R.string.heart_rate_ppg_stop) + getString(R.string.qc_text_0053)).showToast()
                } else {
                    (getString(R.string.heart_rate_ppg_stop) + getString(R.string.qc_text_0054)).showToast()
                }
            },
            HEART_RATE_PPG_INTERVAL,
            true
        )
    }

    @BleIsConnected
    private fun startManualHeartRate() {
        BleOperateManager.getInstance().manualModeHeart(
            ICommandResponse<StartHeartRateRsp> { rsp ->
                if (rsp.status == BaseRspCmd.RESULT_OK) {
                    val value = if (rsp.getHeartRate() > 0) {
                        rsp.getHeartRate()
                    } else {
                        rsp.getValue()
                    }
                    getString(R.string.qc_text_0051, value.toString()).showToast()
                }
            },
            false
        )
    }

    @BleIsConnected()
    private fun stopManualHeartRate() {
        BleOperateManager.getInstance().manualModeHeart(
            ICommandResponse<StartHeartRateRsp> { rsp ->
                if (rsp.status == BaseRspCmd.RESULT_OK) {
                    (getString(R.string.qc_text_0052) + getString(R.string.qc_text_0053)).showToast()
                } else {
                    (getString(R.string.qc_text_0052) + getString(R.string.qc_text_0054)).showToast()
                }
            },
            true
        )
    }

    @BleIsConnected
    private fun startRealtimeHeartRateSession() {
        if (!isRealtimeHeartRateSupported()) {
            return
        }

        realtimeHeartRateRequested = true
        binding.tvCurrHeart.text = getString(R.string.realtime_heart_rate_current_placeholder)
        scheduleRealtimeHeartRateTimeout()
        sendRealtimeHeartRate(HeartRateRealtimeMeasure.ACTION_START, showToast = true)
    }

    @BleIsConnected
    private fun continueRealtimeHeartRateSession(showToast: Boolean) {
        if (!isRealtimeHeartRateSupported()) {
            return
        }

        realtimeHeartRateRequested = true
        scheduleRealtimeHeartRateTimeout()
        sendRealtimeHeartRate(HeartRateRealtimeMeasure.ACTION_CONTINUE, showToast)
    }

    private fun resumeRealtimeHeartRateSession() {
        if (!isRealtimeHeartRateSupported()) {
            realtimeHeartRateRequested = false
            return
        }

        scheduleRealtimeHeartRateTimeout()
        sendRealtimeHeartRate(HeartRateRealtimeMeasure.ACTION_START, showToast = false)
    }

    private fun continueRealtimeHeartRateFromHandler() {
        if (!realtimeHeartRateRequested) {
            return
        }
        if (!isRealtimeHeartRateSupported()) {
            realtimeHeartRateRequested = false
            return
        }

        sendRealtimeHeartRate(HeartRateRealtimeMeasure.ACTION_CONTINUE, showToast = false)
    }

    private fun closeRealtimeHeartRateSession(
        clearRequested: Boolean,
        showToast: Boolean,
        reason: String
    ) {
        if (clearRequested) {
            realtimeHeartRateRequested = false
        }
        realtimeHeartRateHandler.removeCallbacks(realtimeHeartRateContinueRunnable)
        realtimeHeartRateHandler.removeCallbacks(realtimeHeartRateTimeoutRunnable)
        sendRealtimeHeartRateStop(showToast, reason)
    }

    private fun scheduleRealtimeHeartRateContinue(delayMs: Long = HeartRateRealtimeMeasure.CONTINUE_INTERVAL_MS) {
        realtimeHeartRateHandler.removeCallbacks(realtimeHeartRateContinueRunnable)
        if (realtimeHeartRateRequested) {
            realtimeHeartRateHandler.postDelayed(realtimeHeartRateContinueRunnable, delayMs)
        }
    }

    private fun scheduleRealtimeHeartRateTimeout() {
        realtimeHeartRateHandler.removeCallbacks(realtimeHeartRateTimeoutRunnable)
        if (realtimeHeartRateRequested) {
            realtimeHeartRateHandler.postDelayed(
                realtimeHeartRateTimeoutRunnable,
                HeartRateRealtimeMeasure.TIMEOUT_CLOSE_MS
            )
        }
    }

    private fun cancelRealtimeHeartRateTimeout() {
        realtimeHeartRateHandler.removeCallbacks(realtimeHeartRateTimeoutRunnable)
    }

    private fun sendRealtimeHeartRate(type: Int, showToast: Boolean) {
        val actionName = getRealtimeHeartRateActionName(type)
        logRealtimeHeartRateDetail(
            "[REQ]\naction=$actionName request=RealTimeHeartRate type=${formatRealtimeHeartRateType(type)}"
        )
        commandHandle.executeReqCmd(
            HeartRateRealtimeMeasure.createRequest(type),
            ICommandResponse<RealTimeHeartRateRsp> { rsp ->
                val success = rsp.status == BaseRspCmd.RESULT_OK
                logRealtimeHeartRateRsp(actionName, type, success, rsp)
                if (success) {
                    scheduleRealtimeHeartRateContinueAfterSuccess(type)
                } else {
                    stopRealtimeHeartRateAfterFailure(type)
                }
                val displayHeartValue = HeartRateRealtimeMeasure.getDisplayHeartValue(type, rsp.getHeart())
                if (displayHeartValue != null) {
                    cancelRealtimeHeartRateTimeout()
                    runOnUiThread {
                        // Same as QRing_004 HeartActivity: RealTimeHeartRate(1/3) returns the current heart value in rsp.heart.
                        binding.tvCurrHeart.text = displayHeartValue
                    }
                }
                if (showToast && success) {
                    (actionName + getString(R.string.qc_text_0053)).showToast()
                } else if (showToast) {
                    (actionName + getString(R.string.qc_text_0054)).showToast()
                }
            }
        )
    }

    private fun scheduleRealtimeHeartRateContinueAfterSuccess(type: Int) {
        if (type == HeartRateRealtimeMeasure.ACTION_START || type == HeartRateRealtimeMeasure.ACTION_CONTINUE) {
            scheduleRealtimeHeartRateContinue()
        }
    }

    private fun stopRealtimeHeartRateAfterFailure(type: Int) {
        if (type == HeartRateRealtimeMeasure.ACTION_START || type == HeartRateRealtimeMeasure.ACTION_CONTINUE) {
            realtimeHeartRateRequested = false
            realtimeHeartRateHandler.removeCallbacks(realtimeHeartRateContinueRunnable)
            realtimeHeartRateHandler.removeCallbacks(realtimeHeartRateTimeoutRunnable)
        }
    }

    private fun sendRealtimeHeartRateStop(showToast: Boolean, reason: String) {
        if (!BleOperateManager.getInstance().isConnected) {
            return
        }

        val actionName = getRealtimeHeartRateActionName(HeartRateRealtimeMeasure.ACTION_STOP)
        logRealtimeHeartRateDetail(
            "[REQ]\naction=$actionName reason=$reason request=RealTimeHeartRate type=${formatRealtimeHeartRateType(HeartRateRealtimeMeasure.ACTION_STOP)}"
        )
        commandHandle.executeReqCmdNoCallback(
            HeartRateRealtimeMeasure.createRequest(HeartRateRealtimeMeasure.ACTION_STOP)
        )
        if (showToast) {
            (actionName + getString(R.string.qc_text_0053)).showToast()
        }
    }

    private fun isRealtimeHeartRateSupported(): Boolean {
        val supported = HeartRateRealtimeMeasure.isSupported(setTimeCache.supportAppMeasure)
        XLog.tag("HeartRateSupport").d("realtimeHeartRate supportAppMeasure=$supported")
        return ensureSupported(supported)
    }

    private fun getNowUtcSeconds(): Long {
        val offsetSeconds = TimeZone.getDefault().getOffset(System.currentTimeMillis()) / 1000L
        return System.currentTimeMillis() / 1000L + offsetSeconds
    }

    private fun logHeartRateSyncDetail(scope: String, data: Any?) {
        val detail = HealthDataQueryLogFormatter.formatSuccess(
            title = getString(R.string.qc_text_0041),
            scope = scope,
            data = data
        )
        XLog.tag(SYNC_LOG_TAG).d(detail)
        BluetoothLogManager.addExternalLog(detail)
    }

    private fun logHeartRateSettingRsp(
        actionName: String,
        success: Boolean,
        rsp: HeartRateSettingRsp
    ) {
        val detail = buildString {
            append("[RSP]\n")
            append("action=").append(actionName)
            append(" success=").append(success)
            append(" status=").append(rsp.status)
            append(" enable=").append(rsp.isEnable())
            append(" interval=").append(rsp.getStartInterval())
            append(" low=").append(rsp.getTooLowReminder())
            append(" high=").append(rsp.getTooHighReminder())
            append(" main=").append(rsp.getMainSwitch())
        }
        logBlePanelDetail(HEART_RATE_SETTING_LOG_TAG, detail)
    }

    private fun updateRriBlockList(blocks: List<LargeDataHandler.RriBlockDescription>) {
        rriBlocks.clear()
        rriBlocks.addAll(blocks)
        selectedRriBlockId = blocks.firstOrNull()?.blockId
        val options = if (blocks.isEmpty()) {
            listOf(getString(R.string.rri_no_block))
        } else {
            blocks.map { formatRriBlockOption(it) }
        }
        rriBlockAdapter = createRriBlockAdapter(options)
        binding.spinnerRriBlockIndex.adapter = rriBlockAdapter
        binding.spinnerRriBlockIndex.isEnabled = blocks.isNotEmpty()
        binding.spinnerRriBlockIndex.setSelection(0, false)
    }

    private fun createRriBlockAdapter(options: List<String>): ArrayAdapter<String> {
        return ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            options.toMutableList()
        ).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
    }

    private fun logRriSettingRsp(
        actionName: String,
        success: Boolean,
        rsp: BloodSugarLipidsSettingRsp
    ) {
        val detail = buildString {
            append("[RSP]\n")
            append("action=").append(actionName)
            append(" success=").append(success)
            append(" status=").append(rsp.status)
            append(" type=").append(rsp.type)
            append(" enable=").append(rsp.isEnable())
            append(" value=").append(rsp.value)
            append(" startInterval=").append(rsp.startInterval)
            append(" interval=").append(rsp.interval)
            append(" isRead=").append(rsp.isRead)
            append(" rriAutoMeasureEnable=").append(rsp.isRriAutoMeasureEnable())
            append(" toString=").append(rsp.toString())
            append('\n')
            appendRriObjectDump("result", rsp)
        }
        logRriDetail(detail)
    }

    private fun logRriBlockProgress(
        actionName: String,
        blockId: Int,
        current: Int,
        total: Int
    ) {
        val detail = buildString {
            append("[PROGRESS]\n")
            append("action=").append(actionName)
            append(" blockId=").append(blockId)
            append(" current=").append(current)
            append(" total=").append(total)
            append('\n')
            append("result.blockId=").append(blockId)
            append('\n')
            append("result.current=").append(current)
            append('\n')
            append("result.total=").append(total)
        }
        logRriDetail(detail)
    }

    private fun logRriBlockList(
        actionName: String,
        blocks: List<LargeDataHandler.RriBlockDescription>,
        validCount: Int
    ) {
        val detail = buildString {
            append("[RSP]\n")
            append("action=").append(actionName)
            append(" count=").append(blocks.size)
            append(" validCount=").append(validCount)
            blocks.forEachIndexed { index, block ->
                append('\n')
                append("block[").append(index).append("].valid=").append(block.isValidRriBlock())
                append('\n')
                appendRriObjectDump("block[$index]", block)
            }
        }
        logRriDetail(detail)
    }

    private fun LargeDataHandler.RriBlockDescription.isValidRriBlock(): Boolean {
        return blockId >= 0 && endMinuteSec >= startMinuteSec
    }

    private fun logRriBlockData(
        actionName: String,
        blockId: Int,
        rawBytes: ByteArray?,
        minuteData: List<LargeDataHandler.RriMinuteData>
    ) {
        val detail = buildString {
            append("[RSP]\n")
            append("action=").append(actionName)
            append(" blockId=").append(blockId)
            append(" rawBytes=").append(rawBytes?.size ?: 0)
            append(" rawHex=").append(rawBytes?.toHexString().orEmpty())
            append(" minuteCount=").append(minuteData.size)
            append('\n')
            append("result.blockId=").append(blockId)
            append('\n')
            append("result.rawBytes.length=").append(rawBytes?.size ?: 0)
            append('\n')
            append("result.rawBytes.hex=").append(rawBytes?.toHexString().orEmpty())
            minuteData.forEachIndexed { index, minute ->
                append('\n')
                appendRriObjectDump("minuteData[$index]", minute)
            }
        }
        logRriDetail(detail)
    }

    private fun formatRriBlockOption(block: LargeDataHandler.RriBlockDescription): String {
        return "Block ${block.blockId} ${formatRriSpinnerTimestamp(block.startMinuteSec)} - ${formatRriSpinnerTimestamp(block.endMinuteSec)}"
    }

    private fun formatRriTimestamp(minuteSec: Long): String {
        return SimpleDateFormat(RRI_TIME_PATTERN, Locale.getDefault()).format(Date(minuteSec * 1000L))
    }

    private fun formatRriSpinnerTimestamp(minuteSec: Long): String {
        return SimpleDateFormat(RRI_SPINNER_TIME_PATTERN, Locale.getDefault()).format(Date(minuteSec * 1000L))
    }

    private fun getCurrentDeviceAddress(): String {
        return DeviceManager.getInstance().deviceAddress.orEmpty()
    }

    private fun logRriDetail(detail: String) {
        detail.chunked(LOGCAT_CHUNK_SIZE).forEach { chunk ->
            Log.d(RRI_LOG_TAG, chunk)
        }
        XLog.tag(RRI_LOG_TAG).d(detail)
        BluetoothLogManager.addExternalLog(detail)
    }

    private fun StringBuilder.appendRriObjectDump(label: String, value: Any?) {
        append(label).append(".class=").append(value?.javaClass?.name ?: "null")
        append('\n')
        if (value == null) {
            return
        }
        append(label).append(".toString=").append(sanitizeRriLogValue(value.toString()))
        append('\n')
        if (value is ByteArray) {
            append(label).append(".length=").append(value.size)
            append('\n')
            append(label).append(".hex=").append(value.toHexString())
            return
        }
        if (value is Collection<*>) {
            append(label).append(".size=").append(value.size)
            value.forEachIndexed { index, item ->
                append('\n')
                appendRriObjectDump("$label[$index]", item)
            }
            return
        }
        collectRriFields(value.javaClass).forEach { field ->
            val fieldValue = runCatching {
                field.isAccessible = true
                field.get(value)
            }.getOrElse { throwable -> "<field-error:${throwable.javaClass.simpleName}>" }
            append(label)
                .append(".field.")
                .append(field.declaringClass.simpleName)
                .append('.')
                .append(field.name)
                .append('=')
                .append(formatRriDumpValue(field.name, fieldValue))
            append('\n')
        }
        collectRriGetters(value.javaClass).forEach { method ->
            val methodValue = runCatching {
                method.isAccessible = true
                method.invoke(value)
            }.getOrElse { throwable -> "<getter-error:${throwable.javaClass.simpleName}>" }
            append(label)
                .append(".getter.")
                .append(method.name)
                .append('=')
                .append(formatRriDumpValue(method.name, methodValue))
            append('\n')
        }
    }

    private fun collectRriFields(clazz: Class<*>): List<java.lang.reflect.Field> {
        val fields = mutableListOf<java.lang.reflect.Field>()
        var current: Class<*>? = clazz
        while (current != null && current != Any::class.java) {
            current.declaredFields
                .filter { field ->
                    !field.isSynthetic && !Modifier.isStatic(field.modifiers)
                }
                .forEach { fields.add(it) }
            current = current.superclass
        }
        return fields
    }

    private fun collectRriGetters(clazz: Class<*>): List<java.lang.reflect.Method> {
        return clazz.methods
            .filter { method ->
                method.parameterTypes.isEmpty() &&
                    method.returnType != Void.TYPE &&
                    method.declaringClass != Any::class.java &&
                    method.declaringClass != Object::class.java &&
                    !method.isSynthetic &&
                    !method.isBridge &&
                    !Modifier.isStatic(method.modifiers) &&
                    (method.name.startsWith("get") || method.name.startsWith("is"))
            }
            .sortedBy { it.name }
    }

    private fun formatRriDumpValue(name: String, value: Any?): String {
        return when (value) {
            null -> "null"
            is ByteArray -> "ByteArray(length=${value.size}, hex=${value.toHexString()})"
            is Collection<*> -> "Collection(size=${value.size}, values=${sanitizeRriLogValue(value.toString())})"
            is Array<*> -> "Array(size=${value.size}, values=${sanitizeRriLogValue(value.contentToString())})"
            is Number -> formatRriNumberDumpValue(name, value)
            else -> sanitizeRriLogValue(value.toString())
        }
    }

    private fun formatRriNumberDumpValue(name: String, value: Number): String {
        val rawValue = value.toLong()
        return if (isRriTimestampName(name)) {
            "$rawValue (${formatRriEpochTimestamp(rawValue)})"
        } else {
            sanitizeRriLogValue(value.toString())
        }
    }

    private fun isRriTimestampName(name: String): Boolean {
        val normalized = name.lowercase(Locale.US)
        return normalized.contains("timestamp") ||
            normalized.contains("time") ||
            normalized.endsWith("sec")
    }

    private fun formatRriEpochTimestamp(value: Long): String {
        val millis = if (value > EPOCH_MILLIS_THRESHOLD) {
            value
        } else {
            value * 1000L
        }
        return SimpleDateFormat(RRI_TIME_PATTERN, Locale.getDefault()).format(Date(millis))
    }

    private fun sanitizeRriLogValue(value: String): String {
        return value
            .replace("\r", "\\r")
            .replace("\n", "\\n")
            .replace("\t", "\\t")
    }

    private fun ByteArray.toHexString(): String {
        return joinToString(separator = " ") { byte ->
            "%02X".format(byte.toInt() and 0xFF)
        }
    }

    private fun logHeartRatePpgDetail(rsp: StopHeartRateRsp) {
        val detail = buildString {
            append(getString(R.string.text_38))
            append(" status=").append(rsp.status)
            append(" cmdType=").append(rsp.cmdType)
            append(" type=").append(rsp.type)
            append(" errCode=").append(rsp.errCode)
            append(" ppgCount=").append(rsp.getPpgCount())
            append(" greenLightPpgL=").append(rsp.getGreenLightPpgL())
            append(" greenLightPpgH=").append(rsp.getGreenLightPpgH())
            append(" greenLightPpg=").append(rsp.greenLightPpg)
            append(" xL=").append(rsp.getXL())
            append(" xH=").append(rsp.getXH())
            append(" yL=").append(rsp.getYL())
            append(" yH=").append(rsp.getYH())
            append(" zL=").append(rsp.getZL())
            append(" zH=").append(rsp.getZH())
            append(" heartRate=").append(rsp.getHeartRate())
            append(" value=").append(rsp.value)
            append(" rri=").append(rsp.rri)
        }
        XLog.tag(PPG_LOG_TAG).d(detail)
        BluetoothLogManager.addExternalLog(detail)
    }

    private fun getRealtimeHeartRateActionName(type: Int): String {
        val stringRes = when (type) {
            HeartRateRealtimeMeasure.ACTION_START -> R.string.realtime_heart_rate_start
            HeartRateRealtimeMeasure.ACTION_STOP -> R.string.realtime_heart_rate_stop
            HeartRateRealtimeMeasure.ACTION_CONTINUE -> R.string.realtime_heart_rate_continue
            else -> R.string.realtime_heart_rate_unknown
        }
        return getString(stringRes)
    }

    private fun logRealtimeHeartRateRsp(
        actionName: String,
        type: Int,
        success: Boolean,
        rsp: RealTimeHeartRateRsp
    ) {
        val detail = buildString {
            append("[RSP]\n")
            append("action=").append(actionName)
            append(" success=").append(success)
            append(" status=").append(rsp.status)
            append(" type=").append(formatRealtimeHeartRateType(type))
            append(" heart=").append(rsp.getHeart())
        }
        logRealtimeHeartRateDetail(detail)
    }

    private fun logRealtimeHeartRateDetail(detail: String) {
        XLog.tag(REALTIME_HEART_RATE_LOG_TAG).d(detail)
        BluetoothLogManager.addExternalLog(detail)
    }

    private fun formatRealtimeHeartRateType(type: Int): String {
        return "0x%02X".format(Locale.US, type)
    }

    companion object {
        private const val HEART_RATE_SETTING_LOG_TAG = "HeartRateSetting"
        private const val SYNC_LOG_TAG = "HeartRateSync"
        private const val PPG_LOG_TAG = "HeartRatePpg"
        private const val RRI_LOG_TAG = "HeartRateRri"
        private const val REALTIME_HEART_RATE_LOG_TAG = "RealTimeHeartRate"
        private const val RRI_TIME_PATTERN = "yyyy-MM-dd HH:mm:ss"
        private const val RRI_SPINNER_TIME_PATTERN = "yyyy-MM-dd HH:mm"
        private const val EPOCH_MILLIS_THRESHOLD = 10_000_000_000L
        private const val LOGCAT_CHUNK_SIZE = 3500
        private const val HEART_RATE_PPG_INTERVAL = 30
        private const val MANUAL_HEART_PPG_DURATION_SECONDS = 30
    }
}
