package com.qcwireless.sdksample.activity

import android.os.Bundle
import com.elvishew.xlog.XLog
import com.oudmon.ble.base.bluetooth.BleOperateManager
import com.oudmon.ble.base.communication.ICommandResponse
import com.oudmon.ble.base.communication.entity.StartEndTimeEntity
import com.oudmon.ble.base.communication.req.BpSettingReq
import com.oudmon.ble.base.communication.req.SimpleKeyReq
import com.oudmon.ble.base.communication.rsp.BaseRspCmd
import com.oudmon.ble.base.communication.rsp.PressureRsp
import com.oudmon.ble.base.communication.rsp.StartHeartRateRsp
import com.oudmon.ble.base.communication.Constants
import com.qcwireless.sdksample.R
import com.qcwireless.sdksample.annotation.BleIsConnected
import com.qcwireless.sdksample.databinding.ActivityBloodPressureBinding
import com.qcwireless.sdksample.ext.showToast

class BloodPressureActivity : BaseFunctionActivity() {
    private lateinit var binding: ActivityBloodPressureBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBloodPressureBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }

    override fun setupViews() {
        super.setupViews()
        binding.titleBar.tvTitle.text = getString(R.string.qc_text_0061)
        binding.fivSettingRead.setOnClickListener { readBloodPressureSetting() }
        binding.fivSettingWrite.setOnClickListener { writeBloodPressureSetting(true) }
        binding.fivSettingOpen.setOnClickListener { writeBloodPressureSetting(true) }
        binding.fivSettingClose.setOnClickListener { writeBloodPressureSetting(false) }
        bindHealthQueryActions<PressureRsp>(
            todayView = binding.fivTodayData,
            singleDayView = binding.fivSingleDayData,
            rangeView = binding.fivRangeData,
            title = getString(R.string.qc_text_0061),
            supportCheck = { isPressureDataSupported() },
            todayAction = { callback ->
                BleOperateManager.getInstance().getTodayPressure(callback)
            },
            singleDayAction = { dayIndex, callback ->
                BleOperateManager.getInstance().getPressure(dayIndex, callback)
            },
            rangeAction = { startDayIndex, count, callback ->
                BleOperateManager.getInstance().getPressures(startDayIndex, count, callback)
            }
        )
        binding.fivStartMeasure.setOnClickListener { startBloodPressureMeasure() }
        binding.fivStopMeasure.setOnClickListener { stopBloodPressureMeasure() }
        refreshSupportCache()
    }

    private fun isBloodPressureSupported(): Boolean {
        return ensureSupported(setTimeCache.supportBloodPressure)
    }

    private fun isPressureDataSupported(): Boolean {
        return ensureSupported(setTimeCache.supportPressure)
    }

    @BleIsConnected
    private fun readBloodPressureSetting() {
        if (!ensureBloodPressureSettingSupported()) {
            return
        }
        executeSettingAction(
            LOG_TAG,
            "Get BP Setting",
            "BpSettingReq",
            "read",
            BpSettingReq.getReadInstance()
        )
    }

    @BleIsConnected
    private fun writeBloodPressureSetting(enable: Boolean) {
        if (!ensureBloodPressureSettingSupported()) {
            return
        }
        executeSettingAction(
            LOG_TAG,
            "Set BP Setting",
            "BpSettingReq",
            "enable=$enable, start=09:00, end=18:00, multiple=60",
            BpSettingReq.getWriteInstance(enable, StartEndTimeEntity(9, 0, 18, 0), 60)
        )
    }

    @BleIsConnected
    private fun startBloodPressureMeasure() {
        if (!isBloodPressureSupported()) {
            return
        }
        BleOperateManager.getInstance().manualModeBP(
            ICommandResponse<StartHeartRateRsp> { rsp ->
                if (rsp.status == BaseRspCmd.RESULT_OK) {
                    val sbp = rsp.getSbp()
                    val dbp = rsp.getDbp()
                    getString(R.string.qc_text_0078, sbp.toString(), dbp.toString()).showToast()
                }
            },
            false
        )
    }

    @BleIsConnected
    private fun stopBloodPressureMeasure() {
        if (!isBloodPressureSupported()) {
            return
        }
        BleOperateManager.getInstance().manualModeBP(
            ICommandResponse<StartHeartRateRsp> { rsp ->
                if (rsp.status == BaseRspCmd.RESULT_OK) {
                    (getString(R.string.qc_text_0077) + getString(R.string.qc_text_0053)).showToast()
                } else {
                    (getString(R.string.qc_text_0077) + getString(R.string.qc_text_0054)).showToast()
                }
            },
            true
        )
    }

    companion object {
        private const val LOG_TAG = "BloodPressureSetting"
    }
}
