package com.qcwireless.sdksample.activity

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import com.elvishew.xlog.XLog
import com.oudmon.ble.base.communication.file.FileHandle
import com.oudmon.ble.base.communication.file.SimpleCallback
import com.qcwireless.sdksample.R
import com.qcwireless.sdksample.databinding.ActivityResourceUpdateBinding
import com.qcwireless.sdksample.ext.showToast
import com.qcwireless.sdksample.log.BluetoothLogManager
import com.qcwireless.sdksample.utils.GetFilePathFromUri
import java.io.File

class ResourceUpdateActivity : BaseActivity() {

    private lateinit var binding: ActivityResourceUpdateBinding
    private val fileHandle = FileHandle.getInstance()
    private var path = ""
    private var fileNamesCallback: SimpleCallback? = null
    private var updateCallback: SimpleCallback? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityResourceUpdateBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }

    override fun setupViews() {
        super.setupViews()
        binding.titleBar.tvTitle.text = getString(R.string.qc_text_resource_update)
        binding.tvProgress.text = getString(R.string.qc_text_0032, "0")
        binding.selectFilePath.text = getString(R.string.qc_text_0033, "")

        binding.getResourceNames.setOnClickListener {
            getResourceNames()
        }
        binding.selectFile.setOnClickListener {
            selectResourceFile()
        }
        binding.startUpdate.setOnClickListener {
            startResourceUpdate()
        }
    }

    private fun getResourceNames() {
        removeFileNamesCallback()
        val callback = object : SimpleCallback() {
            override fun onFileNames(fileNames: ArrayList<String>) {
                val names = fileNames.joinToString()
                logResource(getString(R.string.resource_update_file_names, names))
                runOnUiThread {
                    removeFileNamesCallback()
                }
            }

            override fun onActionResult(type: Int, errCode: Int) {
                if (errCode != 0) {
                    logResource(getString(R.string.resource_update_action_failed, type, errCode))
                    runOnUiThread {
                        removeFileNamesCallback()
                    }
                }
            }
        }
        fileNamesCallback = callback
        fileHandle.registerCallback(callback)
        fileHandle.initRegister()
        fileHandle.start()
    }

    private fun selectResourceFile() {
        val intent = Intent(Intent.ACTION_GET_CONTENT)
        intent.type = "*/*"
        intent.addCategory(Intent.CATEGORY_OPENABLE)
        startActivityForResult(intent, REQUEST_CODE_SELECT_RESOURCE)
    }

    private fun startResourceUpdate() {
        if (path.isEmpty()) {
            getString(R.string.resource_update_no_file).showToast()
            return
        }
        if (!fileHandle.executeFilePrepare(path)) {
            getString(R.string.resource_update_prepare_failed, path).showToast()
            logResource(getString(R.string.resource_update_prepare_failed, path))
            return
        }

        removeUpdateCallback()
        binding.tvProgress.text = getString(R.string.qc_text_0032, "0")
        val fileName = File(path).name
        val callback = object : SimpleCallback() {
            override fun onProgress(percent: Int) {
                runOnUiThread {
                    binding.tvProgress.text = getString(R.string.qc_text_0032, percent.toString())
                }
            }

            override fun onComplete() {
                logResource(getString(R.string.resource_update_complete))
                runOnUiThread {
                    binding.tvProgress.text = getString(R.string.qc_text_0032, "100")
                    getString(R.string.resource_update_complete).showToast()
                    removeUpdateCallback()
                }
            }

            override fun onActionResult(type: Int, errCode: Int) {
                if (errCode != 0) {
                    logResource(getString(R.string.resource_update_action_failed, type, errCode))
                    runOnUiThread {
                        getString(R.string.resource_update_action_failed, type, errCode).showToast()
                        removeUpdateCallback()
                    }
                }
            }
        }
        updateCallback = callback
        fileHandle.registerCallback(callback)
        fileHandle.initRegister()
        logResource("Start resource update fileName=$fileName path=$path")
        fileHandle.cmdFileInit(fileName)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_CODE_SELECT_RESOURCE || resultCode != RESULT_OK) {
            return
        }
        val uri: Uri = data?.data ?: return
        path = GetFilePathFromUri.getFileAbsolutePath(this, uri)
        binding.selectFilePath.text = getString(R.string.qc_text_0033, path)
        logResource("Selected resource file path=$path")
    }

    override fun onDestroy() {
        removeFileNamesCallback()
        removeUpdateCallback()
        fileHandle.endAndRelease()
        super.onDestroy()
    }

    private fun removeFileNamesCallback() {
        fileNamesCallback?.let {
            fileHandle.unregisterCallback(it)
        }
        fileNamesCallback = null
    }

    private fun removeUpdateCallback() {
        updateCallback?.let {
            fileHandle.unregisterCallback(it)
        }
        updateCallback = null
    }

    private fun logResource(message: String) {
        XLog.tag(TAG).d(message)
        BluetoothLogManager.addExternalLog("[RESOURCE]\n$message")
    }

    companion object {
        private const val REQUEST_CODE_SELECT_RESOURCE = 1001
    }
}
