package com.qcwireless.sdksample

import androidx.core.content.FileProvider

class SampleRecordingFileProvider : FileProvider()
