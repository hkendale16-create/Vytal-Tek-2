package com.qcwireless.sdksample.activity

import android.os.Bundle
import android.util.Log
import com.oudmon.ble.base.bean.SleepDisplay
import com.oudmon.ble.base.bluetooth.BleOperateManager
import com.oudmon.ble.base.bluetooth.task.BleTaskCategory
import com.oudmon.ble.base.bluetooth.task.BleTaskError
import com.oudmon.ble.base.communication.DfuHandle
import com.oudmon.ble.base.communication.ICommandResponse
import com.oudmon.ble.base.communication.ILargeDataSleepResponse
import com.oudmon.ble.base.communication.LargeDataHandler
import com.oudmon.ble.base.communication.bigData.BloodOxygenEntity
import com.oudmon.ble.base.communication.bigData.IBloodOxygenCallback
import com.oudmon.ble.base.communication.bigData.bean.IntervalHeartRateEntity
import com.oudmon.ble.base.communication.bigData.bean.IntervalTemperatureEntity
import com.oudmon.ble.base.communication.bigData.resp.IIntervalHeartRateCallback
import com.oudmon.ble.base.communication.dfu_temperature.TemperatureEntity
import com.oudmon.ble.base.communication.dfu_temperature.TemperatureOnceEntity
import com.oudmon.ble.base.communication.entity.BlePressure
import com.oudmon.ble.base.communication.entity.BleStepDetails
import com.oudmon.ble.base.communication.file.FileHandle
import com.oudmon.ble.base.communication.file.SimpleCallback
import com.oudmon.ble.base.communication.req.HRVReq
import com.oudmon.ble.base.communication.req.ReadDetailSportDataReq
import com.oudmon.ble.base.communication.req.ReadHeartRateReq
import com.oudmon.ble.base.communication.req.ReadPressureReq
import com.oudmon.ble.base.communication.req.StartHeartRateReq
import com.oudmon.ble.base.communication.req.StopHeartRateReq
import com.oudmon.ble.base.communication.rsp.HRVRsp
import com.oudmon.ble.base.communication.rsp.PressureRsp
import com.oudmon.ble.base.communication.rsp.ReadBlePressureRsp
import com.oudmon.ble.base.communication.rsp.ReadDetailSportDataRsp
import com.oudmon.ble.base.communication.rsp.ReadHeartRateRsp
import com.oudmon.ble.base.communication.rsp.StopHeartRateRsp
import com.oudmon.ble.base.communication.sport.BaseCallback
import com.oudmon.ble.base.communication.sport.SportPlusEntity
import com.oudmon.ble.base.communication.sport.SportPlusHandle
import com.oudmon.ble.base.util.DateUtil
import com.qcwireless.sdksample.R
import com.qcwireless.sdksample.annotation.BleIsConnected
import com.qcwireless.sdksample.databinding.ActivityHealthSettingsBinding
import com.qcwireless.sdksample.ext.startKtxActivity
import com.qcwireless.sdksample.log.BluetoothLogManager
import java.util.Calendar
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

class HealthSettingsActivity : BaseFunctionActivity() {
    private lateinit var binding: ActivityHealthSettingsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHealthSettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }

    override fun setupViews() {
        super.setupViews()
        binding.titleBar.tvTitle.text = getString(R.string.title_health_settings)
        binding.fivBatchSync.setOnClickListener {
            startDebugSyncAllChain()
        }
        binding.fivSteps.setOnClickListener { startKtxActivity<StepsActivity>() }
        binding.fivSleep.setOnClickListener { startKtxActivity<SleepActivity>() }
        binding.fivSportRecord.setOnClickListener { startKtxActivity<SportRecordActivity>() }
        binding.fivHeartRate.setOnClickListener { startKtxActivity<HeartRateActivity>() }
        binding.fivBloodPressure.setOnClickListener { startKtxActivity<BloodPressureActivity>() }
        binding.fivBloodOxygen.setOnClickListener { startKtxActivity<BloodOxygenActivity>() }
        binding.fivHrv.setOnClickListener { startKtxActivity<HrvActivity>() }
        binding.fivPressure.setOnClickListener { startKtxActivity<PressureActivity>() }
        binding.fivTemperature.setOnClickListener { startKtxActivity<TemperatureActivity>() }
        binding.fivSugarLipids.setOnClickListener { startKtxActivity<SugarLipidsActivity>() }
        binding.fivEmotion.setOnClickListener { startKtxActivity<EmotionActivity>() }
        binding.fivDrinkReminder.setOnClickListener { startKtxActivity<DrinkReminderActivity>() }
        binding.fivSedentaryReminder.setOnClickListener { startKtxActivity<SedentaryReminderActivity>() }
        refreshCachesIfConnected()
    }

    private fun logBatchDetail(name: String, data: Any?) {
        if(!logEnable){
            return
        }
        val detail = HealthDataValueFormatter.formatFull(data)
        logLongInfo(LOG_TAG, "$name = $detail")
        BluetoothLogManager.addExternalLog("[BATCH]\nname=$name result=$detail")
    }

    private fun logLongInfo(tag: String, message: String) {
//        if(!logEnable){
//            return
//        }
        if (message.length <= LOG_CHUNK_SIZE) {
            Log.i(tag, message)
            return
        }
        message.chunked(LOG_CHUNK_SIZE).forEachIndexed { index, chunk ->
            Log.i(tag, "${index + 1}/${(message.length + LOG_CHUNK_SIZE - 1) / LOG_CHUNK_SIZE} $chunk")
        }
    }

//    private fun dayStartSeconds(dayIndex: Int): Long {
//        val dateUtil = DateUtil()
//        dateUtil.addDay(-dayIndex)
//        return dateUtil.zeroTime
//    }
    companion object {
        private const val LOG_TAG = "BleSdkSample"
        private const val TAG = "HealthTTest"
        private const val logEnable =true
        private const val LOG_CHUNK_SIZE = 3_500

    }

//    fun startDebugSyncAllChain(dayIndex: Int = 1) {
//        BleOperateManager.getInstance()
//            .newTaskChain()
//            .timeoutRecoveryDelay(1_500L)
//
//            // Today
//            .getTodayStepDetail(BleOperateManager.HealthDataCallback { Log.i(TAG, "activity_today data=$it") })
//            .getTodayHeartRate(BleOperateManager.HealthDataCallback { Log.i(TAG, "heart_rate_today uctTime=${it.getmUtcTime()} range=${it.range} size=${it.getmHeartRateArray().size}") })
//            .getTodayHrv(BleOperateManager.HealthDataCallback { logHrv("hrv_today", it) })
//            .getTodayPressure(BleOperateManager.HealthDataCallback { logPressure("stress_today", it) })
//            .getTodayTemperature(BleOperateManager.HealthDataCallback { Log.i(TAG, "temperature_today interval=${it.interval} size=${it.array?.size ?: 0} data=${it.array}") })
//            .getTodayBloodOxygen(BleOperateManager.HealthDataCallback { Log.i(TAG, "blood_oxygen_today interval=${it.interval} size=${it.array?.size ?: 0} data=$it") })
//            .getTodaySleep(BleOperateManager.HealthDataCallback { Log.i(TAG, "sleep_today data=$it") })
//            .getTodaySport(BleOperateManager.HealthDataCallback { Log.i(TAG, "sport_today size=${it.size} data=$it") })
//
//            // Specified day
//            .getStepDetail(dayIndex, BleOperateManager.HealthDataCallback { Log.i(TAG, "activity_$dayIndex data=$it") })
//            .getHeartRate(dayIndex, BleOperateManager.HealthDataCallback { Log.i(TAG, "heart_rate_$dayIndex uctTime=${it.getmUtcTime()} range=${it.range} size=${it.getmHeartRateArray().size}") })
//            .getHrv(dayIndex, BleOperateManager.HealthDataCallback { logHrv("hrv_$dayIndex", it) })
//            .getPressure(dayIndex, BleOperateManager.HealthDataCallback { logPressure("stress_$dayIndex", it) })
//            .getTemperature(dayIndex, BleOperateManager.HealthDataCallback { Log.i(TAG, "temperature_$dayIndex interval=${it.interval} size=${it.array?.size ?: 0} data=${it.array}") })
//            .getBloodOxygen(dayIndex, BleOperateManager.HealthDataCallback { Log.i(TAG, "blood_oxygen_$dayIndex interval=${it.interval} size=${it.array?.size ?: 0} data=$it") })
//            .getSleep(dayIndex, BleOperateManager.HealthDataCallback { Log.i(TAG, "sleep_$dayIndex data=$it") })
//            .getSport(dayIndex, BleOperateManager.HealthDataCallback { Log.i(TAG, "sport_$dayIndex size=${it.size} data=$it") })
//
//            // Range: day 0 -> 6
//            .getStepDetails(0, 7, BleOperateManager.HealthDataCallback { days ->
//                days.sortedByDescending { it.dayIndex }.forEach {
//                    Log.i(TAG, "activity_${it.dayIndex} data=${it.data}")
//                }
//            })
//            .getHeartRates(0, 7, BleOperateManager.HealthDataCallback { days ->
//                days.sortedByDescending { it.dayIndex }.forEach {
//                    Log.i(TAG, "heart_rate_${it.dayIndex} uctTime=${it.data.getmUtcTime()} range=${it.data?.range} size=${it.data?.getmHeartRateArray()?.size ?: 0}")
//                }
//            })
//            .getHrvs(0, 7, BleOperateManager.HealthDataCallback { days ->
//                days.sortedByDescending { it.dayIndex }.forEach {
//                    it.data?.let { data -> logHrv("hrv_${it.dayIndex}", data) }
//                }
//            })
//            .getPressures(0, 7, BleOperateManager.HealthDataCallback { days ->
//                days.sortedByDescending { it.dayIndex }.forEach {
//                    it.data?.let { data -> logPressure("stress_${it.dayIndex}", data) }
//                }
//            })
//            .getTemperatures(0, 7, BleOperateManager.HealthDataCallback { days ->
//                days.sortedByDescending { it.dayIndex }.forEach {
//                    Log.i(TAG, "temperature_${it.dayIndex} interval=${it.data?.interval} size=${it.data?.array?.size ?: 0} data=${it.data?.array}")
//                }
//            })
//            .getBloodOxygens(0, 7, BleOperateManager.HealthDataCallback { days ->
//                days.sortedByDescending { it.dayIndex }.forEach {
//                    Log.i(TAG, "blood_oxygen_${it.dayIndex} interval=${it.data?.interval} size=${it.data?.array?.size ?: 0} data=${it.data}")
//                }
//            })
//            .getSleeps(0, 7, BleOperateManager.HealthDataCallback { days ->
//                days.sortedByDescending { it.dayIndex }.forEach {
//                    Log.i(TAG, "sleep_${it.dayIndex} data=${it.data}")
//                }
//            })
//            .getSports(0, 7, BleOperateManager.HealthDataCallback { days ->
//                days.sortedByDescending { it.dayIndex }.forEach {
//                    Log.i(TAG, "sport_${it.dayIndex} size=${it.data?.size ?: 0} data=${it.data}")
//                }
//            })
//            .start(object : BleOperateManager.TaskChainListener {
//                override fun onStepStart(index: Int, stepName: String?) {
//                    Log.i(TAG, "Step start: $index / $stepName")
//                }
//
//                override fun onStepSuccess(index: Int, stepName: String?, data: Any?) {
//                    Log.i(TAG, "Step success: $index / $stepName data=$data")
//                }
//
//                override fun onStepFail(index: Int, stepName: String?, errorCode: Int, errorMsg: String?) {
//                    Log.e(TAG, "Step fail: $index / $stepName code=$errorCode msg=$errorMsg")
//                }
//
//                override fun onChainFinish(success: Boolean, cancelled: Boolean) {
//                    Log.i(TAG, "Step The entire chain ends success=$success cancelled=$cancelled")
//                }
//            })
//    }

    fun startDebugSyncAllChain(dayIndex: Int = 1) {
        BleOperateManager.getInstance()
            .newTaskChain()
            .timeoutRecoveryDelay(1000L)

            // Today
            .getTodayStepDetail(BleOperateManager.HealthDataCallback { logBatchDetail("activity_today", it) })
            .getTodayHeartRate(BleOperateManager.HealthDataCallback { logBatchDetail("heart_rate_today", it) })
            .getTodayHrv(BleOperateManager.HealthDataCallback { logBatchDetail("hrv_today", it) })
            .getTodayPressure(BleOperateManager.HealthDataCallback { logBatchDetail("stress_today", it) })
            .getTodayTemperature(BleOperateManager.HealthDataCallback { logBatchDetail("temperature_today", it) })
            .getTodayBloodOxygen(BleOperateManager.HealthDataCallback { logBatchDetail("blood_oxygen_today", it) })
            .getTodaySleep(BleOperateManager.HealthDataCallback { logBatchDetail("sleep_today", it) })
            .getTodaySport(BleOperateManager.HealthDataCallback { logBatchDetail("sport_today", it) })

            // Specified day
            .getStepDetail(dayIndex, BleOperateManager.HealthDataCallback { logBatchDetail("activity_$dayIndex", it) })
            .getHeartRate(dayIndex, BleOperateManager.HealthDataCallback { logBatchDetail("heart_rate_$dayIndex", it) })
            .getHrv(dayIndex, BleOperateManager.HealthDataCallback { logBatchDetail("hrv_$dayIndex", it) })
            .getPressure(dayIndex, BleOperateManager.HealthDataCallback { logBatchDetail("stress_$dayIndex", it) })
            .getTemperature(dayIndex, BleOperateManager.HealthDataCallback { logBatchDetail("temperature_$dayIndex", it) })
            .getBloodOxygen(dayIndex, BleOperateManager.HealthDataCallback { logBatchDetail("blood_oxygen_$dayIndex", it) })
            .getSleep(dayIndex, BleOperateManager.HealthDataCallback { logBatchDetail("sleep_$dayIndex", it) })
            .getSport(dayIndex, BleOperateManager.HealthDataCallback { logBatchDetail("sport_$dayIndex", it) })
            .getBloodOxygen(2, BleOperateManager.HealthDataCallback { logBatchDetail("blood_oxygen_2", it) })
            // Range: day 0 -> 6
            .getStepDetails(0, 7, BleOperateManager.HealthDataCallback { days ->
                logBatchDetail("activity_range_0_6", days)
                days.sortedByDescending { it.dayIndex }.forEach {
                    logBatchDetail("activity_${it.dayIndex}", it.data)
                }
            })
            .getHeartRates(0, 7, BleOperateManager.HealthDataCallback { days ->
                logBatchDetail("heart_rate_range_0_6", days)
                days.sortedByDescending { it.dayIndex }.forEach {
                    logBatchDetail("heart_rate_${it.dayIndex}", it.data)
                }
            })
            .getHrvs(0, 7, BleOperateManager.HealthDataCallback { days ->
                logBatchDetail("hrv_range_0_6", days)
                days.sortedByDescending { it.dayIndex }.forEach {
                    logBatchDetail("hrv_${it.dayIndex}", it.data)
                }
            })
            .getPressures(0, 7, BleOperateManager.HealthDataCallback { days ->
                logBatchDetail("stress_range_0_6", days)
                days.sortedByDescending { it.dayIndex }.forEach {
                    logBatchDetail("stress_${it.dayIndex}", it.data)
                }
            })
            .getTemperatures(0, 7, BleOperateManager.HealthDataCallback { days ->
                logBatchDetail("temperature_range_0_6", days)
                days.sortedByDescending { it.dayIndex }.forEach {
                    logBatchDetail("temperature_${it.dayIndex}", it.data)
                }
            })
            .getBloodOxygens(0, 7, BleOperateManager.HealthDataCallback { days ->
                logBatchDetail("blood_oxygen_range_0_6", days)
                days.sortedByDescending { it.dayIndex }.forEach {
                    logBatchDetail("blood_oxygen_${it.dayIndex}", it.data)
                }
            })
            .getSleeps(0, 7, BleOperateManager.HealthDataCallback { days ->
                logBatchDetail("sleep_range_0_6", days)
                days.sortedByDescending { it.dayIndex }.forEach {
                    logBatchDetail("sleep_${it.dayIndex}", it.data)
                }
            })
            .getSports(0, 7, BleOperateManager.HealthDataCallback { days ->
                logBatchDetail("sport_range_0_6", days)
                days.sortedByDescending { it.dayIndex }.forEach {
                    logBatchDetail("sport_${it.dayIndex}", it.data)
                }
            })
            .start(object : BleOperateManager.TaskChainListener {
                override fun onStepStart(index: Int, stepName: String?) {
                    Log.i(LOG_TAG, "Step start: $index / $stepName")
                }

                override fun onStepSuccess(index: Int, stepName: String?, data: Any?) {
                    logLongInfo(LOG_TAG, "Step success: $index / $stepName data=${HealthDataValueFormatter.formatFull(data)}")
                }

                override fun onStepFail(index: Int, stepName: String?, errorCode: Int, errorMsg: String?) {
                    Log.e(LOG_TAG, "Step fail: $index / $stepName code=$errorCode msg=$errorMsg")
                }

                override fun onChainFinish(success: Boolean, cancelled: Boolean) {
                    Log.i(LOG_TAG, "Step The entire chain ends success=$success cancelled=$cancelled")
                }
            })
    }

//    fun startDebugSyncAllChain(dayIndex: Int = 1) {
//        BleOperateManager.getInstance()
//            .newTaskChain()
//            .timeoutRecoveryDelay(1000L)
//            .getBloodOxygens(0, 7, BleOperateManager.HealthDataCallback { days ->
//                logBatchDetail("blood_oxygen_range_0_6", days)
//                days.sortedByDescending { it.dayIndex }.forEach {
//                    logBatchDetail("blood_oxygen_${it.dayIndex}", it.data)
//                }
//            })
//            .getSleeps(0, 7, BleOperateManager.HealthDataCallback { days ->
//                logBatchDetail("sleep_range_0_6", days)
//                days.sortedByDescending { it.dayIndex }.forEach {
//                    logBatchDetail("sleep_${it.dayIndex}", it.data)
//                }
//            })
//            .getSports(0, 7, BleOperateManager.HealthDataCallback { days ->
//                logBatchDetail("sport_range_0_6", days)
//                days.sortedByDescending { it.dayIndex }.forEach {
//                    logBatchDetail("sport_${it.dayIndex}", it.data)
//                }
//            })
//            .start(object : BleOperateManager.TaskChainListener {
//                override fun onStepStart(index: Int, stepName: String?) {
////                    Log.i(LOG_TAG, "Step start: $index / $stepName")
//                }
//
//                override fun onStepSuccess(index: Int, stepName: String?, data: Any?) {
//                    logLongInfo(LOG_TAG, "Step success: $index / $stepName data=${HealthDataValueFormatter.formatFull(data)}")
//                }
//
//                override fun onStepFail(index: Int, stepName: String?, errorCode: Int, errorMsg: String?) {
//                    Log.e(LOG_TAG, "Step fail: $index / $stepName code=$errorCode msg=$errorMsg")
//                }
//
//                override fun onChainFinish(success: Boolean, cancelled: Boolean) {
//                    Log.i(LOG_TAG, "Step The entire chain ends success=$success cancelled=$cancelled")
//                }
//            })
//    }

    private fun startTemperatureStep(
        fileHandle: FileHandle,
        task: BleOperateManager.TaskHandle,
        day: Int
    ) {
        val callback = object : SimpleCallback() {
            override fun onUpdateTemperature(data: TemperatureEntity) {
                if (!task.isActive) return
                Log.i(TAG, "temperature_$day data=$data")
                task.success(data)
            }

            override fun onActionResult(type: Int, errCode: Int) {
                if (!task.isActive || errCode == 0) return
                Log.e(TAG, "temperature_$day action failed type=$type errCode=$errCode")
                task.fail(BleTaskError.ERR_TIMEOUT, "temperature file action failed")
            }
        }

        fileHandle.clearCallback()
        fileHandle.registerCallback(callback)
        fileHandle.initRegister(task.id())
        task.addCleanup {
            fileHandle.clearCallback()
            fileHandle.endAndRelease(task.id())
        }
        fileHandle.startObtainTemperatureSeries(day)
    }

    private fun dayStartSeconds(day: Int): Long {
        val calendar = Calendar.getInstance()
        calendar.add(Calendar.DAY_OF_YEAR, -day)
        calendar.set(Calendar.HOUR_OF_DAY, 0)
        calendar.set(Calendar.MINUTE, 0)
        calendar.set(Calendar.SECOND, 0)
        calendar.set(Calendar.MILLISECOND, 0)
        return calendar.timeInMillis / 1000L
    }

    private fun logHrv(name: String, rsp: HRVRsp) {
        Log.i(TAG, "$name offset=${rsp.offset} range=${rsp.range} size=${rsp.hrvArray.size} end=${rsp.isEndFlag}")
    }

    private fun logPressure(name: String, rsp: PressureRsp) {
        Log.i(TAG, "$name offset=${rsp.offset} range=${rsp.range} size=${rsp.pressureArray.size} end=${rsp.isEndFlag}")
    }
}
