package com.qcwireless.sdksample.activity

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Spinner
import com.oudmon.ble.base.communication.ICommandResponse
import com.oudmon.ble.base.communication.req.TouchControlReq
import com.oudmon.ble.base.communication.rsp.BaseRspCmd
import com.oudmon.ble.base.communication.rsp.TouchControlResp
import com.qcwireless.sdksample.R
import com.qcwireless.sdksample.annotation.BleIsConnected
import com.qcwireless.sdksample.databinding.ActivityTouchGestureBinding
import com.qcwireless.sdksample.ext.showToast
import com.qcwireless.sdksample.log.BluetoothLogManager

class TouchGestureActivity : BaseFunctionActivity() {

    private lateinit var binding: ActivityTouchGestureBinding

    private data class ActionOption(val value: Int, val label: String) {
        override fun toString(): String = label
    }

    private data class FunctionTypeOption(val value: Int, val label: String) {
        override fun toString(): String = label
    }

    private data class AppTypeOption(val value: Int, val label: String) {
        override fun toString(): String = label
    }

    private data class NumberOption(val value: Int, val label: String) {
        override fun toString(): String = label
    }

    private data class StateOption(val value: Int, val label: String) {
        override fun toString(): String = label
    }

    private val actionOptions = listOf(
        ActionOption(0, "0 None"),
        ActionOption(1, "1 Read"),
        ActionOption(2, "2 Set")
    )

    private val functionTypeOptions = listOf(
        FunctionTypeOption(0, "0 Touch"),
        FunctionTypeOption(1, "1 Gesture"),
        FunctionTypeOption(2, "2 RT11 Touch")
    )

    private val appTypeOptions = listOf(
        AppTypeOption(0, "0 Close"),
        AppTypeOption(1, "1 Music"),
        AppTypeOption(2, "2 Short Video"),
        AppTypeOption(3, "3 Muslim Counter"),
        AppTypeOption(4, "4 E-book"),
        AppTypeOption(5, "5 Camera"),
        AppTypeOption(6, "6 Phone Call"),
        AppTypeOption(7, "7 Game"),
        AppTypeOption(8, "8 Manual Heart Rate"),
        AppTypeOption(9, "9 Touch Event"),
        AppTypeOption(10, "10 Lover Interaction")
    )

    private val strengthOptions = (1..10).map { NumberOption(it, it.toString()) }
    private val sleepTimeOptions = (1..5).map { NumberOption(it, "$it min") }
    private val touchStateOptions = listOf(
        StateOption(0, "0 Awake"),
        StateOption(1, "1 Sleeping")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTouchGestureBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }

    override fun setupViews() {
        super.setupViews()
        binding.titleBar.tvTitle.text = getString(R.string.title_touch_gesture)
        bindSpinner(binding.spinnerActionType, actionOptions)
        bindSpinner(binding.spinnerFunctionType, functionTypeOptions)
        bindSpinner(binding.spinnerAppType, appTypeOptions)
        bindSpinner(binding.spinnerStrength, strengthOptions)
        bindSpinner(binding.spinnerSleepTime, sleepTimeOptions)
        bindSpinner(binding.spinnerTouchState, touchStateOptions)

        binding.fivReadTouchGesture.setOnClickListener {
            binding.spinnerActionType.setSelection(READ_ACTION_INDEX)
            readTouchGesture()
        }
        binding.fivSetTouchGesture.setOnClickListener {
            binding.spinnerActionType.setSelection(SET_ACTION_INDEX)
            writeTouchGesture()
        }
        refreshCachesIfConnected()
    }

    override fun onResume() {
        super.onResume()
        refreshCachesIfConnected()
    }

    private fun <T> bindSpinner(spinner: Spinner, options: List<T>) {
        spinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            options
        ).also {
            it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
    }

    @BleIsConnected
    private fun readTouchGesture() {
        val functionType = selectedFunctionType()
        if (!ensureFunctionSupported(functionType)) {
            return
        }
        val isTouch = functionType.value != FUNCTION_TYPE_GESTURE
        val request = if (isTouch) {
            TouchControlReq.getReadInstance(true)
        } else {
            TouchControlReq.getReadInstance(false)
        }
        executeTouchGestureReq(
            actionName = getString(R.string.touch_gesture_read),
            defaultArgs = "Read=1, functionType=${functionType.value}, isTouch=$isTouch",
            request = request
        )
    }

    @BleIsConnected
    private fun writeTouchGesture() {
        val functionType = selectedFunctionType()
        if (!ensureFunctionSupported(functionType)) {
            return
        }
        val appType = selectedAppType()
        val strength = selectedStrength()
        val sleepTime = selectedSleepTime()
        val state = selectedTouchState()
        val request = when (functionType.value) {
            FUNCTION_TYPE_TOUCH -> {
                TouchControlReq.getWriteInstance(appType.value, true, strength.value, sleepTime.value)
            }
            FUNCTION_TYPE_GESTURE -> {
                TouchControlReq.getWriteInstance(appType.value, false, strength.value)
            }
            else -> {
                TouchControlReq.getWriteTpSleepInstance(appType.value, state.value)
            }
        }
        executeTouchGestureReq(
            actionName = getString(R.string.touch_gesture_set),
            defaultArgs = "Write=2, functionType=${functionType.value}, appType=${appType.value}, strength=${strength.value}, sleepTime=${sleepTime.value}, state=${state.value}",
            request = request
        )
    }

    private fun executeTouchGestureReq(
        actionName: String,
        defaultArgs: String,
        request: TouchControlReq
    ) {
        BluetoothLogManager.addExternalLog("[REQ]\naction=$actionName request=TouchControlReq $defaultArgs")
        commandHandle.executeReqCmd(
            request,
            ICommandResponse<TouchControlResp> { rsp ->
                val success = rsp.status == BaseRspCmd.RESULT_OK
                val log = formatTouchGestureResp(actionName, success, rsp)
                BluetoothLogManager.addExternalLog(log)
                if (success) {
                    "$actionName success".showToast()
                } else {
                    "$actionName fail".showToast()
                }
            }
        )
    }

    private fun formatTouchGestureResp(
        actionName: String,
        success: Boolean,
        rsp: TouchControlResp
    ): String {
        return "[RSP]\n" +
            "action=$actionName success=$success status=${rsp.status}\n" +
            "isRead=${rsp.isRead()} isTouch=${rsp.isTouch()} appType=${rsp.getAppType()} " +
            "strength=${rsp.getStrength()} sleepTime=${rsp.getSleepTime()} touchSleep=${rsp.isTouchSleep()}"
    }

    private fun ensureFunctionSupported(functionType: FunctionTypeOption): Boolean {
        return when (functionType.value) {
            FUNCTION_TYPE_TOUCH -> ensureSupported(deviceSupport.supportTouch)
            FUNCTION_TYPE_GESTURE -> ensureSupported(deviceSupport.supportGesture)
            else -> ensureSupported(deviceSupport.supportRt11 && deviceSupport.tpSleep)
        }
    }

    private fun selectedFunctionType(): FunctionTypeOption {
        return binding.spinnerFunctionType.selectedItem as FunctionTypeOption
    }

    private fun selectedAppType(): AppTypeOption {
        return binding.spinnerAppType.selectedItem as AppTypeOption
    }

    private fun selectedStrength(): NumberOption {
        return binding.spinnerStrength.selectedItem as NumberOption
    }

    private fun selectedSleepTime(): NumberOption {
        return binding.spinnerSleepTime.selectedItem as NumberOption
    }

    private fun selectedTouchState(): StateOption {
        return binding.spinnerTouchState.selectedItem as StateOption
    }

    companion object {
        private const val READ_ACTION_INDEX = 1
        private const val SET_ACTION_INDEX = 2
        private const val FUNCTION_TYPE_TOUCH = 0
        private const val FUNCTION_TYPE_GESTURE = 1
    }
}
