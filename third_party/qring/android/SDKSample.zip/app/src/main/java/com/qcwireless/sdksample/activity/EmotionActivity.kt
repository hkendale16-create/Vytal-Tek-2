package com.qcwireless.sdksample.activity

import android.os.Bundle
import com.oudmon.ble.base.bluetooth.BleOperateManager
import com.oudmon.ble.base.communication.req.SugarLipidsSettingReq
import com.oudmon.ble.base.communication.rsp.EmotionRsp
import com.qcwireless.sdksample.R
import com.qcwireless.sdksample.annotation.BleIsConnected
import com.qcwireless.sdksample.databinding.ActivityEmotionBinding

class EmotionActivity : BaseFunctionActivity() {
    private lateinit var binding: ActivityEmotionBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEmotionBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }

    override fun setupViews() {
        super.setupViews()
        val title = getString(R.string.title_emotion)
        binding.titleBar.tvTitle.text = title
        binding.fivSettingRead.setOnClickListener { readEmotionSetting() }
        binding.fivSettingOpen.setOnClickListener { writeEmotionSetting(true) }
        binding.fivSettingClose.setOnClickListener { writeEmotionSetting(false) }
        bindHealthQueryActions<EmotionRsp>(
            todayView = binding.fivTodayData,
            singleDayView = binding.fivSingleDayData,
            rangeView = binding.fivRangeData,
            title = title,
            todayAction = { callback ->
                BleOperateManager.getInstance().getEmotion(0, callback)
            },
            singleDayAction = { dayIndex, callback ->
                BleOperateManager.getInstance().getEmotion(dayIndex, callback)
            },
            rangeAction = { startDayIndex, count, callback ->
                BleOperateManager.getInstance().getEmotions(startDayIndex, count, callback)
            }
        )
    }

    @BleIsConnected
    private fun readEmotionSetting() {
        executeSettingAction(
            LOG_TAG,
            "Get Emotion Setting",
            "SugarLipidsSettingReq",
            "type=TYPE_EMOTION",
            SugarLipidsSettingReq.getReadEmotionInstance()
        )
    }

    @BleIsConnected
    private fun writeEmotionSetting(enable: Boolean) {
        executeSettingAction(
            LOG_TAG,
            if (enable) "Open Emotion Setting" else "Close Emotion Setting",
            "SugarLipidsSettingReq",
            "type=TYPE_EMOTION, enable=$enable",
            SugarLipidsSettingReq.getWriteEmotionInstance(enable)
        )
    }

    companion object {
        private const val LOG_TAG = "Emotion"
    }
}
