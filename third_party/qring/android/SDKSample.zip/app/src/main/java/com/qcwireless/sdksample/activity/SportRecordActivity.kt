package com.qcwireless.sdksample.activity

import android.os.Bundle
import android.os.SystemClock
import androidx.appcompat.app.AlertDialog
import com.elvishew.xlog.XLog
import com.oudmon.ble.base.bluetooth.BleOperateManager
import com.oudmon.ble.base.communication.ICommandResponse
import com.oudmon.ble.base.communication.req.PhoneSportReq
import com.oudmon.ble.base.communication.responseImpl.DeviceSportNotifyListener
import com.oudmon.ble.base.communication.rsp.AppSportRsp
import com.oudmon.ble.base.communication.rsp.BaseRspCmd
import com.oudmon.ble.base.communication.rsp.DeviceNotifyRsp
import com.oudmon.ble.base.communication.sport.SportPlusHandle
import com.qcwireless.sdksample.R
import com.qcwireless.sdksample.annotation.BleIsConnected
import com.qcwireless.sdksample.databinding.ActivitySportRecordBinding
import com.qcwireless.sdksample.ext.showToast
import com.qcwireless.sdksample.sport.SportTypeCatalog
import java.util.Locale

class SportRecordActivity : BaseFunctionActivity() {
    private lateinit var binding: ActivitySportRecordBinding
    private var selectedSportType = SportTypeCatalog.DEFAULT_SPORT_TYPE
    private var sportStartElapsedMillis = 0L
    private var latestSportDurationSeconds = 0
    private val sportNotifyListener = SportNotifyListener()
    private val sportResponse = ICommandResponse<AppSportRsp> { resultEntity ->
        XLog.tag(TAG).i("phone sport response=$resultEntity")
        if (resultEntity != null) {
            XLog.tag(TAG).i(
                "phone sport gpsStatus=${resultEntity.gpsStatus}, timeStamp=${resultEntity.timeStamp}"
            )
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySportRecordBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }

    override fun setupViews() {
        super.setupViews()
        binding.titleBar.tvTitle.text = getString(R.string.qc_text_0064)
        binding.fivDataSync.setOnClickListener { syncSportRecord() }
        binding.fivStartSport.setOnClickListener { showSportTypeDialog() }
        binding.fivStopSport.setOnClickListener { stopSportWithDurationCheck() }
        refreshSupportCache()
    }

    private fun isSportSupported(): Boolean {
        return ensureSupported(true)
    }

    @BleIsConnected
    private fun syncSportRecord() {
        if (!isSportSupported()) {
            return
        }
        val syncSport = SportPlusHandle()
        syncSport.timeFormat = "yyyy-MM-dd HH:mm"
        syncSport.syncSportPlus { errorCode, _ ->
            XLog.tag("Sport").d("syncSportPlus code=$errorCode")
        }
        syncSport.cmdSummary(0)
        getString(R.string.qc_text_0093).showToast()
    }

    private fun showSportTypeDialog() {
        if (!isSportSupported()) {
            return
        }
        val sportTypes = SportTypeCatalog.sportTypes
        val names = sportTypes.map { getString(it.nameRes) }.toTypedArray()
        val checkedIndex = sportTypes.indexOfFirst { it.type == selectedSportType }.takeIf { it >= 0 } ?: 0
        AlertDialog.Builder(this)
            .setTitle(R.string.sport_type_select_title)
            .setSingleChoiceItems(names, checkedIndex) { dialog, which ->
                selectedSportType = sportTypes[which].type
                dialog.dismiss()
                startSport(selectedSportType)
            }
            .setNegativeButton(R.string.recording_cancel, null)
            .show()
    }

    @BleIsConnected
    private fun startSport(sportType: Int) {
        if (!isSportSupported()) {
            return
        }
        selectedSportType = sportType
        sportStartElapsedMillis = SystemClock.elapsedRealtime()
        latestSportDurationSeconds = 0
        commandHandle.executeReqCmd(
            PhoneSportReq.getSportStatus(STATUS_START, sportType.toByte()),
            sportResponse
        )
        val sportName = getSportName(sportType)
        XLog.tag(TAG).i("start sport type=$sportType, name=$sportName")
        getString(R.string.sport_started, sportName).showToast()
    }

    @BleIsConnected
    private fun stopSportWithDurationCheck() {
        if (!isSportSupported()) {
            return
        }
        if (isSportDurationTooShort()) {
            AlertDialog.Builder(this)
                .setMessage(R.string.sport_duration_too_short)
                .setNegativeButton(R.string.sport_continue, null)
                .setPositiveButton(R.string.sport_stop_anyway) { _, _ -> stopSport() }
                .show()
            return
        }
        stopSport()
    }

    private fun stopSport() {
        commandHandle.executeReqCmd(
            PhoneSportReq.getSportStatus(STATUS_STOP, selectedSportType.toByte()),
            sportResponse
        )
        val sportName = getSportName(selectedSportType)
        XLog.tag(TAG).i("stop sport type=$selectedSportType, name=$sportName")
        getString(R.string.sport_stopped, sportName).showToast()
    }

    private fun isSportDurationTooShort(): Boolean {
        val elapsedSeconds = if (sportStartElapsedMillis > 0L) {
            (SystemClock.elapsedRealtime() - sportStartElapsedMillis) / 1000
        } else {
            0L
        }
        val durationSeconds = maxOf(elapsedSeconds, latestSportDurationSeconds.toLong())
        return durationSeconds < MIN_SPORT_DURATION_SECONDS
    }

    private fun getSportName(sportType: Int): String {
        val nameRes = SportTypeCatalog.find(sportType)?.nameRes ?: SportTypeCatalog.defaultSportType.nameRes
        return getString(nameRes)
    }

    private fun formatSportNotifyMessage(data: SportNotifyData): String {
        return getString(
            R.string.sport_notify_data,
            getSportName(selectedSportType),
            data.heartRate,
            formatDistance(data.distanceMeters),
            data.steps,
            data.calorie / 1000
        )
    }

    private fun formatDistance(distanceMeters: Int): String {
        return String.format(Locale.US, "%.2fkm", distanceMeters / 1000.0)
    }

    private fun parseSportNotify(response: DeviceNotifyRsp): SportNotifyData? {
        val data = response.loadData ?: return null
        if (data.size < SPORT_NOTIFY_MIN_LENGTH) {
            XLog.tag(TAG).w("sport notify length invalid=${data.size}")
            return null
        }
        return SportNotifyData(
            status = readUnsignedBigEndian(data, 1, 1),
            durationSeconds = readUnsignedBigEndian(data, 2, 2),
            heartRate = readUnsignedBigEndian(data, 4, 1),
            steps = readUnsignedBigEndian(data, 5, 3),
            distanceMeters = readUnsignedBigEndian(data, 8, 3),
            calorie = readUnsignedBigEndian(data, 11, 3)
        )
    }

    private fun readUnsignedBigEndian(data: ByteArray, start: Int, length: Int): Int {
        var value = 0
        for (index in start until start + length) {
            value = (value shl 8) or (data[index].toInt() and 0xFF)
        }
        return value
    }

    override fun onResume() {
        super.onResume()
        BleOperateManager.getInstance().addSportDeviceListener(SPORT_NOTIFY_TYPE, sportNotifyListener)
    }

    override fun onDestroy() {
        BleOperateManager.getInstance().removeSportDeviceListener(SPORT_NOTIFY_TYPE)
        super.onDestroy()
    }

    private inner class SportNotifyListener : DeviceSportNotifyListener() {
        override fun onDataResponse(resultEntity: DeviceNotifyRsp?) {
            super.onDataResponse(resultEntity)
            if (resultEntity == null || resultEntity.status != BaseRspCmd.RESULT_OK) {
                return
            }
            val sportData = parseSportNotify(resultEntity) ?: return
            latestSportDurationSeconds = sportData.durationSeconds
            val message = formatSportNotifyMessage(sportData)
            XLog.tag(TAG).i(
                "sport notify status=${sportData.status}, duration=${sportData.durationSeconds}s, " +
                    "heartRate=${sportData.heartRate}, distance=${sportData.distanceMeters}m, " +
                    "steps=${sportData.steps}, calorie=${sportData.calorie}, message=$message"
            )
            runOnUiThread { message.showToast() }
        }
    }

    private data class SportNotifyData(
        val status: Int,
        val durationSeconds: Int,
        val heartRate: Int,
        val steps: Int,
        val distanceMeters: Int,
        val calorie: Int
    )

    companion object {
        private const val TAG = "Sport"
        private const val SPORT_NOTIFY_TYPE = 0x78
        private const val SPORT_NOTIFY_MIN_LENGTH = 14
        private const val MIN_SPORT_DURATION_SECONDS = 60
        private const val STATUS_START: Byte = 1
        private const val STATUS_STOP: Byte = 4
    }
}
