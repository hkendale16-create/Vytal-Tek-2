package com.qcwireless.sdksample.cache

import android.content.Context
import com.tencent.mmkv.MMKV

/**
 * MMKV Manager
 */
object MMKVManager {

    private const val KEY_LAST_CONNECTED_DEVICE_MAC = "last_connected_device_mac"
    
    private var mmkv: MMKV? = null
    
    /**
     * init MMKV
     */
    fun initialize(context: Context) {
        MMKV.initialize(context)
        mmkv = MMKV.defaultMMKV()
    }
    
    /**
     * get MMKV instance
     */
    fun getInstance(): MMKV {
        return mmkv ?: throw IllegalStateException("MMKV is not init")
    }
    
    // String 类型操作 / String type operations.
    fun putString(key: String, value: String) {
        getInstance().encode(key, value)
    }
    
    fun getString(key: String, defaultValue: String): String? {
        return getInstance().decodeString(key, defaultValue)
    }

    fun saveLastConnectedDeviceMac(mac: String?) {
        val deviceMac = mac.orEmpty().trim()
        if (deviceMac.isNotEmpty()) {
            putString(KEY_LAST_CONNECTED_DEVICE_MAC, deviceMac)
        }
    }

    fun getLastConnectedDeviceMac(): String {
        return getString(KEY_LAST_CONNECTED_DEVICE_MAC, "").orEmpty()
    }
    
    // Int 类型操作 / Int type operations.
    fun putInt(key: String, value: Int) {
        getInstance().encode(key, value)
    }
    
    fun getInt(key: String, defaultValue: Int): Int {
        return getInstance().decodeInt(key, defaultValue)
    }
    
    // Long 类型操作 / Long type operations.
    fun putLong(key: String, value: Long) {
        getInstance().encode(key, value)
    }
    
    fun getLong(key: String, defaultValue: Long): Long {
        return getInstance().decodeLong(key, defaultValue)
    }
    
    // Float 类型操作 / Float type operations.
    fun putFloat(key: String, value: Float) {
        getInstance().encode(key, value)
    }
    
    fun getFloat(key: String, defaultValue: Float): Float {
        return getInstance().decodeFloat(key, defaultValue)
    }
    
    // Boolean 类型操作 / Boolean type operations.
    fun putBoolean(key: String, value: Boolean) {
        getInstance().encode(key, value)
    }
    
    fun getBoolean(key: String, defaultValue: Boolean): Boolean {
        return getInstance().decodeBool(key, defaultValue)
    }
}
