package com.qcwireless.sdksample.activity

data class HomeDeviceMac(
    val value: String
) {
    val hasValue: Boolean = value.isNotEmpty()

    companion object {
        fun resolve(runtimeMac: String?, cachedMac: String?): HomeDeviceMac {
            val runtimeValue = runtimeMac.orEmpty().trim()
            if (runtimeValue.isNotEmpty()) {
                return HomeDeviceMac(runtimeValue)
            }
            return HomeDeviceMac(cachedMac.orEmpty().trim())
        }
    }
}
