package com.qcwireless.sdksample.activity

import android.os.Bundle
import com.oudmon.ble.base.communication.req.SimpleKeyReq
import com.oudmon.ble.base.communication.rsp.BaseRspCmd
import com.oudmon.ble.base.communication.Constants
import com.qcwireless.sdksample.R
import com.qcwireless.sdksample.annotation.BleIsConnected
import com.qcwireless.sdksample.databinding.ActivitySedentaryReminderBinding
import com.qcwireless.sdksample.ext.showToast

class SedentaryReminderActivity : BaseFunctionActivity() {
    private lateinit var binding: ActivitySedentaryReminderBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySedentaryReminderBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }

    override fun setupViews() {
        super.setupViews()
        binding.titleBar.tvTitle.text = getString(R.string.qc_text_0067)
        binding.fivDataSync.setOnClickListener { syncSedentaryReminder() }
        refreshSupportCache()
    }

    private fun isSedentarySupported(): Boolean {
        return ensureSupported(deviceSupport.supportLongSit)
    }

    @BleIsConnected
    private fun syncSedentaryReminder() {
        if (!isSedentarySupported()) {
            return
        }
        logBlePanelDetail(
            LOG_TAG,
            "[REQ]\naction=syncSedentaryReminder request=SimpleKeyReq CMD_GET_SIT_LONG"
        )
        commandHandle.executeReqCmd(SimpleKeyReq(Constants.CMD_GET_SIT_LONG)) { rsp ->
            val success = rsp.status == BaseRspCmd.RESULT_OK
            logBlePanelDetail(
                LOG_TAG,
                "[RSP]\naction=syncSedentaryReminder request=SimpleKeyReq success=$success status=${rsp.status}"
            )
        }
        getString(R.string.qc_text_0093).showToast()
    }

    companion object {
        private const val LOG_TAG = "Sedentary"
    }
}
