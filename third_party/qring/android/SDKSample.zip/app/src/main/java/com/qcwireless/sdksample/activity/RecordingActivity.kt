package com.qcwireless.sdksample.activity

import android.Manifest
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.MediaPlayer
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.View
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.elvishew.xlog.XLog
import com.oudmon.ble.base.bluetooth.BleOperateManager
import com.oudmon.ble.base.bluetooth.DeviceManager
import com.oudmon.ble.base.communication.ICommandResponse
import com.oudmon.ble.base.communication.rsp.DeviceNotifyRsp
import com.oudmon.ble.base.communication.rsp.DeviceSupportFunctionRsp
import com.oudmon.ble.base.recording.RecordingDeviceRecording
import com.oudmon.ble.base.recording.RecordingFileCountNotifyParser
import com.oudmon.ble.base.recording.RecordingPcmFormat
import com.oudmon.ble.base.recording.RecordingPcmImportListener
import com.oudmon.ble.base.recording.RecordingPcmImportManager
import com.qcwireless.sdksample.R
import com.qcwireless.sdksample.adapter.RecordingListAdapter
import com.qcwireless.sdksample.cache.DeviceFunctionSupport
import com.qcwireless.sdksample.databinding.ActivityRecordingBinding
import com.qcwireless.sdksample.ext.showToast
import com.qcwireless.sdksample.recording.SampleRecordingFileInfo
import com.qcwireless.sdksample.recording.SampleRecordingFileStore
import com.qcwireless.sdksample.recording.SampleRecordingItem
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

class RecordingActivity : BaseActivity() {
    private lateinit var binding: ActivityRecordingBinding
    private lateinit var adapter: RecordingListAdapter
    private lateinit var manager: RecordingPcmImportManager
    private lateinit var fileStore: SampleRecordingFileStore
    private lateinit var recordingSupport: DeviceSupportFunctionRsp
    private val playbackHandler = Handler(Looper.getMainLooper())
    private val importLock = Any()
    private var deviceRecordings: List<RecordingDeviceRecording> = emptyList()
    private var localFilesByName: Map<String, SampleRecordingFileInfo> = emptyMap()
    private var pendingImport: PendingRecordingImport? = null
    private var mediaPlayer: MediaPlayer? = null
    private var pcmAudioTrack: AudioTrack? = null
    private var pcmPlaybackThread: Thread? = null
    @Volatile
    private var pcmStopRequested = false
    private var pcmPlaybackDurationMillis = 0L
    private var pcmPlaybackStartOffsetMillis = 0L
    private var pcmPlaybackStartTimeMillis = 0L
    private var playerPrepared = false
    private var pendingSeekProgress: Int? = null
    private var pendingWifiAction: (() -> Unit)? = null
    private var hasImportableRecordings = false
    private var isOperationBusy = false
    private var pendingRecordingFileCountRefresh = false
    private var recordingFileCountNotifyRegistered = false

    private val recordingFileCountNotifyListener = ICommandResponse<DeviceNotifyRsp> { response ->
        val notify = RecordingFileCountNotifyParser.parse(response) ?: return@ICommandResponse
        XLog.i("Recording file count changed, count=${notify.fileCount}")
        runOnUiThread { refreshRecordingsFromFileCountNotify() }
    }

    private val importListener = object : RecordingPcmImportListener {
        override fun onRecordingsChanged(recordings: List<RecordingDeviceRecording>) {
            deviceRecordings = recordings
            refreshLocalFiles()
            renderRecordings()
        }

        override fun onImportStarted(recording: RecordingDeviceRecording, format: RecordingPcmFormat) {
            startSampleFileImport(recording, format)
        }

        override fun onPcmData(recording: RecordingDeviceRecording, data: ByteArray) {
            synchronized(importLock) {
                pendingImport?.takeIf { it.recording.fileName == recording.fileName }
                    ?.outputStream
                    ?.write(data)
            }
        }

        override fun onImportProgress(recording: RecordingDeviceRecording, percent: Int) {
            adapter.importingFileName = if (percent >= 100) null else recording.fileName
            adapter.importProgress = percent
            adapter.notifyDataSetChanged()
        }

        override fun onImportCompleted(recording: RecordingDeviceRecording) {
            completeSampleFileImport(recording)
        }

        override fun onBusyChanged(isBusy: Boolean) {
            isOperationBusy = isBusy
            binding.btnRefresh.isEnabled = !isBusy
            updateImportAllButton()
            adapter.operationsEnabled = !isBusy
            adapter.notifyDataSetChanged()
            if (!isBusy && pendingRecordingFileCountRefresh) {
                pendingRecordingFileCountRefresh = false
                manager.loadRecordings()
            }
        }

        override fun onError(recording: RecordingDeviceRecording?, message: String, cause: Throwable?) {
            adapter.importingFileName = null
            adapter.notifyDataSetChanged()
            cleanupPendingImport(recording?.fileName)
            showRecordingError(recording?.fileName, message, cause)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRecordingBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }

    override fun setupViews() {
        super.setupViews()
        binding.titleBar.tvTitle.text = getString(R.string.recording_title)
        recordingSupport = buildRecordingSupport()
        if (!recordingSupport.supportAudio) {
            getString(R.string.recording_error, "Device does not support recording").showToast()
            finish()
            return
        }
        binding.tvRecordingMode.text = getString(
            R.string.recording_mode,
            if (SAVE_RECORDING_AS_WAV) "WAV" else "PCM"
        )
        adapter = RecordingListAdapter(::seekPlayback)
        binding.rvRecordings.layoutManager = LinearLayoutManager(this)
        binding.rvRecordings.adapter = adapter
        adapter.addChildClickViewIds(
            R.id.btn_import_or_play,
            R.id.btn_copy_path,
            R.id.btn_share,
            R.id.btn_delete_device,
            R.id.btn_delete_local
        )
        adapter.setOnItemChildClickListener { _, view, position ->
            val item = adapter.data.getOrNull(position) ?: return@setOnItemChildClickListener
            when (view.id) {
                R.id.btn_import_or_play -> {
                    val local = item.localFile
                    if (local == null) ensureWifiPermission { manager.importRecording(item.deviceRecording) }
                    else togglePlayback(local)
                }
                R.id.btn_copy_path -> item.localFile?.let(::copyPath)
                R.id.btn_share -> item.localFile?.let(::shareRecording)
                R.id.btn_delete_device -> confirmDeleteDevice(item.deviceRecording)
                R.id.btn_delete_local -> item.localFile?.let(::confirmDeleteLocal)
            }
        }
        val deviceAddress = DeviceManager.getInstance().deviceAddress.orEmpty()
        val deviceName = DeviceManager.getInstance().deviceName.orEmpty()
        fileStore = SampleRecordingFileStore(this, deviceAddress)
        manager = RecordingPcmImportManager(
            context = this,
            deviceAddress = deviceAddress,
            deviceName = deviceName,
            support = recordingSupport,
            listener = importListener
        )
        binding.btnRefresh.setOnClickListener { manager.loadRecordings() }
        binding.btnImportAll.setOnClickListener {
            ensureWifiPermission {
                manager.importRecordings(
                    recordings = adapter.data.filter { it.localFile == null }.map { it.deviceRecording },
                    continueOnFailure = true
                )
            }
        }
        refreshLocalFiles()
        renderRecordings()
        registerRecordingFileCountNotify()
        manager.loadRecordings()
    }

    private fun buildRecordingSupport(): DeviceSupportFunctionRsp {
        val support = DeviceFunctionSupport.instance
        return DeviceSupportFunctionRsp().apply {
            supportAudio = support.supportAudio
            supportWifiImport = support.supportWifiImport
            supportAudioCoding = support.supportAudioCoding
            isOpusAudio = support.isOpusAudio
        }
    }

    private fun startSampleFileImport(recording: RecordingDeviceRecording, format: RecordingPcmFormat) {
        synchronized(importLock) {
            cleanupPendingImportLocked(recording.fileName)
            val pcmFile = if (SAVE_RECORDING_AS_WAV) {
                fileStore.tempPcmFile(recording)
            } else {
                fileStore.outputFile(recording, asWav = false)
            }
            pcmFile.parentFile?.mkdirs()
            pcmFile.delete()
            val finalFile = if (SAVE_RECORDING_AS_WAV) fileStore.outputFile(recording, asWav = true) else pcmFile
            if (SAVE_RECORDING_AS_WAV) finalFile.delete()
            pendingImport = PendingRecordingImport(
                recording = recording,
                format = format,
                pcmFile = pcmFile,
                finalFile = finalFile,
                outputStream = FileOutputStream(pcmFile, false)
            )
        }
    }

    private fun completeSampleFileImport(recording: RecordingDeviceRecording) {
        val completed = synchronized(importLock) {
            val pending = pendingImport?.takeIf { it.recording.fileName == recording.fileName } ?: return
            pending.outputStream.flush()
            pending.outputStream.close()
            pendingImport = null
            pending
        }
        try {
            val file = if (SAVE_RECORDING_AS_WAV) {
                fileStore.completeWav(completed.recording, completed.format, completed.pcmFile, completed.finalFile)
            } else {
                fileStore.completePcm(completed.recording, completed.format, completed.pcmFile)
            }
            localFilesByName = localFilesByName + (file.deviceFileName to file)
            adapter.importingFileName = null
            renderRecordings()
            XLog.i("Recording imported path=${file.absolutePath}")
            getString(R.string.recording_import_completed, file.absolutePath).showToast()
        } catch (error: Throwable) {
            completed.pcmFile.delete()
            completed.finalFile.delete()
            showRecordingError(recording.fileName, "Unable to save recording", error)
        }
    }

    private fun cleanupPendingImport(fileName: String?) {
        synchronized(importLock) { cleanupPendingImportLocked(fileName) }
    }

    private fun cleanupPendingImportLocked(fileName: String?) {
        val pending = pendingImport ?: return
        if (fileName != null && pending.recording.fileName != fileName) return
        runCatching { pending.outputStream.close() }
        pending.pcmFile.delete()
        pending.finalFile.delete()
        pendingImport = null
    }

    private fun refreshLocalFiles() {
        if (!::fileStore.isInitialized) return
        localFilesByName = fileStore.localFiles().associateBy { it.deviceFileName }
    }

    private fun renderRecordings() {
        val deviceNames = deviceRecordings.map { it.fileName }.toSet()
        val items = deviceRecordings.map { recording ->
            SampleRecordingItem(recording, localFilesByName[recording.fileName])
        } + localFilesByName.values
            .filterNot { it.deviceFileName in deviceNames }
            .map { file ->
                SampleRecordingItem(
                    RecordingDeviceRecording(
                        id = -1,
                        fileName = file.deviceFileName,
                        sourceSizeBytes = file.sizeBytes,
                        durationMillis = file.durationMillis,
                        createTimeMillis = File(file.absolutePath).lastModified(),
                        codec = 0,
                        sampleRateHz = file.sampleRateHz,
                        channels = file.channels,
                        bitsPerSample = file.bitsPerSample
                    ),
                    file
                )
            }
        adapter.setList(items)
        binding.tvEmpty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        hasImportableRecordings = items.any { it.localFile == null && it.deviceRecording.id >= 0 }
        updateImportAllButton()
    }

    private fun registerRecordingFileCountNotify() {
        if (recordingFileCountNotifyRegistered) return
        BleOperateManager.getInstance().addOutDeviceListener(
            DeviceNotifyRsp.TYPE_RECORD_FILE_COUNT,
            recordingFileCountNotifyListener
        )
        recordingFileCountNotifyRegistered = true
    }

    private fun unregisterRecordingFileCountNotify() {
        if (!recordingFileCountNotifyRegistered) return
        BleOperateManager.getInstance().removeOutDeviceListener(DeviceNotifyRsp.TYPE_RECORD_FILE_COUNT)
        recordingFileCountNotifyRegistered = false
    }

    private fun refreshRecordingsFromFileCountNotify() {
        if (!::manager.isInitialized) return
        if (isOperationBusy) {
            pendingRecordingFileCountRefresh = true
            return
        }
        manager.loadRecordings()
    }

    private fun ensureWifiPermission(action: () -> Unit) {
        if (!requiresWifiPermission()) {
            action()
            return
        }
        val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.NEARBY_WIFI_DEVICES
        } else {
            Manifest.permission.ACCESS_FINE_LOCATION
        }
        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
            action()
        } else {
            pendingWifiAction = action
            requestPermissions(arrayOf(permission), REQUEST_WIFI_PERMISSION)
        }
    }

    private fun requiresWifiPermission(): Boolean {
        return recordingSupport.supportWifiImport && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
    }

    private fun updateImportAllButton() {
        binding.btnImportAll.visibility = if (hasImportableRecordings) View.VISIBLE else View.GONE
        binding.btnImportAll.isEnabled = hasImportableRecordings && !isOperationBusy
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQUEST_WIFI_PERMISSION) return
        val action = pendingWifiAction
        pendingWifiAction = null
        if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            action?.invoke()
        } else {
            getString(R.string.recording_permission_denied).showToast()
        }
    }

    private fun togglePlayback(file: SampleRecordingFileInfo, seekProgress: Int? = null) {
        if (seekProgress == null &&
            adapter.playingPath == file.absolutePath &&
            playerPrepared &&
            isPlaybackActive()
        ) {
            releasePlayer()
            return
        }
        releasePlayer()
        adapter.playingPath = file.absolutePath
        adapter.playbackProgress = 0
        adapter.notifyDataSetChanged()
        if (isPcmRecording(file)) {
            startPcmPlayback(file, seekProgress)
        } else {
            startMediaPlayback(file, seekProgress)
        }
    }

    private fun startMediaPlayback(file: SampleRecordingFileInfo, seekProgress: Int?) {
        pendingSeekProgress = seekProgress
        val player = MediaPlayer()
        mediaPlayer = player
        try {
            player.setDataSource(file.absolutePath)
            player.setOnPreparedListener {
                if (mediaPlayer !== it) return@setOnPreparedListener
                playerPrepared = true
                pendingSeekProgress?.let { progress ->
                    val position = (it.duration * progress / 1000f).toInt()
                    it.seekTo(position)
                }
                pendingSeekProgress = null
                it.start()
                schedulePlaybackProgress()
            }
            player.setOnCompletionListener { releasePlayer() }
            player.setOnErrorListener { _, what, extra ->
                showRecordingError(file.deviceFileName, "Playback failed: $what/$extra")
                releasePlayer()
                true
            }
            player.prepareAsync()
        } catch (error: Throwable) {
            showRecordingError(file.deviceFileName, "Playback failed", error)
            releasePlayer()
        }
    }

    private fun startPcmPlayback(file: SampleRecordingFileInfo, seekProgress: Int?) {
        try {
            val source = File(file.absolutePath)
            val sampleRate = file.sampleRateHz.takeIf { it > 0 } ?: DEFAULT_PCM_SAMPLE_RATE
            val channelCount = file.channels.takeIf { it > 0 } ?: DEFAULT_PCM_CHANNELS
            val bitsPerSample = file.bitsPerSample.takeIf { it > 0 } ?: DEFAULT_PCM_BITS_PER_SAMPLE
            val channelMask = when (channelCount) {
                1 -> AudioFormat.CHANNEL_OUT_MONO
                2 -> AudioFormat.CHANNEL_OUT_STEREO
                else -> throw IllegalArgumentException("Unsupported PCM channels: $channelCount")
            }
            val encoding = when (bitsPerSample) {
                8 -> AudioFormat.ENCODING_PCM_8BIT
                16 -> AudioFormat.ENCODING_PCM_16BIT
                24 -> AudioFormat.ENCODING_PCM_24BIT_PACKED
                else -> throw IllegalArgumentException("Unsupported PCM bit depth: $bitsPerSample")
            }
            val bytesPerFrame = channelCount * (bitsPerSample / 8)
            val durationMillis = file.durationMillis.takeIf { it > 0L }
                ?: calculatePcmDurationMillis(source.length(), sampleRate, bytesPerFrame)
            val startOffsetBytes = calculatePcmStartOffsetBytes(
                fileSizeBytes = source.length(),
                progress = seekProgress ?: 0,
                durationMillis = durationMillis,
                sampleRate = sampleRate,
                bytesPerFrame = bytesPerFrame
            )
            val minBufferSize = AudioTrack.getMinBufferSize(sampleRate, channelMask, encoding)
            if (minBufferSize <= 0) {
                throw IllegalArgumentException("Invalid PCM playback buffer: $minBufferSize")
            }
            val playbackBufferSize = alignPcmBufferSize(
                minBufferSize.coerceAtLeast(DEFAULT_PCM_BUFFER_SIZE),
                bytesPerFrame
            )
            val audioTrack = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setSampleRate(sampleRate)
                        .setChannelMask(channelMask)
                        .setEncoding(encoding)
                        .build()
                )
                .setBufferSizeInBytes(playbackBufferSize)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            pcmAudioTrack = audioTrack
            pcmStopRequested = false
            pcmPlaybackDurationMillis = durationMillis
            pcmPlaybackStartOffsetMillis =
                calculatePcmDurationMillis(startOffsetBytes, sampleRate, bytesPerFrame)
            pcmPlaybackStartTimeMillis = SystemClock.elapsedRealtime()
            playerPrepared = true
            val thread = Thread({
                playPcmFile(file, source, audioTrack, startOffsetBytes, playbackBufferSize, bytesPerFrame)
            }, "RecordingPcmPlayback")
            pcmPlaybackThread = thread
            thread.start()
            schedulePlaybackProgress()
        } catch (error: Throwable) {
            showRecordingError(file.deviceFileName, "Playback failed", error)
            releasePlayer()
        }
    }

    private fun playPcmFile(
        file: SampleRecordingFileInfo,
        source: File,
        audioTrack: AudioTrack,
        startOffsetBytes: Long,
        minBufferSize: Int,
        bytesPerFrame: Int
    ) {
        try {
            var submittedFrames = 0L
            FileInputStream(source).use { input ->
                input.channel.position(startOffsetBytes)
                val buffer = ByteArray(minBufferSize)
                audioTrack.play()
                while (!pcmStopRequested) {
                    val read = input.read(buffer)
                    if (read <= 0) break
                    var written = 0
                    while (written < read && !pcmStopRequested) {
                        val result = audioTrack.write(buffer, written, read - written)
                        if (result < 0) throw IllegalStateException("AudioTrack write failed: $result")
                        if (result == 0) {
                            Thread.sleep(10L)
                        } else {
                            written += result
                            submittedFrames += result / bytesPerFrame
                        }
                    }
                }
                if (!pcmStopRequested) waitForPcmPlaybackComplete(audioTrack, submittedFrames)
            }
            playbackHandler.post {
                if (pcmAudioTrack === audioTrack && !pcmStopRequested) releasePlayer()
            }
        } catch (error: Throwable) {
            playbackHandler.post {
                if (pcmAudioTrack === audioTrack) {
                    showRecordingError(file.deviceFileName, "Playback failed", error)
                    releasePlayer()
                }
            }
        }
    }

    private fun waitForPcmPlaybackComplete(audioTrack: AudioTrack, submittedFrames: Long) {
        while (!pcmStopRequested &&
            audioTrack.playState == AudioTrack.PLAYSTATE_PLAYING &&
            audioTrack.playbackHeadPosition.toLong() < submittedFrames
        ) {
            Thread.sleep(50L)
        }
    }

    private fun seekPlayback(item: SampleRecordingItem, progress: Int) {
        val file = item.localFile ?: return
        if (adapter.playingPath != file.absolutePath || !hasPlaybackSession()) {
            togglePlayback(file, progress)
            return
        }
        if (isPcmRecording(file)) {
            togglePlayback(file, progress)
            return
        }
        if (!playerPrepared) {
            pendingSeekProgress = progress
            return
        }
        val player = mediaPlayer ?: return
        val duration = player.duration.takeIf { it > 0 } ?: return
        player.seekTo((duration * progress / 1000f).toInt())
    }

    private fun schedulePlaybackProgress() {
        playbackHandler.removeCallbacksAndMessages(null)
        playbackHandler.post(object : Runnable {
            override fun run() {
                if (!playerPrepared) return
                adapter.playbackProgress = currentPlaybackProgress()
                adapter.notifyDataSetChanged()
                if (isPlaybackActive()) playbackHandler.postDelayed(this, 500L)
            }
        })
    }

    private fun currentPlaybackProgress(): Int {
        mediaPlayer?.let { player ->
            val duration = player.duration
            return if (duration > 0) {
                (player.currentPosition * 1000L / duration).toInt().coerceIn(0, 1000)
            } else 0
        }
        val duration = pcmPlaybackDurationMillis
        if (duration <= 0L) return 0
        val position = pcmPlaybackStartOffsetMillis +
            (SystemClock.elapsedRealtime() - pcmPlaybackStartTimeMillis)
        return (position * 1000L / duration).toInt().coerceIn(0, 1000)
    }

    private fun hasPlaybackSession(): Boolean {
        return mediaPlayer != null || pcmAudioTrack != null
    }

    private fun isPlaybackActive(): Boolean {
        return mediaPlayer?.isPlaying == true ||
            pcmAudioTrack?.playState == AudioTrack.PLAYSTATE_PLAYING
    }

    private fun isPcmRecording(file: SampleRecordingFileInfo): Boolean {
        return file.mimeType.equals("audio/pcm", ignoreCase = true) ||
            file.absolutePath.endsWith(".pcm", ignoreCase = true)
    }

    private fun calculatePcmDurationMillis(fileSizeBytes: Long, sampleRate: Int, bytesPerFrame: Int): Long {
        if (sampleRate <= 0 || bytesPerFrame <= 0) return 0L
        return fileSizeBytes * 1000L / (sampleRate.toLong() * bytesPerFrame)
    }

    private fun calculatePcmStartOffsetBytes(
        fileSizeBytes: Long,
        progress: Int,
        durationMillis: Long,
        sampleRate: Int,
        bytesPerFrame: Int
    ): Long {
        if (durationMillis <= 0L || sampleRate <= 0 || bytesPerFrame <= 0) return 0L
        val targetMillis = durationMillis * progress.coerceIn(0, 1000) / 1000L
        val frames = targetMillis * sampleRate / 1000L
        return (frames * bytesPerFrame).coerceIn(0L, fileSizeBytes).let {
            it - (it % bytesPerFrame)
        }
    }

    private fun alignPcmBufferSize(size: Int, bytesPerFrame: Int): Int {
        if (bytesPerFrame <= 0) return size
        val remainder = size % bytesPerFrame
        return if (remainder == 0) size else size + bytesPerFrame - remainder
    }

    private fun copyPath(file: SampleRecordingFileInfo) {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("recording_path", file.absolutePath))
        getString(R.string.recording_path_copied).showToast()
    }

    private fun shareRecording(file: SampleRecordingFileInfo) {
        val uri = FileProvider.getUriForFile(
            this,
            "$packageName.recording.files",
            File(file.absolutePath)
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = file.mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            clipData = ClipData.newUri(contentResolver, file.deviceFileName, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, getString(R.string.recording_share)))
    }

    private fun confirmDeleteDevice(recording: RecordingDeviceRecording) {
        AlertDialog.Builder(this)
            .setMessage(R.string.recording_delete_device_confirm)
            .setNegativeButton(R.string.recording_cancel, null)
            .setPositiveButton(R.string.recording_delete) { _, _ -> manager.deleteDeviceRecording(recording) }
            .show()
    }

    private fun confirmDeleteLocal(file: SampleRecordingFileInfo) {
        AlertDialog.Builder(this)
            .setMessage(R.string.recording_delete_local_confirm)
            .setNegativeButton(R.string.recording_cancel, null)
            .setPositiveButton(R.string.recording_delete) { _, _ ->
                if (adapter.playingPath == file.absolutePath) releasePlayer()
                if (fileStore.delete(file)) {
                    refreshLocalFiles()
                    renderRecordings()
                } else {
                    showRecordingError(file.deviceFileName, "Unable to delete local recording")
                }
            }
            .show()
    }

    private fun showRecordingError(fileName: String?, message: String, cause: Throwable? = null) {
        XLog.e("Recording error file=$fileName message=$message", cause)
        getString(R.string.recording_error, message).showToast()
    }

    private fun releasePlayer() {
        playbackHandler.removeCallbacksAndMessages(null)
        pcmStopRequested = true
        runCatching { mediaPlayer?.stop() }
        runCatching { mediaPlayer?.release() }
        runCatching { pcmAudioTrack?.pause() }
        runCatching { pcmAudioTrack?.flush() }
        runCatching { pcmAudioTrack?.release() }
        mediaPlayer = null
        pcmAudioTrack = null
        pcmPlaybackThread = null
        pcmPlaybackDurationMillis = 0L
        pcmPlaybackStartOffsetMillis = 0L
        pcmPlaybackStartTimeMillis = 0L
        playerPrepared = false
        pendingSeekProgress = null
        if (::adapter.isInitialized) {
            adapter.playingPath = null
            adapter.playbackProgress = 0
            adapter.notifyDataSetChanged()
        }
    }

    override fun onPause() {
        unregisterRecordingFileCountNotify()
        releasePlayer()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        if (::manager.isInitialized) registerRecordingFileCountNotify()
    }

    override fun onDestroy() {
        unregisterRecordingFileCountNotify()
        releasePlayer()
        cleanupPendingImport(null)
        if (::manager.isInitialized) manager.release()
        super.onDestroy()
    }

    private data class PendingRecordingImport(
        val recording: RecordingDeviceRecording,
        val format: RecordingPcmFormat,
        val pcmFile: File,
        val finalFile: File,
        val outputStream: FileOutputStream
    )

    companion object {
        private const val SAVE_RECORDING_AS_WAV = false
        private const val REQUEST_WIFI_PERMISSION = 501
        private const val DEFAULT_PCM_SAMPLE_RATE = 16_000
        private const val DEFAULT_PCM_CHANNELS = 1
        private const val DEFAULT_PCM_BITS_PER_SAMPLE = 16
        private const val DEFAULT_PCM_BUFFER_SIZE = 4096
    }
}
