package com.qcwireless.sdksample.activity

import android.os.Bundle
import android.text.InputType
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import androidx.appcompat.app.AlertDialog
import com.elvishew.xlog.XLog
import com.oudmon.ble.base.bluetooth.BleOperateManager
import com.oudmon.ble.base.communication.ICommandResponse
import com.oudmon.ble.base.communication.req.SimpleKeyReq
import com.oudmon.ble.base.communication.rsp.BaseRspCmd
import com.oudmon.ble.base.communication.Constants
import com.oudmon.ble.base.communication.entity.BleStepDetails
import com.oudmon.ble.base.communication.rsp.TodaySportDataRsp
import com.oudmon.ble.base.util.ActivityScoreUtils
import com.qcwireless.sdksample.R
import com.qcwireless.sdksample.annotation.BleIsConnected
import com.qcwireless.sdksample.databinding.ActivityStepsBinding
import com.qcwireless.sdksample.ext.dp
import com.qcwireless.sdksample.ext.showToast
import com.qcwireless.sdksample.log.BluetoothLogManager

class StepsActivity : BaseFunctionActivity() {
    private lateinit var binding: ActivityStepsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStepsBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }

    override fun setupViews() {
        super.setupViews()
        binding.titleBar.tvTitle.text = getString(R.string.qc_text_0058)
        binding.fivSyncTodaySteps.setOnClickListener { syncTodaySteps() }
        binding.fivActivityScore.setOnClickListener { showActivityScoreDialog() }
        bindHealthQueryActions<List<BleStepDetails>>(
            todayView = binding.fivTodayData,
            singleDayView = binding.fivSingleDayData,
            rangeView = binding.fivRangeData,
            title = getString(R.string.qc_text_0058),
            supportCheck = { isStepsSupported() },
            todayAction = { callback ->
                BleOperateManager.getInstance().getTodayStepDetail(callback)
            },
            singleDayAction = { dayIndex, callback ->
                BleOperateManager.getInstance().getStepDetail(dayIndex, callback)
            },
            rangeAction = { startDayIndex, count, callback ->
                BleOperateManager.getInstance().getStepDetails(startDayIndex, count, callback)
            }
        )
        refreshSupportCache()
    }

    private fun isStepsSupported(): Boolean {
        return ensureSupported(true)
    }

    private fun showActivityScoreDialog() {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            hint = getString(R.string.activity_score_age_hint)
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20.dp, 12.dp, 20.dp, 12.dp)
            addView(input)
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.activity_score_dialog_title)
            .setView(container)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val age = input.text?.toString()?.trim()?.toIntOrNull()
                if (age == null || age < 0) {
                    getString(R.string.activity_score_invalid_age).showToast()
                    return@setPositiveButton
                }
                getActivityScore(age)
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    @BleIsConnected
    private fun getActivityScore(age: Int) {
        val actionName = getString(R.string.activity_score_get)
        logActivityScore("[REQ]\naction=$actionName request=SimpleKeyReq(CMD_GET_STEP_TODAY) age=$age")
        commandHandle.executeReqCmd(
            SimpleKeyReq(Constants.CMD_GET_STEP_TODAY),
            ICommandResponse<TodaySportDataRsp> { rsp ->
                if (rsp.status == BaseRspCmd.RESULT_OK) {
                    val steps = rsp.sportTotal?.totalSteps ?: 0
                    val score = ActivityScoreUtils.calculateActivityScore(steps, age)
                    val message = getString(R.string.activity_score_result, score, steps, age)
                    logActivityScore("[RSP]\naction=$actionName success=true status=${rsp.status} $message")
                    message.showToast()
                } else {
                    val message = getString(R.string.activity_score_sync_failed, rsp.status)
                    logActivityScore("[RSP]\naction=$actionName success=false status=${rsp.status} message=$message")
                    message.showToast()
                }
            }
        )
    }

    private fun logActivityScore(detail: String) {
        XLog.tag("Steps").d(detail)
        BluetoothLogManager.addExternalLog(detail)
    }

    @BleIsConnected
    private fun syncTodaySteps() {
        if (!isStepsSupported()) {
            return
        }
        commandHandle.executeReqCmd(SimpleKeyReq(Constants.CMD_GET_STEP_TODAY)) { rsp ->
            if (rsp.status == BaseRspCmd.RESULT_OK) {
                XLog.tag("Steps").d("sync today steps success")
            }
        }
        getString(R.string.qc_text_0093).showToast()
    }
}
