package com.qcwireless.sdksample.activity

import android.content.Context
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import com.oudmon.ble.base.communication.req.PressureSettingReq
import com.qcwireless.sdksample.R

data class PressureSettingDialogState(
    val isEnabled: Boolean,
    val supportsInterval: Boolean,
    val minInterval: Int,
    val intervalOptions: List<Int>,
    val selectedIntervalIndex: Int
) {
    val selectedInterval: Int?
        get() = intervalOptions.getOrNull(selectedIntervalIndex)

    val intervalLabels: List<String>
        get() = intervalOptions.map { "$it min" }

    companion object {
        fun build(
            isEnabled: Boolean,
            supportsInterval: Boolean,
            minInterval: Int,
            currentInterval: Int
        ): PressureSettingDialogState {
            val intervalOptions = if (supportsInterval) {
                PressureIntervalOptions.build(minInterval).toList()
            } else {
                emptyList()
            }
            val selectedIntervalIndex = if (intervalOptions.isEmpty()) {
                -1
            } else {
                intervalOptions.indexOf(currentInterval).takeIf { it >= 0 } ?: 0
            }

            return PressureSettingDialogState(
                isEnabled = isEnabled,
                supportsInterval = supportsInterval,
                minInterval = minInterval,
                intervalOptions = intervalOptions,
                selectedIntervalIndex = selectedIntervalIndex
            )
        }
    }
}

fun AppCompatActivity.showPressureSettingDialog(
    isEnabled: Boolean,
    supportsInterval: Boolean,
    minInterval: Int,
    currentInterval: Int,
    onConfirm: (isEnabled: Boolean, minInterval: Int, interval: Int?) -> Unit
) {
    val state = PressureSettingDialogState.build(
        isEnabled = isEnabled,
        supportsInterval = supportsInterval,
        minInterval = minInterval,
        currentInterval = currentInterval
    )
    val contentView = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(24), dp(8), dp(24), 0)
    }
    val enableSwitch = SwitchCompat(this).apply {
        text = getString(R.string.pressure_setting_enable)
        isChecked = state.isEnabled
        setPadding(0, dp(8), 0, dp(8))
    }
    contentView.addView(
        enableSwitch,
        LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
    )

    var selectedIntervalProvider: () -> Int? = { null }
    if (state.supportsInterval) {
        val intervalLabel = TextView(this).apply {
            text = getString(R.string.pressure_setting_interval)
            this.isEnabled = state.isEnabled
        }
        contentView.addView(
            intervalLabel,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(12)
            }
        )

        val intervalSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@showPressureSettingDialog,
                android.R.layout.simple_spinner_item,
                state.intervalOptions.map { getString(R.string.pressure_setting_interval_value, it) }
            ).also {
                it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            }
            setSelection(state.selectedIntervalIndex)
            this.isEnabled = state.isEnabled
        }
        contentView.addView(
            intervalSpinner,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )
        enableSwitch.setOnCheckedChangeListener { _, checked ->
            intervalLabel.isEnabled = checked
            intervalSpinner.isEnabled = checked
        }
        selectedIntervalProvider = {
            state.intervalOptions.getOrNull(intervalSpinner.selectedItemPosition)
        }
    }

    AlertDialog.Builder(this)
        .setTitle(getString(R.string.pressure_setting_title))
        .setView(contentView)
        .setPositiveButton(android.R.string.ok) { _, _ ->
            onConfirm(enableSwitch.isChecked, state.minInterval, selectedIntervalProvider())
        }
        .setNegativeButton(android.R.string.cancel, null)
        .show()
}

fun createPressureSettingWriteRequest(
    isEnabled: Boolean,
    minInterval: Int,
    interval: Int?
): PressureSettingReq {
    if (interval == null) {
        PressureSettingReq.clearCachedIntervalSettings()
        return PressureSettingReq.getWriteInstance(isEnabled)
    }

    PressureSettingReq.cacheIntervalSettings(minInterval, interval)
    return PressureSettingReq.getWriteInstance(isEnabled).also {
        PressureSettingReq.clearCachedIntervalSettings()
    }
}

private fun Context.dp(value: Int): Int {
    return (value * resources.displayMetrics.density + 0.5f).toInt()
}
