package com.qcwireless.sdksample.activity

import com.oudmon.ble.base.communication.req.NotificationEventNotifyReq

object NotificationEventOptions {
    data class Option(val label: String, val value: Int) {
        override fun toString(): String = label
    }

    val priorities = listOf(0, 1, 3, 5, 10).toOptions()
    val loopCounts = listOf(1, 3, 5, 10).toOptions()
    val activeDurations = listOf(1, 5, 10, 20, 50, 127).toOptions()
    val pauseDurations = listOf(0, 5, 10, 20, 50).toOptions()

    val lightModes = listOf(
        Option("0 NULL", NotificationEventNotifyReq.LIGHT_NONE),
        Option("1 Stop", NotificationEventNotifyReq.LIGHT_STOP),
        Option("2 Green", NotificationEventNotifyReq.LIGHT_GREEN),
        Option("3 Red", NotificationEventNotifyReq.LIGHT_RED)
    )

    val vibrationModes = listOf(
        Option("0 NULL", NotificationEventNotifyReq.VIBRATION_NONE),
        Option("1 Stop", NotificationEventNotifyReq.VIBRATION_STOP),
        Option("2 Start", NotificationEventNotifyReq.VIBRATION_START)
    )

    private fun List<Int>.toOptions(): List<Option> {
        return map { Option(it.toString(), it) }
    }
}
