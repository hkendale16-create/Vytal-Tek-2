package com.qcwireless.sdksample.activity

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.util.Log
import androidx.core.app.ActivityCompat
import com.google.gson.Gson
import com.hjq.permissions.OnPermissionCallback
import com.hjq.permissions.XXPermissions
import com.oudmon.ble.base.bean.SleepDisplay
import com.oudmon.ble.base.bluetooth.BleAction
import com.oudmon.ble.base.bluetooth.BleOperateManager
import com.oudmon.ble.base.bluetooth.DeviceManager
import com.oudmon.ble.base.bluetooth.ListenerKey
import com.oudmon.ble.base.communication.CommandHandle
import com.oudmon.ble.base.communication.ICommandResponse
import com.oudmon.ble.base.communication.ILargeDataLaunchSleepResponse
import com.oudmon.ble.base.communication.ILargeDataSleepResponse
import com.oudmon.ble.base.communication.LargeDataHandler
import com.oudmon.ble.base.communication.bigData.AlarmNewEntity
import com.oudmon.ble.base.communication.bigData.IIntervalTemperatureCallback
import com.oudmon.ble.base.communication.bigData.IntervalBloodOxygenEntity
import com.oudmon.ble.base.communication.bigData.bean.IntervalTemperatureEntity
import com.oudmon.ble.base.communication.req.BloodOxygenSettingReq
import com.oudmon.ble.base.communication.req.BluetoothCloseReq
import com.oudmon.ble.base.communication.req.PhoneIdReq
import com.oudmon.ble.base.communication.req.StartHeartRateReq
import com.oudmon.ble.base.communication.req.TouchControlReq
import com.oudmon.ble.base.communication.responseImpl.DeviceNotifyListener
import com.oudmon.ble.base.communication.rsp.BaseRspCmd
import com.oudmon.ble.base.communication.rsp.BloodOxygenSettingRsp
import com.oudmon.ble.base.communication.rsp.BluetoothCloseRsp
import com.oudmon.ble.base.communication.rsp.DeviceNotifyRsp
import com.oudmon.ble.base.communication.rsp.PhoneIdRsp
import com.oudmon.ble.base.communication.rsp.SleepNewProtoResp
import com.oudmon.ble.base.communication.rsp.StopHeartRateRsp
import com.oudmon.ble.base.communication.utils.BLEDataFormatUtils
import com.oudmon.ble.base.util.DateUtil
import com.qcwireless.sdksample.utils.BluetoothUtils
import com.qcwireless.sdksample.app.MyApplication
import com.qcwireless.sdksample.Test
import com.qcwireless.sdksample.databinding.ActivityMainBinding
import com.qcwireless.sdksample.ext.setOnClickListener
import com.qcwireless.sdksample.ext.startKtxActivity
import com.qcwireless.sdksample.utils.hasBluetooth
import com.qcwireless.sdksample.utils.requestAllPermission
import com.qcwireless.sdksample.utils.requestBluetoothPermission
import com.qcwireless.sdksample.utils.requestLocationPermission

class MainActivity : BaseActivity() {
    private lateinit var binding: ActivityMainBinding
    private val test = Test()
    private lateinit var myDeviceNotifyListener: MyDeviceNotifyListener

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        initView()
    }

    private fun initView() {
        setOnClickListener(binding.tvScan) {
            requestLocationPermission(this@MainActivity, PermissionCallback())
        }

        myDeviceNotifyListener = MyDeviceNotifyListener()

        binding.run {
            tvName.text = DeviceManager.getInstance().deviceName
            val connect = BleOperateManager.getInstance().isConnected
            tvConnect.text = connect.toString()

            setOnClickListener(
                btnSetTime,
                btnFindWatch,
                btnBattery,
                btnTimeUnit,
                btnMsgTest,
                btnAlarmRead,
                btnAlarmWrite,
                btnSyncBloodoxygen,
                btnTakePicture,
                btnMusic,
                btnCall,
                btnTarget,
                tvReconnect,
                tvDisconnect,
                btnWatchFace,
                btnSleep,
                btnSleepCalc,
                heart1,
                heart2,
                heart3,
                push1,
                push2,
                temperature1,
                temperature2,
                userprofile1,
                userprofile2,
                addListener1,
                addListener2,
                addListener3,
                ota,
                bt,
                btnPpg,
                btnSport,
                pressure1,
                pressure2,
                btnOneKey,
                tvTouch,
                btnIntervalOxygen,
                btnIntervalOxygenAdd,
                btnUserId,
                btnUserIdWrite,
                btnTemperatureRead,
                btnTemperatureMeasureControl,
                btnCloseBlueTooth,
                btnNewSleep,
                btnShutdown,
                btnHeartRateRead,
                btnHeartRateWrite,
                btnPalmScreenRead,
                btnPalmScreenWrite,
                btnIntervalHeart,
            ) {
                when (this) {
                    tvReconnect -> {
                        BleOperateManager.getInstance()
                            .connectDirectly(DeviceManager.getInstance().deviceAddress)
                    }

                    tvDisconnect -> {
                        BleOperateManager.getInstance().unBindDevice()
                    }

                    btnSetTime -> {
                        test.setTime()
                    }

                    btnFindWatch -> {
//                        test.findPhone()
//                        BleOperateManager.getInstance().manualModeHrv{resultEntity -> Log.i("11111", "---------pressure" + resultEntity.value + "---"+resultEntity.rri)}
                    }

                    btnBattery -> {
                        test.battery
                    }

                    btnTimeUnit -> {
                        test.readMetricAndTimeFormat()
                    }

                    btnMsgTest -> {
                        test.pushMsg()
                    }

                    btnAlarmRead -> {
                        test.readAlarm()
                    }

                    btnAlarmWrite -> {
                        val list = mutableListOf<AlarmNewEntity.AlarmBean>()
                        val bean = AlarmNewEntity.AlarmBean()
                        bean.content = "1234"
                        bean.min = DateUtil().todayMin + 1
                        bean.repeatAndEnable = 0xff
                        bean.alarmLength = 4 + bean.content.encodeToByteArray().size
                        list.add(bean)
                        val entity = AlarmNewEntity()
                        entity.total = 1
                        entity.data = list
                        test.writeAlar(entity)
                    }

                    btnSyncBloodoxygen -> {
                        test.bloodOxygen()
                    }

                    btnTakePicture -> {
                        test.takePicture()
                    }

                    btnMusic -> {
                        test.music()
                    }

                    btnCall -> {
                        test.call()
                    }

                    btnTarget -> {
                        test.setTarget()
                    }

                    btnWatchFace -> {
                        test.watchFace()
                    }

                    btnSleep -> {
                        test.sleep()
                    }

                    btnSleepCalc -> {
//                        test.newSleep()
                        test.contactList()
                    }

                    heart1 -> {
//                        test.heart()
                        test.heartSync()
//                        LargeDataHandler.getInstance().syncManualHeartRateList(
//                            0
//                        ) {
//                            Log.i("",it.index.toString())
//                            Log.i("",it.data.size.toString())
//                        }

                    }

                    heart2 -> {
                        test.bp()
                    }

                    heart3 -> {
                        test.spo2()
                    }

                    pressure1 -> {
                        test.pressure()
                    }

                    pressure2 -> {
                        test.hrv()
                    }

                    push1 -> {
                        test.push1()
                    }

                    push2 -> {
                        test.push2()
                    }

                    temperature1 -> {
                        test.registerTempCallback()
                        test.syncAutoTemperature()
                    }

                    temperature2 -> {
                        test.syncManual()
                    }

                    userprofile1 -> {
                        test.setUserProfile()
                    }

                    userprofile2 -> {
                        test.getUserProfile()
                    }

                    addListener1 -> {
                        BleOperateManager.getInstance()
                            .addOutDeviceListener(ListenerKey.Heart, myDeviceNotifyListener)
                    }

                    addListener2 -> {
                        BleOperateManager.getInstance().removeNotifyListener(ListenerKey.Heart)
                    }

                    addListener3 -> {
                        BleOperateManager.getInstance().removeNotifyListener(ListenerKey.All)
                    }

                    ota -> {
                        startKtxActivity<OtaActivity>()
//                        BleOperateManager.getInstance().ringCalibration(false
//                        ) {
//                            Log.i("11119998",it.success.toString())
//                        }
                    }

                    bt -> {
                        BleOperateManager.getInstance().ringCalibration(
                            true
                        ) {
                            Log.i("11119999", it.success.toString())
                        }
//                        // 获取 BT 的地址和名称 / Get the BT address and name.
//                        LargeDataHandler.getInstance().syncClassicBluetooth {
//                            // 返回 BT 的地址和名称 / Return the BT address and name.
//                        }
//                        // 查询系统蓝牙是否已绑定这个地址 / Check whether system Bluetooth has bonded this address.
//                        val device = BleOperateManager.getInstance()
//                            .getMacSystemBond(String mac)
//                        // 如果 device 不为 null，代表已经绑定，调用连接 / If device is not null, it is bonded; connect it.
//                        //rtk
//                        BleOperateManager.getInstance().connectRtkSPP(device)
//                        //bk
//                        BleOperateManager.getInstance().createBondBlueTooth(device)
//                        // 如果没有绑定，device == null，启动经典蓝牙扫描，可自行实现 / If not bonded and device == null, start classic Bluetooth scanning; implement as needed.
//                        BleOperateManager.getInstance().classicBluetoothStartScan()
//                        // 监听系统经典蓝牙扫描广播：BluetoothDevice.ACTION_FOUND / Listen for the system classic Bluetooth scan broadcast: BluetoothDevice.ACTION_FOUND.
//                        // 通过返回的设备 MAC 和手表给出的地址进行匹配 / Match the returned device MAC with the watch-provided address.
//                        BleOperateManager.getInstance().connectRtkSPP(device)
                    }

                    btnPpg -> {
                        Log.i("HeartTTest", "TYPE_Heart_Raw_Data_Measurement greenLightPpg1:")
                        CommandHandle.getInstance()
                            .executeReqCmd(
                                StartHeartRateReq.getSimpleReq(StartHeartRateReq.TYPE_Heart_Raw_Data_Measurement),
                                object : ICommandResponse<StopHeartRateRsp> {
                                    override fun onDataResponse(resultEntity: StopHeartRateRsp) {
                                        if (resultEntity.errCode == 0x00.toByte() && resultEntity.type == StartHeartRateReq.TYPE_Heart_Raw_Data_Measurement) {
                                            if (resultEntity.value > 0) {
                                                Log.i("111", resultEntity.rri.toString())
                                                binding.tvHeart.setTextColor(Color.RED)
                                                binding.tvHeart.text = resultEntity.rri.toString()
                                            }
                                            Log.i(
                                                "HeartTTest",
                                                "greenLightPpg1:" + resultEntity.greenLightPpg.toString()
                                            )
                                        }
                                    }
                                })

//                        for(index in 0..6){
//                            val entity = AlarmEntity(index, 1, index+5, index*5, 0x80.toByte())
//                            CommandHandle.getInstance().executeReqCmdNoCallback(
//                                SetDrinkAlarmReq(entity)
//                            )
//                        }
                    }

                    btnSport -> {
//                        test.syncSport()
//                        test.heartEnable()
                        binding.tvHard.text = MyApplication.Companion.getInstance.hardwareVersion
                        binding.tvFir.text = MyApplication.Companion.getInstance.firmwareVersion
                    }

                    btnOneKey -> {
//                        BleOperateManager.getInstance().oneClickMeasurement(ICommandResponse<StopHeartRateRsp> {
//                            Log.i("sdk_demo",Gson().toJson(it))
//                        }, false)

                        BleOperateManager.getInstance()
                            .manualModeHeartRateRawData(ICommandResponse<StopHeartRateRsp> {
                                Log.i("sdk_demo", Gson().toJson(it))
                            }, 25, false)
                        BleAction.BLE_DESCRIPTOR_WRITE
                    }

                    tvTouch -> {
                        BleOperateManager.getInstance()
                            .addOutDeviceListener(DeviceNotifyRsp.TYPE_CUSTOM_BUTTON_FUNCTION, myDeviceNotifyListener)
                        CommandHandle.getInstance()
                            .executeReqCmd(TouchControlReq.getWriteInstance(9, true, 5), null)
//                        //Set RT11 Touch muslim Function
//                        CommandHandle.getInstance().executeReqCmd(TouchControlReq.getWriteTpSleepInstance(3,1),
//                            null)
                    }

                    btnIntervalOxygen -> {
                        CommandHandle.getInstance()
                            .executeReqCmd(
                                BloodOxygenSettingReq.getReadInstance(),
                                object : ICommandResponse<BloodOxygenSettingRsp> {
                                    override fun onDataResponse(bloodOxygenSettingRsp: BloodOxygenSettingRsp) {
                                        Log.i(
                                            "sdk_demo",
                                            "bloodOxygenSettingRsp->getReadInstance:" + Gson().toJson(
                                                bloodOxygenSettingRsp
                                            )
                                        )
                                    }
                                })
                        LargeDataHandler.getInstance().syncIntervalBloodOxygenWithCallback(
                            0,
                            fun(p0: IntervalBloodOxygenEntity) {
                                Log.i(
                                    "sdk_demo",
                                    "syncIntervalBloodOxygenWithCallback->" + Gson().toJson(p0)
                                )
                                Log.i(
                                    "sdk_demo",
                                    "syncIntervalBloodOxygenWithCallback->size:" + p0.array.size
                                )
                            })
                    }

                    btnIntervalOxygenAdd -> {
                        CommandHandle.getInstance()
                            .executeReqCmd(
                                BloodOxygenSettingReq.getWriteInstance(true, intervalMin.toByte()),
                                object : ICommandResponse<BloodOxygenSettingRsp> {
                                    override fun onDataResponse(bloodOxygenSettingRsp: BloodOxygenSettingRsp) {
                                        intervalMin++
                                        Log.i(
                                            "sdk_demo",
                                            "bloodOxygenSettingRsp->getWriteInstance:"
                                        )
                                    }
                                })
                    }

                    btnUserId -> {
                        CommandHandle.getInstance()
                            .executeReqCmd(
                                PhoneIdReq.getReadInstance(),
                                object : ICommandResponse<PhoneIdRsp> {
                                    override fun onDataResponse(phoneIdRsp: PhoneIdRsp) {
                                        Log.i(
                                            "sdk_demo",
                                            "phoneIdRsp->getReadInstance->userId:" + phoneIdRsp.getUserId()
                                        )
                                    }
                                })

                    }

                    btnUserIdWrite -> {
                        CommandHandle.getInstance()
                            .executeReqCmd(
                                PhoneIdReq.getWriteInstance("123456789123"),
                                object : ICommandResponse<PhoneIdRsp> {
                                    override fun onDataResponse(phoneIdRsp: PhoneIdRsp) {
                                        Log.i(
                                            "sdk_demo",
                                            "phoneIdRsp->getWriteInstance:"
                                        )
                                    }
                                })
                    }

                    btnTemperatureRead -> {
//                        //support interval temperature
//                        CommandHandle.getInstance()
//                            .executeReqCmd(
//                                DeviceSupportReq.getReadInstance(),
//                                object : ICommandResponse<DeviceSupportFunctionRsp> {
//                                    override fun onDataResponse(deviceSupportFunctionRsp: DeviceSupportFunctionRsp) {
//                                        Log.i(
//                                            "sdk_demo",
//                                            "deviceSupportFunctionRsp->getReadInstance->supportIntervalTemperature:" + deviceSupportFunctionRsp.supportIntervalTemperature
//                                        )
//                                    }
//                                })
//                        //read temperature setting.type:temperature 3
//                        CommandHandle.getInstance()
//                            .executeReqCmd(
//                                SugarLipidsSettingReq.getReadInstance(3),
//                                object : ICommandResponse<BloodSugarLipidsSettingRsp> {
//                                    override fun onDataResponse(bloodSugarLipidsSettingRsp: BloodSugarLipidsSettingRsp) {
//                                        Log.i(
//                                            "sdk_demo",
//                                            "deviceSupportFunctionRsp->getReadInstance->bloodSugarLipidsSettingRsp:" + bloodSugarLipidsSettingRsp
//                                        )
//                                    }
//                                })

//                        //temperature data.dayIndex:today 0,yesterday 1
//                        LargeDataHandler.getInstance().syncIntervalTemperatureWithCallback(
//                            1,
//                            object : IIntervalTemperatureCallback {
//                                override fun readIntervalTemperature(p0: IntervalTemperatureEntity) {
//                                    Log.i(
//                                        "sdk_demo",
//                                        "syncIntervalTemperatureWithCallback->" + Gson().toJson(p0)
//                                    )
//                                    Log.i(
//                                        "sdk_demo",
//                                        "syncIntervalTemperatureWithCallback->size:" + p0.array.size
//                                    )
//                                }
//                            }
//                        )
//                        add(1,IIntervalTemperatureCallback)
//                        type 1 2 3：心率、血压、血氧 / type 1, 2, 3: heart rate, blood pressure, blood oxygen.
//                        //temperature data.dayIndex:today 0,yesterday 1
                        LargeDataHandler.getInstance().syncIntervalThreeTemperatureWithCallback(
                            0,
                            object : IIntervalTemperatureCallback {
                                override fun readIntervalTemperature(p0: IntervalTemperatureEntity) {
                                    Log.i(
                                        "sdk_demo",
                                        "syncIntervalThreeTemperatureWithCallback->" + Gson().toJson(
                                            p0
                                        )
                                    )
                                    for (i in 0 until p0.values.size) {
                                        val it = p0.values[i]
                                        Log.i(
                                            "sdk_demo",
                                            "manualThreeTemperature->value1:" + it.value1 + ",value2:" + it.value2 + ",value3:" + it.value3
                                        )
                                    }
                                    Log.i(
                                        "sdk_demo",
                                        "syncIntervalThreeTemperatureWithCallback->size:" + p0.values.size
                                    )
                                }
                            }
                        )
                    }

                    btnTemperatureMeasureControl -> {
                        //Setting temperature 1min interval.type:temperature 3,value is your interval
//                        CommandHandle.getInstance()
//                            .executeReqCmd(
//                                SugarLipidsSettingReq.getWriteInstance(3, true, 2),
//                                object : ICommandResponse<BloodSugarLipidsSettingRsp> {
//                                    override fun onDataResponse(bloodSugarLipidsSettingRsp: BloodSugarLipidsSettingRsp) {
//                                        Log.i(
//                                            "sdk_demo",
//                                            "deviceSupportFunctionRsp->getWriteInstance->:"
//                                        )
//                                    }
//                                })
                        BleOperateManager.getInstance().manualThreeTemperature({ p0 ->
                            p0.intervalTemperature?.let {
                                Log.i(
                                    "sdk_demo",
                                    "manualThreeTemperature->value1:" + it.value1 + ",value2:" + it.value2 + ",value3:" + it.value3
                                )
                            }
                        }, false)
                    }

                    btnCloseBlueTooth -> {
                        CommandHandle.getInstance()
                            .executeReqCmd(
                                BluetoothCloseReq.getWriteInstance(),
                                object : ICommandResponse<BluetoothCloseRsp> {
                                    override fun onDataResponse(bluetoothCloseRsp: BluetoothCloseRsp) {
                                        Log.i(
                                            "sdk_demo",
                                            "bluetoothCloseRsp->getWriteInstance->:"
                                        )
                                    }
                                })
                    }

                    btnNewSleep -> {
                        LargeDataHandler.getInstance().syncSleepList(0, object :
                            ILargeDataSleepResponse {
                            override fun sleepData(p0: SleepDisplay?) {
                                Log.i(
                                    "sdk_demo",
                                    "syncSleepDataCallback->" + Gson().toJson(p0)
                                )
                            }
                        }, object :
                            ILargeDataLaunchSleepResponse {
                            override fun sleepData(p0: SleepNewProtoResp?) {
                                Log.i(
                                    "sdk_demo",
                                    "syncLaunchSleepDataCallback->" + Gson().toJson(p0)
                                )
                            }
                        })
                    }

                    btnShutdown -> {
                        BleOperateManager.getInstance().shutdown()
                    }

                    btnHeartRateRead -> {
                        //too Low/High Reminder is notify in DeviceNotifyListener DeviceNotifyRsp.TYPE_AUTO_HEART_RATE_ALARM
                        test.heartRead()
                        //add  Heart rate tooLow/High Reminder Listener
                        BleOperateManager.getInstance()
                            .addOutDeviceListener(ListenerKey.Heart, myDeviceNotifyListener)
                    }

                    btnHeartRateWrite -> {
                        test.heartWrite()
                    }

                    btnPalmScreenRead -> {
                        test.palmScreenRead()
                    }

                    btnPalmScreenWrite -> {
                        test.palmScreenWrite()
                    }

                    btnIntervalHeart -> {
                        test.intervalHeartRate()
                    }
                }
            }

        }
    }

    private var intervalMin = 1


    inner class MyDeviceNotifyListener : DeviceNotifyListener() {
        override fun onDataResponse(resultEntity: DeviceNotifyRsp?) {
            if (resultEntity!!.status == BaseRspCmd.RESULT_OK) {
                BleOperateManager.getInstance().removeOthersListener()
                when (resultEntity.dataType) {
                    DeviceNotifyRsp.TYPE_HEART_RATE -> {
                        // 手表心率测试 / Watch heart-rate test.
                    }

                    DeviceNotifyRsp.TYPE_BLOOD_PRESSURE -> {
                        // 手表血压测试 / Watch blood-pressure test.
                    }

                    DeviceNotifyRsp.TYPE_BLOOD_OXYGEN -> {
                        // 手表血氧测试 / Watch blood-oxygen test.
                    }

                    DeviceNotifyRsp.TYPE_STEP -> {
                        // 手表计步详情变化 / Watch step-detail change.
                    }

                    DeviceNotifyRsp.TYPE_BODY_TEMPERATURE -> {
                        // 当天手表体温变化 / Today's watch body-temperature change.
                    }

                    DeviceNotifyRsp.TYPE_SPORT_RECORD -> {
                        // 生成新的运动记录 / New sport record generated.
                    }

                    DeviceNotifyRsp.TYPE_CUSTOM_BUTTON_FUNCTION -> {
                        //The custom function button is triggered
                        val event = BLEDataFormatUtils.bytes2Int(
                            byteArrayOf(
                                resultEntity.loadData[1]
                            )
                        )
//                        event：0 无，1 拒绝，2 上滑，3 单击，4 长按 / event: 0 none, 1 decline, 2 slide up, 3 single tap, 4 long press.
                        Log.i("touch event", event.toString())
                    }

                    DeviceNotifyRsp.TYPE_AUTO_HEART_RATE_ALARM -> {//must add  Heart rate tooLow/High Reminder Listener:ListenerKey.Heart

                        //BleOperateManager.getInstance()
                        //.addOutDeviceListener(ListenerKey.Heart, myDeviceNotifyListener)

                        //Heart Rate too low/high Reminder
                        val type = BLEDataFormatUtils.bytes2Int(
                            byteArrayOf(
                                resultEntity.loadData[1]
                            )
                        )
                        if (type == DeviceNotifyRsp.HEART_RATE_ALARM_LOW) {//too low

                        } else if (type == DeviceNotifyRsp.HEART_RATE_ALARM_HIGH) {//too high

                        }
                        //Heart Rate value
                        val value = BLEDataFormatUtils.bytes2Int(
                            byteArrayOf(
                                resultEntity.loadData[2]
                            )
                        )
                        Log.i("HeartRateTest", "HeartRateReminder type:$type value:$value")
                    }

                    DeviceNotifyRsp.TYPE_AUTO_TEMPERATURE_MINUTE_DATA -> {
                        //The measure temperature
                        val value = BLEDataFormatUtils.bytes2Int(
                            byteArrayOf(
                                resultEntity.loadData[1],
                                resultEntity.loadData[2]
                            )
                        )
                        if (value > 0) {
                            Log.i(
                                "touch event",
                                "temperature event->temperature value:" + (value / 100.0).toString()
                            )
                        }
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        try {
            if (!BluetoothUtils.isEnabledBluetooth(this)) {
                val intent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    if (ActivityCompat.checkSelfPermission(
                            this,
                            Manifest.permission.BLUETOOTH_CONNECT
                        ) != PackageManager.PERMISSION_GRANTED
                    ) {
                        return
                    }
                }
                startActivityForResult(intent, 300)
            }
        } catch (e: Exception) {
        }
        if (!hasBluetooth(this)) {
            requestBluetoothPermission(this, BluetoothPermissionCallback())
        }

        binding.tvName.text = DeviceManager.getInstance().deviceName
        requestAllPermission(this, OnPermissionCallback { permissions, all -> })
    }

    inner class PermissionCallback : OnPermissionCallback {
        override fun onGranted(permissions: MutableList<String>, all: Boolean) {
            if (!all) {

            } else {
                startKtxActivity<DeviceBindActivity>()
            }
        }

        override fun onDenied(permissions: MutableList<String>, never: Boolean) {
            super.onDenied(permissions, never)
            if (never) {
                XXPermissions.startPermissionActivity(this@MainActivity, permissions);
            }
        }

    }

    inner class BluetoothPermissionCallback : OnPermissionCallback {
        override fun onGranted(permissions: MutableList<String>, all: Boolean) {
            if (!all) {

            }
        }

        override fun onDenied(permissions: MutableList<String>, never: Boolean) {
            super.onDenied(permissions, never)
            if (never) {
                XXPermissions.startPermissionActivity(this@MainActivity, permissions)
            }
        }

    }

    inner class AllPermissionCallback : OnPermissionCallback {
        override fun onGranted(permissions: MutableList<String>, all: Boolean) {

        }

        override fun onDenied(permissions: MutableList<String>, never: Boolean) {
            super.onDenied(permissions, never)

        }
    }

}


