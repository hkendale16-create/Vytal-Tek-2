package com.qcwireless.sdksample.activity

import android.os.Bundle
import com.elvishew.xlog.XLog
import com.oudmon.ble.base.bluetooth.BleOperateManager
import com.oudmon.ble.base.communication.ICommandResponse
import com.oudmon.ble.base.communication.IIntervalBloodOxygenCallback
import com.oudmon.ble.base.communication.LargeDataHandler
import com.oudmon.ble.base.communication.bigData.BloodOxygenEntity
import com.oudmon.ble.base.communication.bigData.IntervalBloodOxygenEntity
import com.oudmon.ble.base.communication.req.BloodOxygenSettingReq
import com.oudmon.ble.base.communication.rsp.BaseRspCmd
import com.oudmon.ble.base.communication.rsp.StopHeartRateRsp
import com.qcwireless.sdksample.R
import com.qcwireless.sdksample.annotation.BleIsConnected
import com.qcwireless.sdksample.databinding.ActivityBloodOxygenBinding
import com.qcwireless.sdksample.ext.showToast
import com.qcwireless.sdksample.log.BluetoothLogManager

class BloodOxygenActivity : BaseFunctionActivity() {
    private lateinit var binding: ActivityBloodOxygenBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBloodOxygenBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }

    override fun setupViews() {
        super.setupViews()
        binding.titleBar.tvTitle.text = getString(R.string.qc_text_0062)
        binding.fivSettingRead.setOnClickListener { readBloodOxygenSetting() }
        binding.fivSettingWrite.setOnClickListener { writeBloodOxygenSetting(true) }
        binding.fivSettingOpen.setOnClickListener { writeBloodOxygenSetting(true) }
        binding.fivSettingClose.setOnClickListener { writeBloodOxygenSetting(false) }
        binding.fivStartBloodOxygenPpg.setOnClickListener { startBloodOxygenPpg() }
        binding.fivStopBloodOxygenPpg.setOnClickListener { stopBloodOxygenPpg() }
        bindHealthQueryActions<BloodOxygenEntity>(
            todayView = binding.fivTodayData,
            singleDayView = binding.fivSingleDayData,
            rangeView = binding.fivRangeData,
            title = getString(R.string.qc_text_0062),
            supportCheck = { isBloodOxygenSupported() },
            todayAction = { callback ->
                BleOperateManager.getInstance().getTodayBloodOxygen(callback)
            },
            singleDayAction = { dayIndex, callback ->
                BleOperateManager.getInstance().getBloodOxygen(dayIndex, callback)
            },
            rangeAction = { startDayIndex, count, callback ->
                BleOperateManager.getInstance().getBloodOxygens(startDayIndex, count, callback)
            }
        )
        binding.fivStartMeasure.setOnClickListener { startBloodOxygenMeasure() }
        binding.fivStopMeasure.setOnClickListener { stopBloodOxygenMeasure() }
        refreshSupportCache()
    }

    private fun isBloodOxygenSupported(): Boolean {
        return ensureSupported(setTimeCache.supportBloodOxygen || deviceSupport.supportIntervalBloodOxygen)
    }

    @BleIsConnected
    private fun readBloodOxygenSetting() {
        if (!ensureBloodOxygenSettingSupported()) {
            return
        }
        executeSettingAction(
            LOG_TAG,
            "Get Blood Oxygen Setting",
            "BloodOxygenSettingReq",
            "read",
            BloodOxygenSettingReq.getReadInstance()
        )
    }

    @BleIsConnected
    private fun writeBloodOxygenSetting(enable: Boolean) {
        if (!ensureBloodOxygenSettingSupported()) {
            return
        }
        executeSettingAction(
            LOG_TAG,
            "Set Blood Oxygen Setting",
            "BloodOxygenSettingReq",
            "enable=$enable, interval=2",
            BloodOxygenSettingReq.getWriteInstance(enable, 2.toByte())
        )
    }

    @BleIsConnected
    private fun startBloodOxygenPpg() {
        if (!isBloodOxygenSupported()) {
            return
        }
        BleOperateManager.getInstance().manualModeBloodOxygenRawData(
            ICommandResponse<StopHeartRateRsp> { rsp ->
                logBloodOxygenPpgDetail(rsp)
                if (rsp.errCode != 0x00.toByte()) {
                    (getString(R.string.text_50) + getString(R.string.qc_text_0054)).showToast()
                }
            },
            PPG_MEASURE_DURATION_SECONDS,
            false
        )
    }

    @BleIsConnected
    private fun stopBloodOxygenPpg() {
        if (!isBloodOxygenSupported()) {
            return
        }
        BleOperateManager.getInstance().manualModeBloodOxygenRawData(
            ICommandResponse<StopHeartRateRsp> { rsp ->
                logBloodOxygenPpgDetail(rsp)
                if (rsp.errCode == 0x00.toByte()) {
                    (getString(R.string.text_51) + getString(R.string.qc_text_0053)).showToast()
                } else {
                    (getString(R.string.text_51) + getString(R.string.qc_text_0054)).showToast()
                }
            },
            PPG_MEASURE_DURATION_SECONDS,
            true
        )
    }

    @BleIsConnected
    private fun startBloodOxygenMeasure() {
        if (!isBloodOxygenSupported()) {
            return
        }
        BleOperateManager.getInstance().manualModeSpO2({ rsp ->
            getString(R.string.qc_text_0082, rsp.value.toString()).showToast()

        }, false)
    }

    @BleIsConnected
    private fun stopBloodOxygenMeasure() {
        if (!isBloodOxygenSupported()) {
            return
        }
        BleOperateManager.getInstance().manualModeSpO2({ rsp ->
        }, true)
        (getString(R.string.qc_text_0081) + getString(R.string.qc_text_0053)).showToast()
    }

    private fun logBloodOxygenPpgDetail(rsp: StopHeartRateRsp) {
        val detail = buildString {
            append(getString(R.string.qc_text_0062)).append(" PPG")
            append(" status=").append(rsp.status)
            append(" cmdType=").append(rsp.cmdType)
            append(" type=").append(rsp.type)
            append(" errCode=").append(rsp.errCode)
            append(" ppgCount=").append(rsp.getPpgCount())
            append(" greenLightPpgL=").append(rsp.getGreenLightPpgL())
            append(" greenLightPpgH=").append(rsp.getGreenLightPpgH())
            append(" greenLightPpg=").append(rsp.greenLightPpg)
            append(" redLightPpgL=").append(rsp.getRedLightPpgL())
            append(" redLightPpgH=").append(rsp.getRedLightPpgH())
            append(" redLightPpg=").append(rsp.redLightPpg)
            append(" infraredPpgL=").append(rsp.getInfraredPpgL())
            append(" infraredPpgH=").append(rsp.getInfraredPpgH())
            append(" infraredPpg=").append(rsp.infraredPpg)
            append(" xL=").append(rsp.getXL())
            append(" xH=").append(rsp.getXH())
            append(" yL=").append(rsp.getYL())
            append(" yH=").append(rsp.getYH())
            append(" zL=").append(rsp.getZL())
            append(" zH=").append(rsp.getZH())
            append(" heartRate=").append(rsp.getHeartRate())
            append(" bloodOxygen=").append(rsp.getBloodOxygen())
            append(" value=").append(rsp.value)
            append(" sbp=").append(rsp.sbp)
            append(" dbp=").append(rsp.dbp)
            append(" rri=").append(rsp.rri)
            append(" heart=").append(rsp.heart)
            append(" hrv=").append(rsp.hrv)
            append(" stress=").append(rsp.stress)
            append(" temperature=").append(rsp.temperature)
            append(" intervalTemperature=").append(rsp.intervalTemperature)
        }
        XLog.tag(PPG_LOG_TAG).d(detail)
        BluetoothLogManager.addExternalLog(detail)
    }

    companion object {
        private const val LOG_TAG = "BloodOxygenSetting"
        private const val PPG_LOG_TAG = "BloodOxygenPpg"
        private const val PPG_MEASURE_DURATION_SECONDS = 30
        private const val MANUAL_BLOOD_OXYGEN_PPG_DURATION_SECONDS = 30
    }
}
