package com.qcwireless.sdksample.activity

import android.os.Bundle
import com.oudmon.ble.base.communication.ICommandResponse
import com.oudmon.ble.base.communication.req.ReadDrinkAlarmReq
import com.oudmon.ble.base.communication.rsp.BaseRspCmd
import com.qcwireless.sdksample.R
import com.qcwireless.sdksample.annotation.BleIsConnected
import com.qcwireless.sdksample.databinding.ActivityDrinkReminderBinding
import com.qcwireless.sdksample.ext.showToast

class DrinkReminderActivity : BaseFunctionActivity() {
    private lateinit var binding: ActivityDrinkReminderBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDrinkReminderBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }

    override fun setupViews() {
        super.setupViews()
        binding.titleBar.tvTitle.text = getString(R.string.qc_text_0066)
        binding.fivDataSync.setOnClickListener { syncDrinkReminder() }
        refreshSupportCache()
    }

    private fun isDrinkSupported(): Boolean {
        return ensureSupported(deviceSupport.supportDrink)
    }

    @BleIsConnected
    private fun syncDrinkReminder() {
        if (!isDrinkSupported()) {
            return
        }
        logBlePanelDetail(
            LOG_TAG,
            "[REQ]\naction=syncDrinkReminder request=ReadDrinkAlarmReq type=1"
        )
        commandHandle.executeReqCmd(
            ReadDrinkAlarmReq(1),
            ICommandResponse<BaseRspCmd> { rsp ->
                val success = rsp.status == BaseRspCmd.RESULT_OK
                logBlePanelDetail(
                    LOG_TAG,
                    "[RSP]\naction=syncDrinkReminder request=ReadDrinkAlarmReq success=$success status=${rsp.status}"
                )
            }
        )
        getString(R.string.qc_text_0093).showToast()
    }

    companion object {
        private const val LOG_TAG = "Drink"
    }
}
