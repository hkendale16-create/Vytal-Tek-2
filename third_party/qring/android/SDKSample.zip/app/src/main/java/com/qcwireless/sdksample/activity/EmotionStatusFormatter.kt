package com.qcwireless.sdksample.activity

object EmotionStatusFormatter {
    private val statusNames = mapOf(
        0 to "null",
        1 to "兴奋",
        2 to "开心",
        3 to "愉悦",
        4 to "平静",
        5 to "紧张",
        6 to "困惑",
        7 to "挑战",
        8 to "不舒服",
        9 to "伤心",
        10 to "焦虑"
    )

    fun format(status: Int): String {
        return "$status.${statusNames[status] ?: "unknown"}"
    }
}
