package com.qcwireless.sdksample.utils
import android.content.Context
import androidx.fragment.app.FragmentActivity
import com.hjq.permissions.OnPermissionCallback
import com.hjq.permissions.Permission
import com.hjq.permissions.XXPermissions

/**
 * @author hzy ,
 * @date  2020/12/22
 * <p>
 * "程序应该是写给其他人读的,
 * 让机器来运行它只是一个附带功能"
 **/
fun hasCameraPermission(
    context: Context,
): Boolean {
    val permissions = mutableListOf<String>()
    permissions.add(Permission.CAMERA)
    return XXPermissions.isGranted(context, permissions)
}

fun hasLocationPermission(activity: FragmentActivity): Boolean {
    return XXPermissions.isGranted(activity, Permission.ACCESS_FINE_LOCATION)
}

fun hasBgLocationPermission(activity: FragmentActivity): Boolean {
    return XXPermissions.isGranted(activity, Permission.ACCESS_BACKGROUND_LOCATION)
}

fun hasBluetooth(activity: FragmentActivity): Boolean {
    val permissions = mutableListOf<String>()
    permissions.add(Permission.BLUETOOTH_SCAN)
    permissions.add(Permission.BLUETOOTH_CONNECT)
    permissions.add(Permission.BLUETOOTH_ADVERTISE)
    return XXPermissions.isGranted(activity, permissions)
}


fun requestLocationPermission(
    activity: FragmentActivity,
    requestCallback: OnPermissionCallback,
) {
    XXPermissions.with(activity)
        .permission(Permission.ACCESS_COARSE_LOCATION)
        .permission(Permission.ACCESS_FINE_LOCATION)
        .request(requestCallback)
}

fun requestBluetoothPermission(
    activity: FragmentActivity,
    requestCallback: OnPermissionCallback
) {
    XXPermissions.with(activity)
        .permission(Permission.BLUETOOTH_SCAN)
        .permission(Permission.BLUETOOTH_CONNECT)
        .permission(Permission.BLUETOOTH_ADVERTISE)
        .permission(Permission.ACCESS_FINE_LOCATION)
        .request(requestCallback)
}

fun requestBgLocation(activity: FragmentActivity, requestCallback: OnPermissionCallback) {
    XXPermissions.with(activity)
        .permission(Permission.ACCESS_COARSE_LOCATION)
        .permission(Permission.ACCESS_FINE_LOCATION)
        .permission(Permission.ACCESS_BACKGROUND_LOCATION)
        .request(requestCallback)
}

fun requestAlertWindowPermission(activity: FragmentActivity) {
    XXPermissions.with(activity).permission(Permission.SYSTEM_ALERT_WINDOW)
}


fun requestAllPermission(
    activity: FragmentActivity,
    callback: OnPermissionCallback
) {
    XXPermissions.with(activity)
//        .permission(Permission.WRITE_EXTERNAL_STORAGE)
//        .permission(Permission.READ_EXTERNAL_STORAGE)
        .permission(Permission.MANAGE_EXTERNAL_STORAGE)
        .request(callback)
}


fun requestCameraPermission(
    activity: FragmentActivity,
    requestCallback: OnPermissionCallback,
) {
    XXPermissions.with(activity).permission(
        Permission.CAMERA
    ).request(requestCallback)
}
