package com.qcwireless.sdksample.adapter

import android.view.View
import android.widget.SeekBar
import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.viewholder.BaseViewHolder
import com.qcwireless.sdksample.R
import com.qcwireless.sdksample.recording.SampleRecordingItem
import java.util.Locale

class RecordingListAdapter(
    private val onSeekRequested: (SampleRecordingItem, Int) -> Unit
) : BaseQuickAdapter<SampleRecordingItem, BaseViewHolder>(R.layout.item_recording) {
    var importingFileName: String? = null
    var importProgress: Int = 0
    var playingPath: String? = null
    var playbackProgress: Int = 0
    var operationsEnabled: Boolean = true

    override fun convert(holder: BaseViewHolder, item: SampleRecordingItem) {
        val recording = item.deviceRecording
        val local = item.localFile
        val importing = importingFileName == recording.fileName
        val playing = local != null && playingPath == local.absolutePath
        val displayName = displayRecordingName(recording.fileName)
            .ifBlank { "Recording ${recording.id}" }

        holder.setText(R.id.tv_recording_name, displayName)
        holder.getView<View>(R.id.tv_recording_metadata).visibility = if (local == null) View.GONE else View.VISIBLE
        local?.let {
            holder.setText(
                R.id.tv_recording_metadata,
                context.getString(
                    R.string.recording_metadata,
                    formatDuration(it.durationMillis),
                    formatSize(it.sizeBytes)
                )
            )
        }
        holder.setText(
            R.id.tv_recording_path,
            local?.absolutePath ?: context.getString(R.string.recording_path_unavailable)
        )
        holder.setText(
            R.id.btn_import_or_play,
            when {
                importing -> context.getString(R.string.recording_importing, importProgress)
                playing -> context.getString(R.string.recording_pause)
                local != null -> context.getString(R.string.recording_play)
                else -> context.getString(R.string.recording_import)
            }
        )
        holder.getView<View>(R.id.btn_import_or_play).isEnabled =
            !importing && (local != null || operationsEnabled)
        holder.getView<View>(R.id.btn_copy_path).visibility = if (local == null) View.GONE else View.VISIBLE
        holder.getView<View>(R.id.btn_share).visibility = if (local == null) View.GONE else View.VISIBLE
        holder.getView<View>(R.id.btn_delete_local).visibility = if (local == null) View.GONE else View.VISIBLE
        holder.getView<View>(R.id.btn_delete_device).visibility = if (recording.id < 0) View.GONE else View.VISIBLE
        holder.getView<View>(R.id.btn_delete_device).isEnabled = operationsEnabled
        holder.getView<View>(R.id.btn_delete_local).isEnabled = operationsEnabled

        holder.getView<SeekBar>(R.id.seek_playback).apply {
            visibility = if (local == null) View.GONE else View.VISIBLE
            setOnSeekBarChangeListener(null)
            progress = if (playing) playbackProgress else 0
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) = Unit
                override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
                override fun onStopTrackingTouch(seekBar: SeekBar?) {
                    onSeekRequested(item, seekBar?.progress ?: 0)
                }
            })
        }
    }

    private fun displayRecordingName(fileName: String): String {
        return if (fileName.endsWith(".opus", ignoreCase = true)) {
            fileName.dropLast(".opus".length)
        } else {
            fileName
        }
    }

    private fun formatDuration(durationMillis: Long): String {
        val totalSeconds = (durationMillis / 1000L).coerceAtLeast(0L)
        val hours = totalSeconds / 3600L
        val minutes = totalSeconds % 3600L / 60L
        val seconds = totalSeconds % 60L
        return if (hours > 0L) {
            String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format(Locale.US, "%02d:%02d", minutes, seconds)
        }
    }

    private fun formatSize(bytes: Long): String {
        return when {
            bytes >= 1024L * 1024L -> String.format(Locale.US, "%.2f MB", bytes / 1024.0 / 1024.0)
            bytes >= 1024L -> String.format(Locale.US, "%.1f KB", bytes / 1024.0)
            else -> "$bytes B"
        }
    }
}
