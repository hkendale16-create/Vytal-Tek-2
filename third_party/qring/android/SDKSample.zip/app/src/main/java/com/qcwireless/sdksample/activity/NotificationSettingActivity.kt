package com.qcwireless.sdksample.activity

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Spinner
import com.oudmon.ble.base.communication.Constants
import com.oudmon.ble.base.communication.entity.StartEndTimeEntity
import com.oudmon.ble.base.communication.req.BindAncsReq
import com.oudmon.ble.base.communication.req.DndReq
import com.oudmon.ble.base.communication.req.MusicSwitchReq
import com.oudmon.ble.base.communication.req.NotificationEventNotifyReq
import com.oudmon.ble.base.communication.req.SimpleKeyReq
import com.qcwireless.sdksample.R
import com.qcwireless.sdksample.databinding.ActivityNotificationSettingBinding

class NotificationSettingActivity : BaseFunctionActivity() {

    private lateinit var binding: ActivityNotificationSettingBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNotificationSettingBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }

    override fun setupViews() {
        super.setupViews()
        binding.titleBar.tvTitle.text = getString(R.string.title_notification)
        setupNotificationEventSpinners()
        bindSettingAction(
            binding.fivSetAncs,
            LOG_TAG,
            "Set ANCS",
            "SetANCSReq",
            "call=true, sms=true, qq=true, wechat=true",
            ::ensureNotificationSupported
        ) { createSetAncsReq() }
        bindSettingAction(
            binding.fivGetAncs,
            LOG_TAG,
            "Get ANCS",
            "SimpleKeyReq(Constants.CMD_GET_ANCS_ON_OFF)",
            "cmd=CMD_GET_ANCS_ON_OFF",
            ::ensureNotificationSupported
        ) { SimpleKeyReq(Constants.CMD_GET_ANCS_ON_OFF) }
        bindSettingAction(
            binding.fivBindAncs,
            LOG_TAG,
            "Bind ANCS",
            "BindAncsReq",
            "none",
            ::ensureNotificationSupported
        ) { BindAncsReq() }
        bindSettingAction(
            binding.fivSetDnd,
            LOG_TAG,
            "Set DND",
            "DndReq",
            "isEnable=true, start=22:00, end=07:00",
            ::ensureNotificationSupported
        ) { DndReq.getWriteInstance(true, StartEndTimeEntity(22, 0, 7, 0)) }
        bindSettingAction(
            binding.fivGetDnd,
            LOG_TAG,
            "Get DND",
            "DndReq",
            "read",
            ::ensureNotificationSupported
        ) { DndReq.getReadInstance() }
        bindNotificationEventActions()
        bindSettingAction(
            binding.fivSetMusicSwitch,
            LOG_TAG,
            "Set Music Switch",
            "MusicSwitchReq",
            "enable=true",
            ::ensureMusicSwitchSupported
        ) { MusicSwitchReq.getWriteInstance(true) }
        bindSettingAction(
            binding.fivGetMusicSwitch,
            LOG_TAG,
            "Get Music Switch",
            "MusicSwitchReq",
            "read",
            ::ensureMusicSwitchSupported
        ) { MusicSwitchReq.getReadInstance() }
        refreshCachesIfConnected()
    }

    private fun setupNotificationEventSpinners() {
        binding.spinnerLightPriority.setOptions(NotificationEventOptions.priorities)
        binding.spinnerLightMode.setOptions(NotificationEventOptions.lightModes)
        binding.spinnerLightLoopCount.setOptions(NotificationEventOptions.loopCounts)
        binding.spinnerLightActiveDuration.setOptions(NotificationEventOptions.activeDurations)
        binding.spinnerLightPauseDuration.setOptions(NotificationEventOptions.pauseDurations)

        binding.spinnerVibrationPriority.setOptions(NotificationEventOptions.priorities)
        binding.spinnerVibrationMode.setOptions(NotificationEventOptions.vibrationModes)
        binding.spinnerVibrationLoopCount.setOptions(NotificationEventOptions.loopCounts)
        binding.spinnerVibrationActiveDuration.setOptions(NotificationEventOptions.activeDurations)
        binding.spinnerVibrationPauseDuration.setOptions(NotificationEventOptions.pauseDurations)
    }

    private fun Spinner.setOptions(options: List<NotificationEventOptions.Option>) {
        adapter = ArrayAdapter(
            this@NotificationSettingActivity,
            android.R.layout.simple_spinner_item,
            options
        ).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
    }

    private fun bindNotificationEventActions() {
        binding.fivSetLightNotification.setOnClickListener {
            if (!ensureNotificationSupported()) {
                return@setOnClickListener
            }
            val params = currentLightParams()
            executeSettingAction(
                LOG_TAG,
                getString(R.string.notification_set_light),
                "NotificationEventNotifyReq.getCustomLightInstance",
                params.toLogArgs("light"),
                NotificationEventNotifyReq.getCustomLightInstance(
                    params.priority,
                    params.mode,
                    params.loopCount,
                    params.activeDuration,
                    params.pauseDuration
                )
            )
        }

        binding.fivSetVibrationNotification.setOnClickListener {
            if (!ensureNotificationSupported()) {
                return@setOnClickListener
            }
            val params = currentVibrationParams()
            executeSettingAction(
                LOG_TAG,
                getString(R.string.notification_set_vibration),
                "NotificationEventNotifyReq.getCustomVibrationInstance",
                params.toLogArgs("vibration"),
                NotificationEventNotifyReq.getCustomVibrationInstance(
                    params.priority,
                    params.mode,
                    params.loopCount,
                    params.activeDuration,
                    params.pauseDuration
                )
            )
        }
    }

    private fun currentLightParams(): NotificationEventParams {
        return NotificationEventParams(
            priority = binding.spinnerLightPriority.selectedValue(),
            mode = binding.spinnerLightMode.selectedValue(),
            loopCount = binding.spinnerLightLoopCount.selectedValue(),
            activeDuration = binding.spinnerLightActiveDuration.selectedValue(),
            pauseDuration = binding.spinnerLightPauseDuration.selectedValue()
        )
    }

    private fun currentVibrationParams(): NotificationEventParams {
        return NotificationEventParams(
            priority = binding.spinnerVibrationPriority.selectedValue(),
            mode = binding.spinnerVibrationMode.selectedValue(),
            loopCount = binding.spinnerVibrationLoopCount.selectedValue(),
            activeDuration = binding.spinnerVibrationActiveDuration.selectedValue(),
            pauseDuration = binding.spinnerVibrationPauseDuration.selectedValue()
        )
    }

    private fun Spinner.selectedValue(): Int {
        return (selectedItem as NotificationEventOptions.Option).value
    }

    override fun onResume() {
        super.onResume()
        refreshCachesIfConnected()
    }

    private data class NotificationEventParams(
        val priority: Int,
        val mode: Int,
        val loopCount: Int,
        val activeDuration: Int,
        val pauseDuration: Int
    ) {
        fun toLogArgs(modeName: String): String {
            return "priority=$priority, $modeName=$mode, loop=$loopCount, activeDuration=$activeDuration, pauseDuration=$pauseDuration"
        }
    }

    companion object {
        private const val LOG_TAG = "NotificationSetting"
    }
}
