package com.qcwireless.sdksample.recording

import android.content.Context
import android.os.Environment
import com.oudmon.ble.base.recording.RecordingDeviceRecording
import com.oudmon.ble.base.recording.RecordingPcmFormat
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.Properties

class SampleRecordingFileStore(
    private val context: Context,
    deviceAddress: String
) {
    val rootDirectory: File = run {
        val external = context.getExternalFilesDir(Environment.DIRECTORY_MUSIC)
        val directoryName = deviceDirectoryName(deviceAddress)
        val externalDirectory = external?.let { File(File(it, "recordings"), directoryName) }
        if (externalDirectory != null &&
            (externalDirectory.isDirectory || externalDirectory.mkdirs()) &&
            externalDirectory.canWrite()
        ) {
            externalDirectory
        } else {
            File(File(context.filesDir, "recordings"), directoryName).apply {
                check(isDirectory || mkdirs()) { "Unable to create recording directory" }
            }
        }
    }

    fun outputFile(recording: RecordingDeviceRecording, asWav: Boolean): File {
        val extension = if (asWav) "wav" else "pcm"
        return File(rootDirectory, "${storageKey(recording)}.$extension")
    }

    fun tempPcmFile(recording: RecordingDeviceRecording): File {
        return File(rootDirectory, "${storageKey(recording)}.tmp.pcm")
    }

    fun completePcm(recording: RecordingDeviceRecording, format: RecordingPcmFormat, pcmFile: File): SampleRecordingFileInfo {
        val info = buildInfo(recording, format, pcmFile, "audio/pcm")
        persistMetadata(info)
        return info
    }

    fun completeWav(
        recording: RecordingDeviceRecording,
        format: RecordingPcmFormat,
        pcmFile: File,
        wavFile: File
    ): SampleRecordingFileInfo {
        WavFileWriter.writePcmAsWav(
            pcmFile = pcmFile,
            wavFile = wavFile,
            sampleRateHz = format.sampleRateHz,
            channels = format.channels,
            bitsPerSample = format.bitsPerSample
        )
        pcmFile.delete()
        val info = buildInfo(recording, format, wavFile, "audio/wav")
        persistMetadata(info)
        return info
    }

    fun localFiles(): List<SampleRecordingFileInfo> {
        return rootDirectory.listFiles()
            .orEmpty()
            .filter { file ->
                file.isFile &&
                    !file.name.endsWith(".part") &&
                    !file.name.endsWith(".tmp.pcm") &&
                    !file.name.endsWith(METADATA_SUFFIX)
            }
            .sortedByDescending { it.lastModified() }
            .mapNotNull(::readMetadata)
    }

    fun delete(file: SampleRecordingFileInfo): Boolean {
        val audioFile = File(file.absolutePath)
        val deleted = audioFile.delete()
        metadataFile(audioFile).delete()
        return deleted
    }

    private fun buildInfo(
        recording: RecordingDeviceRecording,
        format: RecordingPcmFormat,
        file: File,
        mimeType: String
    ): SampleRecordingFileInfo {
        val audioBytes = if (mimeType == "audio/wav") (file.length() - 44L).coerceAtLeast(0L) else file.length()
        val bytesPerFrame = format.channels.coerceAtLeast(1) * (format.bitsPerSample.coerceAtLeast(8) / 8)
        val duration = if (format.sampleRateHz > 0 && bytesPerFrame > 0) {
            audioBytes * 1000L / (format.sampleRateHz.toLong() * bytesPerFrame)
        } else {
            recording.durationMillis
        }
        return SampleRecordingFileInfo(
            deviceFileName = recording.fileName,
            absolutePath = file.absolutePath,
            mimeType = mimeType,
            sizeBytes = file.length(),
            durationMillis = duration.takeIf { it > 0L } ?: recording.durationMillis,
            sampleRateHz = format.sampleRateHz,
            channels = format.channels,
            bitsPerSample = format.bitsPerSample
        )
    }

    private fun persistMetadata(info: SampleRecordingFileInfo) {
        val file = File(info.absolutePath)
        val properties = Properties().apply {
            setProperty(KEY_DEVICE_FILE_NAME, info.deviceFileName)
            setProperty(KEY_MIME, info.mimeType)
            setProperty(KEY_SIZE, info.sizeBytes.toString())
            setProperty(KEY_DURATION, info.durationMillis.toString())
            setProperty(KEY_SAMPLE_RATE, info.sampleRateHz.toString())
            setProperty(KEY_CHANNELS, info.channels.toString())
            setProperty(KEY_BITS, info.bitsPerSample.toString())
        }
        FileOutputStream(metadataFile(file)).use { properties.store(it, "SDKSample recording metadata") }
    }

    private fun readMetadata(file: File): SampleRecordingFileInfo? {
        val metadata = metadataFile(file)
        if (!metadata.isFile) return null
        val properties = Properties()
        FileInputStream(metadata).use(properties::load)
        return SampleRecordingFileInfo(
            deviceFileName = properties.getProperty(KEY_DEVICE_FILE_NAME, file.name),
            absolutePath = file.absolutePath,
            mimeType = properties.getProperty(KEY_MIME, if (file.extension == "wav") "audio/wav" else "audio/pcm"),
            sizeBytes = file.length(),
            durationMillis = properties.getProperty(KEY_DURATION)?.toLongOrNull() ?: 0L,
            sampleRateHz = properties.getProperty(KEY_SAMPLE_RATE)?.toIntOrNull() ?: 16_000,
            channels = properties.getProperty(KEY_CHANNELS)?.toIntOrNull() ?: 1,
            bitsPerSample = properties.getProperty(KEY_BITS)?.toIntOrNull() ?: 16
        )
    }

    private fun metadataFile(audioFile: File): File = File(audioFile.parentFile, audioFile.name + METADATA_SUFFIX)

    private fun storageKey(recording: RecordingDeviceRecording): String {
        val safeOriginalName = sanitizeFileName(recording.fileName)
        val sourceToken = safeOriginalName.replace('.', '_')
        val identity = if (recording.id > 0) {
            "id${recording.id}"
        } else {
            "h${recording.fileName.hashCode().toUInt().toString(16)}"
        }
        return "${sourceToken}_$identity"
    }

    private fun sanitizeFileName(fileName: String): String {
        val leafName = File(fileName).name
        val sanitized = leafName.replace(UNSAFE_CHARACTERS, "_").trim('.', '_')
        return sanitized.ifEmpty { "recording_${System.currentTimeMillis()}" }
    }

    private fun deviceDirectoryName(deviceAddress: String): String {
        val safeAddress = deviceAddress.replace(UNSAFE_CHARACTERS, "_").trim('_')
        return "device_${safeAddress.ifEmpty { "unknown" }}"
    }

    companion object {
        private val UNSAFE_CHARACTERS = Regex("[^A-Za-z0-9._-]")
        private const val METADATA_SUFFIX = ".metadata.properties"
        private const val KEY_DEVICE_FILE_NAME = "deviceFileName"
        private const val KEY_MIME = "mimeType"
        private const val KEY_SIZE = "sizeBytes"
        private const val KEY_DURATION = "durationMillis"
        private const val KEY_SAMPLE_RATE = "sampleRateHz"
        private const val KEY_CHANNELS = "channels"
        private const val KEY_BITS = "bitsPerSample"
    }
}
