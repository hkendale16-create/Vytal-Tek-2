package com.qcwireless.sdksample.activity

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import androidx.core.app.ActivityCompat
import com.elvishew.xlog.XLog
import com.hjq.permissions.OnPermissionCallback
import com.hjq.permissions.XXPermissions
import com.oudmon.ble.base.bluetooth.BleOperateManager
import com.oudmon.ble.base.bluetooth.DeviceManager
import com.oudmon.ble.base.communication.CommandHandle
import com.oudmon.ble.base.communication.Constants
import com.oudmon.ble.base.communication.ICommandResponse
import com.oudmon.ble.base.communication.req.DeviceSupportReq
import com.oudmon.ble.base.communication.req.FindDeviceReq
import com.oudmon.ble.base.communication.req.SetTimeReq
import com.oudmon.ble.base.communication.req.SimpleKeyReq
import com.oudmon.ble.base.communication.responseImpl.DeviceNotifyListener
import com.oudmon.ble.base.communication.rsp.BatteryRsp
import com.oudmon.ble.base.communication.rsp.BaseRspCmd
import com.oudmon.ble.base.communication.rsp.DeviceNotifyRsp
import com.oudmon.ble.base.communication.rsp.DeviceSupportFunctionRsp
import com.oudmon.ble.base.communication.rsp.SetTimeRsp
import com.oudmon.ble.base.communication.utils.BLEDataFormatUtils
import com.oudmon.ble.base.communication.utils.ByteUtil
import com.oudmon.ble.base.util.DateUtil
import com.qcwireless.sdksample.app.MyApplication
import com.qcwireless.sdksample.event.BluetoothEvent
import com.qcwireless.sdksample.event.FirmwareVersionEvent
import com.qcwireless.sdksample.utils.BluetoothUtils
import com.qcwireless.sdksample.BuildConfig
import com.qcwireless.sdksample.R
import com.qcwireless.sdksample.annotation.BleIsConnected
import com.qcwireless.sdksample.bean.HomeConnectionActionVisibility
import com.qcwireless.sdksample.bean.HomeFirmwareVersionVisibility
import com.qcwireless.sdksample.cache.DeviceFunctionSupport
import com.qcwireless.sdksample.cache.MMKVManager
import com.qcwireless.sdksample.cache.SetTime
import com.qcwireless.sdksample.databinding.ActivityHomeBinding
import com.qcwireless.sdksample.dialog.NotificationDialog
import com.qcwireless.sdksample.event.MessageEvent
import com.qcwireless.sdksample.ext.showToast
import com.qcwireless.sdksample.ext.startKtxActivity
import com.qcwireless.sdksample.utils.hasBluetooth
import com.qcwireless.sdksample.utils.requestBluetoothPermission
import com.qcwireless.sdksample.utils.requestLocationPermission
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode

/**
 * 功能列表演示页面
 */
class HomeActivity : BaseActivity() {

    private lateinit var binding: ActivityHomeBinding

    private lateinit var myDeviceNotifyListener: MyDeviceNotifyListener


    companion object {
        //Your key，Only for register and unregister
        private const val MAIN_KEY = DeviceNotifyRsp.TYPE_TIME_FORMAT
    }

    override fun getStatusBarColorRes() = R.color.bg_primary

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }

    override fun setupViews() {
        super.setupViews()
        binding.run {
            tvVersion.text = getString(R.string.app_name)+":"+BuildConfig.VERSION_NAME
        }
        myDeviceNotifyListener = MyDeviceNotifyListener()
        BleOperateManager.getInstance()
            .addOutDeviceListener(MAIN_KEY, myDeviceNotifyListener)
        // 扫描设备 / Scan devices.
        binding.fivScan.setOnClickListener {
            requestLocationPermission(this@HomeActivity, PermissionCallback())
        }

        // 重连设备 / Reconnect the device.
        binding.fivReconnect.setOnClickListener {
            reconnectDevice()
        }

        // 断开连接 / Disconnect the device.
        binding.fivDisconnect.setOnClickListener {
            disconnectDevice()
        }

        // 蓝牙配对 / Pair Bluetooth.
        binding.fivBtPair.setOnClickListener {
            createBond()
        }

        binding.fivUnbindDevice.setOnClickListener {
            unbindDevice()
        }

        // 查找设备 / Find the device.
        binding.fivFindDevice.setOnClickListener {
            findDevice()
        }

        binding.fivHealthSettings.setOnClickListener {
            startKtxActivity<HealthSettingsActivity>()
        }

        binding.fivTargetAndProfile.setOnClickListener {
            startKtxActivity<TargetAndProfileActivity>()
        }

        binding.fivDisplay.setOnClickListener {
            startKtxActivity<DisplayActivity>()
        }

        binding.fivDevice.setOnClickListener {
            startKtxActivity<DeviceActivity>()
        }

        binding.fivNotification.setOnClickListener {
            startKtxActivity<NotificationSettingActivity>()
        }

        binding.fivTouchGesture.setOnClickListener {
            startKtxActivity<TouchGestureActivity>()
        }

        binding.fivAdvanced.setOnClickListener {
            startKtxActivity<AdvancedSettingActivity>()
        }

        binding.fivViaBleUpdate.setOnClickListener {
            startKtxActivity<OtaActivity>()
        }

        binding.fivResourceUpdate.setOnClickListener {
            startKtxActivity<ResourceUpdateActivity>()
        }
    }

    override fun onResume() {
        super.onResume()
        try {
            if (!BluetoothUtils.isEnabledBluetooth(this)) {
                val intent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    if (ActivityCompat.checkSelfPermission(
                            this,
                            Manifest.permission.BLUETOOTH_CONNECT
                        ) != PackageManager.PERMISSION_GRANTED
                    ) {
                        return
                    }
                }
                startActivityForResult(intent, 300)
            }
        } catch (e: Exception) {
        }
        if (!hasBluetooth(this)) {
            requestBluetoothPermission(this, BluetoothPermissionCallback())
        }

        val deviceName = DeviceManager.getInstance().deviceName.orEmpty()
        val deviceMac = HomeDeviceMac.resolve(
            runtimeMac = DeviceManager.getInstance().deviceAddress,
            cachedMac = MMKVManager.getLastConnectedDeviceMac()
        )

        binding.tvDeviceName.text =
            getString(R.string.qc_text_0009) + deviceName
        binding.tvDeviceMac.text =
            getString(R.string.qc_text_0010) + deviceMac.value
        if (BleOperateManager.getInstance().isConnected) {
            showConnectedState()
            requestBatteryStatus()
        } else {
            showDisconnectedState()
        }

     }

    inner class MyDeviceNotifyListener : DeviceNotifyListener() {
        override fun onDataResponse(resultEntity: DeviceNotifyRsp?) {
            if (resultEntity!!.status == BaseRspCmd.RESULT_OK) {
                // 数据同步中时，应返回不处理回调 / During data sync, return without handling this callback.
                BleOperateManager.getInstance().removeOthersListener()
                when (resultEntity.dataType) {
                    DeviceNotifyRsp.TYPE_HEART_RATE -> {
//                        viewModel.syncTodayHeartSingleData()
                    }

                    DeviceNotifyRsp.TYPE_BLOOD_PRESSURE -> {
//                        viewModel.syncBpSingle()
                    }

                    DeviceNotifyRsp.TYPE_BLOOD_OXYGEN -> {
//                        viewModel.syncTodaySpo2Single(0x00)
                    }

                    DeviceNotifyRsp.TYPE_STEP -> {
//                        viewModel.syncTodayStepDetailSingle()
                    }

                    DeviceNotifyRsp.TYPE_BODY_TEMPERATURE -> {
//                        viewModel.syncTodayTemperatureSingle()
                    }

                    DeviceNotifyRsp.TYPE_SPORT_RECORD -> {
//                        sportRunning = false
//                        sportType = 0
//                        sportStatus = 0
//                        viewModel.syncTodaySportPlusDetailSingle()
                    }

                    DeviceNotifyRsp.TYPE_DND_SETTING, DeviceNotifyRsp.TYPE_TIME_FORMAT -> {
//                        EventBus.getDefault().post(DeviceToAppSyncEvent(resultEntity.dataType))
                    }

                    DeviceNotifyRsp.TYPE_BATTERY -> {
                        try {
                            val battery = BLEDataFormatUtils.bytes2Int(
                                byteArrayOf(
                                    resultEntity.loadData[1]
                                )
                            )
                            val charging = BLEDataFormatUtils.bytes2Int(
                                byteArrayOf(
                                    resultEntity.loadData[2]
                                )
                            )
                            updateBatteryStatus(battery, charging == DeviceNotifyRsp.CHARGE_STATUS_CHARGING)
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }

                    DeviceNotifyRsp.TYPE_BLOOD_GLUCOSE -> {
//                        viewModel.syncTodayBloodSugar(0x00)
                    }

                    DeviceNotifyRsp.TYPE_TARGET -> {
//                        CommandHandle.getInstance().executeReqCmd(
//                            TargetSettingReq.getReadInstance(), ICommandResponse<TargetSettingRsp> {
//                                XLog.i(it)
//                                if (it.action == TargetSettingRsp.ACTION_READ) {
//                                    ktxRunOnBgSingle {
//                                        if (it.step > 0) {
//                                            val target =
//                                                TargetEntity(
//                                                    UserConfig.getInstance().deviceAddressNoClear,
//                                                    it.step,
//                                                    it.calorie / 1000f,
//                                                    it.distance / 1000f,
//                                                    3f,
//                                                    8f, 1320, 540, 660
//                                                )
//                                            UserProfileRepository.getInstance.insertTarget(target)
//                                            EventBus.getDefault().post(DeviceNotifyTypeEvent(0x10))
//                                        }
//                                    }
//                                }
//                            }
//                        )
                    }

                    DeviceNotifyRsp.TYPE_AUTO_TEMPERATURE -> {
//                        viewModel.syncTodayTemperatureSingle()
                    }

                    DeviceNotifyRsp.TYPE_HRV -> {
//                        viewModel.syncTodayHrvSingle()
                    }

                    DeviceNotifyRsp.TYPE_PRESSURE -> {
//                        viewModel.syncTodayPressureSingle()
                    }

                    DeviceNotifyRsp.TYPE_GAME_EVENT -> {
//                        EventBus.getDefault().post(RingGameDataEvent())
                    }

                    DeviceNotifyRsp.TYPE_MUSLIM_TASBIH_CLICK -> {
                        //732500000013000700000000000000b2
                        val count = BLEDataFormatUtils.bytes2Int(
                            byteArrayOf(
                                resultEntity.loadData[1],
                                resultEntity.loadData[2],
                                resultEntity.loadData[3],
                                resultEntity.loadData[4],
                            )
                        )
                       getString(R.string.praise_count).format(count) .showToast()

//                        XLog.i(count)
//                        EventBus.getDefault().post(RingGameDataEvent())
//                        EventBus.getDefault().post(DataEvent(count, false))
//                        ktxRunOnBgSingle {
//                            Repository.getInstance.saveTotal(count)
//                            muslimTemp++
//                            ktxRunOnUi {
//                                try {
//                                    if (!muslimRefresh || muslimTemp > 10) {
//                                        muslimRefresh = true
//                                        muslimTemp = 0
//                                        viewModel.syncTodayOnly(object :
//                                            BaseDeviceResult<Rsp> {
//                                            override fun result(errorCode: Int, t: Rsp) {
//                                                ktxRunOnUi {
//                                                    healthyAdapter.updateCount(count, true)
//                                                }
//                                            }
//
//                                        })
//                                        if (count > 1) {
//                                            healthyModule()
//                                        }
//                                    }
//                                } catch (e: Exception) {
//                                    e.printStackTrace()
//                                }
//                            }
//                        }
//                        ktxRunOnUi {
//                            try {
//                                if (count >= UserConfig.getInstance().muslimCustomTarget) {
//                                    if (UserConfig.getInstance().muslimNotification != DateUtil().y_M_D) {
//                                        UserConfig.getInstance().muslimNotification =
//                                            DateUtil().y_M_D
//                                        UserConfig.getInstance().save()
//                                        XLog.i("----notification")
//                                        NotificationUtils(context).initMuslinNotification()
//                                    }
//                                } else {
//                                    XLog.i("----notification11")
//                                }
//                                healthyAdapter.updateCount(count, true)
//                            } catch (e: Exception) {
//                                e.printStackTrace()
//                            }
//                        }
                    }

                    DeviceNotifyRsp.TYPE_RAISE_WRIST -> {
                        // 亮屏和左右佩戴（屏幕方向切换） / Raise-to-wake and wear side (screen orientation switch).
                        XLog.i(ByteUtil.bytesToString(resultEntity.loadData))
                        // 屏幕：0 关，1 开 / Screen: 0 off, 1 on.
                        val open = BLEDataFormatUtils.bytes2Int(
                            byteArrayOf(
                                resultEntity.loadData[2]
                            )
                        )
                        // 1 左手佩戴，2 右手佩戴 / Wear side: 1 left hand, 2 right hand.
                        val wear = BLEDataFormatUtils.bytes2Int(
                            byteArrayOf(
                                resultEntity.loadData[2]
                            )
                        )
                        if (open == 1) {
                            if (wear == 1) {
                                XLog.i("Screen----left")
                            } else {
                                XLog.i("Screen----right")
                            }
                        } else {
                            XLog.i("Screen----close")
                        }

                    }

                    DeviceNotifyRsp.TYPE_STEP_CALORIE_DISTANCE -> {
                        //step calorie  distance update reminder
                        //7312 00005200025100003c0000000066
                        XLog.i(ByteUtil.bytesToString(resultEntity.loadData))

                        val step = BLEDataFormatUtils.bytes2Int(
                            byteArrayOf(
                                resultEntity.loadData[1],
                                resultEntity.loadData[2],
                                resultEntity.loadData[3]
                            )
                        )

                        val calorie = BLEDataFormatUtils.bytes2Int(
                            byteArrayOf(
                                resultEntity.loadData[4],
                                resultEntity.loadData[5],
                                resultEntity.loadData[6]
                            )
                        )
                        val distance = BLEDataFormatUtils.bytes2Int(
                            byteArrayOf(
                                resultEntity.loadData[7],
                                resultEntity.loadData[8],
                                resultEntity.loadData[9]
                            )
                        )

                        val content = getString(
                            R.string.qc_text_0031,
                            step.toString(),
                            calorie.toString(),
                            distance.toString()
                        )
                        XLog.d(content)
                        content.showToast()
                    }

                    DeviceNotifyRsp.TYPE_SPORT_HEART_RATE_WARNING -> {
                        // 运动心率预警提醒上报 / Sport heart-rate warning reminder report.
                        val heartValue = ByteUtil.byteToInt(resultEntity.loadData[1]).toString()
                        val content = getString(
                            R.string.qc_text_0030,
                            heartValue
                        )
                        showCmdRemindDialog(content)
                    }

                    DeviceNotifyRsp.TYPE_DRINK_WATER_REMINDER -> {
                        // 喝水提醒上报 / Drink-water reminder report.
                        showCmdRemindDialog(
                            getString(R.string.qc_text_0029)
                        )
                    }

                    DeviceNotifyRsp.TYPE_SEDENTARY_REMINDER -> {
                        // 久坐提醒上报 / Sedentary reminder report.
                        showCmdRemindDialog(getString(R.string.qc_text_0028))
                    }

                    DeviceNotifyRsp.TYPE_ALARM_REMINDER -> {
                        // 闹钟提醒上报 / Alarm reminder report.
                        val dateNow = DateUtil()
                        val nowMinute = dateNow.hour * 60 + dateNow.minute
                        //Your cache AlarmTime
                        val saveTime = dateNow.hour * 60 + dateNow.minute
                        if (saveTime == nowMinute) {
                            showCmdRemindDialog(getString(R.string.qc_text_0027))
                        }
                    }

//                    0x37 -> {
//                        // 设备端心率测量结果上报 / Device-side heart-rate measurement result report.
//                        val heartValue = ByteUtil.byteToInt(resultEntity.loadData[1])
//                    }

//                    0x38 -> {
//                        val praiseCount = ByteUtil.bytesToInt(
//                            byteArrayOf(
//                                resultEntity.loadData[2],
//                                resultEntity.loadData[3]
//                            )
//                        )
//                        EventBus.getDefault().post(DeviceCustomerPraiseCountEvent(praiseCount))
//                    }

                    DeviceNotifyRsp.TYPE_MENSTRUATION_REMINDER -> {
                        // 生理周期提醒 / Menstrual cycle reminder.
                        // 1 经期，2 排卵期 / 1 menstrual period, 2 ovulation period.
                        val type = ByteUtil.byteToInt(resultEntity.loadData[1])
                        //day later
                        val day = ByteUtil.byteToInt(resultEntity.loadData[2])
                        val content = if (type == 1) {
                            getString(R.string.qc_text_0025, day.toString())
                        } else {
                            getString(R.string.qc_text_0026, day.toString())
                        }
                        showCmdRemindDialog(content)
                    }

                    DeviceNotifyRsp.TYPE_AUTO_HEART_RATE_ALARM -> {
                        // 设备端心率过高过低提醒上报 / Device-side high/low heart-rate reminder report.
                        val type = ByteUtil.byteToInt(resultEntity.loadData[1])
                        // 心率值，如果设备支持 / Heart-rate value, if supported by the device.
                        val value = ByteUtil.byteToInt(resultEntity.loadData[2])

                        if (type == DeviceNotifyRsp.HEART_RATE_ALARM_LOW) {
                            showCmdRemindDialog(getString(R.string.qc_text_0021) + ":$value", "")
                        } else if (type == DeviceNotifyRsp.HEART_RATE_ALARM_HIGH) {
                            showCmdRemindDialog(getString(R.string.qc_text_0022) + ":$value", "")
                        }
                    }
                }
            }
        }
    }

    fun showCmdRemindDialog(content: String, title: String = getString(R.string.qc_text_0024)) {

        val dialog = NotificationDialog.Builder()
            .setConfirmMessage(getString(R.string.qc_text_0023))
            .setTitle(title)
            .setContent(content).build()

        if (!supportFragmentManager.isStateSaved) {
            dialog.show(supportFragmentManager, "showCmdRemindDialog")
        } else {
            window?.decorView?.post {
                if (!isFinishing && !supportFragmentManager.isStateSaved) {
                    dialog.show(supportFragmentManager, "showCmdRemindDialog")
                }
            }
        }
        dialog.setOnConfirmListener {}
    }

    inner class PermissionCallback : OnPermissionCallback {
        override fun onGranted(permissions: MutableList<String>, all: Boolean) {
            if (!all) {

            } else {
                startKtxActivity<DeviceBindActivity>()
            }
        }

        override fun onDenied(permissions: MutableList<String>, never: Boolean) {
            super.onDenied(permissions, never)
            if (never) {
                XXPermissions.startPermissionActivity(this@HomeActivity, permissions);
            }
        }

    }

    inner class BluetoothPermissionCallback : OnPermissionCallback {
        override fun onGranted(permissions: MutableList<String>, all: Boolean) {
            if (!all) {

            }
        }

        override fun onDenied(permissions: MutableList<String>, never: Boolean) {
            super.onDenied(permissions, never)
            if (never) {
                XXPermissions.startPermissionActivity(this@HomeActivity, permissions)
            }
        }

    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    override fun onMessageEvent(messageEvent: MessageEvent) {
        if(messageEvent is BluetoothEvent) {
            if (messageEvent.connect) {
                CommandHandle.getInstance()
                    .executeReqCmd(SetTimeReq(1), ICommandResponse<SetTimeRsp>() {
                        GlobalScope.launch {
                            SetTime.instance.updateFrom(it)
                        }
                    })
                CommandHandle.getInstance()
                    .executeReqCmd(
                        DeviceSupportReq.getReadInstance(),
                        ICommandResponse<DeviceSupportFunctionRsp> {
                            //supportBlePair to bleCreateBond
                            if(it.supportBlePair){
                                BleOperateManager.getInstance().bleCreateBond()
                            }
                            DeviceFunctionSupport.instance.updateFrom(it)
                        })
                showConnectedState()
                requestBatteryStatus()
            } else {
                showDisconnectedState()
            }
        }
    }

    private fun showConnectedState() {
        binding.tvBleStatus.text =
            getString(R.string.qc_text_0011) + getString(R.string.qc_text_0012)
        refreshConnectionActionState(isConnected = true)
        refreshFirmwareVersionState(isConnected = true)
    }

    private fun showDisconnectedState() {
        binding.tvBleStatus.text =
            getString(R.string.qc_text_0011) + getString(R.string.qc_text_0013)
        binding.tvBatteryStatus.visibility = View.GONE
        refreshConnectionActionState(isConnected = false)
        refreshFirmwareVersionState(isConnected = false)
    }

    private fun refreshConnectionActionState(
        isConnected: Boolean = BleOperateManager.getInstance().isConnected,
        deviceMac: String = HomeDeviceMac.resolve(
            runtimeMac = DeviceManager.getInstance().deviceAddress,
            cachedMac = MMKVManager.getLastConnectedDeviceMac()
        ).value
    ) {
        val uiState = HomeConnectionActionVisibility.resolve(
            isConnected = isConnected,
            deviceMac = deviceMac
        )
        binding.fivReconnect.visibility = if (uiState.reconnectVisible) View.VISIBLE else View.GONE
        binding.fivDisconnect.visibility = if (uiState.disconnectVisible) View.VISIBLE else View.GONE
        binding.fivBtPair.visibility = if (uiState.btPairVisible) View.VISIBLE else View.GONE
        binding.fivUnbindDevice.visibility = if (uiState.unbindVisible) View.VISIBLE else View.GONE
        binding.fivFindDevice.visibility = if (uiState.findDeviceVisible) View.VISIBLE else View.GONE
    }


    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onFirmwareVersionEvent(messageEvent: FirmwareVersionEvent) {
        refreshFirmwareVersionState(firmwareVersion = messageEvent.firmwareVersion)
    }

    private fun refreshFirmwareVersionState(
        isConnected: Boolean = BleOperateManager.getInstance().isConnected,
        firmwareVersion: String = MyApplication.getInstance.firmwareVersion
    ) {
        val uiState = HomeFirmwareVersionVisibility.resolve(
            isConnected = isConnected,
            firmwareVersion = firmwareVersion
        )
        binding.tvFirmwareVersion.visibility = if (uiState.visible) View.VISIBLE else View.GONE
        if (uiState.visible) {
            binding.tvFirmwareVersion.text =
                getString(R.string.qc_text_0104, uiState.firmwareVersion)
        }
    }

    private fun requestBatteryStatus() {
        XLog.tag("BatteryTTest").d("requestBatteryStatus: start")
        CommandHandle.getInstance()
            .executeReqCmd(
                SimpleKeyReq(Constants.CMD_GET_DEVICE_ELECTRICITY_VALUE),
                ICommandResponse<BatteryRsp> {
                    XLog.tag("BatteryTTest").d("requestBatteryStatus:end:status"+it.status+"battery:"+it.batteryValue)
                    if (it.status == BaseRspCmd.RESULT_OK) {
                        updateBatteryStatus(it.batteryValue, it.isCharging)
                    }
                })
    }

    private fun updateBatteryStatus(battery: Int, isCharging: Boolean) {
        binding.root.post {
            if (!BleOperateManager.getInstance().isConnected) {
                binding.tvBatteryStatus.visibility = View.GONE
                return@post
            }
            binding.tvBatteryStatus.text = BatteryStatusFormatter.format(this, battery, isCharging)
            binding.tvBatteryStatus.visibility = View.VISIBLE
        }
    }

    private fun reconnectDevice() {
        val deviceMac = HomeDeviceMac.resolve(
            runtimeMac = DeviceManager.getInstance().deviceAddress,
            cachedMac = MMKVManager.getLastConnectedDeviceMac()
        )
        if (deviceMac.hasValue) {
            DeviceManager.getInstance().deviceAddress = deviceMac.value
            BleOperateManager.getInstance().connectDirectly(deviceMac.value)
        }
    }

    @BleIsConnected
    private fun disconnectDevice() {
        if( DeviceFunctionSupport.instance.supportBlePair) {
            BleOperateManager.getInstance().unBindDevice()
            showDisconnectedState()
        }else{
            BleOperateManager.getInstance().disconnect()
        }
    }

    @BleIsConnected
    private fun createBond() {
        BleOperateManager.getInstance().bleCreateBond()
    }

    @BleIsConnected
    private fun unbindDevice() {
        BleOperateManager.getInstance().unBindDevice()
        showDisconnectedState()
    }

    @BleIsConnected
    private fun findDevice() {
        CommandHandle.getInstance().executeReqCmd(FindDeviceReq()) { }
    }

    override fun onDestroy() {
        super.onDestroy()
        BleOperateManager.getInstance().removeNotifyListener(MAIN_KEY)
    }
}

