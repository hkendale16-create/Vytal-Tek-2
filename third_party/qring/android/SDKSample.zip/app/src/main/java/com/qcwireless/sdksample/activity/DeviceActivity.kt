package com.qcwireless.sdksample.activity

import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import com.oudmon.ble.base.bluetooth.BleOperateManager
import com.oudmon.ble.base.communication.Constants
import com.oudmon.ble.base.communication.ICommandResponse
import com.oudmon.ble.base.communication.req.BatterySavingReq
import com.oudmon.ble.base.communication.req.CameraReq
import com.oudmon.ble.base.communication.req.DegreeSwitchReq
import com.oudmon.ble.base.communication.req.RestoreKeyReq
import com.oudmon.ble.base.communication.rsp.BaseRspCmd
import com.oudmon.ble.base.communication.rsp.CameraNotifyRsp
import com.qcwireless.sdksample.R
import com.qcwireless.sdksample.annotation.BleIsConnected
import com.qcwireless.sdksample.databinding.ActivityDeviceBinding
import com.qcwireless.sdksample.ext.showToast
import com.qcwireless.sdksample.ext.startKtxActivity
import com.qcwireless.sdksample.log.BluetoothLogManager

class DeviceActivity : BaseFunctionActivity() {

    private lateinit var binding: ActivityDeviceBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDeviceBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }

    override fun setupViews() {
        super.setupViews()
        binding.titleBar.tvTitle.text = getString(R.string.title_device)
        bindSettingAction(
            binding.fivSetDegreeSwitch,
            LOG_TAG,
            "Set Degree Switch",
            "DegreeSwitchReq",
            "enable=true, isCelsius=true"
        ) { DegreeSwitchReq.getWriteInstance(true, true) }
        bindSettingAction(
            binding.fivGetDegreeSwitch,
            LOG_TAG,
            "Get Degree Switch",
            "DegreeSwitchReq",
            "read"
        ) { DegreeSwitchReq.getReadInstance() }
        bindSettingAction(
            binding.fivSetBatterySaving,
            LOG_TAG,
            "Set Battery Saving",
            "BatterySavingReq",
            "enable=true"
        ) { BatterySavingReq.getWriteInstance(true) }
        bindSettingAction(
            binding.fivGetBatterySaving,
            LOG_TAG,
            "Get Battery Saving",
            "BatterySavingReq",
            "read"
        ) { BatterySavingReq.getReadInstance() }
        binding.fivStartCameraControl.setOnClickListener { startCameraControl() }
        binding.fivStopCameraControl.setOnClickListener { stopCameraControl() }
        binding.fivWearCalibration.setOnClickListener {
            startKtxActivity<RevisionActivity>()
        }
        binding.fivShutdownDevice.setOnClickListener {
            confirmHighRiskAction(
                message = getString(R.string.high_risk_shutdown_message)
            ) { shutdownDevice() }
        }
        binding.fivRebootDevice.setOnClickListener {
            confirmHighRiskAction(
                message = getString(R.string.high_risk_reboot_message)
            ) { rebootDevice() }
        }
        binding.fivRestoreFactory.setOnClickListener {
            confirmHighRiskAction(
                message = getString(R.string.high_risk_restore_factory_message)
            ) { restoreFactorySettings() }
        }
        refreshCachesIfConnected()
    }

    override fun onResume() {
        super.onResume()
        refreshCachesIfConnected()
    }

    @BleIsConnected
    private fun startCameraControl() {
        val actionName = getString(R.string.display_start_camera_control)
        BluetoothLogManager.addExternalLog("[REQ]\naction=$actionName request=CameraReq(ACTION_INTO_CAMARA_UI)")
        commandHandle.executeReqCmd(
            CameraReq(CameraReq.ACTION_INTO_CAMARA_UI),
            ICommandResponse<BaseRspCmd> { rsp ->
                val success = rsp.status == BaseRspCmd.RESULT_OK
                BluetoothLogManager.addExternalLog(
                    "[RSP]\naction=$actionName success=$success status=${rsp.status}"
                )
                if (success) {
                    getString(R.string.camera_control_started).showToast()
                    registerCameraNotifyListener()
                } else {
                    (actionName + getString(R.string.qc_text_0054)).showToast()
                }
            }
        )
    }

    @BleIsConnected
    private fun stopCameraControl() {
        val actionName = getString(R.string.display_stop_camera_control)
        BluetoothLogManager.addExternalLog("[REQ]\naction=$actionName request=CameraReq(ACTION_FINISH)")
        commandHandle.executeReqCmd(
            CameraReq(CameraReq.ACTION_FINISH),
            ICommandResponse<BaseRspCmd> { rsp ->
                val success = rsp.status == BaseRspCmd.RESULT_OK
                BluetoothLogManager.addExternalLog(
                    "[RSP]\naction=$actionName success=$success status=${rsp.status}"
                )
                BleOperateManager.getInstance()
                    .removeNotifyListener(Constants.CMD_TAKING_PICTURE.toInt())
                if (success) {
                    getString(R.string.camera_control_stopped).showToast()
                } else {
                    (actionName + getString(R.string.qc_text_0054)).showToast()
                }
            }
        )
    }

    private fun registerCameraNotifyListener() {
        BleOperateManager.getInstance()
            .addNotifyListener(
                Constants.CMD_TAKING_PICTURE.toInt(),
                ICommandResponse<CameraNotifyRsp> { rsp ->
                    val message = when (rsp.action) {
                        CameraNotifyRsp.ACTION_TAKE_PHOTO -> getString(R.string.camera_control_take_photo)
                        CameraNotifyRsp.ACTION_FINISH -> getString(R.string.camera_control_finished)
                        else -> getString(R.string.camera_control_unknown_action, rsp.action)
                    }
                    BluetoothLogManager.addExternalLog("[NOTIFY]\naction=${getString(R.string.display_start_camera_control)} message=$message")
                    message.showToast()
                }
            )
    }

    private fun confirmHighRiskAction(
        message: String,
        onConfirm: () -> Unit
    ) {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.high_risk_confirm_title))
            .setMessage(message)
            .setPositiveButton(getString(R.string.high_risk_confirm_button)) { _, _ -> onConfirm() }
            .setNegativeButton(getString(R.string.common_cancel), null)
            .show()
    }

    @BleIsConnected
    private fun shutdownDevice() {
        val actionName = getString(R.string.device_shutdown_device)
        BluetoothLogManager.addExternalLog("[REQ]\naction=$actionName request=BleOperateManager.shutdown")
        BleOperateManager.getInstance().shutdown()
        getString(R.string.high_risk_action_sent, actionName).showToast()
    }

    @BleIsConnected
    private fun rebootDevice() {
        val actionName = getString(R.string.device_reboot_device)
        BluetoothLogManager.addExternalLog("[REQ]\naction=$actionName request=RestoreKeyReq(CMD_RE_BOOT)")
        commandHandle.executeReqCmd(
            RestoreKeyReq(Constants.CMD_RE_BOOT),
            ICommandResponse<BaseRspCmd> { rsp -> handleHighRiskResponse(actionName, rsp) }
        )
    }

    @BleIsConnected
    private fun restoreFactorySettings() {
        val actionName = getString(R.string.device_restore_factory)
        BluetoothLogManager.addExternalLog("[REQ]\naction=$actionName request=RestoreKeyReq(CMD_RE_STORE)")
        commandHandle.executeReqCmd(
            RestoreKeyReq(Constants.CMD_RE_STORE),
            ICommandResponse<BaseRspCmd> { rsp -> handleHighRiskResponse(actionName, rsp) }
        )
    }

    private fun handleHighRiskResponse(actionName: String, rsp: BaseRspCmd) {
        val success = rsp.status == BaseRspCmd.RESULT_OK
        BluetoothLogManager.addExternalLog(
            "[RSP]\naction=$actionName success=$success status=${rsp.status}"
        )
        if (success) {
            getString(R.string.high_risk_action_success, actionName).showToast()
        } else {
            getString(R.string.high_risk_action_failed, actionName, rsp.status).showToast()
        }
    }

    companion object {
        private const val LOG_TAG = "Device"
    }
}
