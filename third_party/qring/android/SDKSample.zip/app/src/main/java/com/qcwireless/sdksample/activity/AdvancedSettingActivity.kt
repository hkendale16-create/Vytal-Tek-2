package com.qcwireless.sdksample.activity

import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.core.view.isVisible
import com.oudmon.ble.base.bluetooth.BleOperateManager
import com.oudmon.ble.base.communication.ICommandResponse
import com.oudmon.ble.base.communication.req.AgpsReq
import com.oudmon.ble.base.communication.req.BluetoothCloseReq
import com.oudmon.ble.base.communication.req.DeviceSupportReq
import com.oudmon.ble.base.communication.req.IntellReq
import com.oudmon.ble.base.communication.req.MuslimReq
import com.oudmon.ble.base.communication.req.MuslimTargetReq
import com.oudmon.ble.base.communication.req.ReadPersonalizationSettingReq
import com.oudmon.ble.base.communication.rsp.BaseRspCmd
import com.qcwireless.sdksample.R
import com.qcwireless.sdksample.annotation.BleIsConnected
import com.qcwireless.sdksample.cache.DeviceFunctionSupport
import com.qcwireless.sdksample.databinding.ActivityAdvancedSettingBinding
import com.qcwireless.sdksample.ext.showToast
import com.qcwireless.sdksample.ext.startKtxActivity
import com.qcwireless.sdksample.log.BluetoothLogManager

class AdvancedSettingActivity : BaseFunctionActivity() {

    private lateinit var binding: ActivityAdvancedSettingBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAdvancedSettingBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }

    override fun setupViews() {
        super.setupViews()
        binding.titleBar.tvTitle.text = getString(R.string.title_advanced)
        bindSettingAction(
            binding.fivSetAgps,
            LOG_TAG,
            "Set AGPS",
            "AgpsReq",
            "enable=true"
        ) { AgpsReq.getWriteInstance(true) }
        bindSettingAction(
            binding.fivGetAgps,
            LOG_TAG,
            "Get AGPS",
            "AgpsReq",
            "read"
        ) { AgpsReq.getReadInstance() }
        bindSettingAction(
            binding.fivSetIntell,
            LOG_TAG,
            "Set Intell",
            "IntellReq",
            "isEnable=true, delaySecond=5"
        ) { IntellReq.getWriteInstance(true, 5.toByte()) }
        bindSettingAction(
            binding.fivGetIntell,
            LOG_TAG,
            "Get Intell",
            "IntellReq",
            "read"
        ) { IntellReq.getReadInstance() }
        bindSettingAction(
            binding.fivSetMuslim,
            LOG_TAG,
            "Set Muslim",
            "MuslimReq",
            "enable=true",
            ::ensureMuslimSupported
        ) { MuslimReq.getWriteInstance(true) }
        bindSettingAction(
            binding.fivSetMuslimTarget,
            LOG_TAG,
            "Set Muslim Target",
            "MuslimTargetReq",
            "goal=33",
            ::ensureMuslimSupported
        ) { MuslimTargetReq(33) }
        binding.fivCloseDeviceBluetooth.setOnClickListener {
            confirmHighRiskAction(
                message = getString(R.string.high_risk_close_bluetooth_message)
            ) { closeDeviceBluetooth() }
        }
        binding.fivShutdownDevice.setOnClickListener {
            confirmHighRiskAction(
                message = getString(R.string.high_risk_shutdown_message)
            ) { shutdownDevice() }
        }
        bindSettingAction(
            binding.fivGetDeviceSupport,
            LOG_TAG,
            "Get Device Support",
            "DeviceSupportReq",
            "read"
        ) { DeviceSupportReq.getReadInstance() }
        bindSettingAction(
            binding.fivGetPersonalizationSetting,
            LOG_TAG,
            "Get Personalization Setting",
            "ReadPersonalizationSettingReq",
            "read"
        ) { ReadPersonalizationSettingReq.getReadInstance() }
        binding.fivRecording.setOnClickListener {
            startKtxActivity<RecordingActivity>()
        }
        binding.fivRecording.isVisible = DeviceFunctionSupport.instance.supportAudio
        refreshCachesIfConnected()
    }

    private fun confirmHighRiskAction(
        message: String,
        onConfirm: () -> Unit
    ) {
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.high_risk_confirm_title))
            .setMessage(message)
            .setPositiveButton(getString(R.string.high_risk_confirm_button)) { _, _ -> onConfirm() }
            .setNegativeButton(getString(R.string.common_cancel), null)
            .show()
    }

    @BleIsConnected
    private fun closeDeviceBluetooth() {
        val actionName = getString(R.string.advanced_close_device_bluetooth)
        BluetoothLogManager.addExternalLog("[REQ]\naction=$actionName request=BluetoothCloseReq")
        commandHandle.executeReqCmd(
            BluetoothCloseReq.getWriteInstance(),
            ICommandResponse<BaseRspCmd> { rsp -> handleHighRiskResponse(actionName, rsp) }
        )
    }

    @BleIsConnected
    private fun shutdownDevice() {
        val actionName = getString(R.string.advanced_shutdown_device)
        BluetoothLogManager.addExternalLog("[REQ]\naction=$actionName request=BleOperateManager.shutdown")
        BleOperateManager.getInstance().shutdown()
        getString(R.string.high_risk_action_sent, actionName).showToast()
    }

    private fun handleHighRiskResponse(actionName: String, rsp: BaseRspCmd) {
        val success = rsp.status == BaseRspCmd.RESULT_OK
        BluetoothLogManager.addExternalLog(
            "[RSP]\naction=$actionName success=$success status=${rsp.status}"
        )
        if (success) {
            getString(R.string.high_risk_action_success, actionName).showToast()
        } else {
            getString(R.string.high_risk_action_failed, actionName, rsp.status).showToast()
        }
    }

    override fun onResume() {
        super.onResume()
        refreshCachesIfConnected()
    }

    companion object {
        private const val LOG_TAG = "AdvancedSetting"
    }
}
