package com.qcwireless.sdksample.activity

import org.junit.Assert.assertArrayEquals
import org.junit.Test

class PressureIntervalOptionsTest {

    @Test
    fun buildIncludesFiveWhenMinimumIsFiveOrLess() {
        assertArrayEquals(
            intArrayOf(5, 10, 15, 20, 30, 60),
            PressureIntervalOptions.build(5)
        )
        assertArrayEquals(
            intArrayOf(5, 10, 15, 20, 30, 60),
            PressureIntervalOptions.build(1)
        )
    }

    @Test
    fun buildStartsAtTenWhenMinimumIsTen() {
        assertArrayEquals(
            intArrayOf(10, 15, 20, 30, 60),
            PressureIntervalOptions.build(10)
        )
    }

    @Test
    fun buildStartsAtFifteenWhenMinimumIsFifteen() {
        assertArrayEquals(
            intArrayOf(15, 20, 30, 60),
            PressureIntervalOptions.build(15)
        )
    }

    @Test
    fun buildFiltersStandardOptionsAboveFifteen() {
        assertArrayEquals(
            intArrayOf(20, 30, 60),
            PressureIntervalOptions.build(20)
        )
        assertArrayEquals(
            intArrayOf(30, 60),
            PressureIntervalOptions.build(30)
        )
        assertArrayEquals(
            intArrayOf(60),
            PressureIntervalOptions.build(60)
        )
    }

    @Test
    fun buildFallsBackToMinimumWhenNoStandardOptionIsLargeEnough() {
        assertArrayEquals(
            intArrayOf(90),
            PressureIntervalOptions.build(90)
        )
    }
}
