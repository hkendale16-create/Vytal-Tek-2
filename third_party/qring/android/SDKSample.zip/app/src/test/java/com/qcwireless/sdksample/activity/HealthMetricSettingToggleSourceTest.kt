package com.qcwireless.sdksample.activity

import java.io.File
import org.junit.Assert.assertTrue
import org.junit.Test

class HealthMetricSettingToggleSourceTest {

    @Test
    fun healthMetricPagesExposeSettingOpenAndCloseActions() {
        val pages = listOf(
            Page(
                activityPath = "src/main/java/com/qcwireless/sdksample/activity/HeartRateActivity.kt",
                layoutPath = "src/main/res/layout/activity_heart_rate.xml",
                openId = "fiv_heart_rate_setting_open",
                closeId = "fiv_heart_rate_setting_close",
                openBinding = "binding.fivHeartRateSettingOpen.setOnClickListener",
                closeBinding = "binding.fivHeartRateSettingClose.setOnClickListener",
                writerSignature = "private fun writeHeartRateSetting(enable: Boolean)",
                openCall = "writeHeartRateSetting(true)",
                closeCall = "writeHeartRateSetting(false)",
                request = "HeartRateSettingReq.getWriteInstance(enable"
            ),
            Page(
                activityPath = "src/main/java/com/qcwireless/sdksample/activity/BloodPressureActivity.kt",
                layoutPath = "src/main/res/layout/activity_blood_pressure.xml",
                openId = "fiv_setting_open",
                closeId = "fiv_setting_close",
                openBinding = "binding.fivSettingOpen.setOnClickListener",
                closeBinding = "binding.fivSettingClose.setOnClickListener",
                writerSignature = "private fun writeBloodPressureSetting(enable: Boolean)",
                openCall = "writeBloodPressureSetting(true)",
                closeCall = "writeBloodPressureSetting(false)",
                request = "BpSettingReq.getWriteInstance(enable"
            ),
            Page(
                activityPath = "src/main/java/com/qcwireless/sdksample/activity/BloodOxygenActivity.kt",
                layoutPath = "src/main/res/layout/activity_blood_oxygen.xml",
                openId = "fiv_setting_open",
                closeId = "fiv_setting_close",
                openBinding = "binding.fivSettingOpen.setOnClickListener",
                closeBinding = "binding.fivSettingClose.setOnClickListener",
                writerSignature = "private fun writeBloodOxygenSetting(enable: Boolean)",
                openCall = "writeBloodOxygenSetting(true)",
                closeCall = "writeBloodOxygenSetting(false)",
                request = "BloodOxygenSettingReq.getWriteInstance(enable"
            ),
            Page(
                activityPath = "src/main/java/com/qcwireless/sdksample/activity/HrvActivity.kt",
                layoutPath = "src/main/res/layout/activity_hrv.xml",
                openId = "fiv_setting_open",
                closeId = "fiv_setting_close",
                openBinding = "binding.fivSettingOpen.setOnClickListener",
                closeBinding = "binding.fivSettingClose.setOnClickListener",
                writerSignature = "private fun writeHrvSetting(enable: Boolean)",
                openCall = "writeHrvSetting(true)",
                closeCall = "writeHrvSetting(false)",
                request = "HrvSettingReq.getWriteInstance(enable"
            ),
            Page(
                activityPath = "src/main/java/com/qcwireless/sdksample/activity/PressureActivity.kt",
                layoutPath = "src/main/res/layout/activity_pressure.xml",
                openId = "fiv_setting_open",
                closeId = "fiv_setting_close",
                openBinding = "binding.fivSettingOpen.setOnClickListener",
                closeBinding = "binding.fivSettingClose.setOnClickListener",
                writerSignature = "private fun writePressureSetting(enable: Boolean)",
                openCall = "writePressureSetting(true)",
                closeCall = "writePressureSetting(false)",
                request = "createPressureSettingWriteRequest(enable"
            ),
            Page(
                activityPath = "src/main/java/com/qcwireless/sdksample/activity/TemperatureActivity.kt",
                layoutPath = "src/main/res/layout/activity_temperature.xml",
                openId = "fiv_setting_open",
                closeId = "fiv_setting_close",
                openBinding = "binding.fivSettingOpen.setOnClickListener",
                closeBinding = "binding.fivSettingClose.setOnClickListener",
                writerSignature = "private fun writeTemperatureSetting(enable: Boolean)",
                openCall = "writeTemperatureSetting(true)",
                closeCall = "writeTemperatureSetting(false)",
                request = "TemperatureSettingReq.getWriteInstance(enable"
            )
        )

        pages.forEach { page ->
            val activitySource = projectFile(page.activityPath).readText()
            val layoutSource = projectFile(page.layoutPath).readText()

            assertTrue("${page.layoutPath} missing ${page.openId}", layoutSource.contains(page.openId))
            assertTrue("${page.layoutPath} missing ${page.closeId}", layoutSource.contains(page.closeId))
            assertTrue("${page.activityPath} missing open click binding", activitySource.contains(page.openBinding))
            assertTrue("${page.activityPath} missing close click binding", activitySource.contains(page.closeBinding))
            assertTrue("${page.activityPath} missing open click call", activitySource.contains(page.openCall))
            assertTrue("${page.activityPath} missing close click call", activitySource.contains(page.closeCall))
            assertTrue("${page.activityPath} missing enable-aware writer", activitySource.contains(page.writerSignature))
            assertTrue("${page.activityPath} missing enable-aware request", activitySource.contains(page.request))
        }
    }

    private data class Page(
        val activityPath: String,
        val layoutPath: String,
        val openId: String,
        val closeId: String,
        val openBinding: String,
        val closeBinding: String,
        val writerSignature: String,
        val openCall: String,
        val closeCall: String,
        val request: String
    )

    private fun projectFile(path: String): File {
        return sequenceOf(File(path), File("app/$path"))
            .first { it.isFile }
    }
}
