package com.qcwireless.sdksample.ext

import java.io.File
import org.junit.Assert.assertTrue
import org.junit.Test

class CommonExtSourceTest {

    @Test
    fun showToastPostsToastCreationToMainLooper() {
        val source = commonExtSource()

        assertTrue(
            "showToast should create and show Toast on the main thread",
            Regex(
                """fun\s+CharSequence\.showToast\([^)]*\)\s*\{[\s\S]*Handler\(Looper\.getMainLooper\(\)\)\.post\s*\{[\s\S]*Toast\.makeText\([\s\S]*\.show\(\)[\s\S]*\}[\s\S]*\}"""
            ).containsMatchIn(source)
        )
    }

    private fun commonExtSource(): String {
        val path = "src/main/java/com/qcwireless/sdksample/ext/CommonExt.kt"
        return sequenceOf(File(path), File("app/$path"))
            .first { it.isFile }
            .readText()
    }
}
