package com.qcwireless.sdksample.activity

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class HomeDeviceMacTest {

    @Test
    fun runtimeMacTakesPriorityOverCachedMac() {
        val deviceMac = HomeDeviceMac.resolve(
            runtimeMac = "AA:BB:CC:DD:EE:FF",
            cachedMac = "11:22:33:44:55:66"
        )

        assertEquals("AA:BB:CC:DD:EE:FF", deviceMac.value)
        assertTrue(deviceMac.hasValue)
    }

    @Test
    fun cachedMacIsUsedWhenRuntimeMacIsEmpty() {
        val deviceMac = HomeDeviceMac.resolve(
            runtimeMac = " ",
            cachedMac = "11:22:33:44:55:66"
        )

        assertEquals("11:22:33:44:55:66", deviceMac.value)
        assertTrue(deviceMac.hasValue)
    }

    @Test
    fun missingRuntimeAndCachedMacHasNoValue() {
        val deviceMac = HomeDeviceMac.resolve(
            runtimeMac = "",
            cachedMac = ""
        )

        assertEquals("", deviceMac.value)
        assertFalse(deviceMac.hasValue)
    }
}
