package com.qcwireless.sdksample.activity

import java.io.File
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class EmotionActivitySourceTest {

    @Test
    fun emotionSettingUsesSugarLipidsSettingReq() {
        val source = emotionActivitySource()

        assertTrue(source.contains("SugarLipidsSettingReq.getReadEmotionInstance()"))
        assertTrue(source.contains("SugarLipidsSettingReq.getWriteEmotionInstance(enable)"))
    }

    @Test
    fun emotionDataUsesBleOperateManagerEmotionQueries() {
        val source = emotionActivitySource()

        assertFalse(source.contains("PressureReq"))
        assertTrue(
            Regex("""BleOperateManager\.getInstance\(\)\.getEmotion\(\s*0\s*,""")
                .containsMatchIn(source)
        )
        assertTrue(source.contains("BleOperateManager.getInstance().getEmotions(startDayIndex, count, callback)"))
        assertFalse(source.contains("getMethod("))
    }

    private fun emotionActivitySource(): String {
        val path = "src/main/java/com/qcwireless/sdksample/activity/EmotionActivity.kt"
        return sequenceOf(File(path), File("app/$path"))
            .first { it.isFile }
            .readText()
    }
}
