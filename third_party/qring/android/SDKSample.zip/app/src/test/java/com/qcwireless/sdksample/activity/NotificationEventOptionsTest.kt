package com.qcwireless.sdksample.activity

import org.junit.Assert.assertEquals
import org.junit.Test

class NotificationEventOptionsTest {

    @Test
    fun lightModesMapProtocolValues() {
        assertEquals(
            listOf(
                NotificationEventOptions.Option("0 NULL", 0),
                NotificationEventOptions.Option("1 Stop", 1),
                NotificationEventOptions.Option("2 Green", 2),
                NotificationEventOptions.Option("3 Red", 3)
            ),
            NotificationEventOptions.lightModes
        )
    }

    @Test
    fun vibrationModesMapProtocolValues() {
        assertEquals(
            listOf(
                NotificationEventOptions.Option("0 NULL", 0),
                NotificationEventOptions.Option("1 Stop", 1),
                NotificationEventOptions.Option("2 Start", 2)
            ),
            NotificationEventOptions.vibrationModes
        )
    }

    @Test
    fun numericOptionsExposeSamplePresets() {
        assertEquals(listOf(0, 1, 3, 5, 10), NotificationEventOptions.priorities.map { it.value })
        assertEquals(listOf(1, 3, 5, 10), NotificationEventOptions.loopCounts.map { it.value })
        assertEquals(listOf(1, 5, 10, 20, 50, 127), NotificationEventOptions.activeDurations.map { it.value })
        assertEquals(listOf(0, 5, 10, 20, 50), NotificationEventOptions.pauseDurations.map { it.value })
    }
}
