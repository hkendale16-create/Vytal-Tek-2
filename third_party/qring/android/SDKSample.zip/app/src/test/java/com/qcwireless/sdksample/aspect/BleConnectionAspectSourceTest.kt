package com.qcwireless.sdksample.aspect

import java.io.File
import org.junit.Assert.assertTrue
import org.junit.Test

class BleConnectionAspectSourceTest {

    @Test
    fun aspectPromptsWhenBluetoothIsDisabledBeforeSendingCommand() {
        val aspectSource = source("app/src/main/java/com/qcwireless/sdksample/aspect/BleConnectionAspect.kt")
        val stringsSource = source("app/src/main/res/values/strings.xml")
        val zhStringsSource = source("app/src/main/res/values-zh-rCN/strings.xml")

        assertTrue(
            "BleConnectionAspect should check whether system Bluetooth is enabled",
            aspectSource.contains("BluetoothUtils.isEnabledBluetooth(application)")
        )
        assertTrue(
            "BleConnectionAspect should show the Bluetooth disabled message",
            aspectSource.contains("R.string.bluetooth_disabled_prompt")
        )
        assertTrue(
            "English strings should define bluetooth_disabled_prompt",
            stringsSource.contains("name=\"bluetooth_disabled_prompt\"")
        )
        assertTrue(
            "Chinese strings should ask the user to turn on Bluetooth first",
            zhStringsSource.contains("name=\"bluetooth_disabled_prompt\"") &&
                zhStringsSource.contains("请先开启蓝牙")
        )
    }

    private fun source(path: String): String {
        return sequenceOf(File(path), File("../$path"))
            .first { it.isFile }
            .readText()
    }
}
