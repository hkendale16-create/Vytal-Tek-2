package com.qcwireless.sdksample.activity

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class HeartRateRealtimeMeasureTest {

    @Test
    fun actionsMatchRealtimeHeartRateProtocolTypes() {
        assertEquals(0x01, HeartRateRealtimeMeasure.ACTION_START)
        assertEquals(0x02, HeartRateRealtimeMeasure.ACTION_STOP)
        assertEquals(0x03, HeartRateRealtimeMeasure.ACTION_CONTINUE)
    }

    @Test
    fun timingMatchesReferenceHeartActivityRealtimeFlow() {
        assertEquals(2_000L, HeartRateRealtimeMeasure.CONTINUE_INTERVAL_MS)
        assertEquals(30_000L, HeartRateRealtimeMeasure.TIMEOUT_CLOSE_MS)
    }

    @Test
    fun requestUsesSelectedRealtimeHeartRateType() {
        val request = HeartRateRealtimeMeasure.createRequest(HeartRateRealtimeMeasure.ACTION_CONTINUE)

        assertEquals(0x03, request.type)
    }

    @Test
    fun supportDependsOnlyOnSetTimeAppMeasureFlag() {
        assertTrue(HeartRateRealtimeMeasure.isSupported(true))
        assertFalse(HeartRateRealtimeMeasure.isSupported(false))
    }

    @Test
    fun startRealtimeHeartRateReturnsPositiveHeartForDisplay() {
        val displayValue = HeartRateRealtimeMeasure.getDisplayHeartValue(
            HeartRateRealtimeMeasure.ACTION_START,
            72
        )

        assertEquals("72", displayValue)
    }

    @Test
    fun startRealtimeHeartRateIgnoresZeroHeartForDisplay() {
        val displayValue = HeartRateRealtimeMeasure.getDisplayHeartValue(
            HeartRateRealtimeMeasure.ACTION_START,
            0
        )

        assertEquals(null, displayValue)
    }

    @Test
    fun continueRealtimeHeartRateReturnsPositiveHeartForDisplay() {
        val displayValue = HeartRateRealtimeMeasure.getDisplayHeartValue(
            HeartRateRealtimeMeasure.ACTION_CONTINUE,
            73
        )

        assertEquals("73", displayValue)
    }

    @Test
    fun nonStartRealtimeHeartRateDoesNotReturnHeartForDisplay() {
        val displayValue = HeartRateRealtimeMeasure.getDisplayHeartValue(
            HeartRateRealtimeMeasure.ACTION_STOP,
            72
        )

        assertEquals(null, displayValue)
    }
}
