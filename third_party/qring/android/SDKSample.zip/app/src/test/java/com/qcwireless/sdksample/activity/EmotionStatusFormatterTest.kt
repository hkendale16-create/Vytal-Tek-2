package com.qcwireless.sdksample.activity

import org.junit.Assert.assertEquals
import org.junit.Test

class EmotionStatusFormatterTest {

    @Test
    fun formatsKnownEmotionStatuses() {
        assertEquals("0.null", EmotionStatusFormatter.format(0))
        assertEquals("1.兴奋", EmotionStatusFormatter.format(1))
        assertEquals("2.开心", EmotionStatusFormatter.format(2))
        assertEquals("3.愉悦", EmotionStatusFormatter.format(3))
        assertEquals("4.平静", EmotionStatusFormatter.format(4))
        assertEquals("5.紧张", EmotionStatusFormatter.format(5))
        assertEquals("6.困惑", EmotionStatusFormatter.format(6))
        assertEquals("7.挑战", EmotionStatusFormatter.format(7))
        assertEquals("8.不舒服", EmotionStatusFormatter.format(8))
        assertEquals("9.伤心", EmotionStatusFormatter.format(9))
        assertEquals("10.焦虑", EmotionStatusFormatter.format(10))
    }

    @Test
    fun formatsUnknownEmotionStatus() {
        assertEquals("11.unknown", EmotionStatusFormatter.format(11))
    }
}
