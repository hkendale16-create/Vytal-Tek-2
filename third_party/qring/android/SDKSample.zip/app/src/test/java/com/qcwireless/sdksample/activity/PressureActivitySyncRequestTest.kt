package com.qcwireless.sdksample.activity

import java.io.File
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PressureActivitySyncRequestTest {

    @Test
    fun syncPressureDataUsesBleOperateManagerPressureQuery() {
        val source = pressureActivitySource()

        assertFalse(source.contains("PressureReq"))
        assertTrue(
            Regex("""BleOperateManager\.getInstance\(\)\.getPressure\(\s*0\s*,""")
                .containsMatchIn(source)
        )
    }

    private fun pressureActivitySource(): String {
        val path = "src/main/java/com/qcwireless/sdksample/activity/PressureActivity.kt"
        return sequenceOf(File(path), File("app/$path"))
            .first { it.isFile }
            .readText()
    }
}
