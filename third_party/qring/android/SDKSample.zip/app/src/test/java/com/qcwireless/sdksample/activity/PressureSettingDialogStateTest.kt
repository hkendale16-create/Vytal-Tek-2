package com.qcwireless.sdksample.activity

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PressureSettingDialogStateTest {

    @Test
    fun buildKeepsCurrentSwitchAndIntervalSelection() {
        val state = PressureSettingDialogState.build(
            isEnabled = true,
            supportsInterval = true,
            minInterval = 10,
            currentInterval = 15
        )

        assertTrue(state.isEnabled)
        assertTrue(state.supportsInterval)
        assertEquals(10, state.minInterval)
        assertEquals(listOf(10, 15, 20, 30, 60), state.intervalOptions)
        assertEquals(1, state.selectedIntervalIndex)
        assertEquals(15, state.selectedInterval)
        assertEquals(listOf("10 min", "15 min", "20 min", "30 min", "60 min"), state.intervalLabels)
    }

    @Test
    fun buildFallsBackToFirstIntervalWhenCurrentIntervalIsUnavailable() {
        val state = PressureSettingDialogState.build(
            isEnabled = true,
            supportsInterval = true,
            minInterval = 20,
            currentInterval = 10
        )

        assertEquals(listOf(20, 30, 60), state.intervalOptions)
        assertEquals(0, state.selectedIntervalIndex)
        assertEquals(20, state.selectedInterval)
    }

    @Test
    fun buildSupportsSwitchOnlyPressureSetting() {
        val state = PressureSettingDialogState.build(
            isEnabled = false,
            supportsInterval = false,
            minInterval = 0,
            currentInterval = 0
        )

        assertFalse(state.isEnabled)
        assertFalse(state.supportsInterval)
        assertEquals(emptyList<Int>(), state.intervalOptions)
        assertEquals(-1, state.selectedIntervalIndex)
        assertNull(state.selectedInterval)
        assertEquals(emptyList<String>(), state.intervalLabels)
    }

    @Test
    fun createWriteRequestIncludesSelectedIntervalWhenPresent() {
        val request = createPressureSettingWriteRequest(
            isEnabled = true,
            minInterval = 10,
            interval = 15
        )

        assertTrue(request.isOpen)
        assertTrue(request.hasIntervalSettings())
        assertEquals(10, request.minInterval)
        assertEquals(15, request.interval)
    }

    @Test
    fun createWriteRequestClearsIntervalForSwitchOnlySetting() {
        val requestWithInterval = createPressureSettingWriteRequest(
            isEnabled = true,
            minInterval = 10,
            interval = 15
        )
        assertTrue(requestWithInterval.hasIntervalSettings())

        val request = createPressureSettingWriteRequest(
            isEnabled = false,
            minInterval = 0,
            interval = null
        )

        assertFalse(request.isOpen)
        assertFalse(request.hasIntervalSettings())
    }
}
