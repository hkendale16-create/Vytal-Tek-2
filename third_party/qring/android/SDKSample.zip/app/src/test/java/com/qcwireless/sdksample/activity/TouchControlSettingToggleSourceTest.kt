package com.qcwireless.sdksample.activity

import java.io.File
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TouchControlSettingToggleSourceTest {

    @Test
    fun homeOpensDedicatedTouchGesturePage() {
        val homeSource = projectFile("src/main/java/com/qcwireless/sdksample/activity/HomeActivity.kt").readText()
        val homeLayout = projectFile("src/main/res/layout/activity_home.xml").readText()
        val manifest = projectFile("src/main/AndroidManifest.xml").readText()

        assertTrue(homeLayout.contains("fiv_touch_gesture"))
        assertTrue(homeSource.contains("binding.fivTouchGesture.setOnClickListener"))
        assertTrue(homeSource.contains("startKtxActivity<TouchGestureActivity>()"))
        assertTrue(manifest.contains(".activity.TouchGestureActivity"))
    }

    @Test
    fun touchGesturePageExposesFullProtocolOptionsAndSdkFactories() {
        val activitySource = projectFile("src/main/java/com/qcwireless/sdksample/activity/TouchGestureActivity.kt").readText()
        val layoutSource = projectFile("src/main/res/layout/activity_touch_gesture.xml").readText()

        listOf(
            "spinner_action_type",
            "spinner_function_type",
            "spinner_app_type",
            "spinner_strength",
            "spinner_sleep_time",
            "spinner_touch_state",
            "fiv_read_touch_gesture",
            "fiv_set_touch_gesture"
        ).forEach { id ->
            assertTrue("activity_touch_gesture.xml missing $id", layoutSource.contains(id))
        }

        listOf(
            "0 Close",
            "1 Music",
            "2 Short Video",
            "3 Muslim Counter",
            "4 E-book",
            "5 Camera",
            "6 Phone Call",
            "7 Game",
            "8 Manual Heart Rate",
            "9 Touch Event",
            "10 Lover Interaction"
        ).forEach { label ->
            assertTrue("TouchGestureActivity missing option $label", activitySource.contains(label))
        }

        listOf(
            "ActionOption(0,",
            "ActionOption(1,",
            "ActionOption(2,",
            "(1..10)",
            "(1..5)",
            "StateOption(0,",
            "StateOption(1,"
        ).forEach { token ->
            assertTrue("TouchGestureActivity missing $token", activitySource.contains(token))
        }

        assertTrue(activitySource.contains("TouchControlReq.getReadInstance(true)"))
        assertTrue(activitySource.contains("TouchControlReq.getReadInstance(false)"))
        assertTrue(activitySource.contains("TouchControlReq.getWriteInstance(appType.value, true, strength.value, sleepTime.value)"))
        assertTrue(activitySource.contains("TouchControlReq.getWriteInstance(appType.value, false, strength.value)"))
        assertTrue(activitySource.contains("TouchControlReq.getWriteTpSleepInstance(appType.value, state.value)"))
        assertTrue(activitySource.contains("rsp.isRead()"))
        assertTrue(activitySource.contains("rsp.isTouch()"))
        assertTrue(activitySource.contains("rsp.getAppType()"))
        assertTrue(activitySource.contains("rsp.getStrength()"))
        assertTrue(activitySource.contains("rsp.getSleepTime()"))
        assertTrue(activitySource.contains("rsp.isTouchSleep()"))
    }

    @Test
    fun touchGestureSupportChecksUseOnlyTopLevelCapabilities() {
        val activitySource = projectFile("src/main/java/com/qcwireless/sdksample/activity/TouchGestureActivity.kt").readText()
        val supportSource = projectFile("src/main/java/com/qcwireless/sdksample/cache/DeviceFunctionSupport.kt").readText()

        assertTrue(supportSource.contains("var tpSleep by BooleanPreference(false)"))
        assertTrue(supportSource.contains("tpSleep = rsp.tpSleep"))
        assertTrue(activitySource.contains("FUNCTION_TYPE_TOUCH -> ensureSupported(deviceSupport.supportTouch)"))
        assertTrue(activitySource.contains("FUNCTION_TYPE_GESTURE -> ensureSupported(deviceSupport.supportGesture)"))
        assertTrue(activitySource.contains("else -> ensureSupported(deviceSupport.supportRt11 && deviceSupport.tpSleep)"))
        listOf(
            "supportRingMusicTouch",
            "supportRingVideoTouch",
            "supportRingEbookTouch",
            "supportRingCameraTouch",
            "supportRingPhoneCallTouch",
            "supportRingGameTouch",
            "supportHeartTouch",
            "supportMoslinTouch"
        ).forEach { token ->
            assertFalse("TouchGestureActivity should not filter CC options by $token", activitySource.contains(token))
        }
    }

    @Test
    fun oldPagesNoLongerExposeFixedTouchGestureButtons() {
        listOf(
            "src/main/java/com/qcwireless/sdksample/activity/AdvancedSettingActivity.kt",
            "src/main/java/com/qcwireless/sdksample/activity/DisplayActivity.kt",
            "src/main/java/com/qcwireless/sdksample/activity/DeviceSettingActivity.kt",
            "src/main/res/layout/activity_advanced_setting.xml",
            "src/main/res/layout/activity_display.xml",
            "src/main/res/layout/activity_device_setting.xml"
        ).forEach { path ->
            val source = projectFile(path).readText()
            listOf(
                "fiv_touch_control_open",
                "fiv_touch_control_close",
                "fiv_gesture_control_open",
                "fiv_gesture_control_close",
                "writeTouchControl(true, true)",
                "writeTouchControl(true, false)",
                "writeTouchControl(false, true)",
                "writeTouchControl(false, false)",
                "getWriteTpSleepInstance(3, 1)",
                "getWriteTpSleepInstance(0, 1)"
            ).forEach { token ->
                assertFalse("$path should not keep old fixed touch/gesture token $token", source.contains(token))
            }
        }
    }

    @Test
    fun externalDocsDescribeTouchGesturePageAndProtocolParameters() {
        val cnDoc = projectFile("docs/sdk_ring_external_access_cn.md").readText()
        val enDoc = projectFile("docs/sdk_ring_external_access_en.md").readText()
        val cnTouchGestureSection = docSection(cnDoc, "### 8.2 触摸/手势", "### 8.3")
        val enTouchGestureSection = docSection(enDoc, "### 8.2 Touch/Gesture", "### 8.3")

        listOf(cnTouchGestureSection, enTouchGestureSection).forEach { doc ->
            assertTrue(doc.contains("TouchGestureActivity"))
            listOf("AA", "BB", "CC", "DD", "EE").forEach { legacyField ->
                assertFalse("touch/gesture docs should not mention legacy field $legacyField", doc.contains(legacyField))
            }
            listOf("type", "isTouch", "appType", "strength", "sleepTime", "state").forEach { field ->
                assertTrue("touch/gesture docs missing $field", doc.contains(field))
            }
            listOf(
                "TouchControlReq.getReadInstance",
                "TouchControlReq.getWriteInstance",
                "TouchControlReq.getWriteTpSleepInstance",
                "TouchControlResp",
                "getAppType()",
                "getStrength()",
                "getSleepTime()",
                "isTouchSleep()"
            ).forEach { token ->
                assertTrue("doc missing $token", doc.contains(token))
            }
            (0..10).forEach { type ->
                assertTrue("doc missing function type $type", doc.contains("| `$type` |"))
            }
        }
    }

    private fun projectFile(path: String): File {
        return sequenceOf(File(path), File("app/$path"), File("../$path"))
            .first { it.isFile }
    }

    private fun docSection(source: String, startHeading: String, nextHeadingPrefix: String): String {
        val start = source.indexOf(startHeading)
        assertTrue("doc missing $startHeading", start >= 0)
        val next = source.indexOf(nextHeadingPrefix, start + startHeading.length)
        assertTrue("doc missing section end $nextHeadingPrefix", next > start)
        return source.substring(start, next)
    }
}
