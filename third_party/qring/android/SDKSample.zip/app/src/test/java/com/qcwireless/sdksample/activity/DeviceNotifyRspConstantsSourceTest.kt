package com.qcwireless.sdksample.activity

import java.io.File
import org.junit.Assert.assertTrue
import org.junit.Test

class DeviceNotifyRspConstantsSourceTest {

    @Test
    fun deviceNotifyListenersUseDeviceNotifyRspTypeConstants() {
        val homeSource = source("app/src/main/java/com/qcwireless/sdksample/activity/HomeActivity.kt")
        val mainSource = source("app/src/main/java/com/qcwireless/sdksample/activity/MainActivity.kt")
        val revisionSource = source("app/src/main/java/com/qcwireless/sdksample/activity/RevisionActivity.kt")

        listOf(
            "TYPE_HEART_RATE",
            "TYPE_BLOOD_PRESSURE",
            "TYPE_BLOOD_OXYGEN",
            "TYPE_STEP",
            "TYPE_BODY_TEMPERATURE",
            "TYPE_SPORT_RECORD",
            "TYPE_DND_SETTING",
            "TYPE_TIME_FORMAT",
            "TYPE_BATTERY",
            "TYPE_BLOOD_GLUCOSE",
            "TYPE_TARGET",
            "TYPE_RAISE_WRIST",
            "TYPE_STEP_CALORIE_DISTANCE",
            "TYPE_AUTO_TEMPERATURE",
            "TYPE_GAME_EVENT",
            "TYPE_MUSLIM_TASBIH_CLICK",
            "TYPE_HRV",
            "TYPE_PRESSURE",
            "TYPE_SPORT_HEART_RATE_WARNING",
            "TYPE_DRINK_WATER_REMINDER",
            "TYPE_SEDENTARY_REMINDER",
            "TYPE_ALARM_REMINDER",
            "TYPE_MENSTRUATION_REMINDER",
            "TYPE_AUTO_HEART_RATE_ALARM"
        ).forEach { constant ->
            assertTrue("HomeActivity should use DeviceNotifyRsp.$constant", homeSource.contains("DeviceNotifyRsp.$constant"))
        }

        listOf(
            "TYPE_CUSTOM_BUTTON_FUNCTION",
            "TYPE_AUTO_HEART_RATE_ALARM",
            "TYPE_AUTO_TEMPERATURE_MINUTE_DATA"
        ).forEach { constant ->
            assertTrue("MainActivity should use DeviceNotifyRsp.$constant", mainSource.contains("DeviceNotifyRsp.$constant"))
        }

        assertTrue(revisionSource.contains("DeviceNotifyRsp.TYPE_BATTERY"))
    }

    @Test
    fun externalDocsDescribeDeviceNotifyRspConstantsAndEmotionReports() {
        val cnDoc = source("docs/sdk_ring_external_access_cn.md")
        val enDoc = source("docs/sdk_ring_external_access_en.md")

        listOf(cnDoc, enDoc).forEach { doc ->
            assertTrue(doc.contains("DeviceNotifyRsp.TYPE_HEART_RATE"))
            assertTrue(doc.contains("DeviceNotifyRsp.TYPE_BATTERY"))
            assertTrue(doc.contains("DeviceNotifyRsp.TYPE_STEP_CALORIE_DISTANCE"))
            assertTrue(doc.contains("DeviceNotifyRsp.TYPE_MUSLIM_TASBIH_CLICK"))
            assertTrue(doc.contains("DeviceNotifyRsp.TYPE_CUSTOM_BUTTON_FUNCTION"))
            assertTrue(doc.contains("DeviceNotifyRsp.TYPE_AUTO_HEART_RATE_ALARM"))
            assertTrue(doc.contains("DeviceNotifyRsp.TYPE_EMOTION"))
            assertTrue(doc.contains("getEmotion("))
            assertTrue(doc.contains("getEmotions("))
        }
    }

    private fun source(path: String): String {
        return sequenceOf(File(path), File("../$path"))
            .first { it.isFile }
            .readText()
    }
}
