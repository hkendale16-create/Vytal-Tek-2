package com.qcwireless.sdksample.activity

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class HealthDataValueFormatterTest {

    @Test
    fun formatPrintsAllArrayItems() {
        val result = HealthDataValueFormatter.format(ByteArray(25) { it.toByte() })

        assertTrue(result.startsWith("byte[25]("))
        assertTrue(result.contains("0, 1, 2, 3, 4"))
        assertTrue(result.contains("20, 21, 22, 23, 24"))
        assertFalse(result.contains("more"))
    }
}
