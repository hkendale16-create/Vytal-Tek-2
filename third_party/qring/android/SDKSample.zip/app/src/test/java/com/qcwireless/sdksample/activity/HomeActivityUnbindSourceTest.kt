package com.qcwireless.sdksample.activity

import java.io.File
import org.junit.Assert.assertTrue
import org.junit.Test

class HomeActivityUnbindSourceTest {

    @Test
    fun unbindDeviceRefreshesHomeUiToDisconnectedState() {
        val source = homeActivitySource()

        assertTrue(
            "HomeActivity should update the local UI immediately after unbinding",
            Regex(
                """private\s+fun\s+unbindDevice\(\)\s*\{[\s\S]*BleOperateManager\.getInstance\(\)\.unBindDevice\(\)[\s\S]*showDisconnectedState\(\)[\s\S]*\}"""
            ).containsMatchIn(source)
        )
    }

    private fun homeActivitySource(): String {
        val path = "src/main/java/com/qcwireless/sdksample/activity/HomeActivity.kt"
        return sequenceOf(File(path), File("app/$path"))
            .first { it.isFile }
            .readText()
    }
}
