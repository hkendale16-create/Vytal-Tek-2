//
//  QCSampleFirmwareUpdateViewController.h
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//
//  Firmware OTA sample. SDK calls are in QCSampleFirmwareUpdateViewController.m
//  固件 OTA 示例。SDK 调用见 QCSampleFirmwareUpdateViewController.m

#import "QCSampleHealthFunctionViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface QCSampleFirmwareUpdateViewController : QCSampleHealthFunctionViewController

@end

NS_ASSUME_NONNULL_END
