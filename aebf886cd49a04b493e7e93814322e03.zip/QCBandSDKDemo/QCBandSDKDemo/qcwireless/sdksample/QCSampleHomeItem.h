//
//  QCSampleHomeItem.h
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, QCSampleHomeItemActionType) {
    /// Execute an SDK action directly without navigation. 点击后直接执行 SDK 动作，不跳转页面
    QCSampleHomeItemActionTypeExecute = 0,
    /// Push an existing view controller. 点击后 push 到已有页面
    QCSampleHomeItemActionTypeNavigateExisting,
};

typedef NS_ENUM(NSInteger, QCSampleHomeItemIdentifier) {
    QCSampleHomeItemIdentifierScan = 0,
    QCSampleHomeItemIdentifierReconnect,
    QCSampleHomeItemIdentifierDisconnect,
    QCSampleHomeItemIdentifierUnbind,
    QCSampleHomeItemIdentifierFindDevice,

    QCSampleHomeItemIdentifierHealthSettings,
    QCSampleHomeItemIdentifierGoalsProfile,
    QCSampleHomeItemIdentifierDisplay,
    QCSampleHomeItemIdentifierDevice,
    QCSampleHomeItemIdentifierNotifications,
    QCSampleHomeItemIdentifierTouchGestures,
    QCSampleHomeItemIdentifierAdvanced,

    QCSampleHomeItemIdentifierFirmwareUpdateBLE,
    QCSampleHomeItemIdentifierResourceUpdate,
};

@interface QCSampleHomeItem : NSObject

@property (nonatomic, assign, readonly) QCSampleHomeItemIdentifier identifier;
@property (nonatomic, copy, readonly) NSString *title;
@property (nonatomic, assign, readonly) QCSampleHomeItemActionType actionType;
@property (nonatomic, assign, readonly) BOOL showsDisclosure;
/// Used when actionType is NavigateExisting. actionType 为 NavigateExisting 时使用
@property (nonatomic, copy, readonly, nullable) NSString *existingViewControllerClassName;

+ (instancetype)itemWithIdentifier:(QCSampleHomeItemIdentifier)identifier
                             title:(NSString *)title
                        actionType:(QCSampleHomeItemActionType)actionType
                  showsDisclosure:(BOOL)showsDisclosure
    existingViewControllerClassName:(nullable NSString *)existingViewControllerClassName;

@end

@interface QCSampleHomeSection : NSObject

@property (nonatomic, copy, readonly) NSString *title;
@property (nonatomic, copy, readonly) NSArray<QCSampleHomeItem *> *items;

+ (instancetype)sectionWithTitle:(NSString *)title items:(NSArray<QCSampleHomeItem *> *)items;

@end

@interface QCSampleHomeDataSource : NSObject

+ (NSArray<QCSampleHomeSection *> *)defaultSections;

@end

NS_ASSUME_NONNULL_END
