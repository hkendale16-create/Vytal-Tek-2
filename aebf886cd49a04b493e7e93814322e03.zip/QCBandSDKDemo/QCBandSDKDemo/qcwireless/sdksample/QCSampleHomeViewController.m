//
//  QCSampleHomeViewController.m
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//

#import "QCSampleHomeViewController.h"
#import "QCSampleHomeItem.h"
#import "QCSampleDeviceStatus.h"
#import "QCSampleDeviceStatusHeaderView.h"
#import "QCSampleLocalization.h"
#import "QCCentralManager.h"
#import "QCScanViewController.h"
#import "QCSampleToast.h"

#import <QCBandSDK/QCSDKManager.h>
#import <QCBandSDK/QCSDKCmdCreator.h>

static NSString * const kQCSampleHomeCellIdentifier = @"QCSampleHomeCell";

@interface QCSampleHomeViewController () <
UITableViewDelegate,
UITableViewDataSource,
QCSampleDeviceStatusObserver,
QCCentralManagerDelegate
>

@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, copy) NSArray<QCSampleHomeSection *> *sections;
@property (nonatomic, strong) QCSampleDeviceStatusHeaderView *statusHeaderView;
@property (nonatomic, strong) QCSampleDeviceStatus *deviceStatus;
@property (nonatomic, copy, nullable) NSString *currentLanguageBucket;

@end

@implementation QCSampleHomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.edgesForExtendedLayout = UIRectEdgeNone;
    self.view.backgroundColor = [UIColor groupTableViewBackgroundColor];
    
    self.title = [NSString stringWithFormat:@"QCBandSDK Sample:%@",[QCSDKManager shareInstance].getVersionInfo];

    self.sections = [QCSampleHomeDataSource defaultSections];
    self.deviceStatus = [QCSampleDeviceStatusProvider shared].currentStatus;

    [self setupTableView];
    [self updateStatusHeaderLayout];

    [[QCSampleDeviceStatusProvider shared] addObserver:self];
    [QCCentralManager shared].delegate = self;
    self.currentLanguageBucket = QCSampleUsesChineseLanguage() ? @"zh" : @"en";
    [[QCSampleDeviceStatusProvider shared] updateForDeviceState:[QCCentralManager shared].deviceState];

    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(reloadLocalizedContent)
                                                 name:NSCurrentLocaleDidChangeNotification
                                               object:nil];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [QCCentralManager shared].delegate = self;
    [self reloadLocalizedContent];
    [[QCSampleDeviceStatusProvider shared] updateForDeviceState:[QCCentralManager shared].deviceState];
}

- (void)reloadLocalizedContent {
    NSString *languageBucket = QCSampleUsesChineseLanguage() ? @"zh" : @"en";
    if ([languageBucket isEqualToString:self.currentLanguageBucket] && self.sections.count > 0) {
        return;
    }
    self.currentLanguageBucket = languageBucket;
    self.sections = [QCSampleHomeDataSource defaultSections];
    [self.tableView reloadData];
    [self updateStatusHeaderLayout];
    [[QCSampleDeviceStatusProvider shared] updateForDeviceState:[QCCentralManager shared].deviceState];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    self.tableView.frame = self.view.bounds;
}

- (void)dealloc {
    [[QCSampleDeviceStatusProvider shared] removeObserver:self];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

#pragma mark - Setup

- (void)setupTableView {
    self.tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStyleGrouped];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.backgroundColor = [UIColor groupTableViewBackgroundColor];
    self.tableView.separatorInset = UIEdgeInsetsMake(0, 16.0, 0, 0);
    if (@available(iOS 15.0, *)) {
        self.tableView.sectionHeaderTopPadding = 0;
    }
    [self.tableView registerClass:[QCSampleHomeSectionHeaderView class]
forHeaderFooterViewReuseIdentifier:NSStringFromClass([QCSampleHomeSectionHeaderView class])];
    [self.view addSubview:self.tableView];

    self.statusHeaderView = [[QCSampleDeviceStatusHeaderView alloc] initWithFrame:CGRectZero];
}

- (void)updateStatusHeaderLayout {
    CGFloat width = CGRectGetWidth(self.view.bounds);
    if (width <= 0) {
        width = kScreenWidth;
    }
    CGFloat height = [QCSampleDeviceStatusHeaderView preferredHeightForStatus:self.deviceStatus width:width];
    self.statusHeaderView.frame = CGRectMake(0, 0, width, height);
    [self.statusHeaderView configureWithStatus:self.deviceStatus];
    self.tableView.tableHeaderView = self.statusHeaderView;
}

#pragma mark - QCSampleDeviceStatusObserver

- (void)deviceStatusDidChange:(QCSampleDeviceStatus *)status {
    self.deviceStatus = status;
    [self updateStatusHeaderLayout];
}

#pragma mark - QCCentralManagerDelegate

- (void)didState:(QCState)state {
    [[QCSampleDeviceStatusProvider shared] updateForDeviceState:state];
}

#pragma mark - Actions

- (nullable QCSampleHomeItem *)itemAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section >= (NSInteger)self.sections.count) {
        return nil;
    }
    QCSampleHomeSection *section = self.sections[indexPath.section];
    if (indexPath.row >= (NSInteger)section.items.count) {
        return nil;
    }
    return section.items[indexPath.row];
}

- (void)handleItemSelection:(QCSampleHomeItem *)item {
    switch (item.actionType) {
        case QCSampleHomeItemActionTypeNavigateExisting:
            [self pushExistingViewControllerForItem:item];
            break;
        case QCSampleHomeItemActionTypeExecute:
            [self executeActionForItem:item];
            break;
    }
}

- (void)pushExistingViewControllerForItem:(QCSampleHomeItem *)item {
    NSString *className = item.existingViewControllerClassName;
    Class viewControllerClass = NSClassFromString(className);
    if (!viewControllerClass) {
        [QCSampleToast showCenterWithText:QCSampleLocalizedFormat(QCSampleLocalizedKeyToastPageNotFound, className ?: @"")];
        return;
    }
    UIViewController *viewController = [[viewControllerClass alloc] init];
    viewController.title = item.title;
    viewController.edgesForExtendedLayout = UIRectEdgeNone;
    [self.navigationController pushViewController:viewController animated:YES];
}

- (void)executeActionForItem:(QCSampleHomeItem *)item {
    switch (item.identifier) {
        case QCSampleHomeItemIdentifierDisconnect:
            [[QCCentralManager shared] disconnect];
            [QCSampleToast showCenterWithText:QCSampleLocalized(QCSampleLocalizedKeyToastDisconnectStarted)];
            break;
        case QCSampleHomeItemIdentifierReconnect:
            [[QCCentralManager shared] reconnectLastDevice];
            break;
        case QCSampleHomeItemIdentifierUnbind:
            [[QCCentralManager shared] remove];
            [QCSampleToast showCenterWithText:QCSampleLocalized(QCSampleLocalizedKeyToastUnbindDone)];
            break;
        case QCSampleHomeItemIdentifierFindDevice:
            [QCSDKCmdCreator lookupDeviceSuccess:^{
                [QCSampleToast showCenterWithText:QCSampleLocalized(QCSampleLocalizedKeyToastFindDeviceSent)];
            } fail:^{
                [QCSampleToast showCenterWithText:QCSampleLocalized(QCSampleLocalizedKeyToastFindDeviceFailed)];
            }];
            break;
        default:
            break;
    }
}

#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return self.sections.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.sections[section].items.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:kQCSampleHomeCellIdentifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:kQCSampleHomeCellIdentifier];
        cell.textLabel.font = [UIFont systemFontOfSize:16.0];
        cell.textLabel.textColor = [UIColor blackColor];
    }

    QCSampleHomeItem *item = [self itemAtIndexPath:indexPath];
    cell.textLabel.text = item.title;
    cell.accessoryType = item.showsDisclosure ? UITableViewCellAccessoryDisclosureIndicator : UITableViewCellAccessoryNone;
    cell.selectionStyle = UITableViewCellSelectionStyleDefault;
    return cell;
}

#pragma mark - UITableViewDelegate

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    QCSampleHomeSectionHeaderView *header = [tableView dequeueReusableHeaderFooterViewWithIdentifier:NSStringFromClass([QCSampleHomeSectionHeaderView class])];
    [header configureWithTitle:self.sections[section].title];
    return header;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 30.0;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    QCSampleHomeItem *item = [self itemAtIndexPath:indexPath];
    if (item) {
        [self handleItemSelection:item];
    }
}

@end

#pragma mark - QCSampleHomeSectionHeaderView

@interface QCSampleHomeSectionHeaderView ()
@property (nonatomic, strong) UILabel *titleLabel;
@end

@implementation QCSampleHomeSectionHeaderView

- (instancetype)initWithReuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithReuseIdentifier:reuseIdentifier];
    if (self) {
        self.contentView.backgroundColor = [UIColor groupTableViewBackgroundColor];
        [self.contentView addSubview:self.titleLabel];
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    self.titleLabel.frame = CGRectMake(16.0, 6.0, self.contentView.bounds.size.width - 32.0, 16.0);
}

- (void)configureWithTitle:(NSString *)title {
    self.titleLabel.text = title;
}

- (UILabel *)titleLabel {
    if (!_titleLabel) {
        _titleLabel = [[UILabel alloc] init];
        _titleLabel.textAlignment = NSTextAlignmentLeft;
        _titleLabel.textColor = [UIColor blackColor];
        _titleLabel.font = [UIFont systemFontOfSize:14.0];
    }
    return _titleLabel;
}

@end

#pragma mark - AxcNavigationController

@implementation AxcNavigationController

- (void)viewDidLoad {
    [super viewDidLoad];
    [AxcNavigationController axc_applyDefaultAppearanceToNavigationBar:self.navigationBar];
    self.interactivePopGestureRecognizer.enabled = YES;
}

+ (void)axc_applyDefaultAppearanceToNavigationBar:(UINavigationBar *)navigationBar {
    navigationBar.translucent = NO;
    navigationBar.barTintColor = [UIColor whiteColor];
    navigationBar.tintColor = [UIColor blackColor];
    navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName: [UIColor blackColor]};
    if (@available(iOS 13.0, *)) {
        UINavigationBarAppearance *appearance = [[UINavigationBarAppearance alloc] init];
        [appearance configureWithOpaqueBackground];
        appearance.backgroundColor = [UIColor whiteColor];
        appearance.titleTextAttributes = @{NSForegroundColorAttributeName: [UIColor blackColor]};
        appearance.shadowColor = [UIColor colorWithWhite:0.85 alpha:1.0];
        navigationBar.standardAppearance = appearance;
        navigationBar.scrollEdgeAppearance = appearance;
        navigationBar.compactAppearance = appearance;
    }
}

@end

#pragma mark - AxcNavigationTitleView

@interface AxcNavigationTitleView ()
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UILabel *subtitleLabel;
@end

@implementation AxcNavigationTitleView

+ (instancetype)viewWithTitle:(NSString *)title subtitle:(NSString *)subtitle {
    CGFloat width = [UIScreen mainScreen].bounds.size.width - 120.0;
    AxcNavigationTitleView *titleView = [[AxcNavigationTitleView alloc] initWithFrame:CGRectMake(0, 0, width, 44.0)];
    titleView.titleLabel.text = title;
    titleView.subtitleLabel.text = subtitle;
    [titleView setNeedsLayout];
    return titleView;
}

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        _titleLabel = [[UILabel alloc] init];
        _titleLabel.font = [UIFont boldSystemFontOfSize:17.0];
        _titleLabel.textColor = [UIColor blackColor];
        _titleLabel.textAlignment = NSTextAlignmentCenter;
        _titleLabel.lineBreakMode = NSLineBreakByTruncatingTail;
        [self addSubview:_titleLabel];

        _subtitleLabel = [[UILabel alloc] init];
        _subtitleLabel.font = [UIFont systemFontOfSize:11.0];
        _subtitleLabel.textColor = [UIColor darkGrayColor];
        _subtitleLabel.textAlignment = NSTextAlignmentCenter;
        _subtitleLabel.lineBreakMode = NSLineBreakByTruncatingMiddle;
        [self addSubview:_subtitleLabel];
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    if (self.subtitleLabel.text.length > 0) {
        self.titleLabel.frame = CGRectMake(0, 2.0, self.bounds.size.width, 20.0);
        self.subtitleLabel.frame = CGRectMake(0, 22.0, self.bounds.size.width, 16.0);
        self.subtitleLabel.hidden = NO;
    } else {
        self.titleLabel.frame = self.bounds;
        self.subtitleLabel.hidden = YES;
    }
}

- (CGSize)intrinsicContentSize {
    return CGSizeMake(UIViewNoIntrinsicMetric, 44.0);
}

@end
