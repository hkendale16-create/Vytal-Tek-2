//
//  QCSampleTouchGesturesViewController.m
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/28.
//
//  Touch / gesture SDK sample.
//  触摸/手势 SDK 示例。
//
//  Recommended order: setTime (features) → setTouchControl → register Live callbacks → tap ring.
//  推荐顺序：setTime 查能力 → setTouchControl 写模式 → 注册 Live 回调 → 点击戒指。
//
//  See QCSampleTouchGesturesViewController.h for full integration guide.
//  详细集成说明见 QCSampleTouchGesturesViewController.h

#import "QCSampleTouchGesturesViewController.h"
#import "QCSampleLocalization.h"
#import <QCBandSDK/QCSDKCmdCreator.h>
#import <QCBandSDK/QCSDKManager.h>
#import <QCBandSDK/QCFlipWristInfoModel.h>
#import <QCBandSDK/QCDFU_Utils.h>

typedef NS_ENUM(NSInteger, QCSampleTouchGestureSetKind) {
    QCSampleTouchGestureSetKindTouch,
    QCSampleTouchGestureSetKindGesture,
    QCSampleTouchGestureSetKindRT11,
};

@interface QCSampleTouchGesturesViewController ()
@property (nonatomic, copy, nullable) NSDictionary<NSString *, NSNumber *> *featureList;
@property (nonatomic, assign) BOOL liveReportEnabled;
@end

@implementation QCSampleTouchGesturesViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = QCSampleLocalized(QCSampleLocalizedKeyItemTouchGestures);
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    // Unregister Live callbacks when leaving to avoid dangling references.
    // 离开页面时取消 Live 回调，防止野指针。
    if (self.isMovingFromParentViewController || self.isBeingDismissed) {
        [self stopLiveReport];
    }
}

- (void)setupActions {
    __weak typeof(self) weakSelf = self;

    [self beginActionSection:QCSampleLocalized(QCSampleLocalizedKeyTouchGestureSectionFeatures)];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyTouchGestureCheckFeatures) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf checkFeatureSupport];
    }];

    [self beginActionSection:QCSampleLocalized(QCSampleLocalizedKeyTouchGestureSectionTouch)];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyTouchGestureReadTouch) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf readTouchControl];
    }];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyTouchGestureSetTouch) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf presentSetControlForKind:QCSampleTouchGestureSetKindTouch];
    }];

    [self beginActionSection:QCSampleLocalized(QCSampleLocalizedKeyTouchGestureSectionGesture)];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyTouchGestureReadGesture) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf readGestureControl];
    }];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyTouchGestureSetGesture) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf presentSetControlForKind:QCSampleTouchGestureSetKindGesture];
    }];

    [self beginActionSection:QCSampleLocalized(QCSampleLocalizedKeyTouchGestureSectionRT11)];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyTouchGestureReadRT11) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf readRT11TouchControl];
    }];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyTouchGestureSetRT11) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf presentSetControlForKind:QCSampleTouchGestureSetKindRT11];
    }];

    [self beginActionSection:QCSampleLocalized(QCSampleLocalizedKeyTouchGestureSectionFlipWrist)];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyTouchGestureReadFlipWrist) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf readFlipWristInfo];
    }];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyTouchGestureSetFlipWrist) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf setFlipWristLeftHand];
    }];

    [self beginActionSection:QCSampleLocalized(QCSampleLocalizedKeyTouchGestureSectionLive)];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyTouchGestureStartLive) handler:^{
        [weakSelf startLiveReport];
    }];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyTouchGestureStopLive) handler:^{
        [weakSelf stopLiveReport];
    }];
    
   
}

#pragma mark - Feature support

- (BOOL)featureEnabled:(NSString *)key {
    return [[self.featureList objectForKey:key] boolValue];
}

/// Sync time via setTime and read featureList; run before any touch/gesture API.
/// setTime 同步时钟并返回 featureList；任何触摸/手势 API 调用前应先确认能力。
- (void)checkFeatureSupport {
    [self appendLog:@"SDK setTime (feature check)"];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator setTime:[NSDate date] success:^(NSDictionary * _Nonnull featureList) {
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf) { return; }
        strongSelf.featureList = featureList;
        [strongSelf appendLog:@"[TouchGesture] feature check success"];
        [strongSelf logFeatureFlags:featureList];
        [strongSelf logSupportedControlTypes:featureList];
    } failed:^{
        [weakSelf appendLog:@"[TouchGesture] feature check failed (setTime)"];
    }];
}

- (void)logFeatureFlags:(NSDictionary<NSString *, NSNumber *> *)featureList {
    [self appendLogFormat:@"  touch=%@ gesture=%@ rt11=%@ flipWrist=%@",
     [self yesNoFromFeature:featureList key:QCBandFeatureTouchControl],
     [self yesNoFromFeature:featureList key:QCBandFeatureGestureControl],
     [self yesNoFromFeature:featureList key:QCBandFeatureTouchControlOfScreenDevice],
     [self yesNoFromFeature:featureList key:QCBandFeatureFlipWrist]];
}

- (NSString *)yesNoFromFeature:(NSDictionary<NSString *, NSNumber *> *)featureList key:(NSString *)key {
    return [[featureList objectForKey:key] boolValue] ? @"YES" : @"NO";
}

- (NSArray<NSNumber *> *)supportedControlTypesFromFeatures:(NSDictionary<NSString *, NSNumber *> *)featureList {
    NSMutableArray<NSNumber *> *types = [NSMutableArray arrayWithObject:@(QCTouchGestureControlTypeOff)];
    if ([[featureList objectForKey:QCBandFeatureGestureControlMusic] boolValue]) {
        [types addObject:@(QCTouchGestureControlTypeMusic)];
    }
    if ([[featureList objectForKey:QCBandFeatureGestureControlVideo] boolValue]) {
        [types addObject:@(QCTouchGestureControlTypeVideo)];
    }
    if ([[featureList objectForKey:QCBandFeatureMSLPraise] boolValue]) {
        [types addObject:@(QCTouchGestureControlTypeMSLPraise)];
    }
    if ([[featureList objectForKey:QCBandFeatureGestureControlEBook] boolValue]) {
        [types addObject:@(QCTouchGestureControlTypeEBook)];
    }
    if ([[featureList objectForKey:QCBandFeatureGestureControlTakePhoto] boolValue]) {
        [types addObject:@(QCTouchGestureControlTypeTakePhoto)];
    }
    if ([[featureList objectForKey:QCBandFeatureGestureControlPhoneCall] boolValue]) {
        [types addObject:@(QCTouchGestureControlTypePhoneCall)];
    }
    if ([[featureList objectForKey:QCBandFeatureGestureControlGame] boolValue]) {
        [types addObject:@(QCTouchGestureControlTypeGame)];
    }
    if ([[featureList objectForKey:QCBandFeatureGestureControlHRMeasure] boolValue]) {
        [types addObject:@(QCTouchGestureControlTypeHRMeasure)];
    }
    // 9=TouchEvent; app listens for CustomKey(0x2D) taps in watchDataUpdateReport.
    // 9=TouchEvent；App 侧在 watchDataUpdateReport 监听 CustomKey(0x2D) 点击。
    [types addObject:@(QCTouchGestureControlTypeTouchEvent)];
    return types;
}

- (void)logSupportedControlTypes:(NSDictionary<NSString *, NSNumber *> *)featureList {
    NSArray<NSNumber *> *types = [self supportedControlTypesFromFeatures:featureList];
    NSMutableArray<NSString *> *labels = [NSMutableArray arrayWithCapacity:types.count];
    for (NSNumber *typeNumber in types) {
        [labels addObject:[self controlTypeLabel:[typeNumber integerValue]]];
    }
    [self appendLogFormat:@"  supported app types: %@", [labels componentsJoinedByString:@", "]];
}

/// If featureList is not cached, call setTime first then run block.
/// 若未缓存 featureList，先 setTime 再执行 block。
- (void)ensureFeaturesThen:(void (^)(NSDictionary<NSString *, NSNumber *> *featureList))block {
    if (self.featureList.count > 0) {
        block(self.featureList);
        return;
    }
    __weak typeof(self) weakSelf = self;
    [self appendLog:@"SDK setTime (feature check)"];
    [QCSDKCmdCreator setTime:[NSDate date] success:^(NSDictionary * _Nonnull featureList) {
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf) { return; }
        strongSelf.featureList = featureList;
        block(featureList);
    } failed:^{
        [weakSelf appendLog:@"[TouchGesture] feature check failed (setTime)"];
    }];
}

#pragma mark - Log helpers

- (NSString *)controlTypeLabel:(QCTouchGestureControlType)type {
    switch (type) {
        case QCTouchGestureControlTypeOff: return @"Close(0)";
        case QCTouchGestureControlTypeMusic: return @"Music(1)";
        case QCTouchGestureControlTypeVideo: return @"Video(2)";
        case QCTouchGestureControlTypeMSLPraise: return @"MSLPraise(3)";
        case QCTouchGestureControlTypeEBook: return @"EBook(4)";
        case QCTouchGestureControlTypeTakePhoto: return @"TakePhoto(5)";
        case QCTouchGestureControlTypePhoneCall: return @"PhoneCall(6)";
        case QCTouchGestureControlTypeGame: return @"Game(7)";
        case QCTouchGestureControlTypeHRMeasure: return @"HRMeasure(8)";
        case QCTouchGestureControlTypeTouchEvent: return @"TouchEvent(9)";
        default: return [NSString stringWithFormat:@"Unknown(%ld)", (long)type];
    }
}

- (void)logTouchReadResultWithTag:(NSString *)tag
                             type:(QCTouchGestureControlType)type
                         strength:(NSInteger)strength
                         sleeping:(BOOL)sleeping
                         duration:(NSInteger)duration {
    [self appendLogFormat:@"[%@] success", tag];
    [self appendLogFormat:@"  type=%@ strength=%ld sleeping=%@ duration=%ldmin",
     [self controlTypeLabel:type],
     (long)strength,
     sleeping ? @"YES" : @"NO",
     (long)duration];
}

- (void)logGestureReadResultWithTag:(NSString *)tag
                               type:(QCTouchGestureControlType)type
                           strength:(NSInteger)strength
                           sleeping:(BOOL)sleeping {
    [self appendLogFormat:@"[%@] success", tag];
    [self appendLogFormat:@"  type=%@ strength=%ld sleeping=%@",
     [self controlTypeLabel:type],
     (long)strength,
     sleeping ? @"YES" : @"NO"];
}

#pragma mark - Read

/// Read touch config (0x3b). Returns current mode/sleep/duration — not tap events.
/// 读取触摸配置（0x3b）。仅返回当前模式/休眠/时长，不是点击事件。
- (void)readTouchControl {
    __weak typeof(self) weakSelf = self;
    [self ensureFeaturesThen:^(NSDictionary<NSString *, NSNumber *> *featureList) {
        if (![[featureList objectForKey:QCBandFeatureTouchControl] boolValue]) {
            [weakSelf appendLog:@"[Touch] device does not support touch control"];
            return;
        }
        [weakSelf appendLog:@"SDK getTouchControlFinshed"];
        // Active query: type/strength/sleeping/duration = current device config.
        // 主动查询：type/strength/sleeping/duration 为设备当前配置。
        [QCSDKCmdCreator getTouchControlFinshed:^(QCTouchGestureControlType type, NSInteger strength, BOOL sleeping, NSInteger duration, NSError * _Nullable error) {
            if (error) {
                [weakSelf appendLogFormat:@"[Touch] get failed: %@", error.localizedDescription ?: @""];
                return;
            }
            [weakSelf logTouchReadResultWithTag:@"Touch" type:type strength:strength sleeping:sleeping duration:duration];
        }];
    }];
}

/// Read gesture config (IMU mode; pick touch or gesture, not both).
/// 读取手势配置（IMU 模式，与触摸互斥选用）。
- (void)readGestureControl {
    __weak typeof(self) weakSelf = self;
    [self ensureFeaturesThen:^(NSDictionary<NSString *, NSNumber *> *featureList) {
        if (![[featureList objectForKey:QCBandFeatureGestureControl] boolValue]) {
            [weakSelf appendLog:@"[Gesture] device does not support gesture control"];
            return;
        }
        [weakSelf appendLog:@"SDK getGestureControlFinshed"];
        [QCSDKCmdCreator getGestureControlFinshed:^(QCTouchGestureControlType type, NSInteger strength, BOOL sleeping, NSError * _Nullable error) {
            if (error) {
                [weakSelf appendLogFormat:@"[Gesture] get failed: %@", error.localizedDescription ?: @""];
                return;
            }
            [weakSelf logGestureReadResultWithTag:@"Gesture" type:type strength:strength sleeping:sleeping];
        }];
    }];
}

/// Read RT11 screen-ring touch config.
/// 读取 RT11 带屏戒指触摸配置。
- (void)readRT11TouchControl {
    __weak typeof(self) weakSelf = self;
    [self ensureFeaturesThen:^(NSDictionary<NSString *, NSNumber *> *featureList) {
        if (![[featureList objectForKey:QCBandFeatureTouchControlOfScreenDevice] boolValue]) {
            [weakSelf appendLog:@"[RT11] device does not support screen touch control"];
            return;
        }
        [weakSelf appendLog:@"SDK getTouchControlOfScreenDevieFinshed"];
        [QCSDKCmdCreator getTouchControlOfScreenDevieFinshed:^(QCTouchGestureControlType type, NSInteger strength, BOOL sleeping, NSInteger duration, NSError * _Nullable error) {
            if (error) {
                [weakSelf appendLogFormat:@"[RT11] get failed: %@", error.localizedDescription ?: @""];
                return;
            }
            [weakSelf logTouchReadResultWithTag:@"RT11" type:type strength:strength sleeping:sleeping duration:duration];
        }];
    }];
}

/// Read raise-to-wake / wearing hand; verify flipType matches actual hand if gestures are unstable.
/// 读取抬腕/佩戴手信息；手势不稳定时可先确认 flipType 与实际佩戴一致。
- (void)readFlipWristInfo {
    __weak typeof(self) weakSelf = self;
    [self ensureFeaturesThen:^(NSDictionary<NSString *, NSNumber *> *featureList) {
        if (![[featureList objectForKey:QCBandFeatureFlipWrist] boolValue]) {
            [weakSelf appendLog:@"[FlipWrist] device does not support flip wrist info"];
            return;
        }
        [weakSelf appendLog:@"SDK getFlipWristInfoFinshed"];
        [QCSDKCmdCreator getFlipWristInfoFinshed:^(QCFlipWristInfoModel * _Nullable info, NSError * _Nullable error) {
            if (error) {
                [weakSelf appendLogFormat:@"[FlipWrist] get failed: %@", error.localizedDescription ?: @""];
                return;
            }
            [weakSelf appendLog:@"[FlipWrist] success"];
            [weakSelf appendLogFormat:@"  enable=%@ hand=%ld brightness=%ld/%ld timeMode=%ld start=%ld end=%ld",
             info.enable ? @"YES" : @"NO",
             (long)info.flipType,
             (long)info.brightness,
             (long)info.brightnessMax,
             (long)info.timeMode,
             (long)info.startTime,
             (long)info.endTime];
        }];
    }];
}

#pragma mark - Set

- (void)presentSetControlForKind:(QCSampleTouchGestureSetKind)kind {
    __weak typeof(self) weakSelf = self;
    [self ensureFeaturesThen:^(NSDictionary<NSString *, NSNumber *> *featureList) {
        NSString *featureKey = nil;
        NSString *tag = nil;
        switch (kind) {
            case QCSampleTouchGestureSetKindTouch:
                featureKey = QCBandFeatureTouchControl;
                tag = @"Touch";
                break;
            case QCSampleTouchGestureSetKindGesture:
                featureKey = QCBandFeatureGestureControl;
                tag = @"Gesture";
                break;
            case QCSampleTouchGestureSetKindRT11:
                featureKey = QCBandFeatureTouchControlOfScreenDevice;
                tag = @"RT11";
                break;
        }
        if (![[featureList objectForKey:featureKey] boolValue]) {
            [weakSelf appendLogFormat:@"[%@] device does not support this feature", tag];
            return;
        }
        [weakSelf presentControlTypePickerWithFeatureList:featureList kind:kind tag:tag];
    }];
}

- (void)presentControlTypePickerWithFeatureList:(NSDictionary<NSString *, NSNumber *> *)featureList
                                           kind:(QCSampleTouchGestureSetKind)kind
                                            tag:(NSString *)tag {
    NSArray<NSNumber *> *types = [self supportedControlTypesFromFeatures:featureList];
    UIAlertController *sheet = [UIAlertController alertControllerWithTitle:QCSampleLocalized(QCSampleLocalizedKeyTouchGesturePickType)
                                                                   message:nil
                                                            preferredStyle:UIAlertControllerStyleActionSheet];
    __weak typeof(self) weakSelf = self;
    for (NSNumber *typeNumber in types) {
        QCTouchGestureControlType type = (QCTouchGestureControlType)[typeNumber integerValue];
        [sheet addAction:[UIAlertAction actionWithTitle:[self controlTypeLabel:type]
                                                  style:UIAlertActionStyleDefault
                                                handler:^(UIAlertAction * _Nonnull action) {
            [weakSelf presentSetParamsForKind:kind type:type tag:tag];
        }]];
    }
    [sheet addAction:[UIAlertAction actionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyCommonCancel)
                                              style:UIAlertActionStyleCancel
                                            handler:nil]];
    [self presentAlertController:sheet];
}

- (void)presentSetParamsForKind:(QCSampleTouchGestureSetKind)kind
                           type:(QCTouchGestureControlType)type
                            tag:(NSString *)tag {
    if (kind == QCSampleTouchGestureSetKindGesture) {
        [self presentStrengthAlertForKind:kind type:type tag:tag includeDuration:NO];
        return;
    }
    [self presentStrengthAlertForKind:kind type:type tag:tag includeDuration:YES];
}

- (void)presentStrengthAlertForKind:(QCSampleTouchGestureSetKind)kind
                               type:(QCTouchGestureControlType)type
                                tag:(NSString *)tag
                    includeDuration:(BOOL)includeDuration {
    // strength / duration protocol range: 1～10
    // 力度 / 休眠时长协议范围：1～10
    static const NSInteger kStrengthMin = 1;
    static const NSInteger kStrengthMax = 10;
    static const NSInteger kDurationMin = 1;
    static const NSInteger kDurationMax = 10;

    UIAlertController *alert = [UIAlertController alertControllerWithTitle:QCSampleLocalized(QCSampleLocalizedKeyTouchGestureSetParamsTitle)
                                                                   message:[self controlTypeLabel:type]
                                                            preferredStyle:UIAlertControllerStyleAlert];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyTouchGestureStrengthTitle)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyTouchGestureStrengthHint,
                                                        (long)kStrengthMin,
                                                        (long)kStrengthMax)
                           text:5];
    if (includeDuration) {
        [self addNumberFieldToAlert:alert
                              title:QCSampleLocalized(QCSampleLocalizedKeyTouchGestureDurationTitle)
                        placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyTouchGestureDurationHint,
                                                            (long)kDurationMin,
                                                            (long)kDurationMax)
                               text:3];
    }
    __weak typeof(self) weakSelf = self;
    [alert addAction:[UIAlertAction actionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyCommonCancel)
                                              style:UIAlertActionStyleCancel
                                            handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyCommonOK)
                                              style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction * _Nonnull action) {
        NSInteger strength = [alert.textFields.firstObject.text integerValue];
        if (![weakSelf validateInputValue:strength
                                      min:kStrengthMin
                                      max:kStrengthMax
                               fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyTouchGestureStrengthTitle)]) {
            return;
        }
        NSInteger duration = 0;
        if (includeDuration) {
            duration = [alert.textFields.lastObject.text integerValue];
            if (![weakSelf validateInputValue:duration
                                          min:kDurationMin
                                          max:kDurationMax
                                   fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyTouchGestureDurationTitle)]) {
                return;
            }
        }
        [weakSelf setControlForKind:kind type:type strength:strength duration:duration tag:tag];
    }]];
    [self presentAlertController:alert];
}

/// Write touch/gesture/RT11 mode. duration = touch auto-sleep minutes; TouchEvent(9) taps → watchDataUpdateReport.
/// 写入触摸/手势/RT11 模式。duration=触摸自动休眠分钟数；TouchEvent(9) 点击走 watchDataUpdateReport。
- (void)setControlForKind:(QCSampleTouchGestureSetKind)kind
                     type:(QCTouchGestureControlType)type
                 strength:(NSInteger)strength
                 duration:(NSInteger)duration
                      tag:(NSString *)tag {
    __weak typeof(self) weakSelf = self;
    switch (kind) {
        case QCSampleTouchGestureSetKindTouch: {
            [self appendLogFormat:@"SDK setTouchControl type=%@ strength=%ld duration=%ld",
             [self controlTypeLabel:type], (long)strength, (long)duration];
            // Music/Video etc.: BLE HID, no SDK tap callback. TouchEvent(9): use Live callbacks.
            // Music/Video 等：HID 控制，无 SDK 点击回调；TouchEvent(9)：需配合 Live 回调。
            [QCSDKCmdCreator setTouchControl:type strength:strength duration:duration finshed:^(NSError * _Nullable error) {
                if (error) {
                    [weakSelf appendLogFormat:@"[Touch] set failed: %@", error.localizedDescription ?: @""];
                    return;
                }
                [weakSelf appendLog:@"[Touch] set success"];
                [weakSelf readTouchControl];
            }];
            break;
        }
        case QCSampleTouchGestureSetKindGesture: {
            [self appendLogFormat:@"SDK setGestureControl type=%@ strength=%ld",
             [self controlTypeLabel:type], (long)strength];
            // strength 1~10 = gesture sensitivity.
            // strength 1~10，手势灵敏度。
            [QCSDKCmdCreator setGestureControl:type strength:strength finshed:^(NSError * _Nullable error) {
                if (error) {
                    [weakSelf appendLogFormat:@"[Gesture] set failed: %@", error.localizedDescription ?: @""];
                    return;
                }
                [weakSelf appendLog:@"[Gesture] set success"];
                [weakSelf readGestureControl];
            }];
            break;
        }
        case QCSampleTouchGestureSetKindRT11: {
            [self appendLogFormat:@"SDK setTouchControlOfScreenDevie type=%@ strength=%ld duration=%ld",
             [self controlTypeLabel:type], (long)strength, (long)duration];
            [QCSDKCmdCreator setTouchControlOfScreenDevie:type strength:strength duration:duration finshed:^(NSError * _Nullable error) {
                if (error) {
                    [weakSelf appendLogFormat:@"[RT11] set failed: %@", error.localizedDescription ?: @""];
                    return;
                }
                [weakSelf appendLog:@"[RT11] set success"];
                [weakSelf readRT11TouchControl];
            }];
            break;
        }
    }
}

/// Set left-hand wearing (flipType 1=left, 2=right); configure before first use if needed.
/// 设置左手佩戴（flipType 1=左，2=右），手势/触摸不稳定时建议先配置。
- (void)setFlipWristLeftHand {
    __weak typeof(self) weakSelf = self;
    [self ensureFeaturesThen:^(NSDictionary<NSString *, NSNumber *> *featureList) {
        if (![[featureList objectForKey:QCBandFeatureFlipWrist] boolValue]) {
            [weakSelf appendLog:@"[FlipWrist] device does not support flip wrist info"];
            return;
        }
        QCFlipWristInfoModel *model = [[QCFlipWristInfoModel alloc] init];
        model.enable = YES;
        model.flipType = 1;
        [weakSelf appendLog:@"SDK setFlipWristInfo enable=YES hand=1(left)"];
        [QCSDKCmdCreator setFlipWristInfo:model finshed:^(NSError * _Nullable error) {
            if (error) {
                [weakSelf appendLogFormat:@"[FlipWrist] set failed: %@", error.localizedDescription ?: @""];
                return;
            }
            [weakSelf appendLog:@"[FlipWrist] set success"];
            [weakSelf readFlipWristInfo];
        }];
    }];
}

#pragma mark - Live report

/// Register 0x73 live reports. Call after BLE connect, before tapping; stopLiveReport on leave.
/// 注册 0x73 实时上报。BLE 连接后、点击戒指前调用；离开页面时 stopLiveReport 取消。
- (void)startLiveReport {
    if (self.liveReportEnabled) {
        [self appendLog:@"[Live] already started"];
        return;
    }
    self.liveReportEnabled = YES;
    __weak typeof(self) weakSelf = self;
    // 0x28 mode/type change (not each tap).
    // 0x28 模式变更（非每次点击）。
    [QCSDKManager shareInstance].gestureAndTouchInfo = ^(NSInteger mode, QCTouchGestureControlType type) {
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf) { return; }
        [strongSelf appendLogFormat:@"[Live] gesture/touch mode=%ld type=%@",
         (long)mode,
         [strongSelf controlTypeLabel:type]];
    };
    // 0x11 raise-to-wake / wearing hand.
    // 0x11 抬腕/佩戴手。
    [QCSDKManager shareInstance].flipWristInfo = ^(NSInteger enable, NSInteger hand) {
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf) { return; }
        [strongSelf appendLogFormat:@"[Live] flipWrist enable=%ld hand=%ld", (long)enable, (long)hand];
    };
    // 0x2A touch sleep state.
    // 0x2A 触摸休眠。
    [QCSDKManager shareInstance].touchSleepInfo = ^(BOOL sleeping) {
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf) { return; }
        [strongSelf appendLogFormat:@"[Live] touchSleep %@", sleeping ? @"sleeping" : @"awake"];
    };
    // TouchEvent(9) tap → CustomKey(0x2D): 1=swipe down, 2=swipe up, 3=click, 4=long press.
    // TouchEvent(9) 点击 → CustomKey(0x2D)：1=下滑，2=上滑，3=单击，4=长按。
    [QCSDKManager shareInstance].watchDataUpdateReport = ^(QCDeviceDataUpdateReport type, NSInteger value) {
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf) { return; }
        [strongSelf appendLogFormat:@"[Live] watchDataUpdateReport %@ value=%ld (%@) date=%0f",
         QCDeviceDataUpdateReportName(type),
         (long)value,
         QCDeviceDataUpdateReportValueHint(type),[[NSDate date] timeIntervalSince1970]];
    };
    [self appendLog:@"[Live] started (gestureAndTouchInfo + flipWristInfo + touchSleepInfo + watchDataUpdateReport)"];
    [self appendLog:@"[Live] note: Power/StepInfo/RaiseToWake/TouchControl/TouchSleep/DialIndex/LowPower use dedicated callbacks"];
}

/// Clear all Live callbacks so reports stop after the page is dismissed.
/// 取消全部 Live 回调，避免页面销毁后仍收到上报。
- (void)stopLiveReport {
    if (!self.liveReportEnabled) {
        return;
    }
    self.liveReportEnabled = NO;
    [QCSDKManager shareInstance].gestureAndTouchInfo = nil;
    [QCSDKManager shareInstance].flipWristInfo = nil;
    [QCSDKManager shareInstance].touchSleepInfo = nil;
    [QCSDKManager shareInstance].watchDataUpdateReport = nil;
    [self appendLog:@"[Live] stopped"];
}

#pragma mark - Presentation

- (void)presentAlertController:(UIAlertController *)controller {
    if (controller.popoverPresentationController) {
        controller.popoverPresentationController.sourceView = self.view;
        controller.popoverPresentationController.sourceRect = CGRectMake(CGRectGetMidX(self.view.bounds), CGRectGetMidY(self.view.bounds), 1, 1);
    }
    [self presentViewController:controller animated:YES completion:nil];
}

@end
