//
//  QCScanViewController.m
//  QCBandSDKDemo
//
//  Created by steve on 2023/2/28.
//

#import "QCScanViewController.h"
#import "QCCentralManager.h"
#import "QCSampleLocalization.h"
#import "QcxUI_TextHUD.h"

static CGFloat const kQCScanHeaderHeight = 52.0;
static CGFloat const kQCScanHeaderHorizontalPadding = 16.0;
static CGFloat const kQCScanHeaderItemSpacing = 10.0;

@interface QCScanViewController () <
UITableViewDataSource,
UITableViewDelegate,
QCCentralManagerDelegate,
UITextFieldDelegate
>

@property (nonatomic, strong) UIView *searchHeaderView;
@property (nonatomic, strong) UITextField *filterTextField;
@property (nonatomic, strong) UIButton *scanButton;
@property (nonatomic, strong) UIActivityIndicatorView *indicatorView;
@property (nonatomic, strong) UITableView *tableView;

@property (nonatomic, copy) NSArray<QCBlePeripheral *> *allPeripherals;
@property (nonatomic, copy) NSArray<QCBlePeripheral *> *filteredPeripherals;

@end

@implementation QCScanViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.edgesForExtendedLayout = UIRectEdgeNone;

    self.allPeripherals = @[];
    self.filteredPeripherals = @[];

    [self setupSearchHeader];
    [self setupTableView];
    [self updateLocalizedTexts];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [QCCentralManager shared].delegate = self;
    [self updateLocalizedTexts];
    if ([QCCentralManager shared].deviceState != QCStateConnected &&
        ![QCCentralManager shared].isScanning) {
        [self startScanning];
    }
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];

    self.searchHeaderView.frame = CGRectMake(0, 0, CGRectGetWidth(self.view.bounds), kQCScanHeaderHeight);

    CGFloat contentWidth = CGRectGetWidth(self.view.bounds) - kQCScanHeaderHorizontalPadding * 2.0 - kQCScanHeaderItemSpacing;
    CGFloat fieldWidth = floor(contentWidth * 0.72);
    CGFloat buttonWidth = contentWidth - fieldWidth;
    CGFloat itemHeight = 36.0;
    CGFloat itemY = (kQCScanHeaderHeight - itemHeight) / 2.0;
    CGFloat originX = kQCScanHeaderHorizontalPadding;

    self.filterTextField.frame = CGRectMake(originX, itemY, fieldWidth, itemHeight);
    originX += fieldWidth + kQCScanHeaderItemSpacing;
    self.scanButton.frame = CGRectMake(originX, itemY, buttonWidth, itemHeight);
    self.indicatorView.center = CGPointMake(CGRectGetMidX(self.scanButton.frame), CGRectGetMidY(self.scanButton.frame));

    CGFloat tableY = CGRectGetMaxY(self.searchHeaderView.frame);
    self.tableView.frame = CGRectMake(0,
                                      tableY,
                                      CGRectGetWidth(self.view.bounds),
                                      CGRectGetHeight(self.view.bounds) - tableY);
}

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    [[QCCentralManager shared] stopScan];
    [self.indicatorView stopAnimating];
    // Dismiss connect HUD if the scan page leaves. 离开扫描页时关闭连接提示 HUD
    [QcxUI_TextHUD QcxUI_dismiss];
}

#pragma mark - Setup

- (void)setupSearchHeader {
    self.searchHeaderView = [[UIView alloc] init];
    self.searchHeaderView.backgroundColor = [UIColor colorWithWhite:0.96 alpha:1.0];
    [self.view addSubview:self.searchHeaderView];

    _filterTextField = [[UITextField alloc] init];
    _filterTextField.delegate = self;
    _filterTextField.borderStyle = UITextBorderStyleNone;
    _filterTextField.backgroundColor = [UIColor whiteColor];
    _filterTextField.font = [UIFont systemFontOfSize:14.0];
    _filterTextField.textColor = [UIColor blackColor];
    _filterTextField.clearButtonMode = UITextFieldViewModeWhileEditing;
    _filterTextField.autocapitalizationType = UITextAutocapitalizationTypeNone;
    _filterTextField.autocorrectionType = UITextAutocorrectionTypeNo;
    _filterTextField.returnKeyType = UIReturnKeyDone;
    _filterTextField.layer.cornerRadius = 6.0;
    _filterTextField.layer.borderWidth = 0.5;
    _filterTextField.layer.borderColor = [UIColor colorWithWhite:0.78 alpha:1.0].CGColor;
    _filterTextField.leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 10.0, 36.0)];
    _filterTextField.leftViewMode = UITextFieldViewModeAlways;
    [_filterTextField addTarget:self action:@selector(filterTextDidChange:) forControlEvents:UIControlEventEditingChanged];
    [self.searchHeaderView addSubview:_filterTextField];

    _scanButton = [UIButton buttonWithType:UIButtonTypeCustom];
    _scanButton.backgroundColor = [UIColor colorWithWhite:0.90 alpha:1.0];
    _scanButton.titleLabel.font = [UIFont systemFontOfSize:14.0];
    [_scanButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    _scanButton.layer.cornerRadius = 6.0;
    _scanButton.layer.borderWidth = 0.5;
    _scanButton.layer.borderColor = [UIColor colorWithWhite:0.78 alpha:1.0].CGColor;
    [_scanButton addTarget:self action:@selector(scanButtonTapped) forControlEvents:UIControlEventTouchUpInside];
    [self.searchHeaderView addSubview:_scanButton];

    if (@available(iOS 13.0, *)) {
        _indicatorView = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleMedium];
    } else {
        _indicatorView = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    }
    _indicatorView.hidesWhenStopped = YES;
    [self.searchHeaderView addSubview:_indicatorView];
}

- (void)setupTableView {
    self.tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.backgroundColor = [UIColor whiteColor];
    self.tableView.keyboardDismissMode = UIScrollViewKeyboardDismissModeOnDrag;
    self.tableView.tableFooterView = [[UIView alloc] init];
    [self.view addSubview:self.tableView];
}

- (void)updateLocalizedTexts {
    self.title = QCSampleLocalized(QCSampleLocalizedKeyItemScan);
    self.filterTextField.placeholder = QCSampleLocalized(QCSampleLocalizedKeyScanFilterPlaceholder);
    [self.scanButton setTitle:QCSampleLocalized(QCSampleLocalizedKeyScanStartButton) forState:UIControlStateNormal];
}

#pragma mark - Scan & Filter

- (void)startScanning {
    [QCCentralManager shared].delegate = self;
    [[QCCentralManager shared] scan];
    [self.indicatorView startAnimating];
    self.scanButton.enabled = NO;
}

- (void)scanButtonTapped {
    [self.filterTextField resignFirstResponder];
    [[QCCentralManager shared] stopScan];
    [self startScanning];
}

- (void)filterTextDidChange:(UITextField *)textField {
    [self applyFilterWithKeyword:textField.text];
}

- (NSString *)normalizedSearchText:(NSString *)text {
    if (text.length == 0) {
        return @"";
    }
    NSString *normalized = [[text lowercaseString] stringByReplacingOccurrencesOfString:@" " withString:@""];
    normalized = [normalized stringByReplacingOccurrencesOfString:@":" withString:@""];
    normalized = [normalized stringByReplacingOccurrencesOfString:@"-" withString:@""];
    return normalized;
}

- (BOOL)peripheral:(QCBlePeripheral *)peripheral matchesKeyword:(NSString *)keyword {
    if (keyword.length == 0) {
        return YES;
    }

    NSString *normalizedKeyword = [self normalizedSearchText:keyword];
    NSString *deviceName = [peripheral.peripheral.name lowercaseString] ?: @"";
    NSString *macAddress = [peripheral.mac lowercaseString] ?: @"";
    NSString *normalizedMac = [self normalizedSearchText:macAddress];

    if ([deviceName containsString:keyword.lowercaseString]) {
        return YES;
    }
    if ([macAddress containsString:keyword.lowercaseString]) {
        return YES;
    }
    if (normalizedKeyword.length > 0 && [normalizedMac containsString:normalizedKeyword]) {
        return YES;
    }
    return NO;
}

- (void)applyFilterWithKeyword:(NSString *)keyword {
    if (keyword.length == 0) {
        self.filteredPeripherals = self.allPeripherals;
    } else {
        NSPredicate *predicate = [NSPredicate predicateWithBlock:^BOOL(QCBlePeripheral *peripheral, NSDictionary<NSString *,id> * _Nullable bindings) {
            return [self peripheral:peripheral matchesKeyword:keyword];
        }];
        self.filteredPeripherals = [self.allPeripherals filteredArrayUsingPredicate:predicate];
    }
    [self.tableView reloadData];
}

#pragma mark - QCCentralManagerDelegate

- (void)didScanPeripherals:(NSArray *)peripheralArr {
    self.allPeripherals = peripheralArr ?: @[];
    [self applyFilterWithKeyword:self.filterTextField.text];
    [self.indicatorView stopAnimating];
    self.scanButton.enabled = YES;
}

- (void)scanPeripheralFinish {
    [self.indicatorView stopAnimating];
    self.scanButton.enabled = YES;
}

- (void)didState:(QCState)state {
    if (state == QCStateConnected) {
        // Hide connecting tip before leaving. 连接成功后关闭提示再返回
        [QcxUI_TextHUD QcxUI_dismiss];
        [self.navigationController popViewControllerAnimated:YES];
    }
}

- (void)didFailConnected:(CBPeripheral *)peripheral error:(NSError *)error {
    NSLog(@"Connected Fail: %@", error.localizedDescription);
    // Hide connecting tip and resume scanning. 连接失败后关闭提示并继续扫描
    [QcxUI_TextHUD QcxUI_dismiss];
    [self startScanning];
}

#pragma mark - UITextFieldDelegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}

#pragma mark - UITableViewDataSource & Delegate

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.filteredPeripherals.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellIdentifier = @"QCScanDeviceCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIdentifier];
    }

    QCBlePeripheral *peripheral = self.filteredPeripherals[indexPath.row];
    cell.textLabel.text = peripheral.peripheral.name.length > 0 ? peripheral.peripheral.name : @"--";
    cell.textLabel.textColor = [UIColor colorWithRed:0.10 green:0.45 blue:0.95 alpha:1.0];
    cell.detailTextLabel.text = peripheral.mac.length > 0 ? peripheral.mac : @"--";
    cell.detailTextLabel.textColor = [UIColor grayColor];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    [self.filterTextField resignFirstResponder];
    [self.indicatorView stopAnimating];
    [[QCCentralManager shared] stopScan];

    QCBlePeripheral *peripheral = self.filteredPeripherals[indexPath.row];
    NSLog(@"Connecting to %@, mac:%@", peripheral.peripheral.name, peripheral.mac);
    // Show connecting HUD when user taps a device. 点击选择设备连接时展示提示 HUD
    [QcxUI_TextHUD QcxUI_showWithText:QCSampleLocalized(QCSampleLocalizedKeyScanConnecting)
                           shimmering:YES];
    [[QCCentralManager shared] connect:peripheral.peripheral];
}

@end
