//
//  QCSampleDeviceStatusHeaderView.h
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//

#import <UIKit/UIKit.h>
#import "QCSampleDeviceStatus.h"

NS_ASSUME_NONNULL_BEGIN

@interface QCSampleDeviceStatusHeaderView : UIView

- (void)configureWithStatus:(QCSampleDeviceStatus *)status;

+ (CGFloat)preferredHeightForStatus:(QCSampleDeviceStatus *)status width:(CGFloat)width;

@end

NS_ASSUME_NONNULL_END
