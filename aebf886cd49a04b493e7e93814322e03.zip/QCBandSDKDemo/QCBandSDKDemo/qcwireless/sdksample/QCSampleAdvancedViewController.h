//
//  QCSampleAdvancedViewController.h
//  QCBandSDKDemo
//
//  Created by zhong on 2026/8/5.
//
//  Advanced SDK sample (AGPS, PXP/Intell, MSL praise, features, resources, power).
//  高级 SDK 示例（AGPS、智能报警、赞念、能力列表、个性化资源、关机）。
//
//  SDK APIs / 使用的 SDK API:
//  - getAGPSStatusWithCurrentState:… / setAGPSStatus:…
//  - getPxpAlarmDelay:fail: / setPxpAlarmDelay:delaySeconds:…
//  - getTouchControlFinshed: / setTouchControl:… (MSL praise)
//  - getPraiseDataByDayIndexs:finished: / clearPraiseDataWithSuccess:fail:
//  - setTime:success:failed: / getDeviceFeatureConfigSuccess:fail:
//  - getResourceWithUITypes:success:fail:
//  - shutDownSuccess:fail:
//

#import "QCSampleHealthFunctionViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface QCSampleAdvancedViewController : QCSampleHealthFunctionViewController

@end

NS_ASSUME_NONNULL_END
