//
//  QCSampleSystemTimePickerView.h
//  QCBandSDKDemo
//
//  Wheels-style UIDatePicker; I/O is always 24h "HH:mm".
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef void (^QCSampleSystemTimePickerValueChanged)(NSString *selectedTimer);

/// System `UIDatePicker` (wheels) time roller. 基于系统 UIDatePicker（wheels）的时间滚轮。
/// Input/output is always 24-hour `HH:mm` for BLE / storage. 内外读写始终为 24 小时制 HH:mm。
@interface QCSampleSystemTimePickerView : UIView
 
@property (nonatomic, copy, nullable) QCSampleSystemTimePickerValueChanged valueChanged;

/// Input/output is 24-hour `HH:mm`. Default `00:00`. Corresponds to Swift `initTimer`.
@property (nonatomic, copy) NSString *initialTimer;

/// Always returns 24-hour `HH:mm`.
@property (nonatomic, readonly) NSString *selectedTimer;

/**
 * Present a bottom sheet with localized Cancel / OK.
 * 弹出底部时间选择面板（取消 / 确定已国际化）。
 *
 * @param viewController Host view controller.
 * @param title Sheet title; pass nil to use the default localized title.
 * @param initialTimer Initial time in `HH:mm`.
 * @param completion Called with selected `HH:mm` when user taps OK. Not called on Cancel.
 */
+ (void)showInViewController:(UIViewController *)viewController
                       title:(nullable NSString *)title
               initialTimer:(NSString *)initialTimer
                  completion:(void (^)(NSString *selectedTimer))completion;

@end

NS_ASSUME_NONNULL_END
