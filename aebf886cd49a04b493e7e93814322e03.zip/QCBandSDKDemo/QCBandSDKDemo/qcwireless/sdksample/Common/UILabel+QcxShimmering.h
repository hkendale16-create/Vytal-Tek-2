//
//  UILabel+QcxShimmering.h
//  QCBandSDKDemo
//
//  Created by zhong on 2026/8/5.
//
//  UILabel shimmering effect category used by QcxUI_TextHUD.
//  供 QcxUI_TextHUD 使用的 UILabel 文字滑闪效果分类。

#import <UIKit/UIKit.h>

@interface UILabel (QcxShimmering)

/**
 *  Start the shimmering animation (internal helper for the HUD).
 *  开始闪动（HUD 框架内部方法）。
 */
- (void)QcxUI_shimmeringEffectStart;

@end
