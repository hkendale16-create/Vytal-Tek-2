//
//  QCSampleLogCell.m
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//

#import "QCSampleLogCell.h"
#import "QCSampleLocalization.h"

static CGFloat const kQCSampleLogHorizontalPadding = 16.0;
static CGFloat const kQCSampleLogVerticalPadding = 12.0;
static CGFloat const kQCSampleLogToolbarHeight = 36.0;
static CGFloat const kQCSampleLogClearButtonWidth = 36.0;
static CGFloat const kQCSampleLogToolbarSpacing = 8.0;

@interface QCSampleLogCell ()
@property (nonatomic, strong) UITextView *logTextView;
@property (nonatomic, strong) UIButton *logCopyButton;
@property (nonatomic, strong) UIButton *logClearButton;
@end

@implementation QCSampleLogCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;

        _logTextView = [[UITextView alloc] init];
        _logTextView.editable = NO;
        _logTextView.scrollEnabled = NO;
        _logTextView.font = [UIFont fontWithName:@"Menlo" size:12.0] ?: [UIFont systemFontOfSize:12.0];
        _logTextView.textColor = [UIColor darkGrayColor];
        _logTextView.backgroundColor = [UIColor colorWithWhite:0.97 alpha:1.0];
        _logTextView.layer.cornerRadius = 8.0;
        _logTextView.textContainerInset = UIEdgeInsetsMake(10, 8, 10, 8);
        [self.contentView addSubview:_logTextView];

        _logCopyButton = [UIButton buttonWithType:UIButtonTypeSystem];
        [_logCopyButton setTitle:QCSampleLocalized(QCSampleLocalizedKeyHealthCopyLog) forState:UIControlStateNormal];
        _logCopyButton.titleLabel.font = [UIFont systemFontOfSize:15.0];
        _logCopyButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeading;
        [_logCopyButton addTarget:self action:@selector(copyButtonTapped) forControlEvents:UIControlEventTouchUpInside];
        [self.contentView addSubview:_logCopyButton];

        _logClearButton = [UIButton buttonWithType:UIButtonTypeSystem];
        if (@available(iOS 13.0, *)) {
            UIImage *clearImage = [UIImage systemImageNamed:@"trash"];
            [_logClearButton setImage:clearImage forState:UIControlStateNormal];
        } else {
            [_logClearButton setTitle:QCSampleLocalized(QCSampleLocalizedKeyHealthClearLog) forState:UIControlStateNormal];
            _logClearButton.titleLabel.font = [UIFont systemFontOfSize:13.0];
        }
        _logClearButton.tintColor = [UIColor systemRedColor];
        _logClearButton.accessibilityLabel = QCSampleLocalized(QCSampleLocalizedKeyHealthClearLog);
        [_logClearButton addTarget:self action:@selector(clearButtonTapped) forControlEvents:UIControlEventTouchUpInside];
        [self.contentView addSubview:_logClearButton];
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];

    CGFloat width = self.contentView.bounds.size.width;
    CGFloat toolbarY = kQCSampleLogVerticalPadding;
    CGFloat clearX = width - kQCSampleLogHorizontalPadding - kQCSampleLogClearButtonWidth;

    self.logClearButton.frame = CGRectMake(clearX,
                                           toolbarY,
                                           kQCSampleLogClearButtonWidth,
                                           kQCSampleLogToolbarHeight);

    CGFloat copyWidth = clearX - kQCSampleLogHorizontalPadding - kQCSampleLogToolbarSpacing;
    self.logCopyButton.frame = CGRectMake(kQCSampleLogHorizontalPadding,
                                          toolbarY,
                                          copyWidth,
                                          kQCSampleLogToolbarHeight);

    CGFloat textY = CGRectGetMaxY(self.logCopyButton.frame) + 8.0;
    self.logTextView.frame = CGRectMake(kQCSampleLogHorizontalPadding,
                                        textY,
                                        width - kQCSampleLogHorizontalPadding * 2.0,
                                        self.contentView.bounds.size.height - textY - kQCSampleLogVerticalPadding);
}

- (void)configureWithText:(NSString *)text {
    self.logTextView.text = text.length > 0 ? text : @"";
    [self.logCopyButton setTitle:QCSampleLocalized(QCSampleLocalizedKeyHealthCopyLog) forState:UIControlStateNormal];
    self.logClearButton.accessibilityLabel = QCSampleLocalized(QCSampleLocalizedKeyHealthClearLog);
    [self setNeedsLayout];
}

+ (CGFloat)heightForText:(NSString *)text width:(CGFloat)width {
    CGFloat contentWidth = width - kQCSampleLogHorizontalPadding * 2.0 - 16.0;
    UIFont *font = [UIFont fontWithName:@"Menlo" size:12.0] ?: [UIFont systemFontOfSize:12.0];
    NSString *displayText = text.length > 0 ? text : @" ";
    CGRect rect = [displayText boundingRectWithSize:CGSizeMake(contentWidth, CGFLOAT_MAX)
                                             options:NSStringDrawingUsesLineFragmentOrigin
                                          attributes:@{NSFontAttributeName: font}
                                             context:nil];
    return kQCSampleLogVerticalPadding
         + kQCSampleLogToolbarHeight
         + 8.0
         + ceil(rect.size.height) + 20.0
         + kQCSampleLogVerticalPadding;
}

- (void)copyButtonTapped {
    if (self.copyHandler) {
        self.copyHandler();
    }
}

- (void)clearButtonTapped {
    if (self.clearHandler) {
        self.clearHandler();
    }
}

@end
