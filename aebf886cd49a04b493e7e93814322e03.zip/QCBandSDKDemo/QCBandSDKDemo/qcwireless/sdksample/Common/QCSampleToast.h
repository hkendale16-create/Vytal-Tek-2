//
//  QCSampleToast.h
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//
//  Shared toast helper for SDK demo pages. 各演示页共用的 Toast 提示。

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface QCSampleToast : NSObject

+ (void)showCenterWithText:(NSString *)text;
+ (void)showCenterWithText:(NSString *)text duration:(CGFloat)duration;

+ (void)showTopWithText:(NSString *)text;
+ (void)showTopWithText:(NSString *)text duration:(CGFloat)duration;
+ (void)showTopWithText:(NSString *)text topOffset:(CGFloat)topOffset;
+ (void)showTopWithText:(NSString *)text topOffset:(CGFloat)topOffset duration:(CGFloat)duration;

+ (void)showBottomWithText:(NSString *)text;
+ (void)showBottomWithText:(NSString *)text duration:(CGFloat)duration;
+ (void)showBottomWithText:(NSString *)text bottomOffset:(CGFloat)bottomOffset;
+ (void)showBottomWithText:(NSString *)text bottomOffset:(CGFloat)bottomOffset duration:(CGFloat)duration;

@end

NS_ASSUME_NONNULL_END
