//
//  QCSampleSystemTimePickerView.m
//  QCBandSDKDemo
//
//  Objective-C port of QIFSystemTimePickerView.
//

#import "QCSampleSystemTimePickerView.h"
#import "QCSampleLocalization.h"
#import <objc/runtime.h>

static const CGFloat kQCSampleTimePickerHeight = 216.0;
static const CGFloat kQCSampleTimePickerToolbarHeight = 48.0;
static const CGFloat kQCSampleTimePickerCornerRadius = 16.0;
static char kQCSampleTimePickerDismissKey;

@interface QCSampleSystemTimePickerView ()
@property (nonatomic, strong) UIDatePicker *datePicker;
@property (nonatomic, assign) BOOL isApplyingProgrammatically;
@end

@interface QCSampleSystemTimePickerSheetController : NSObject
@property (nonatomic, weak) UIView *dimmingView;
@property (nonatomic, weak) UIView *panel;
@property (nonatomic, weak) QCSampleSystemTimePickerView *picker;
@property (nonatomic, copy, nullable) void (^completion)(NSString *selectedTimer);
@property (nonatomic, assign) CGFloat panelHeight;
- (void)dismissWithConfirm:(BOOL)confirm;
- (void)handleCancel;
- (void)handleOK;
- (void)handleDimTap;
@end

@implementation QCSampleSystemTimePickerSheetController

- (void)handleCancel {
    [self dismissWithConfirm:NO];
}

- (void)handleOK {
    [self dismissWithConfirm:YES];
}

- (void)handleDimTap {
    [self dismissWithConfirm:NO];
}

- (void)dismissWithConfirm:(BOOL)confirm {
    UIView *dimmingView = self.dimmingView;
    UIView *panel = self.panel;
    QCSampleSystemTimePickerView *picker = self.picker;
    void (^completion)(NSString *) = self.completion;
    CGFloat panelHeight = self.panelHeight;
    if (!dimmingView || !panel) { return; }

    UIView *hostView = dimmingView.superview;
    [UIView animateWithDuration:0.25 animations:^{
        dimmingView.alpha = 0;
        panel.frame = CGRectMake(0, hostView.bounds.size.height, hostView.bounds.size.width, panelHeight);
    } completion:^(BOOL finished) {
        if (confirm && completion) {
            completion(picker.selectedTimer);
        }
        objc_setAssociatedObject(dimmingView, &kQCSampleTimePickerDismissKey, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        [dimmingView removeFromSuperview];
    }];
}

@end

@implementation QCSampleSystemTimePickerView

#pragma mark - Lifecycle

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        _initialTimer = @"00:00";
        [self setupUI];
    }
    return self;
}

- (instancetype)initWithCoder:(NSCoder *)coder {
    self = [super initWithCoder:coder];
    if (self) {
        _initialTimer = @"00:00";
        [self setupUI];
    }
    return self;
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    // Wheels may rebuild subviews and reset text color; refresh on layout.
    [self applyAppearance];
}

- (void)traitCollectionDidChange:(UITraitCollection *)previousTraitCollection {
    [super traitCollectionDidChange:previousTraitCollection];
    if (@available(iOS 13.0, *)) {
        if (self.traitCollection.userInterfaceStyle != previousTraitCollection.userInterfaceStyle) {
            [self applyAppearance];
        }
    }
}

#pragma mark - Public

- (void)setInitialTimer:(NSString *)initialTimer {
    _initialTimer = [initialTimer copy] ?: @"00:00";
    [self applyInitialTimer:_initialTimer];
}

- (NSString *)selectedTimer {
    return [self timeStringFromDate:self.datePicker.date];
}

+ (void)showInViewController:(UIViewController *)viewController
                       title:(NSString *)title
               initialTimer:(NSString *)initialTimer
                  completion:(void (^)(NSString *selectedTimer))completion {
    if (!viewController) { return; }

    UIView *hostView = viewController.view;
    NSString *sheetTitle = title.length > 0
        ? title
        : QCSampleLocalized(QCSampleLocalizedKeyCommonSelectTime);

    UIView *dimmingView = [[UIView alloc] initWithFrame:hostView.bounds];
    dimmingView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    dimmingView.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.4];
    dimmingView.alpha = 0;

    UIView *panel = [[UIView alloc] init];
    panel.backgroundColor = [self qc_sheetBackgroundColor];
    if (@available(iOS 11.0, *)) {
        panel.layer.cornerRadius = kQCSampleTimePickerCornerRadius;
        panel.layer.maskedCorners = kCALayerMinXMinYCorner | kCALayerMaxXMinYCorner;
    }
    panel.clipsToBounds = YES;

    UILabel *titleLabel = [[UILabel alloc] init];
    titleLabel.text = sheetTitle;
    titleLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightSemibold];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    titleLabel.textColor = [self qc_primaryTextColor];

    UIButton *cancelButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [cancelButton setTitle:QCSampleLocalized(QCSampleLocalizedKeyCommonCancel) forState:UIControlStateNormal];
    cancelButton.titleLabel.font = [UIFont systemFontOfSize:16];
    cancelButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;

    UIButton *okButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [okButton setTitle:QCSampleLocalized(QCSampleLocalizedKeyCommonOK) forState:UIControlStateNormal];
    okButton.titleLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightSemibold];
    okButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;

    QCSampleSystemTimePickerView *picker = [[QCSampleSystemTimePickerView alloc] initWithFrame:CGRectZero];
    picker.initialTimer = initialTimer.length > 0 ? initialTimer : @"10:00";

    [hostView addSubview:dimmingView];
    [dimmingView addSubview:panel];
    [panel addSubview:cancelButton];
    [panel addSubview:titleLabel];
    [panel addSubview:okButton];
    [panel addSubview:picker];

    CGFloat safeBottom = 0;
    if (@available(iOS 11.0, *)) {
        safeBottom = hostView.safeAreaInsets.bottom;
    }
    CGFloat panelHeight = kQCSampleTimePickerToolbarHeight + kQCSampleTimePickerHeight + safeBottom;
    panel.frame = CGRectMake(0, hostView.bounds.size.height, hostView.bounds.size.width, panelHeight);

    cancelButton.frame = CGRectMake(16, 0, 80, kQCSampleTimePickerToolbarHeight);
    okButton.frame = CGRectMake(panel.bounds.size.width - 96, 0, 80, kQCSampleTimePickerToolbarHeight);
    titleLabel.frame = CGRectMake(96, 0, panel.bounds.size.width - 192, kQCSampleTimePickerToolbarHeight);
    picker.frame = CGRectMake(0, kQCSampleTimePickerToolbarHeight, panel.bounds.size.width, kQCSampleTimePickerHeight);

    cancelButton.autoresizingMask = UIViewAutoresizingFlexibleRightMargin;
    okButton.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
    titleLabel.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    picker.autoresizingMask = UIViewAutoresizingFlexibleWidth;

    QCSampleSystemTimePickerSheetController *controller = [[QCSampleSystemTimePickerSheetController alloc] init];
    controller.dimmingView = dimmingView;
    controller.panel = panel;
    controller.picker = picker;
    controller.completion = completion;
    controller.panelHeight = panelHeight;
    // Retain controller for the lifetime of the sheet.
    objc_setAssociatedObject(dimmingView, &kQCSampleTimePickerDismissKey, controller, OBJC_ASSOCIATION_RETAIN_NONATOMIC);

    [cancelButton addTarget:controller action:@selector(handleCancel) forControlEvents:UIControlEventTouchUpInside];
    [okButton addTarget:controller action:@selector(handleOK) forControlEvents:UIControlEventTouchUpInside];

    UIButton *dimButton = [UIButton buttonWithType:UIButtonTypeCustom];
    dimButton.frame = dimmingView.bounds;
    dimButton.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    [dimButton addTarget:controller action:@selector(handleDimTap) forControlEvents:UIControlEventTouchUpInside];
    [dimmingView insertSubview:dimButton atIndex:0];

    [UIView animateWithDuration:0.28 delay:0 options:UIViewAnimationOptionCurveEaseOut animations:^{
        dimmingView.alpha = 1;
        panel.frame = CGRectMake(0, hostView.bounds.size.height - panelHeight, hostView.bounds.size.width, panelHeight);
    } completion:nil];
}

#pragma mark - Setup

- (void)setupUI {
    self.datePicker = [[UIDatePicker alloc] initWithFrame:CGRectZero];
    self.datePicker.datePickerMode = UIDatePickerModeTime;
    self.datePicker.calendar = [NSCalendar calendarWithIdentifier:NSCalendarIdentifierGregorian];
    self.datePicker.timeZone = [NSTimeZone localTimeZone];
    self.datePicker.minuteInterval = 1;
    self.datePicker.backgroundColor = [UIColor clearColor];
    if (@available(iOS 13.4, *)) {
        self.datePicker.preferredDatePickerStyle = UIDatePickerStyleWheels;
    }
    [self.datePicker addTarget:self action:@selector(dateChanged) forControlEvents:UIControlEventValueChanged];

    [self addSubview:self.datePicker];
    self.datePicker.translatesAutoresizingMaskIntoConstraints = NO;
    [NSLayoutConstraint activateConstraints:@[
        [self.datePicker.topAnchor constraintEqualToAnchor:self.topAnchor],
        [self.datePicker.bottomAnchor constraintEqualToAnchor:self.bottomAnchor],
        [self.datePicker.leadingAnchor constraintEqualToAnchor:self.leadingAnchor],
        [self.datePicker.trailingAnchor constraintEqualToAnchor:self.trailingAnchor],
    ]];

    [self applyHourCycle];
    [self applyAppearance];
    [self applyInitialTimer:self.initialTimer];

    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(currentLocaleDidChange)
                                                 name:NSCurrentLocaleDidChangeNotification
                                               object:nil];
}

#pragma mark - Appearance / Locale

- (void)currentLocaleDidChange {
    NSString *current = self.selectedTimer;
    [self applyHourCycle];
    [self applyAppearance];
    [self applyInitialTimer:current];
}

/// Follow system 12/24h. 12h uses app language so AM/PM / 上午下午 match i18n.
- (void)applyHourCycle {
    BOOL use24h = [self qc_isTwentyFourHour];
    // 24h: en_GB (0–23). 12h: zh_CN → 上午/下午, en_US → AM/PM.
    NSString *localeId = use24h ? @"en_GB" : (QCSampleUsesChineseLanguage() ? @"zh_CN" : @"en_US");
    self.datePicker.locale = [[NSLocale alloc] initWithLocaleIdentifier:localeId];
}

- (void)applyAppearance {
    BOOL isDark = NO;
    if (@available(iOS 13.0, *)) {
        isDark = self.traitCollection.userInterfaceStyle == UIUserInterfaceStyleDark;
        self.datePicker.overrideUserInterfaceStyle = isDark ? UIUserInterfaceStyleDark : UIUserInterfaceStyleLight;
    }
    UIColor *textColor = isDark ? [UIColor whiteColor] : [UIColor darkTextColor];
    if (@available(iOS 13.0, *)) {
        textColor = isDark ? [UIColor whiteColor] : [UIColor labelColor];
    }
    // UIDatePicker wheels has no public text-color API.
    @try {
        [self.datePicker setValue:textColor forKey:@"textColor"];
        [self.datePicker setValue:@NO forKey:@"highlightsToday"];
    } @catch (__unused NSException *exception) {
    }
}

#pragma mark - Time helpers

- (void)applyInitialTimer:(NSString *)timer {
    NSDate *date = [self dateFromTimer:timer];
    if (!date) { return; }
    self.isApplyingProgrammatically = YES;
    [self.datePicker setDate:date animated:NO];
    self.isApplyingProgrammatically = NO;
}

- (void)dateChanged {
    if (self.isApplyingProgrammatically) { return; }
    if (self.valueChanged) {
        self.valueChanged(self.selectedTimer);
    }
}

- (NSDate *)dateFromTimer:(NSString *)timer {
    NSArray<NSString *> *parts = [timer componentsSeparatedByString:@":"];
    if (parts.count < 2) { return nil; }
    NSInteger hour = parts[0].integerValue;
    NSString *minutePart = parts[1];
    if (minutePart.length > 2) {
        minutePart = [minutePart substringToIndex:2];
    }
    NSInteger minute = minutePart.integerValue;
    hour = MIN(MAX(hour, 0), 23);
    minute = MIN(MAX(minute, 0), 59);

    NSCalendar *calendar = [NSCalendar calendarWithIdentifier:NSCalendarIdentifierGregorian];
    calendar.timeZone = [NSTimeZone localTimeZone];
    NSDateComponents *comps = [calendar components:(NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay)
                                          fromDate:[NSDate date]];
    comps.hour = hour;
    comps.minute = minute;
    comps.second = 0;
    return [calendar dateFromComponents:comps];
}

- (NSString *)timeStringFromDate:(NSDate *)date {
    NSCalendar *calendar = [NSCalendar calendarWithIdentifier:NSCalendarIdentifierGregorian];
    calendar.timeZone = [NSTimeZone localTimeZone];
    NSInteger hour = [calendar component:NSCalendarUnitHour fromDate:date];
    NSInteger minute = [calendar component:NSCalendarUnitMinute fromDate:date];
    return [NSString stringWithFormat:@"%02ld:%02ld", (long)hour, (long)minute];
}

- (BOOL)qc_isTwentyFourHour {
    NSString *format = [NSDateFormatter dateFormatFromTemplate:@"j"
                                                       options:0
                                                        locale:[NSLocale currentLocale]];
    return [format containsString:@"H"] || [format containsString:@"k"];
}

+ (UIColor *)qc_sheetBackgroundColor {
    if (@available(iOS 13.0, *)) {
        return [UIColor secondarySystemBackgroundColor];
    }
    return [UIColor whiteColor];
}

+ (UIColor *)qc_primaryTextColor {
    if (@available(iOS 13.0, *)) {
        return [UIColor labelColor];
    }
    return [UIColor darkTextColor];
}

@end
