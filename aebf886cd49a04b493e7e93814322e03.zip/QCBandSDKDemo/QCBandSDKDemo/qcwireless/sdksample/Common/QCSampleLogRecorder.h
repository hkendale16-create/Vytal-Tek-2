//
//  QCSampleLogRecorder.h
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//
//  Shared log buffer for SDK demo pages. 各演示页共用的日志缓冲器。

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef void (^QCSampleLogUpdateHandler)(NSString *logText);

/// Append-only log recorder with change notification for demo UITableView panels. 追加式日志记录器，供演示页日志面板刷新。
@interface QCSampleLogRecorder : NSObject

@property (nonatomic, copy, readonly) NSString *text;
@property (nonatomic, copy, nullable) QCSampleLogUpdateHandler updateHandler;

- (void)clear;
- (void)appendLine:(NSString *)line;
- (void)appendFormat:(NSString *)format, ... NS_FORMAT_FUNCTION(1, 2);

@end

NS_ASSUME_NONNULL_END
