//
//  UIView+QCSampleLayout.m
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//
#import "UIView+QCSampleLayout.h"

@implementation UIView (QCSampleLayout)

- (void)setQcsSample_X:(CGFloat)qcsSample_X
{
    CGRect frame = self.frame;
    frame.origin.x = qcsSample_X;
    self.frame = frame;
}

- (void)setQcsSample_Y:(CGFloat)qcsSample_Y
{
    CGRect frame = self.frame;
    frame.origin.y = qcsSample_Y;
    self.frame = frame;
}

- (CGFloat)qcsSample_X
{
    return self.frame.origin.x;
}

- (CGFloat)qcsSample_Y
{
    return self.frame.origin.y;
}

- (void)setQcsSample_Width:(CGFloat)qcsSample_Width
{
    CGRect frame = self.frame;
    frame.size.width = qcsSample_Width;
    self.frame = frame;
}

- (void)setQcsSample_Height:(CGFloat)qcsSample_Height
{
    CGRect frame = self.frame;
    frame.size.height = qcsSample_Height;
    self.frame = frame;
}

- (CGFloat)qcsSample_Height
{
    return self.frame.size.height;
}

- (CGFloat)qcsSample_Width
{
    return self.frame.size.width;
}

- (UIView * (^)(CGFloat x))setX{
    return ^(CGFloat x) {
        self.qcsSample_X = x;
        return self;
    };
}

- (void)setQcsSample_CenterX:(CGFloat)qcsSample_CenterX
{
    CGPoint center = self.center;
    center.x = qcsSample_CenterX;
    self.center = center;
}

- (CGFloat)qcsSample_CenterX
{
    return self.center.x;
}

- (void)setQcsSample_CenterY:(CGFloat)qcsSample_CenterY
{
    CGPoint center = self.center;
    center.y = qcsSample_CenterY;
    self.center = center;
}

- (CGFloat)qcsSample_CenterY
{
    return self.center.y;
}

- (void)setQcsSample_Size:(CGSize)qcsSample_Size
{
    CGRect frame = self.frame;
    frame.size = qcsSample_Size;
    self.frame = frame;
}

- (CGSize)qcsSample_Size
{
    return self.frame.size;
}

- (void)setQcsSample_Origin:(CGPoint)qcsSample_Origin
{
    CGRect frame = self.frame;
    frame.origin = qcsSample_Origin;
    self.frame = frame;
}

- (CGPoint)qcsSample_Origin
{
    return self.frame.origin;
}

- (CGFloat)qcsSample_Left {
    return self.frame.origin.x;
}

- (void)setQcsSample_Left:(CGFloat)qcsSample_Left {
    CGRect frame = self.frame;
    frame.origin.x = qcsSample_Left;
    self.frame = frame;
}

- (CGFloat)qcsSample_Top {
    return self.frame.origin.y;
}

- (void)setQcsSample_Top:(CGFloat)qcsSample_Top {
    CGRect frame = self.frame;
    frame.origin.y = qcsSample_Top;
    self.frame = frame;
}

- (CGFloat)qcsSample_Right {
    return self.frame.origin.x + self.frame.size.width;
}

- (void)setQcsSample_Right:(CGFloat)qcsSample_Right {
    CGRect frame = self.frame;
    frame.origin.x = qcsSample_Right - frame.size.width;
    self.frame = frame;
}

- (CGFloat)qcsSample_Bottom {
    return self.frame.origin.y + self.frame.size.height;
}

- (void)setQcsSample_Bottom:(CGFloat)qcsSample_Bottom {
    CGRect frame = self.frame;
    frame.origin.y = qcsSample_Bottom - frame.size.height;
    self.frame = frame;
}


- (UIView *(^)(UIColor *color)) setColor{
    return ^ (UIColor *color) {
        self.backgroundColor = color;
        return self;
    };
}

- (UIView *(^)(CGRect frame)) setFrame{
    return ^ (CGRect frame) {
        self.frame = frame;
        return self;
    };
}

- (UIView *(^)(CGSize size)) setSize
{
    return ^ (CGSize size) {
        self.bounds = CGRectMake(0, 0, size.width, size.height);
        return self;
    };
}

- (UIView *(^)(CGPoint point)) setCenter
{
    return ^ (CGPoint point) {
        self.center = point;
        return self;
    };
}

- (UIView *(^)(NSInteger tag)) setTag
{
    return ^ (NSInteger tag) {
        self.tag = tag;
        return self;
    };
}

- (void)setHollowWithCenterFrame:(CGRect)centerFrame{
    UIBezierPath *path = [UIBezierPath bezierPath];
    [path appendPath:[UIBezierPath bezierPathWithRect:self.frame]];
    [path appendPath:[UIBezierPath bezierPathWithRect:centerFrame].bezierPathByReversingPath];
    CAShapeLayer *maskLayer = [CAShapeLayer layer];
    maskLayer.path = path.CGPath;
    self.layer.mask = maskLayer;
}

/**
 *  1.获取屏幕图片
 */
- (UIImage *)imageFromSelfView{
    return [self imageFromViewWithFrame:self.frame];
}

- (UIImage *)imageFromViewWithFrame:(CGRect)frame
{
    UIGraphicsBeginImageContext(self.frame.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSaveGState(context);
    UIRectClip(frame);
    [self.layer renderInContext:context];
    UIImage *theImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return  theImage;
}

@end
