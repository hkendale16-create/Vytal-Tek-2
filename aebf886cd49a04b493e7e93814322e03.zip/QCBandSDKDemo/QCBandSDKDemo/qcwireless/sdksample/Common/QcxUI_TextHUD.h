//
//  QcxUI_TextHUD.h
//  QCBandSDKDemo
//
//  Created by zhong on 2026/8/5.
//
//  Lightweight text-only HUD tip. 轻量级纯文字提示 HUD。

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/** Background overlay type. 背景遮罩类型 */
typedef NS_ENUM(NSInteger, QcxTextHUDOverlayType) {
    QcxTextHUDOverlayTypeNone,        /**< No overlay (default). 无遮罩（默认） */
    QcxTextHUDOverlayTypeBlur,        /**< Blur overlay. 模糊遮罩 */
    QcxTextHUDOverlayTypeTransparent, /**< Semi-transparent black overlay. 半透明黑遮罩 */
    QcxTextHUDOverlayTypeShadow       /**< Shadow on the HUD itself. 自身阴影 */
};

/** Appear animation style. 入场动画 */
typedef NS_ENUM(NSInteger, QcxTextHUDAppearAnimationType) {
    QcxTextHUDAppearAnimationTypeSlideFromTop,    /**< Slide in from top. 从上滑入 */
    QcxTextHUDAppearAnimationTypeSlideFromBottom, /**< Slide in from bottom. 从下滑入 */
    QcxTextHUDAppearAnimationTypeSlideFromLeft,   /**< Slide in from left. 从左滑入 */
    QcxTextHUDAppearAnimationTypeSlideFromRight,  /**< Slide in from right. 从右滑入 */
    QcxTextHUDAppearAnimationTypeZoomIn,          /**< Zoom in. 放大进入 */
    QcxTextHUDAppearAnimationTypeFadeIn           /**< Fade in (default). 淡入（默认） */
};

/** Disappear animation style. 出场动画 */
typedef NS_ENUM(NSInteger, QcxTextHUDDisappearAnimationType) {
    QcxTextHUDDisappearAnimationTypeSlideToTop,    /**< Slide out to top. 向上滑出 */
    QcxTextHUDDisappearAnimationTypeSlideToBottom, /**< Slide out to bottom. 向下滑出 */
    QcxTextHUDDisappearAnimationTypeSlideToLeft,   /**< Slide out to left. 向左滑出 */
    QcxTextHUDDisappearAnimationTypeSlideToRight,  /**< Slide out to right. 向右滑出 */
    QcxTextHUDDisappearAnimationTypeZoomOut,       /**< Zoom out. 缩小退出 */
    QcxTextHUDDisappearAnimationTypeFadeOut        /**< Fade out (default). 淡出（默认） */
};

/**
 *  Lightweight text-only loading / tip HUD.
 *  轻量级纯文字加载提示工具。
 *
 *  Two usage styles:
 *  支持两种调用方式：
 *  1. Singleton class methods: + [QcxUI_TextHUD QcxUI_showWithText:@"Connecting..."]
 *     单例类方法快捷调用：+ [QcxUI_TextHUD QcxUI_showWithText:@"正在连接..."]
 *  2. Instance usage: create independent HUD instances as needed.
 *     实例化调用：可按需独立创建多个 HUD。
 */
@interface QcxUI_TextHUD : UIView

/**
 *  Shared singleton for class-method usage.
 *  单例对象，配合类方法使用。
 */
+ (instancetype)shared;

#pragma mark - Style Properties / 样式属性
/**
 *  Text color. Default: white.
 *  文字颜色，默认白色。
 */
@property (strong, nonatomic) UIColor *qcxUI_textColor;
/**
 *  Background color. Default: black with alpha 0.7.
 *  背景颜色，默认黑色半透明。
 */
@property (strong, nonatomic) UIColor *qcxUI_backgroundColor;
/**
 *  Font size. Default: 14.
 *  文字字号，默认14。
 */
@property (nonatomic, assign) CGFloat qcxUI_fontSize;
/**
 *  Corner radius. Default: 5.
 *  圆角值，默认5。
 */
@property (nonatomic, assign) CGFloat qcxUI_cornerRadius;
/**
 *  Horizontal padding. Default: 16.
 *  左右内边距，默认16。
 */
@property (nonatomic, assign) CGFloat qcxUI_horizontalPadding;
/**
 *  Vertical padding. Default: 12.
 *  上下内边距，默认12。
 */
@property (nonatomic, assign) CGFloat qcxUI_verticalPadding;
/**
 *  Max text width. Default: screen width / 2.8.
 *  文字最大宽度，默认屏幕宽度的1/2.8。
 */
@property (nonatomic, assign) CGFloat qcxUI_maxWidth;

#pragma mark - Border Properties / 边框属性
/**
 *  Border color. Default: clear (hidden).
 *  边框颜色，默认透明（不显示）。
 */
@property (strong, nonatomic) UIColor *qcxUI_borderColor;
/**
 *  Border width. Default: 0.
 *  边框宽度，默认0。
 */
@property (nonatomic, assign) CGFloat qcxUI_borderWidth;

#pragma mark - Overlay & Interaction / 遮罩与交互属性
/**
 *  Background overlay type. Default: QcxTextHUDOverlayTypeNone.
 *  背景遮罩类型，默认 QcxTextHUDOverlayTypeNone。
 */
@property (nonatomic, assign) QcxTextHUDOverlayType qcxUI_overlayType;
/**
 *  Whether to block background taps while shown. Default: YES.
 *  是否屏蔽背景点击（展示时禁用父视图其它控件交互），默认 YES。
 */
@property (nonatomic, assign) BOOL qcxUI_isTheOnlyActiveView;

#pragma mark - Animation Properties / 动画属性
/**
 *  Appear animation style. Default: FadeIn.
 *  入场动画风格，默认 FadeIn。
 */
@property (nonatomic, assign) QcxTextHUDAppearAnimationType qcxUI_appearAnimationType;
/**
 *  Disappear animation style. Default: FadeOut.
 *  退场动画风格，默认 FadeOut。
 */
@property (nonatomic, assign) QcxTextHUDDisappearAnimationType qcxUI_disappearAnimationType;
/**
 *  Whether text shimmering is enabled. Default: NO.
 *  是否开启文字滑闪效果，默认 NO。
 */
@property (nonatomic, assign) BOOL qcxUI_shimmeringEnabled;

#pragma mark - Instance Methods / 实例方法
/**
 *  Show centered on keyWindow.
 *  居中展示于 keyWindow。
 */
- (void)QcxUI_showWithText:(NSString *)text;
/**
 *  Show centered on keyWindow, optionally with shimmering text.
 *  居中展示于 keyWindow，并设置是否开启文字滑闪。
 */
- (void)QcxUI_showWithText:(NSString *)text shimmering:(BOOL)shimmering;
/**
 *  Show centered in a given view.
 *  居中展示于指定 View。
 */
- (void)QcxUI_showWithText:(NSString *)text inView:(UIView *)view;
/**
 *  Show centered in a given view, optionally with shimmering text.
 *  居中展示于指定 View，并设置是否开启文字滑闪。
 */
- (void)QcxUI_showWithText:(NSString *)text inView:(UIView *)view shimmering:(BOOL)shimmering;
/**
 *  Update the displayed text while visible.
 *  刷新展示文字。
 */
- (void)QcxUI_updateText:(NSString *)text;
/**
 *  Dismiss the HUD.
 *  移除展示。
 */
- (void)QcxUI_dismiss;

#pragma mark - Class Methods (Singleton) / 类方法（基于单例）
/**
 *  Show centered on keyWindow.
 *  居中展示于 keyWindow。
 */
+ (void)QcxUI_showWithText:(NSString *)text;
/**
 *  Show centered on keyWindow, optionally with shimmering text.
 *  居中展示于 keyWindow，并设置是否开启文字滑闪。
 */
+ (void)QcxUI_showWithText:(NSString *)text shimmering:(BOOL)shimmering;
/**
 *  Show centered in a given view.
 *  居中展示于指定 View。
 */
+ (void)QcxUI_showWithText:(NSString *)text inView:(UIView *)view;
/**
 *  Show centered in a given view, optionally with shimmering text.
 *  居中展示于指定 View，并设置是否开启文字滑闪。
 */
+ (void)QcxUI_showWithText:(NSString *)text inView:(UIView *)view shimmering:(BOOL)shimmering;
/**
 *  Update the displayed text while visible.
 *  刷新展示文字。
 */
+ (void)QcxUI_updateText:(NSString *)text;
/**
 *  Dismiss the HUD.
 *  移除展示。
 */
+ (void)QcxUI_dismiss;

@end

NS_ASSUME_NONNULL_END
