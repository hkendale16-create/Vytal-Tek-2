//
//  UIView+QCSampleLayout.h
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//

#import <UIKit/UIKit.h>

@interface UIView (QCSampleLayout)
/**
 *  1.间隔X值
 */
@property (nonatomic, assign) CGFloat qcsSample_X;

/**
 *  2.间隔Y值
 */
@property (nonatomic, assign) CGFloat qcsSample_Y;

/**
 *  3.宽度
 */
@property (nonatomic, assign) CGFloat qcsSample_Width;

/**
 *  4.高度
 */
@property (nonatomic, assign) CGFloat qcsSample_Height;

/**
 *  5.中心点X值
 */
@property (nonatomic, assign) CGFloat qcsSample_CenterX;

/**
 *  6.中心点Y值
 */
@property (nonatomic, assign) CGFloat qcsSample_CenterY;

/**
 *  7.尺寸大小
 */
@property (nonatomic, assign) CGSize qcsSample_Size;

/**
 *  8.起始点
 */
@property (nonatomic, assign) CGPoint qcsSample_Origin;

/**
 *  9.上 < Shortcut for frame.origin.y
 */
@property (nonatomic) CGFloat qcsSample_Top;

/**
 *  10.下 < Shortcut for frame.origin.y + frame.size.height
 */
@property (nonatomic) CGFloat qcsSample_Bottom;

/**
 *  11.左 < Shortcut for frame.origin.x.
 */
@property (nonatomic) CGFloat qcsSample_Left;

/**
 *  12.右 < Shortcut for frame.origin.x + frame.size.width
 */
@property (nonatomic) CGFloat qcsSample_Right;


/** 以下为未开放测试的API，以后可能修改名称等参数，不推荐使用  */
/**
 *  13.设置镂空中间的视图
 *
 */
- (void)setHollowWithCenterFrame:(CGRect)centerFrame;
/**
 *  14.获取屏幕图片
 */
- (UIImage *)imageFromSelfView;


@end
