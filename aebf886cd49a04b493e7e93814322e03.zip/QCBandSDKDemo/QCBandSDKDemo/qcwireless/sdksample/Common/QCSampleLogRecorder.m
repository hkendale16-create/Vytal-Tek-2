//
//  QCSampleLogRecorder.m
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//

#import "QCSampleLogRecorder.h"

@interface QCSampleLogRecorder ()
@property (nonatomic, strong) NSMutableString *buffer;
@end

@implementation QCSampleLogRecorder

- (instancetype)init {
    self = [super init];
    if (self) {
        _buffer = [NSMutableString string];
    }
    return self;
}

- (NSString *)text {
    return [self.buffer copy];
}

- (void)clear {
    [self.buffer setString:@""];
    [self notifyUpdate];
}

- (void)appendLine:(NSString *)line {
    if (line.length == 0) {
        return;
    }
    if (self.buffer.length > 0) {
        [self.buffer appendString:@"\n"];
    }
    [self.buffer appendString:line];
    NSLog(@"%@", line);
    [self notifyUpdate];
}

- (void)appendFormat:(NSString *)format, ... {
    va_list args;
    va_start(args, format);
    NSString *line = [[NSString alloc] initWithFormat:format arguments:args];
    va_end(args);
    [self appendLine:line];
}

- (void)notifyUpdate {
    if (self.updateHandler) {
        self.updateHandler(self.text);
    }
}

@end
