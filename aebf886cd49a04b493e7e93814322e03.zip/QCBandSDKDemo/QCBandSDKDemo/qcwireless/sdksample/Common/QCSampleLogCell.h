//
//  QCSampleLogCell.h
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//
//  Shared log panel cell for SDK demo pages. 各演示页共用的日志面板 Cell。

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/// Log text view with copy / clear actions for demo pages. 演示页日志展示 Cell，支持复制与清空。
@interface QCSampleLogCell : UITableViewCell

@property (nonatomic, copy, nullable) void (^copyHandler)(void);
@property (nonatomic, copy, nullable) void (^clearHandler)(void);

- (void)configureWithText:(NSString *)text;
+ (CGFloat)heightForText:(NSString *)text width:(CGFloat)width;

@end

NS_ASSUME_NONNULL_END
