//
//  QcxUI_TextHUD.m
//  QCBandSDKDemo
//
//  Created by zhong on 2026/8/5.
//
//  Lightweight text-only HUD tip. 轻量级纯文字提示 HUD。

#import "QcxUI_TextHUD.h"
#import "UILabel+QcxShimmering.h"

@implementation QcxUI_TextHUD
{
    UILabel *_textLabel;
    // Weak host view to avoid retain cycles. 当前承载的父视图，弱引用避免循环
    __weak UIView *_targetView;
    // Overlay view (blur / translucent black). 遮罩视图（模糊/半透明黑）
    UIView *_overlay;
}



#pragma mark - Singleton / 单例
/**
 *  Shared singleton instance.
 *  获取共享单例。
 */
+ (instancetype)shared {
    static QcxUI_TextHUD *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[QcxUI_TextHUD alloc] initWithFrame:CGRectZero];
    });
    return instance;
}

#pragma mark - Init / 初始化
- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self setup];
    }
    return self;
}

/**
 *  Apply default styles and build the text label.
 *  应用默认样式并创建文字标签。
 */
- (void)setup {
    // Style defaults aligned with the original text HUD presentation.
    // 样式默认值（对齐原文字 HUD 的文字展示）
    _qcxUI_textColor = [UIColor whiteColor];
    _qcxUI_backgroundColor = [UIColor colorWithWhite:0 alpha:0.7];
    _qcxUI_fontSize = 14;
    _qcxUI_cornerRadius = 5;
    _qcxUI_horizontalPadding = 16;
    _qcxUI_verticalPadding = 12;
    _qcxUI_maxWidth = [UIScreen mainScreen].bounds.size.width / 2.8;

    // Border defaults. 边框默认值
    _qcxUI_borderColor = [UIColor clearColor];
    _qcxUI_borderWidth = 0;

    // Overlay & interaction defaults. 遮罩与交互默认值
    _qcxUI_overlayType = QcxTextHUDOverlayTypeNone;
    _qcxUI_isTheOnlyActiveView = YES;

    // Animation defaults. 动画默认值
    _qcxUI_appearAnimationType = QcxTextHUDAppearAnimationTypeFadeIn;
    _qcxUI_disappearAnimationType = QcxTextHUDDisappearAnimationTypeFadeOut;
    _qcxUI_shimmeringEnabled = NO;

    self.backgroundColor = _qcxUI_backgroundColor;
    self.layer.cornerRadius = _qcxUI_cornerRadius;
    self.layer.masksToBounds = YES;
    // Resting alpha is 1; appear animations handle fade/slide.
    // resting alpha 为1，入场动画自行处理淡入/滑入
    self.alpha = 1.0;

    _textLabel = [[UILabel alloc] init];
    _textLabel.numberOfLines = 0;
    _textLabel.textAlignment = NSTextAlignmentCenter;
    _textLabel.textColor = _qcxUI_textColor;
    _textLabel.font = [UIFont systemFontOfSize:_qcxUI_fontSize];
    [self addSubview:_textLabel];
}

#pragma mark - Style Property Setters / 样式属性 SET 方法
- (void)setQcxUI_textColor:(UIColor *)qcxUI_textColor {
    _qcxUI_textColor = qcxUI_textColor;
    _textLabel.textColor = qcxUI_textColor;
}

- (void)setQcxUI_backgroundColor:(UIColor *)qcxUI_backgroundColor {
    _qcxUI_backgroundColor = qcxUI_backgroundColor;
    self.backgroundColor = qcxUI_backgroundColor;
}

- (void)setQcxUI_fontSize:(CGFloat)qcxUI_fontSize {
    _qcxUI_fontSize = qcxUI_fontSize;
    _textLabel.font = [UIFont systemFontOfSize:qcxUI_fontSize];
}

- (void)setQcxUI_cornerRadius:(CGFloat)qcxUI_cornerRadius {
    _qcxUI_cornerRadius = qcxUI_cornerRadius;
    self.layer.cornerRadius = qcxUI_cornerRadius;
}

- (void)setQcxUI_borderColor:(UIColor *)qcxUI_borderColor {
    _qcxUI_borderColor = qcxUI_borderColor;
    self.layer.borderColor = qcxUI_borderColor.CGColor;
}

- (void)setQcxUI_borderWidth:(CGFloat)qcxUI_borderWidth {
    _qcxUI_borderWidth = qcxUI_borderWidth;
    self.layer.borderWidth = qcxUI_borderWidth;
}

#pragma mark - Public SHOW Methods / 公开的 SHOW 方法重载
// MARK: Show on keyWindow / 展示于 keyWindow
- (void)QcxUI_showWithText:(NSString *)text {
    [self QcxUI_showWithText:text inView:[self defaultSuperView]];
}
- (void)QcxUI_showWithText:(NSString *)text shimmering:(BOOL)shimmering {
    self.qcxUI_shimmeringEnabled = shimmering;
    [self QcxUI_showWithText:text];
}
// MARK: Show in a specific view / 展示于指定 View
- (void)QcxUI_showWithText:(NSString *)text inView:(UIView *)view {
    // Remove any existing presentation to avoid stacking.
    // 如果已在展示，先移除，避免多次叠加
    if (self.superview) {
        [self removeFromSuperview];
    }
    _targetView = view;

    [self applyOverlay];                 // Add overlay by type. 按遮罩类型添加背景
    [view addSubview:self];
    [view bringSubviewToFront:self];

    [self relayoutWithText:text];        // Layout + shimmer. 布局并应用滑闪
    [self blockBackgroundInteraction];   // Block background taps. 屏蔽背景点击

    [self showAnimation];                // Appear animation. 入场动画
}
- (void)QcxUI_showWithText:(NSString *)text inView:(UIView *)view shimmering:(BOOL)shimmering {
    self.qcxUI_shimmeringEnabled = shimmering;
    [self QcxUI_showWithText:text inView:view];
}

#pragma mark - Update Text / 刷新文字
- (void)QcxUI_updateText:(NSString *)text {
    if (self.superview) {
        [self relayoutWithText:text];
    }
}

#pragma mark - Dismiss / 移除
- (void)QcxUI_dismiss {
    if (self.superview) {
        [self hideAnimation];
    }
}

#pragma mark - Overlay / 遮罩
/**
 *  Add background overlay based on qcxUI_overlayType.
 *  按 qcxUI_overlayType 添加背景遮罩。
 */
- (void)applyOverlay {
    [self removeOverlay];
    switch (self.qcxUI_overlayType) {
        case QcxTextHUDOverlayTypeNone:
            // No overlay. 无遮罩，不处理
            break;

        case QcxTextHUDOverlayTypeBlur: {
            UIVisualEffectView *blurView = [[UIVisualEffectView alloc] initWithFrame:_targetView.bounds];
            blurView.effect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleExtraLight];
            _overlay = blurView;
            [_targetView addSubview:_overlay];
            break;
        }
        case QcxTextHUDOverlayTypeTransparent: {
            UIView *maskView = [[UIView alloc] initWithFrame:_targetView.bounds];
            maskView.backgroundColor = [UIColor blackColor];
            maskView.alpha = 0.25;
            _overlay = maskView;
            [_targetView addSubview:_overlay];
            break;
        }
        case QcxTextHUDOverlayTypeShadow:
            // Shadow is applied on the HUD itself; masksToBounds must be off.
            // 阴影作用于 HUD 自身，需关闭 masksToBounds
            self.layer.masksToBounds = NO;
            self.layer.shadowColor = [UIColor blackColor].CGColor;
            self.layer.shadowOffset = CGSizeMake(2.0, 2.0);
            self.layer.shadowOpacity = 0.5;
            break;
    }
}

/**
 *  Remove overlay and reset shadow state.
 *  移除遮罩并重置阴影状态。
 */
- (void)removeOverlay {
    if (_overlay != nil) {
        [_overlay removeFromSuperview];
        _overlay = nil;
    }
    self.layer.masksToBounds = YES;
    self.layer.shadowColor = [UIColor clearColor].CGColor;
    self.layer.shadowOffset = CGSizeMake(0, 0);
    self.layer.shadowOpacity = 0;
}

#pragma mark - Background Interaction / 背景交互屏蔽
/**
 *  Disable interaction on sibling views when requested.
 *  在需要时禁用同级视图交互。
 */
- (void)blockBackgroundInteraction {
    if (self.qcxUI_isTheOnlyActiveView && _targetView) {
        for (UIView *view in _targetView.subviews) {
            if (view != self && view != _overlay) {
                view.userInteractionEnabled = NO;
            }
        }
    }
}

/**
 *  Restore interaction on sibling views.
 *  恢复同级视图交互。
 */
- (void)restoreBackgroundInteraction {
    if (self.qcxUI_isTheOnlyActiveView && _targetView) {
        for (UIView *view in _targetView.subviews) {
            view.userInteractionEnabled = YES;
        }
    }
}

#pragma mark - Appear Animations / 入场动画
- (void)showAnimation {
    switch (self.qcxUI_appearAnimationType) {
        case QcxTextHUDAppearAnimationTypeSlideFromTop:
            [self showSlideFromTop];
            break;
        case QcxTextHUDAppearAnimationTypeSlideFromBottom:
            [self showSlideFromBottom];
            break;
        case QcxTextHUDAppearAnimationTypeSlideFromLeft:
            [self showSlideFromLeft];
            break;
        case QcxTextHUDAppearAnimationTypeSlideFromRight:
            [self showSlideFromRight];
            break;
        case QcxTextHUDAppearAnimationTypeZoomIn:
            [self showZoomIn];
            break;
        case QcxTextHUDAppearAnimationTypeFadeIn:
            [self showFadeIn];
            break;
    }
}

- (void)showFadeIn {
    self.alpha = 0.0;
    self.center = [self centerPoint];
    [UIView animateWithDuration:0.35 animations:^{
        self.alpha = 1.0;
    }];
}

- (void)showSlideFromTop {
    self.center = CGPointMake([self centerPoint].x, -CGRectGetHeight(self.bounds));
    [UIView animateWithDuration:0.4
                          delay:0
         usingSpringWithDamping:0.6
          initialSpringVelocity:1.0
                        options:UIViewAnimationOptionCurveEaseIn
                     animations:^{
        self.center = [self centerPoint];
    } completion:nil];
}

- (void)showSlideFromBottom {
    self.center = CGPointMake([self centerPoint].x, CGRectGetHeight(_targetView.bounds) + CGRectGetHeight(self.bounds));
    [UIView animateWithDuration:0.4
                          delay:0
         usingSpringWithDamping:0.6
          initialSpringVelocity:1.0
                        options:UIViewAnimationOptionCurveEaseInOut
                     animations:^{
        self.center = [self centerPoint];
    } completion:nil];
}

- (void)showSlideFromLeft {
    self.center = CGPointMake(-CGRectGetWidth(self.bounds), [self centerPoint].y);
    [UIView animateWithDuration:0.4
                          delay:0
         usingSpringWithDamping:0.6
          initialSpringVelocity:1.0
                        options:UIViewAnimationOptionCurveEaseInOut
                     animations:^{
        self.center = [self centerPoint];
    } completion:nil];
}

- (void)showSlideFromRight {
    self.center = CGPointMake(CGRectGetWidth(_targetView.bounds) + CGRectGetWidth(self.bounds), [self centerPoint].y);
    [UIView animateWithDuration:0.4
                          delay:0
         usingSpringWithDamping:0.6
          initialSpringVelocity:1.0
                        options:UIViewAnimationOptionCurveEaseInOut
                     animations:^{
        self.center = [self centerPoint];
    } completion:nil];
}

- (void)showZoomIn {
    self.center = [self centerPoint];
    self.transform = CGAffineTransformScale(CGAffineTransformIdentity, 0.001, 0.001);
    [UIView animateWithDuration:0.15 animations:^{
        self.transform = CGAffineTransformScale(CGAffineTransformIdentity, 1.1, 1.1);
    } completion:^(BOOL finished) {
        [UIView animateWithDuration:0.1 animations:^{
            self.transform = CGAffineTransformScale(CGAffineTransformIdentity, 0.9, 0.9);
        } completion:^(BOOL finished) {
            [UIView animateWithDuration:0.1 animations:^{
                self.transform = CGAffineTransformIdentity;
            }];
        }];
    }];
}

#pragma mark - Disappear Animations / 离场动画
- (void)hideAnimation {
    switch (self.qcxUI_disappearAnimationType) {
        case QcxTextHUDDisappearAnimationTypeSlideToTop:
            [self hideSlideToTop];
            break;
        case QcxTextHUDDisappearAnimationTypeSlideToBottom:
            [self hideSlideToBottom];
            break;
        case QcxTextHUDDisappearAnimationTypeSlideToLeft:
            [self hideSlideToLeft];
            break;
        case QcxTextHUDDisappearAnimationTypeSlideToRight:
            [self hideSlideToRight];
            break;
        case QcxTextHUDDisappearAnimationTypeZoomOut:
            [self hideZoomOut];
            break;
        case QcxTextHUDDisappearAnimationTypeFadeOut:
            [self hideFadeOut];
            break;
    }
}

- (void)hideFadeOut {
    CGFloat originalAlpha = self.alpha;
    [UIView animateWithDuration:0.35
                          delay:0
                        options:kNilOptions
                     animations:^{
        self.alpha = 0.0;
    } completion:^(BOOL finished) {
        self.alpha = originalAlpha;
        [self cleanupAfterHide];
    }];
}

- (void)hideSlideToTop {
    [UIView animateWithDuration:0.25
                          delay:0
                        options:UIViewAnimationOptionCurveEaseInOut
                     animations:^{
        self.center = CGPointMake([self centerPoint].x, -CGRectGetHeight(self.bounds));
    } completion:^(BOOL finished) {
        [self cleanupAfterHide];
    }];
}

- (void)hideSlideToBottom {
    [UIView animateWithDuration:0.25
                          delay:0
                        options:UIViewAnimationOptionCurveEaseInOut
                     animations:^{
        self.center = CGPointMake([self centerPoint].x, CGRectGetHeight(_targetView.bounds) + CGRectGetHeight(self.bounds));
    } completion:^(BOOL finished) {
        [self cleanupAfterHide];
    }];
}

- (void)hideSlideToLeft {
    [UIView animateWithDuration:0.15
                          delay:0
                        options:UIViewAnimationOptionCurveEaseInOut
                     animations:^{
        self.center = CGPointMake(-CGRectGetWidth(self.bounds), [self centerPoint].y);
    } completion:^(BOOL finished) {
        [self cleanupAfterHide];
    }];
}

- (void)hideSlideToRight {
    [UIView animateWithDuration:0.15
                          delay:0
                        options:UIViewAnimationOptionCurveEaseInOut
                     animations:^{
        self.center = CGPointMake(CGRectGetWidth(_targetView.bounds) + CGRectGetWidth(self.bounds), [self centerPoint].y);
    } completion:^(BOOL finished) {
        [self cleanupAfterHide];
    }];
}

- (void)hideZoomOut {
    [UIView animateWithDuration:0.15 animations:^{
        self.transform = CGAffineTransformScale(CGAffineTransformIdentity, 1.1, 1.1);
    } completion:^(BOOL finished) {
        [UIView animateWithDuration:0.1 animations:^{
            self.transform = CGAffineTransformScale(CGAffineTransformIdentity, 0.9, 0.9);
        } completion:^(BOOL finished) {
            [UIView animateWithDuration:0.1 animations:^{
                self.transform = CGAffineTransformScale(CGAffineTransformIdentity, 0.01, 0.01);
            } completion:^(BOOL finished) {
                [self cleanupAfterHide];
            }];
        }];
    }];
}

/**
 *  Cleanup after disappear animation finishes.
 *  离场动画完成后的清理。
 */
- (void)cleanupAfterHide {
    [self removeOverlay];
    [self restoreBackgroundInteraction];
    [self removeFromSuperview];
}

#pragma mark - Helpers / 工具类
/**
 *  Measure text, update layout, and optionally start shimmering.
 *  计算文字尺寸并刷新布局，必要时开启滑闪。
 */
- (void)relayoutWithText:(NSString *)text {
    _textLabel.text = text;
    CGRect rect = [text boundingRectWithSize:CGSizeMake(self.qcxUI_maxWidth, CGFLOAT_MAX)
                                     options:NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading
                                  attributes:@{NSFontAttributeName: _textLabel.font}
                                     context:nil];
    CGFloat width = ceil(rect.size.width) + self.qcxUI_horizontalPadding * 2;
    CGFloat height = ceil(rect.size.height) + self.qcxUI_verticalPadding * 2;

    self.bounds = CGRectMake(0, 0, width, height);
    _textLabel.frame = CGRectMake(self.qcxUI_horizontalPadding,
                                  self.qcxUI_verticalPadding,
                                  width - self.qcxUI_horizontalPadding * 2,
                                  height - self.qcxUI_verticalPadding * 2);
    self.center = [self centerPoint];

    // Clear residual mask so an old-size mask won't clip new text.
    // 文字滑闪效果：先清除可能残留的蒙层，避免旧尺寸蒙层裁剪文字
    _textLabel.layer.mask = nil;
    if (self.qcxUI_shimmeringEnabled) {
        [_textLabel QcxUI_shimmeringEffectStart];
    }
}

/**
 *  Center point inside the host view.
 *  目标视图中心点。
 */
- (CGPoint)centerPoint {
    return CGPointMake(CGRectGetMidX(_targetView.bounds), CGRectGetMidY(_targetView.bounds));
}

/**
 *  Prefer keyWindow; fall back to the last window.
 *  优先使用 keyWindow，否则回退到最后一个 window。
 */
- (UIView *)defaultSuperView {
    UIWindow *window = [UIApplication sharedApplication].keyWindow;
    if (!window) {
        window = [[UIApplication sharedApplication].windows lastObject];
    }
    return window;
}

#pragma mark - Class Methods (Singleton) / 类方法（基于单例）
+ (void)QcxUI_showWithText:(NSString *)text {
    [[QcxUI_TextHUD shared] QcxUI_showWithText:text];
}

+ (void)QcxUI_showWithText:(NSString *)text shimmering:(BOOL)shimmering {
    [[QcxUI_TextHUD shared] QcxUI_showWithText:text shimmering:shimmering];
}

+ (void)QcxUI_showWithText:(NSString *)text inView:(UIView *)view {
    [[QcxUI_TextHUD shared] QcxUI_showWithText:text inView:view];
}

+ (void)QcxUI_showWithText:(NSString *)text inView:(UIView *)view shimmering:(BOOL)shimmering {
    [[QcxUI_TextHUD shared] QcxUI_showWithText:text inView:view shimmering:shimmering];
}

+ (void)QcxUI_updateText:(NSString *)text {
    [[QcxUI_TextHUD shared] QcxUI_updateText:text];
}

+ (void)QcxUI_dismiss {
    [[QcxUI_TextHUD shared] QcxUI_dismiss];
}

@end
