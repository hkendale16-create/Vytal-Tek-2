//
//  QCSampleToast.m
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//

#import "QCSampleToast.h"

#define QCSampleToastDefaultDuration 1.2f
#define QCSampleToastDefaultOffset 100.0f
#define QCSampleToastBackgroundColor [UIColor colorWithRed:0.2 green:0.2 blue:0.2 alpha:0.75]

@interface QCSampleToast ()
@property (nonatomic, strong) UIButton *contentView;
@property (nonatomic, assign) CGFloat duration;
@end

@implementation QCSampleToast

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIDeviceOrientationDidChangeNotification object:[UIDevice currentDevice]];
}

- (instancetype)initWithText:(NSString *)text {
    self = [super init];
    if (self) {
        UIFont *font = [UIFont boldSystemFontOfSize:16];
        NSDictionary *attributes = @{NSFontAttributeName: font};
        CGRect rect = [text boundingRectWithSize:CGSizeMake(250, CGFLOAT_MAX)
                                         options:NSStringDrawingTruncatesLastVisibleLine | NSStringDrawingUsesFontLeading | NSStringDrawingUsesLineFragmentOrigin
                                      attributes:attributes
                                         context:nil];
        UILabel *textLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, rect.size.width + 40, rect.size.height + 20)];
        textLabel.backgroundColor = [UIColor clearColor];
        textLabel.textColor = [UIColor whiteColor];
        textLabel.textAlignment = NSTextAlignmentCenter;
        textLabel.font = font;
        textLabel.text = text;
        textLabel.numberOfLines = 0;

        _contentView = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, textLabel.frame.size.width, textLabel.frame.size.height)];
        _contentView.layer.cornerRadius = 20.0f;
        _contentView.backgroundColor = QCSampleToastBackgroundColor;
        [_contentView addSubview:textLabel];
        _contentView.autoresizingMask = UIViewAutoresizingFlexibleWidth;
        [_contentView addTarget:self action:@selector(toastTapped:) forControlEvents:UIControlEventTouchDown];
        _contentView.alpha = 0.0f;
        _duration = QCSampleToastDefaultDuration;
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(deviceOrientationDidChange:) name:UIDeviceOrientationDidChangeNotification object:[UIDevice currentDevice]];
    }
    return self;
}

- (void)deviceOrientationDidChange:(NSNotification *)notify {
    [self hideAnimation];
}

- (void)dismissToast {
    [self.contentView removeFromSuperview];
}

- (void)toastTapped:(UIButton *)sender {
    [self hideAnimation];
}

- (void)showAnimation {
    [UIView animateWithDuration:0.3 animations:^{
        self.contentView.alpha = 1.0f;
    }];
}

- (void)hideAnimation {
    [UIView animateWithDuration:0.3 delay:0 options:UIViewAnimationOptionCurveEaseOut animations:^{
        self.contentView.alpha = 0.0f;
    } completion:^(BOOL finished) {
        [self dismissToast];
    }];
}

- (void)showInWindowWithCenter:(CGPoint)center {
    UIWindow *window = UIApplication.sharedApplication.windows.lastObject;
    self.contentView.center = center;
    [window addSubview:self.contentView];
    [self showAnimation];
    [self performSelector:@selector(hideAnimation) withObject:nil afterDelay:self.duration];
}

- (void)show {
    UIWindow *window = UIApplication.sharedApplication.windows.lastObject;
    [self showInWindowWithCenter:window.center];
}

- (void)showFromTopOffset:(CGFloat)top {
    UIWindow *window = UIApplication.sharedApplication.windows.lastObject;
    [self showInWindowWithCenter:CGPointMake(window.center.x, top + self.contentView.frame.size.height / 2.0)];
}

- (void)showFromBottomOffset:(CGFloat)bottom {
    UIWindow *window = UIApplication.sharedApplication.windows.lastObject;
    [self showInWindowWithCenter:CGPointMake(window.center.x, window.frame.size.height - (bottom + self.contentView.frame.size.height / 2.0))];
}

+ (void)showCenterWithText:(NSString *)text {
    [self showCenterWithText:text duration:QCSampleToastDefaultDuration];
}

+ (void)showCenterWithText:(NSString *)text duration:(CGFloat)duration {
    QCSampleToast *toast = [[QCSampleToast alloc] initWithText:text];
    toast.duration = duration;
    [toast show];
}

+ (void)showTopWithText:(NSString *)text {
    [self showTopWithText:text topOffset:QCSampleToastDefaultOffset duration:QCSampleToastDefaultDuration];
}

+ (void)showTopWithText:(NSString *)text duration:(CGFloat)duration {
    [self showTopWithText:text topOffset:QCSampleToastDefaultOffset duration:duration];
}

+ (void)showTopWithText:(NSString *)text topOffset:(CGFloat)topOffset {
    [self showTopWithText:text topOffset:topOffset duration:QCSampleToastDefaultDuration];
}

+ (void)showTopWithText:(NSString *)text topOffset:(CGFloat)topOffset duration:(CGFloat)duration {
    QCSampleToast *toast = [[QCSampleToast alloc] initWithText:text];
    toast.duration = duration;
    [toast showFromTopOffset:topOffset];
}

+ (void)showBottomWithText:(NSString *)text {
    [self showBottomWithText:text bottomOffset:QCSampleToastDefaultOffset duration:QCSampleToastDefaultDuration];
}

+ (void)showBottomWithText:(NSString *)text duration:(CGFloat)duration {
    [self showBottomWithText:text bottomOffset:QCSampleToastDefaultOffset duration:duration];
}

+ (void)showBottomWithText:(NSString *)text bottomOffset:(CGFloat)bottomOffset {
    [self showBottomWithText:text bottomOffset:bottomOffset duration:QCSampleToastDefaultDuration];
}

+ (void)showBottomWithText:(NSString *)text bottomOffset:(CGFloat)bottomOffset duration:(CGFloat)duration {
    QCSampleToast *toast = [[QCSampleToast alloc] initWithText:text];
    toast.duration = duration;
    [toast showFromBottomOffset:bottomOffset];
}

@end
