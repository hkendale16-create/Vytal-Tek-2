//
//  QCSampleAdvancedViewController.m
//  QCBandSDKDemo
//
//  Created by zhong on 2026/8/5.
//
//  Advanced SDK sample.
//  高级 SDK 示例。
//

#import "QCSampleAdvancedViewController.h"
#import "QCSampleLocalization.h"
#import "QCSampleToast.h"
#import <QCBandSDK/QCSDKCmdCreator.h>
#import <QCBandSDK/QCDFU_Utils.h>
#import <QCBandSDK/QCMslPrayerModel.h>

#pragma mark - Value ranges / 传值范围

static const NSInteger kQCSampleBoolMin = 0;
static const NSInteger kQCSampleBoolMax = 1;
/// PXP delay is a 1-byte field.
/// 智能报警延迟为单字节字段。
static const NSInteger kQCSamplePxpDelayMin = 0;
static const NSInteger kQCSamplePxpDelayMax = 255;
/// Touch strength for enabling MSL praise mode.
/// 开启赞念触摸模式时的力度范围。
static const NSInteger kQCSampleTouchStrengthMin = 1;
static const NSInteger kQCSampleTouchStrengthMax = 10;

@interface QCSampleAdvancedViewController ()
@property (nonatomic, assign) BOOL lastAGPSEnable;
@property (nonatomic, assign) BOOL lastPxpOn;
@property (nonatomic, assign) NSInteger lastPxpDelay;
@property (nonatomic, assign) NSInteger lastTouchStrength;
@end

@implementation QCSampleAdvancedViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = QCSampleLocalized(QCSampleLocalizedKeyItemAdvanced);
    self.lastAGPSEnable = YES;
    self.lastPxpOn = YES;
    self.lastPxpDelay = 5;
    self.lastTouchStrength = 5;
}

- (void)setupActions {
    __weak typeof(self) weakSelf = self;
    
    [self beginActionSection:QCSampleLocalized(QCSampleLocalizedKeyAdvSectionAGPS)];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyAdvGetAGPS) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf getAGPS];
    }];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyAdvSetAGPS) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf presentSetAGPSAlert];
    }];
    
    [self beginActionSection:QCSampleLocalized(QCSampleLocalizedKeyAdvSectionIntell)];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyAdvGetIntell) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf getIntell];
    }];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyAdvSetIntell) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf presentSetIntellAlert];
    }];
    
    [self beginActionSection:QCSampleLocalized(QCSampleLocalizedKeyAdvSectionMuslim)];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyAdvGetMuslim) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf getMuslim];
    }];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyAdvSetMuslim) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf presentSetMuslimAlert];
    }];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyAdvGetPraise) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf getPraiseToday];
    }];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyAdvClearPraise) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf clearPraise];
    }];
    
    [self beginActionSection:QCSampleLocalized(QCSampleLocalizedKeyAdvSectionFeatures)];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyAdvGetSupport) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf getDeviceSupport];
    }];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyAdvGetFeatureConfig) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf getFeatureConfig];
    }];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyAdvGetPersonalization) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf getPersonalization];
    }];
    
    [self beginActionSection:QCSampleLocalized(QCSampleLocalizedKeyAdvSectionPower)];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyAdvShutdown) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf confirmHighRiskWithMessage:QCSampleLocalized(QCSampleLocalizedKeyAdvShutdownConfirm)
                                      action:^{ [weakSelf shutdownDevice]; }];
    }];
}

#pragma mark - AGPS

- (void)getAGPS {
    [self appendLogFormat:@"SDK getAGPSStatus hint=%@", self.lastAGPSEnable ? @"YES" : @"NO"];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator getAGPSStatusWithCurrentState:self.lastAGPSEnable success:^(BOOL enable) {
        weakSelf.lastAGPSEnable = enable;
        [weakSelf appendLogFormat:@"[AGPS] get success on=%@", enable ? @"YES" : @"NO"];
    } fail:^{
        [weakSelf appendLog:@"[AGPS] get failed (timeout / device may not support 0x30)"];
    }];
}

- (void)presentSetAGPSAlert {
    UIAlertController *alert =
    [UIAlertController alertControllerWithTitle:QCSampleLocalized(QCSampleLocalizedKeyAdvSetAGPS)
                                        message:nil
                                 preferredStyle:UIAlertControllerStyleAlert];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyAdvEnable)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyAdvBoolHint,
                                                        (long)kQCSampleBoolMin,
                                                        (long)kQCSampleBoolMax)
                           text:self.lastAGPSEnable ? 1 : 0];
    __weak typeof(self) weakSelf = self;
    [alert addAction:[UIAlertAction actionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyCommonCancel)
                                              style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyCommonOK)
                                              style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction *action) {
        NSInteger enable = alert.textFields.firstObject.text.integerValue;
        if (![weakSelf validateInputValue:enable min:kQCSampleBoolMin max:kQCSampleBoolMax
                               fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyAdvEnable)]) {
            return;
        }
        [weakSelf setAGPSOn:(enable == 1)];
    }]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)setAGPSOn:(BOOL)on {
    [self appendLogFormat:@"SDK setAGPSStatus %@", on ? @"YES" : @"NO"];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator setAGPSStatus:on success:^(BOOL enable) {
        weakSelf.lastAGPSEnable = enable;
        [weakSelf appendLogFormat:@"[AGPS] set success on=%@", enable ? @"YES" : @"NO"];
    } fail:^{
        [weakSelf appendLog:@"[AGPS] set failed (timeout / device may not support 0x30)"];
    }];
}

#pragma mark - Intell / PXP

- (void)getIntell {
    [self appendLog:@"SDK getPxpAlarmDelay"];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator getPxpAlarmDelay:^(BOOL featureOn, NSInteger delaySeconds) {
        weakSelf.lastPxpOn = featureOn;
        weakSelf.lastPxpDelay = delaySeconds;
        [weakSelf appendLogFormat:@"[Intell] get success on=%@ delay=%ld",
         featureOn ? @"YES" : @"NO", (long)delaySeconds];
    } fail:^{
        [weakSelf appendLog:@"[Intell] get failed (timeout / device may not support 0x09 PXP)"];
    }];
}

- (void)presentSetIntellAlert {
    UIAlertController *alert =
    [UIAlertController alertControllerWithTitle:QCSampleLocalized(QCSampleLocalizedKeyAdvSetIntell)
                                        message:nil
                                 preferredStyle:UIAlertControllerStyleAlert];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyAdvEnable)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyAdvBoolHint,
                                                        (long)kQCSampleBoolMin,
                                                        (long)kQCSampleBoolMax)
                           text:self.lastPxpOn ? 1 : 0];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyAdvPxpDelay)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyAdvPxpDelayHint,
                                                        (long)kQCSamplePxpDelayMin,
                                                        (long)kQCSamplePxpDelayMax)
                           text:self.lastPxpDelay];
    __weak typeof(self) weakSelf = self;
    [alert addAction:[UIAlertAction actionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyCommonCancel)
                                              style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyCommonOK)
                                              style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction *action) {
        NSInteger on = alert.textFields[0].text.integerValue;
        NSInteger delay = alert.textFields[1].text.integerValue;
        if (![weakSelf validateInputValue:on min:kQCSampleBoolMin max:kQCSampleBoolMax
                               fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyAdvEnable)] ||
            ![weakSelf validateInputValue:delay min:kQCSamplePxpDelayMin max:kQCSamplePxpDelayMax
                               fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyAdvPxpDelay)]) {
            return;
        }
        [weakSelf setIntellOn:(on == 1) delay:delay];
    }]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)setIntellOn:(BOOL)on delay:(NSInteger)delay {
    [self appendLogFormat:@"SDK setPxpAlarmDelay on=%@ delay=%ld", on ? @"YES" : @"NO", (long)delay];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator setPxpAlarmDelay:on delaySeconds:delay success:^(BOOL featureOn, NSInteger realDelay) {
        weakSelf.lastPxpOn = featureOn;
        weakSelf.lastPxpDelay = realDelay;
        [weakSelf appendLogFormat:@"[Intell] set success on=%@ delay=%ld",
         featureOn ? @"YES" : @"NO", (long)realDelay];
    } fail:^{
        [weakSelf appendLog:@"[Intell] set failed (timeout / device may not support 0x09 PXP)"];
    }];
}

#pragma mark - Muslim / MSL Praise

- (void)getMuslim {
    [self appendLog:@"SDK getTouchControlFinshed"];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator getTouchControlFinshed:^(QCTouchGestureControlType type,
                                              NSInteger strength,
                                              BOOL sleeping,
                                              NSInteger duration,
                                              NSError * _Nullable error) {
        if (error) {
            [weakSelf appendLogFormat:@"[Muslim] get failed error=%@", error.localizedDescription ?: @"unknown"];
            return;
        }
        weakSelf.lastTouchStrength = strength > 0 ? strength : weakSelf.lastTouchStrength;
        [weakSelf appendLogFormat:@"[Muslim] get success type=%ld strength=%ld sleeping=%@ duration=%ld",
         (long)type, (long)strength, sleeping ? @"YES" : @"NO", (long)duration];
    }];
}

- (void)presentSetMuslimAlert {
    UIAlertController *alert =
    [UIAlertController alertControllerWithTitle:QCSampleLocalized(QCSampleLocalizedKeyAdvSetMuslim)
                                        message:nil
                                 preferredStyle:UIAlertControllerStyleAlert];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyAdvEnable)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyAdvBoolHint,
                                                        (long)kQCSampleBoolMin,
                                                        (long)kQCSampleBoolMax)
                           text:1];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyAdvTouchStrength)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyAdvTouchStrengthHint,
                                                        (long)kQCSampleTouchStrengthMin,
                                                        (long)kQCSampleTouchStrengthMax)
                           text:self.lastTouchStrength];
    __weak typeof(self) weakSelf = self;
    [alert addAction:[UIAlertAction actionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyCommonCancel)
                                              style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyCommonOK)
                                              style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction *action) {
        NSInteger enable = alert.textFields[0].text.integerValue;
        NSInteger strength = alert.textFields[1].text.integerValue;
        if (![weakSelf validateInputValue:enable min:kQCSampleBoolMin max:kQCSampleBoolMax
                               fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyAdvEnable)] ||
            ![weakSelf validateInputValue:strength min:kQCSampleTouchStrengthMin max:kQCSampleTouchStrengthMax
                               fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyAdvTouchStrength)]) {
            return;
        }
        [weakSelf setMuslimOn:(enable == 1) strength:strength];
    }]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)setMuslimOn:(BOOL)on strength:(NSInteger)strength {
    QCTouchGestureControlType type = on ? QCTouchGestureControlTypeMSLPraise : QCTouchGestureControlTypeOff;
    self.lastTouchStrength = strength;
    [self appendLogFormat:@"SDK setTouchControl type=%ld strength=%ld duration=3", (long)type, (long)strength];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator setTouchControl:type strength:strength duration:3 finshed:^(NSError * _Nullable error) {
        if (error) {
            [weakSelf appendLogFormat:@"[Muslim] set failed error=%@", error.localizedDescription ?: @"unknown"];
            return;
        }
        [weakSelf appendLogFormat:@"[Muslim] set success on=%@", on ? @"YES" : @"NO"];
    }];
}

- (void)getPraiseToday {
    [self appendLog:@"SDK getPraiseDataByDayIndexs @[0]"];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator getPraiseDataByDayIndexs:@[@0] finished:^(NSArray * _Nullable praiseList, NSError * _Nullable error) {
        if (error) {
            [weakSelf appendLogFormat:@"[Praise] get failed error=%@", error.localizedDescription ?: @"unknown"];
            return;
        }
        NSInteger dayCount = praiseList.count;
        NSInteger sampleCount = 0;
        if ([praiseList.firstObject isKindOfClass:[QCMslPrayerModel class]]) {
            sampleCount = ((QCMslPrayerModel *)praiseList.firstObject).counts.count;
        }
        [weakSelf appendLogFormat:@"[Praise] get success days=%ld samples=%ld", (long)dayCount, (long)sampleCount];
    }];
}

- (void)clearPraise {
    [self appendLog:@"SDK clearPraiseDataWithSuccess"];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator clearPraiseDataWithSuccess:^{
        [weakSelf appendLog:@"[Praise] clear success"];
    } fail:^{
        [weakSelf appendLog:@"[Praise] clear failed"];
    }];
}

#pragma mark - Features / Personalization

- (void)getDeviceSupport {
    [self appendLog:@"SDK setTime (read featureList)"];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator setTime:[NSDate date] success:^(NSDictionary *featureList) {
        [weakSelf appendLogFormat:@"[Support] setTime success keys=%lu %@",
         (unsigned long)featureList.count,
         [weakSelf featureSummary:featureList]];
    } failed:^{
        [weakSelf appendLog:@"[Support] setTime failed"];
    }];
}

- (void)getFeatureConfig {
    [self appendLog:@"SDK getDeviceFeatureConfigSuccess"];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator getDeviceFeatureConfigSuccess:^(NSDictionary *featureList) {
        [weakSelf appendLogFormat:@"[FeatureConfig] success keys=%lu %@",
         (unsigned long)featureList.count,
         [weakSelf featureSummary:featureList]];
    } fail:^{
        [weakSelf appendLog:@"[FeatureConfig] failed"];
    }];
}

- (void)getPersonalization {
    NSArray<NSNumber *> *uiTypes = @[
        @(ODM_RES_UIType_StandBy),
        @(ODM_RES_UIType_Boot),
        @(ODM_RES_UIType_ShutDown)
    ];
    [self appendLog:@"SDK getResourceWithUITypes standby/boot/shutdown"];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator getResourceWithUITypes:uiTypes success:^(NSArray<NSNumber *> *resourceTypes) {
        [weakSelf appendLogFormat:@"[Personalization] success types=%@",
         [resourceTypes componentsJoinedByString:@","] ?: @""];
    } fail:^{
        [weakSelf appendLog:@"[Personalization] failed (timeout / device may not support 0x17 resource)"];
    }];
}

- (NSString *)featureSummary:(NSDictionary *)featureList {
    if (featureList.count == 0) { return @"(empty)"; }
    NSArray *keys = [[featureList allKeys] sortedArrayUsingSelector:@selector(compare:)];
    NSMutableArray<NSString *> *parts = [NSMutableArray array];
    NSInteger limit = MIN((NSInteger)keys.count, 12);
    for (NSInteger i = 0; i < limit; i++) {
        NSString *key = keys[i];
        [parts addObject:[NSString stringWithFormat:@"%@=%@", key, featureList[key]]];
    }
    if ((NSInteger)keys.count > limit) {
        [parts addObject:[NSString stringWithFormat:@"…(+%ld)", (long)(keys.count - limit)]];
    }
    return [parts componentsJoinedByString:@" "];
}

#pragma mark - Power

- (void)confirmHighRiskWithMessage:(NSString *)message action:(dispatch_block_t)action {
    UIAlertController *alert =
    [UIAlertController alertControllerWithTitle:QCSampleLocalized(QCSampleLocalizedKeyAdvHighRiskTitle)
                                        message:message
                                 preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyCommonCancel)
                                              style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyAdvHighRiskConfirm)
                                              style:UIAlertActionStyleDestructive
                                            handler:^(UIAlertAction *alertAction) {
        if (action) { action(); }
    }]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)shutdownDevice {
    [self appendLog:@"SDK shutDownSuccess"];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator shutDownSuccess:^{
        [weakSelf appendLog:@"[Power] shutdown success"];
        [QCSampleToast showCenterWithText:QCSampleLocalized(QCSampleLocalizedKeyAdvShutdownSuccess)];
    } fail:^{
        [weakSelf appendLog:@"[Power] shutdown failed"];
    }];
}

@end
