//
//  QCSampleDeviceStatusHeaderView.m
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//

#import "QCSampleDeviceStatusHeaderView.h"
#import "QCSampleLocalization.h"

static CGFloat const kQCSampleStatusHorizontalPadding = 16.0;
static CGFloat const kQCSampleStatusVerticalPadding = 12.0;
static CGFloat const kQCSampleStatusInfoLineSpacing = 8.0;

@interface QCSampleDeviceStatusHeaderView ()

@property (nonatomic, strong) UILabel *deviceNameLabel;
@property (nonatomic, strong) UILabel *bluetoothStatusLabel;
@property (nonatomic, strong) UILabel *macAddressLabel;
@property (nonatomic, strong) UILabel *batteryLabel;
@property (nonatomic, strong) UILabel *firmwareLabel;
@property (nonatomic, copy) NSArray<UILabel *> *infoLabels;

@end

@implementation QCSampleDeviceStatusHeaderView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor whiteColor];

        _deviceNameLabel = [self makeInfoLabel];
        _bluetoothStatusLabel = [self makeInfoLabel];
        _macAddressLabel = [self makeInfoLabel];
        _batteryLabel = [self makeInfoLabel];
        _firmwareLabel = [self makeInfoLabel];
        _infoLabels = @[_deviceNameLabel, _bluetoothStatusLabel, _macAddressLabel, _batteryLabel, _firmwareLabel];
    }
    return self;
}

- (UILabel *)makeInfoLabel {
    UILabel *label = [[UILabel alloc] init];
    label.font = [UIFont systemFontOfSize:14.0];
    label.textColor = [UIColor darkGrayColor];
    label.numberOfLines = 0;
    [self addSubview:label];
    return label;
}

+ (NSString *)displayTextForKey:(NSString *)key value:(NSString *)value {
    return QCSampleLocalizedFormat(key, value.length > 0 ? value : @"--");
}

- (void)layoutSubviews {
    [super layoutSubviews];

    CGFloat width = CGRectGetWidth(self.bounds);
    CGFloat contentWidth = width - kQCSampleStatusHorizontalPadding * 2.0;
    CGFloat y = kQCSampleStatusVerticalPadding;

    for (UILabel *label in self.infoLabels) {
        CGFloat lineHeight = [label sizeThatFits:CGSizeMake(contentWidth, CGFLOAT_MAX)].height;
        label.frame = CGRectMake(kQCSampleStatusHorizontalPadding, y, contentWidth, lineHeight);
        y = CGRectGetMaxY(label.frame) + kQCSampleStatusInfoLineSpacing;
    }
}

- (void)configureWithStatus:(QCSampleDeviceStatus *)status {
    self.deviceNameLabel.text = [QCSampleDeviceStatusHeaderView displayTextForKey:QCSampleLocalizedKeyHeaderDeviceName
                                                                             value:status.deviceName];
    self.bluetoothStatusLabel.text = [QCSampleDeviceStatusHeaderView displayTextForKey:QCSampleLocalizedKeyHeaderBluetoothStatus
                                                                                 value:status.bluetoothStatusText];
    self.bluetoothStatusLabel.textColor = [self colorForConnectionState:status.connectionState];
    self.macAddressLabel.text = [QCSampleDeviceStatusHeaderView displayTextForKey:QCSampleLocalizedKeyHeaderMacAddress
                                                                            value:status.macAddress];
    self.batteryLabel.text = [QCSampleDeviceStatusHeaderView displayTextForKey:QCSampleLocalizedKeyHeaderBattery
                                                                         value:status.batteryText];
    self.firmwareLabel.text = [QCSampleDeviceStatusHeaderView displayTextForKey:QCSampleLocalizedKeyHeaderFirmwareVersion
                                                                            value:status.firmwareVersion];
    [self setNeedsLayout];
}

- (UIColor *)colorForConnectionState:(QCSampleConnectionPresentation)state {
    switch (state) {
        case QCSampleConnectionPresentationConnected:
            return [UIColor colorWithRed:0.18 green:0.67 blue:0.34 alpha:1.0];
        case QCSampleConnectionPresentationConnecting:
            return [UIColor colorWithRed:0.95 green:0.61 blue:0.07 alpha:1.0];
        case QCSampleConnectionPresentationDisconnected:
        default:
            return [UIColor colorWithRed:0.86 green:0.24 blue:0.24 alpha:1.0];
    }
}

+ (CGFloat)preferredHeightForStatus:(QCSampleDeviceStatus *)status width:(CGFloat)width {
    CGFloat contentWidth = width - kQCSampleStatusHorizontalPadding * 2.0;
    CGFloat height = kQCSampleStatusVerticalPadding;

    UIFont *infoFont = [UIFont systemFontOfSize:14.0];
    NSArray<NSString *> *lines = @[
        [self displayTextForKey:QCSampleLocalizedKeyHeaderDeviceName value:status.deviceName],
        [self displayTextForKey:QCSampleLocalizedKeyHeaderBluetoothStatus value:status.bluetoothStatusText],
        [self displayTextForKey:QCSampleLocalizedKeyHeaderMacAddress value:status.macAddress],
        [self displayTextForKey:QCSampleLocalizedKeyHeaderBattery value:status.batteryText],
        [self displayTextForKey:QCSampleLocalizedKeyHeaderFirmwareVersion value:status.firmwareVersion]
    ];

    for (NSString *line in lines) {
        CGRect rect = [line boundingRectWithSize:CGSizeMake(contentWidth, CGFLOAT_MAX)
                                           options:NSStringDrawingUsesLineFragmentOrigin
                                        attributes:@{NSFontAttributeName: infoFont}
                                           context:nil];
        height += ceil(rect.size.height) + kQCSampleStatusInfoLineSpacing;
    }

    height += kQCSampleStatusVerticalPadding - kQCSampleStatusInfoLineSpacing;
    return height;
}

@end
