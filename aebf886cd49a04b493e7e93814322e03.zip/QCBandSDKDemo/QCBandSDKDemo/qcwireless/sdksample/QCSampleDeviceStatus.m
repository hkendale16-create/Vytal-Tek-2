//
//  QCSampleDeviceStatus.m
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//

#import "QCSampleDeviceStatus.h"
#import "QCSampleLocalization.h"
#import <QCBandSDK/QCSDKCmdCreator.h>
#import <QCBandSDK/QCSDKManager.h>

static NSString * const kQCSamplePlaceholderText = @"--";

@interface QCSampleDeviceStatus ()
@property (nonatomic, copy, readwrite) NSString *deviceName;
@property (nonatomic, copy, readwrite) NSString *bluetoothStatusText;
@property (nonatomic, assign, readwrite) QCSampleConnectionPresentation connectionState;
@property (nonatomic, copy, readwrite) NSString *macAddress;
@property (nonatomic, copy, readwrite) NSString *batteryText;
@property (nonatomic, copy, readwrite) NSString *firmwareVersion;
@end

@implementation QCSampleDeviceStatus

- (BOOL)isConnected {
    return self.connectionState == QCSampleConnectionPresentationConnected;
}

@end

@interface QCSampleDeviceStatusProvider ()
@property (nonatomic, strong, readwrite) QCSampleDeviceStatus *currentStatus;
@property (nonatomic, strong) NSHashTable<id<QCSampleDeviceStatusObserver>> *observers;
@property (nonatomic, assign) BOOL isRefreshingDeviceInfo;
@end

@implementation QCSampleDeviceStatusProvider

+ (instancetype)shared {
    static QCSampleDeviceStatusProvider *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[QCSampleDeviceStatusProvider alloc] init];
    });
    return instance;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        _observers = [NSHashTable weakObjectsHashTable];
        _currentStatus = [self buildStatusForDeviceState:[QCCentralManager shared].deviceState];
        [self registerBatteryNotification];
    }
    return self;
}

#pragma mark - SDK Samples (integrators can copy these calls)

/// Refreshes device info after connection. SDK commands must be sent serially, not in parallel. 连接成功后刷新设备信息。SDK 指令需串行下发，不可并行。
- (void)refreshConnectedDeviceInfo {
    if (!self.currentStatus.isConnected || self.isRefreshingDeviceInfo) {
        return;
    }
    self.isRefreshingDeviceInfo = YES;

    __weak typeof(self) weakSelf = self;

    // 1) Sync device time first after connection. 连接成功后先同步时间（SetTime）
    // [QCSDKCmdCreator setTime:[NSDate date] success:^(NSDictionary *featureList) { ... } failed:^{ ... }];
    [QCSDKCmdCreator setTime:[NSDate date] success:^(NSDictionary *featureList) {
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf) {
            return;
        }
        [strongSelf fetchMacAddressThenBatteryThenFirmware];
    } failed:^{
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf) {
            return;
        }
        [strongSelf fetchMacAddressThenBatteryThenFirmware];
    }];
}

- (void)fetchMacAddressThenBatteryThenFirmware {
    __weak typeof(self) weakSelf = self;

    // 2) 读取 Mac 地址
    // [QCSDKCmdCreator getDeviceMacAddressSuccess:^(NSString *macAddress) { ... } fail:^{ ... }];
    [QCSDKCmdCreator getDeviceMacAddressSuccess:^(NSString *macAddress) {
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf) {
            return;
        }
        if (macAddress.length > 0) {
            strongSelf.currentStatus.macAddress = macAddress;
        }
        [strongSelf fetchBatteryThenFirmware];
    } fail:^{
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf) {
            return;
        }
        [strongSelf fetchBatteryThenFirmware];
    }];
}

- (void)fetchBatteryThenFirmware {
    __weak typeof(self) weakSelf = self;

    // 3) 读取电量（也可监听实时推送，见 registerBatteryNotification）
    // [QCSDKCmdCreator readBatterySuccess:^(int battery, BOOL charging) { ... } failed:^{ ... }];
    [QCSDKCmdCreator readBatterySuccess:^(int level, BOOL charging) {
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf) {
            return;
        }
        strongSelf.currentStatus.batteryText = [strongSelf batteryTextWithLevel:level charging:charging];
        [strongSelf fetchFirmwareVersion];
    } failed:^{
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf) {
            return;
        }
        [strongSelf fetchFirmwareVersion];
    }];
}

- (void)fetchFirmwareVersion {
    __weak typeof(self) weakSelf = self;

    // 4) 读取软硬件版本（softVersion 即固件版本）
    // [QCSDKCmdCreator getDeviceSoftAndHardVersionSuccess:^(NSString *hardVersion, NSString *softVersion) { ... } fail:^{ ... }];
    [QCSDKCmdCreator getDeviceSoftAndHardVersionSuccess:^(NSString *hardVersion, NSString *softVersion) {
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf) {
            return;
        }
        if (softVersion.length > 0) {
            strongSelf.currentStatus.firmwareVersion = softVersion;
        } else if (hardVersion.length > 0) {
            strongSelf.currentStatus.firmwareVersion = hardVersion;
        }
        [strongSelf finishRefreshingDeviceInfo];
    } fail:^{
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf) {
            return;
        }
        [strongSelf finishRefreshingDeviceInfo];
    }];
}

- (void)registerBatteryNotification {
    __weak typeof(self) weakSelf = self;

    // 5) 订阅设备主动上报的电量变化（与 ViewController.m 同款写法）
    // [QCSDKManager shareInstance].currentBatteryInfo = ^(NSInteger battery, BOOL charging) { ... };
    [QCSDKManager shareInstance].currentBatteryInfo = ^(NSInteger battery, BOOL charging) {
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf || !strongSelf.currentStatus.isConnected) {
            return;
        }
        strongSelf.currentStatus.batteryText = [strongSelf batteryTextWithLevel:(int)battery charging:charging];
        [strongSelf notifyObservers];
    };
}

- (NSString *)batteryTextWithLevel:(int)level charging:(BOOL)charging {
    if (charging) {
        return QCSampleLocalizedFormat(QCSampleLocalizedKeyStatusBatteryCharging, level);
    }
    return QCSampleLocalizedFormat(QCSampleLocalizedKeyStatusBatteryNormal, level);
}

- (void)finishRefreshingDeviceInfo {
    self.isRefreshingDeviceInfo = NO;
    [self notifyObservers];
}

- (void)addObserver:(id<QCSampleDeviceStatusObserver>)observer {
    if (!observer) {
        return;
    }
    [self.observers addObject:observer];
}

- (void)removeObserver:(id<QCSampleDeviceStatusObserver>)observer {
    if (!observer) {
        return;
    }
    [self.observers removeObject:observer];
}

- (void)updateForDeviceState:(QCState)state {
    [self didState:state];
}

#pragma mark - QCCentralManagerDelegate

- (void)didState:(QCState)state {
    self.currentStatus = [self buildStatusForDeviceState:state];
    [self notifyObservers];

    if (self.currentStatus.isConnected) {
        [self refreshConnectedDeviceInfo];
    }
}

#pragma mark - Private

- (QCSampleDeviceStatus *)buildStatusForDeviceState:(QCState)state {
    QCSampleDeviceStatus *status = [[QCSampleDeviceStatus alloc] init];

    CBPeripheral *peripheral = [QCCentralManager shared].connectedPeripheral;
    switch (state) {
        case QCStateConnected:
            status.connectionState = QCSampleConnectionPresentationConnected;
            status.bluetoothStatusText = QCSampleLocalized(QCSampleLocalizedKeyStatusConnected);
            status.deviceName = peripheral.name.length > 0 ? peripheral.name : kQCSamplePlaceholderText;
            status.macAddress = kQCSamplePlaceholderText;
            status.batteryText = kQCSamplePlaceholderText;
            status.firmwareVersion = kQCSamplePlaceholderText;
            break;
        case QCStateConnecting:
            status.connectionState = QCSampleConnectionPresentationConnecting;
            status.bluetoothStatusText = QCSampleLocalized(QCSampleLocalizedKeyStatusConnecting);
            status.deviceName = peripheral.name.length > 0 ? peripheral.name : kQCSamplePlaceholderText;
            status.macAddress = kQCSamplePlaceholderText;
            status.batteryText = kQCSamplePlaceholderText;
            status.firmwareVersion = kQCSamplePlaceholderText;
            break;
        default:
            status.connectionState = QCSampleConnectionPresentationDisconnected;
            status.bluetoothStatusText = QCSampleLocalized(QCSampleLocalizedKeyStatusDisconnected);
            status.deviceName = kQCSamplePlaceholderText;
            status.macAddress = kQCSamplePlaceholderText;
            status.batteryText = kQCSamplePlaceholderText;
            status.firmwareVersion = kQCSamplePlaceholderText;
            break;
    }
    return status;
}

- (void)notifyObservers {
    for (id<QCSampleDeviceStatusObserver> observer in self.observers.allObjects) {
        [observer deviceStatusDidChange:self.currentStatus];
    }
}

@end
