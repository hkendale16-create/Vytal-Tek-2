//
//  QCSampleLocalization.m
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//

#import "QCSampleLocalization.h"

NSString * const QCSampleLocalizedKeyHomeSectionConnect = @"home.section.connect";
NSString * const QCSampleLocalizedKeyHomeSectionSettings = @"home.section.settings";
NSString * const QCSampleLocalizedKeyHomeSectionFirmware = @"home.section.firmware";

NSString * const QCSampleLocalizedKeyItemScan = @"home.item.scan";
NSString * const QCSampleLocalizedKeyItemReconnect = @"home.item.reconnect";
NSString * const QCSampleLocalizedKeyItemDisconnect = @"home.item.disconnect";
NSString * const QCSampleLocalizedKeyItemUnbind = @"home.item.unbind";
NSString * const QCSampleLocalizedKeyItemFindDevice = @"home.item.find_device";
NSString * const QCSampleLocalizedKeyItemHealthSettings = @"home.item.health_settings";
NSString * const QCSampleLocalizedKeyItemGoalsProfile = @"home.item.goals_profile";
NSString * const QCSampleLocalizedKeyItemDisplay = @"home.item.display";
NSString * const QCSampleLocalizedKeyItemDevice = @"home.item.device";
NSString * const QCSampleLocalizedKeyItemNotifications = @"home.item.notifications";
NSString * const QCSampleLocalizedKeyItemTouchGestures = @"home.item.touch_gestures";
NSString * const QCSampleLocalizedKeyItemAdvanced = @"home.item.advanced";
NSString * const QCSampleLocalizedKeyItemFirmwareBLE = @"home.item.firmware_ble";
NSString * const QCSampleLocalizedKeyItemResourceUpdate = @"home.item.resource_update";

NSString * const QCSampleLocalizedKeyStatusConnected = @"status.connected";
NSString * const QCSampleLocalizedKeyStatusConnecting = @"status.connecting";
NSString * const QCSampleLocalizedKeyStatusDisconnected = @"status.disconnected";
NSString * const QCSampleLocalizedKeyStatusBatteryNormal = @"status.battery_normal";
NSString * const QCSampleLocalizedKeyStatusBatteryCharging = @"status.battery_charging";

NSString * const QCSampleLocalizedKeyHeaderDeviceName = @"header.device_name";
NSString * const QCSampleLocalizedKeyHeaderBluetoothStatus = @"header.bluetooth_status";
NSString * const QCSampleLocalizedKeyHeaderMacAddress = @"header.mac_address";
NSString * const QCSampleLocalizedKeyHeaderBattery = @"header.battery";
NSString * const QCSampleLocalizedKeyHeaderFirmwareVersion = @"header.firmware_version";

NSString * const QCSampleLocalizedKeyToastPageNotFound = @"toast.page_not_found";
NSString * const QCSampleLocalizedKeyToastDisconnectStarted = @"toast.disconnect_started";
NSString * const QCSampleLocalizedKeyToastUnbindDone = @"toast.unbind_done";
NSString * const QCSampleLocalizedKeyToastFindDeviceSent = @"toast.find_device_sent";
NSString * const QCSampleLocalizedKeyToastFindDeviceFailed = @"toast.find_device_failed";
NSString * const QCSampleLocalizedKeyScanFilterPlaceholder = @"scan.filter_placeholder";
NSString * const QCSampleLocalizedKeyScanStartButton = @"scan.start_button";
NSString * const QCSampleLocalizedKeyScanConnecting = @"scan.connecting";

NSString * const QCSampleLocalizedKeyHealthBatchSync = @"health.batch_sync";
NSString * const QCSampleLocalizedKeyHealthActivitySteps = @"health.activity_steps";
NSString * const QCSampleLocalizedKeyHealthSleep = @"health.sleep";
NSString * const QCSampleLocalizedKeyHealthSleepFromDay = @"health.sleep_from_day";
NSString * const QCSampleLocalizedKeyHealthSportRecords = @"health.sport_records";
NSString * const QCSampleLocalizedKeyHealthHeartRate = @"health.heart_rate";
NSString * const QCSampleLocalizedKeyHealthBloodPressure = @"health.blood_pressure";
NSString * const QCSampleLocalizedKeyHealthBloodOxygen = @"health.blood_oxygen";
NSString * const QCSampleLocalizedKeyHealthHRV = @"health.hrv";
NSString * const QCSampleLocalizedKeyHealthStress = @"health.stress";
NSString * const QCSampleLocalizedKeyHealthBodyTemperature = @"health.body_temperature";
NSString * const QCSampleLocalizedKeyHealthBloodGlucoseLipids = @"health.blood_glucose_lipids";
NSString * const QCSampleLocalizedKeyHealthEmotion = @"health.emotion";
NSString * const QCSampleLocalizedKeyHealthWaterReminder = @"health.water_reminder";
NSString * const QCSampleLocalizedKeyHealthSedentaryReminder = @"health.sedentary_reminder";
NSString * const QCSampleLocalizedKeyHealthCopyLog = @"health.copy_log";
NSString * const QCSampleLocalizedKeyHealthCopySuccess = @"health.copy_success";
NSString * const QCSampleLocalizedKeyHealthCopyEmpty = @"health.copy_empty";
NSString * const QCSampleLocalizedKeyHealthClearLog = @"health.clear_log";
NSString * const QCSampleLocalizedKeyHealthRunning = @"health.running";
NSString * const QCSampleLocalizedKeyHealthFinished = @"health.finished";
NSString * const QCSampleLocalizedKeyHealthBatchSyncDone = @"health.batch_sync_done";
NSString * const QCSampleLocalizedKeyHealthSampleMethod = @"health.sample_method";
NSString * const QCSampleLocalizedKeyHealthAPIReference = @"health.api_reference";
NSString * const QCSampleLocalizedKeyHealthQueryToday = @"health.query_today";
NSString * const QCSampleLocalizedKeyHealthQuerySingleDay = @"health.query_single_day";
NSString * const QCSampleLocalizedKeyHealthQueryDayRange = @"health.query_day_range";
NSString * const QCSampleLocalizedKeyHealthQueryDayIndexTitle = @"health.query_day_index_title";
NSString * const QCSampleLocalizedKeyHealthQueryStartDayTitle = @"health.query_start_day_title";
NSString * const QCSampleLocalizedKeyHealthQueryCountTitle = @"health.query_count_title";
NSString * const QCSampleLocalizedKeyHealthQueryDayIndexHint = @"health.query_day_index_hint";
NSString * const QCSampleLocalizedKeyInputOutOfRange = @"input.out_of_range";
NSString * const QCSampleLocalizedKeyHealthActivityScoreAgeField = @"health.activity_score_age_field";
NSString * const QCSampleLocalizedKeyHealthQueryStartDayHint = @"health.query_start_day_hint";
NSString * const QCSampleLocalizedKeyHealthQueryCountHint = @"health.query_count_hint";
NSString * const QCSampleLocalizedKeyHealthQueryInvalidNumber = @"health.query_invalid_number";
NSString * const QCSampleLocalizedKeyHealthActionsSection = @"health.actions_section";
NSString * const QCSampleLocalizedKeyHealthLogSection = @"health.log_section";
NSString * const QCSampleLocalizedKeyHealthNotConnected = @"health.not_connected";
NSString * const QCSampleLocalizedKeyHealthSwitchOn = @"health.switch_on";
NSString * const QCSampleLocalizedKeyHealthSwitchOff = @"health.switch_off";
NSString * const QCSampleLocalizedKeyHealthSwitchReading = @"health.switch_reading";
NSString * const QCSampleLocalizedKeyHealthSwitchUpdating = @"health.switch_updating";
NSString * const QCSampleLocalizedKeyHealthSwitchReadFailed = @"health.switch_read_failed";
NSString * const QCSampleLocalizedKeyHealthSwitchUpdateFailed = @"health.switch_update_failed";
NSString * const QCSampleLocalizedKeyHealthSwitchUnsupported = @"health.switch_unsupported";
NSString * const QCSampleLocalizedKeyHealthHRSwitch = @"health.hr_switch";
NSString * const QCSampleLocalizedKeyHealthRRISwitch = @"health.rri_switch";
NSString * const QCSampleLocalizedKeyHealthBPSwitch = @"health.bp_switch";
NSString * const QCSampleLocalizedKeyHealthBOSwitch = @"health.bo_switch";
NSString * const QCSampleLocalizedKeyHealthHRVSwitch = @"health.hrv_switch";
NSString * const QCSampleLocalizedKeyHealthStressSwitch = @"health.stress_switch";
NSString * const QCSampleLocalizedKeyHealthEmotionSwitch = @"health.emotion_switch";
NSString * const QCSampleLocalizedKeyHealthTemperatureSwitch = @"health.temperature_switch";
NSString * const QCSampleLocalizedKeyHealthSyncTodaySteps = @"health.sync_today_steps";
NSString * const QCSampleLocalizedKeyHealthActivityScoreAgeTitle = @"health.activity_score_age_title";
NSString * const QCSampleLocalizedKeyHealthActivityScoreAgeHint = @"health.activity_score_age_hint";
NSString * const QCSampleLocalizedKeyHealthActivityScoreAgeInvalid = @"health.activity_score_age_invalid";
NSString * const QCSampleLocalizedKeyHealthActivityScoreResult = @"health.activity_score_result";
NSString * const QCSampleLocalizedKeyHealthActivityScoreLow = @"health.activity_score_low";
NSString * const QCSampleLocalizedKeyHealthActivityScoreFair = @"health.activity_score_fair";
NSString * const QCSampleLocalizedKeyHealthActivityScoreGood = @"health.activity_score_good";
NSString * const QCSampleLocalizedKeyHealthActivityScoreExcellent = @"health.activity_score_excellent";
NSString * const QCSampleLocalizedKeyHealthSleepScoreToday = @"health.sleep_score_today";
NSString * const QCSampleLocalizedKeyHealthSleepScoreNoData = @"health.sleep_score_no_data";
NSString * const QCSampleLocalizedKeyHealthSleepScoreResult = @"health.sleep_score_result";
NSString * const QCSampleLocalizedKeyHealthFetchSportRecords = @"health.fetch_sport_records";
NSString * const QCSampleLocalizedKeyHealthHRSectionHistory = @"health.hr_section_history";
NSString * const QCSampleLocalizedKeyHealthHRSectionSettings = @"health.hr_section_settings";
NSString * const QCSampleLocalizedKeyHealthHRSectionLive = @"health.hr_section_live";
NSString * const QCSampleLocalizedKeyHealthHRStatusInterval = @"health.hr_status_interval";
NSString * const QCSampleLocalizedKeyHealthHRInfo = @"health.hr_info";
NSString * const QCSampleLocalizedKeyHealthHROneMinute = @"health.hr_one_minute";
NSString * const QCSampleLocalizedKeyHealthHRRealtimeStart = @"health.hr_realtime_start";
NSString * const QCSampleLocalizedKeyHealthHRRealtimeStop = @"health.hr_realtime_stop";
NSString * const QCSampleLocalizedKeyHealthHRMeasureStart = @"health.hr_measure_start";
NSString * const QCSampleLocalizedKeyHealthHRMeasureStop = @"health.hr_measure_stop";
NSString * const QCSampleLocalizedKeyHealthHRVSectionSettings = @"health.hrv_section_settings";
NSString * const QCSampleLocalizedKeyHealthHRVSectionHistory = @"health.hrv_section_history";
NSString * const QCSampleLocalizedKeyHealthHRVSectionMeasure = @"health.hrv_section_measure";
NSString * const QCSampleLocalizedKeyHealthHRVMeasureStart = @"health.hrv_measure_start";
NSString * const QCSampleLocalizedKeyHealthHRVMeasureStop = @"health.hrv_measure_stop";
NSString * const QCSampleLocalizedKeyHealthStressStatusInterval = @"health.stress_status_interval";
NSString * const QCSampleLocalizedKeyHealthStressSetInterval = @"health.stress_set_interval";
NSString * const QCSampleLocalizedKeyHealthTemperatureScheduledQuery = @"health.temperature_scheduled_query";
NSString * const QCSampleLocalizedKeyHealthTemperatureManualQuery = @"health.temperature_manual_query";
NSString * const QCSampleLocalizedKeyHealthTemperatureIntervalQuery = @"health.temperature_interval_query";
NSString * const QCSampleLocalizedKeyHealthTemperatureAppMeasure = @"health.temperature_app_measure";
NSString * const QCSampleLocalizedKeyHealthReadDrinkReminder = @"health.read_drink_reminder";
NSString * const QCSampleLocalizedKeyHealthSetDrinkReminder = @"health.set_drink_reminder";
NSString * const QCSampleLocalizedKeyHealthFetchSedentaryData = @"health.fetch_sedentary_data";
NSString * const QCSampleLocalizedKeyHealthBatchSyncHint = @"health.batch_sync_hint";
NSString * const QCSampleLocalizedKeyHealthBatchSyncStart = @"health.batch_sync_start";
NSString * const QCSampleLocalizedKeyCommonCancel = @"common.cancel";
NSString * const QCSampleLocalizedKeyCommonOK = @"common.ok";
NSString * const QCSampleLocalizedKeyCommonSelectTime = @"common.select_time";

NSString * const QCSampleLocalizedKeyLauncherTitle = @"launcher.title";
NSString * const QCSampleLocalizedKeyLauncherHint = @"launcher.hint";
NSString * const QCSampleLocalizedKeyLauncherLegacyDemo = @"launcher.legacy_demo";
NSString * const QCSampleLocalizedKeyLauncherLegacyDemoSubtitle = @"launcher.legacy_demo_subtitle";
NSString * const QCSampleLocalizedKeyLauncherModularHome = @"launcher.modular_home";
NSString * const QCSampleLocalizedKeyLauncherModularHomeSubtitle = @"launcher.modular_home_subtitle";

NSString * const QCSampleLocalizedKeyFirmwareGetVersion = @"firmware.get_version";
NSString * const QCSampleLocalizedKeyFirmwareStartOTA = @"firmware.start_ota";

NSString * const QCSampleLocalizedKeyResourceSectionStep1 = @"resource.section_step1";
NSString * const QCSampleLocalizedKeyResourceSectionStep2 = @"resource.section_step2";
NSString * const QCSampleLocalizedKeyResourceSectionStep3 = @"resource.section_step3";
NSString * const QCSampleLocalizedKeyResourceCheckTouchFeature = @"resource.check_touch_feature";
NSString * const QCSampleLocalizedKeyResourceCheckMissingFiles = @"resource.check_missing_files";
NSString * const QCSampleLocalizedKeyResourceStartUpdate = @"resource.start_update";
NSString * const QCSampleLocalizedKeyResourceSectionOptional = @"resource.section_optional";
NSString * const QCSampleLocalizedKeyResourcePickDeviceFile = @"resource.pick_device_file";

NSString * const QCSampleLocalizedKeyTouchGestureSectionFeatures = @"touch_gesture.section_features";
NSString * const QCSampleLocalizedKeyTouchGestureCheckFeatures = @"touch_gesture.check_features";
NSString * const QCSampleLocalizedKeyTouchGestureSectionTouch = @"touch_gesture.section_touch";
NSString * const QCSampleLocalizedKeyTouchGestureReadTouch = @"touch_gesture.read_touch";
NSString * const QCSampleLocalizedKeyTouchGestureSetTouch = @"touch_gesture.set_touch";
NSString * const QCSampleLocalizedKeyTouchGestureSectionGesture = @"touch_gesture.section_gesture";
NSString * const QCSampleLocalizedKeyTouchGestureReadGesture = @"touch_gesture.read_gesture";
NSString * const QCSampleLocalizedKeyTouchGestureSetGesture = @"touch_gesture.set_gesture";
NSString * const QCSampleLocalizedKeyTouchGestureSectionRT11 = @"touch_gesture.section_rt11";
NSString * const QCSampleLocalizedKeyTouchGestureReadRT11 = @"touch_gesture.read_rt11";
NSString * const QCSampleLocalizedKeyTouchGestureSetRT11 = @"touch_gesture.set_rt11";
NSString * const QCSampleLocalizedKeyTouchGestureSectionFlipWrist = @"touch_gesture.section_flip_wrist";
NSString * const QCSampleLocalizedKeyTouchGestureReadFlipWrist = @"touch_gesture.read_flip_wrist";
NSString * const QCSampleLocalizedKeyTouchGestureSetFlipWrist = @"touch_gesture.set_flip_wrist";
NSString * const QCSampleLocalizedKeyTouchGestureSectionLive = @"touch_gesture.section_live";
NSString * const QCSampleLocalizedKeyTouchGestureStartLive = @"touch_gesture.start_live";
NSString * const QCSampleLocalizedKeyTouchGestureStopLive = @"touch_gesture.stop_live";
NSString * const QCSampleLocalizedKeyTouchGesturePickType = @"touch_gesture.pick_type";
NSString * const QCSampleLocalizedKeyTouchGestureSetParamsTitle = @"touch_gesture.set_params_title";
NSString * const QCSampleLocalizedKeyTouchGestureStrengthTitle = @"touch_gesture.strength_title";
NSString * const QCSampleLocalizedKeyTouchGestureDurationTitle = @"touch_gesture.duration_title";
NSString * const QCSampleLocalizedKeyTouchGestureStrengthHint = @"touch_gesture.strength_hint";
NSString * const QCSampleLocalizedKeyTouchGestureDurationHint = @"touch_gesture.duration_hint";

NSString * const QCSampleLocalizedKeyGoalsSectionTarget = @"goals.section_target";
NSString * const QCSampleLocalizedKeyGoalsSectionProfile = @"goals.section_profile";
NSString * const QCSampleLocalizedKeyGoalsGetTarget = @"goals.get_target";
NSString * const QCSampleLocalizedKeyGoalsSetTarget = @"goals.set_target";
NSString * const QCSampleLocalizedKeyGoalsGetProfile = @"goals.get_profile";
NSString * const QCSampleLocalizedKeyGoalsSetProfile = @"goals.set_profile";
NSString * const QCSampleLocalizedKeyGoalsTargetRangeNote = @"goals.target_range_note";
NSString * const QCSampleLocalizedKeyGoalsProfileRangeNote = @"goals.profile_range_note";
NSString * const QCSampleLocalizedKeyGoalsStep = @"goals.step";
NSString * const QCSampleLocalizedKeyGoalsCalorie = @"goals.calorie";
NSString * const QCSampleLocalizedKeyGoalsDistance = @"goals.distance";
NSString * const QCSampleLocalizedKeyGoalsSportMinute = @"goals.sport_minute";
NSString * const QCSampleLocalizedKeyGoalsSleepMinute = @"goals.sleep_minute";
NSString * const QCSampleLocalizedKeyGoalsStepHint = @"goals.step_hint";
NSString * const QCSampleLocalizedKeyGoalsCalorieHint = @"goals.calorie_hint";
NSString * const QCSampleLocalizedKeyGoalsDistanceHint = @"goals.distance_hint";
NSString * const QCSampleLocalizedKeyGoalsSportMinuteHint = @"goals.sport_minute_hint";
NSString * const QCSampleLocalizedKeyGoalsSleepMinuteHint = @"goals.sleep_minute_hint";
NSString * const QCSampleLocalizedKeyGoalsIs24 = @"goals.is24";
NSString * const QCSampleLocalizedKeyGoalsMetric = @"goals.metric";
NSString * const QCSampleLocalizedKeyGoalsGender = @"goals.gender";
NSString * const QCSampleLocalizedKeyGoalsAge = @"goals.age";
NSString * const QCSampleLocalizedKeyGoalsHeight = @"goals.height";
NSString * const QCSampleLocalizedKeyGoalsWeight = @"goals.weight";
NSString * const QCSampleLocalizedKeyGoalsSbp = @"goals.sbp";
NSString * const QCSampleLocalizedKeyGoalsDbp = @"goals.dbp";
NSString * const QCSampleLocalizedKeyGoalsHrAlarm = @"goals.hr_alarm";
NSString * const QCSampleLocalizedKeyGoalsIs24Hint = @"goals.is24_hint";
NSString * const QCSampleLocalizedKeyGoalsMetricHint = @"goals.metric_hint";
NSString * const QCSampleLocalizedKeyGoalsGenderHint = @"goals.gender_hint";
NSString * const QCSampleLocalizedKeyGoalsAgeHint = @"goals.age_hint";
NSString * const QCSampleLocalizedKeyGoalsHeightHint = @"goals.height_hint";
NSString * const QCSampleLocalizedKeyGoalsWeightHint = @"goals.weight_hint";
NSString * const QCSampleLocalizedKeyGoalsSbpHint = @"goals.sbp_hint";
NSString * const QCSampleLocalizedKeyGoalsDbpHint = @"goals.dbp_hint";
NSString * const QCSampleLocalizedKeyGoalsHrAlarmHint = @"goals.hr_alarm_hint";
NSString * const QCSampleLocalizedKeyGoalsInvalidNumber = @"goals.invalid_number";
NSString * const QCSampleLocalizedKeyGoalsOutOfRange = @"goals.out_of_range";

NSString * const QCSampleLocalizedKeyDeviceSectionInfo = @"device.section_info";
NSString * const QCSampleLocalizedKeyDeviceSectionDegree = @"device.section_degree";
NSString * const QCSampleLocalizedKeyDeviceSectionBatterySaving = @"device.section_battery_saving";
NSString * const QCSampleLocalizedKeyDeviceSectionCamera = @"device.section_camera";
NSString * const QCSampleLocalizedKeyDeviceSectionWear = @"device.section_wear";
NSString * const QCSampleLocalizedKeyDeviceSectionPower = @"device.section_power";
NSString * const QCSampleLocalizedKeyDeviceReadBattery = @"device.read_battery";
NSString * const QCSampleLocalizedKeyDeviceReadMac = @"device.read_mac";
NSString * const QCSampleLocalizedKeyDeviceReadVersion = @"device.read_version";
NSString * const QCSampleLocalizedKeyDeviceGetDegree = @"device.get_degree";
NSString * const QCSampleLocalizedKeyDeviceSetDegree = @"device.set_degree";
NSString * const QCSampleLocalizedKeyDeviceDegreeEnable = @"device.degree_enable";
NSString * const QCSampleLocalizedKeyDeviceDegreeCelsius = @"device.degree_celsius";
NSString * const QCSampleLocalizedKeyDeviceBoolHint = @"device.bool_hint";
NSString * const QCSampleLocalizedKeyDeviceCelsiusHint = @"device.celsius_hint";
NSString * const QCSampleLocalizedKeyDeviceGetBatterySaving = @"device.get_battery_saving";
NSString * const QCSampleLocalizedKeyDeviceSetBatterySaving = @"device.set_battery_saving";
NSString * const QCSampleLocalizedKeyDeviceBatterySavingEnable = @"device.battery_saving_enable";
NSString * const QCSampleLocalizedKeyDeviceStartCamera = @"device.start_camera";
NSString * const QCSampleLocalizedKeyDeviceStopCamera = @"device.stop_camera";
NSString * const QCSampleLocalizedKeyDeviceCameraStarted = @"device.camera_started";
NSString * const QCSampleLocalizedKeyDeviceCameraStopped = @"device.camera_stopped";
NSString * const QCSampleLocalizedKeyDeviceCameraTakePhoto = @"device.camera_take_photo";
NSString * const QCSampleLocalizedKeyDeviceCameraFinished = @"device.camera_finished";
NSString * const QCSampleLocalizedKeyDeviceStartWear = @"device.start_wear";
NSString * const QCSampleLocalizedKeyDeviceStopWear = @"device.stop_wear";
NSString * const QCSampleLocalizedKeyDeviceWearCharging = @"device.wear_charging";
NSString * const QCSampleLocalizedKeyDeviceWearSuccess = @"device.wear_success";
NSString * const QCSampleLocalizedKeyDeviceWearFailed = @"device.wear_failed";
NSString * const QCSampleLocalizedKeyDeviceShutdown = @"device.shutdown";
NSString * const QCSampleLocalizedKeyDeviceReboot = @"device.reboot";
NSString * const QCSampleLocalizedKeyDeviceFactoryReset = @"device.factory_reset";
NSString * const QCSampleLocalizedKeyDeviceHighRiskTitle = @"device.high_risk_title";
NSString * const QCSampleLocalizedKeyDeviceHighRiskConfirm = @"device.high_risk_confirm";
NSString * const QCSampleLocalizedKeyDeviceShutdownConfirm = @"device.shutdown_confirm";
NSString * const QCSampleLocalizedKeyDeviceRebootConfirm = @"device.reboot_confirm";
NSString * const QCSampleLocalizedKeyDeviceFactoryConfirm = @"device.factory_confirm";
NSString * const QCSampleLocalizedKeyDeviceHighRiskSuccess = @"device.high_risk_success";

NSString * const QCSampleLocalizedKeyDisplaySectionBrightness = @"display.section_brightness";
NSString * const QCSampleLocalizedKeyDisplaySectionClock = @"display.section_clock";
NSString * const QCSampleLocalizedKeyDisplaySectionOrientation = @"display.section_orientation";
NSString * const QCSampleLocalizedKeyDisplaySectionStyle = @"display.section_style";
NSString * const QCSampleLocalizedKeyDisplaySectionTime = @"display.section_time";
NSString * const QCSampleLocalizedKeyDisplaySectionDial = @"display.section_dial";
NSString * const QCSampleLocalizedKeyDisplaySectionPalm = @"display.section_palm";
NSString * const QCSampleLocalizedKeyDisplayGetBrightness = @"display.get_brightness";
NSString * const QCSampleLocalizedKeyDisplaySetBrightness = @"display.set_brightness";
NSString * const QCSampleLocalizedKeyDisplayBrightness = @"display.brightness";
NSString * const QCSampleLocalizedKeyDisplayBrightnessHint = @"display.brightness_hint";
NSString * const QCSampleLocalizedKeyDisplayGetClock = @"display.get_clock";
NSString * const QCSampleLocalizedKeyDisplaySetClock = @"display.set_clock";
NSString * const QCSampleLocalizedKeyDisplayClockEnable = @"display.clock_enable";
NSString * const QCSampleLocalizedKeyDisplayBoolHint = @"display.bool_hint";
NSString * const QCSampleLocalizedKeyDisplayGetOrientation = @"display.get_orientation";
NSString * const QCSampleLocalizedKeyDisplaySetOrientation = @"display.set_orientation";
NSString * const QCSampleLocalizedKeyDisplayPortrait = @"display.portrait";
NSString * const QCSampleLocalizedKeyDisplayLeftHand = @"display.left_hand";
NSString * const QCSampleLocalizedKeyDisplayPortraitHint = @"display.portrait_hint";
NSString * const QCSampleLocalizedKeyDisplayLeftHandHint = @"display.left_hand_hint";
NSString * const QCSampleLocalizedKeyDisplayGetStyle = @"display.get_style";
NSString * const QCSampleLocalizedKeyDisplaySetStyle = @"display.set_style";
NSString * const QCSampleLocalizedKeyDisplayStyle = @"display.style";
NSString * const QCSampleLocalizedKeyDisplayStyleHint = @"display.style_hint";
NSString * const QCSampleLocalizedKeyDisplayGetTime = @"display.get_time";
NSString * const QCSampleLocalizedKeyDisplaySetTime = @"display.set_time";
NSString * const QCSampleLocalizedKeyDisplayLightingSec = @"display.lighting_sec";
NSString * const QCSampleLocalizedKeyDisplayHomeType = @"display.home_type";
NSString * const QCSampleLocalizedKeyDisplayTransparency = @"display.transparency";
NSString * const QCSampleLocalizedKeyDisplayAllTimeScreen = @"display.all_time_screen";
NSString * const QCSampleLocalizedKeyDisplayLightingSecHint = @"display.lighting_sec_hint";
NSString * const QCSampleLocalizedKeyDisplayHomeTypeHint = @"display.home_type_hint";
NSString * const QCSampleLocalizedKeyDisplayTransparencyHint = @"display.transparency_hint";
NSString * const QCSampleLocalizedKeyDisplayAllTimeScreenHint = @"display.all_time_screen_hint";
NSString * const QCSampleLocalizedKeyDisplayGetDial = @"display.get_dial";
NSString * const QCSampleLocalizedKeyDisplaySetDial = @"display.set_dial";
NSString * const QCSampleLocalizedKeyDisplayDialIndex = @"display.dial_index";
NSString * const QCSampleLocalizedKeyDisplayDialIndexHint = @"display.dial_index_hint";
NSString * const QCSampleLocalizedKeyDisplayGetPalm = @"display.get_palm";
NSString * const QCSampleLocalizedKeyDisplaySetPalm = @"display.set_palm";
NSString * const QCSampleLocalizedKeyDisplayPalmEnable = @"display.palm_enable";
NSString * const QCSampleLocalizedKeyDisplayPalmHand = @"display.palm_hand";
NSString * const QCSampleLocalizedKeyDisplayPalmHandHint = @"display.palm_hand_hint";

NSString * const QCSampleLocalizedKeyNotifSectionANCS = @"notif.section_ancs";
NSString * const QCSampleLocalizedKeyNotifSectionDND = @"notif.section_dnd";
NSString * const QCSampleLocalizedKeyNotifSectionLight = @"notif.section_light";
NSString * const QCSampleLocalizedKeyNotifSectionVibration = @"notif.section_vibration";
NSString * const QCSampleLocalizedKeyNotifSectionMusic = @"notif.section_music";
NSString * const QCSampleLocalizedKeyNotifGetANCS = @"notif.get_ancs";
NSString * const QCSampleLocalizedKeyNotifSetANCS = @"notif.set_ancs";
NSString * const QCSampleLocalizedKeyNotifBindANCS = @"notif.bind_ancs";
NSString * const QCSampleLocalizedKeyNotifBindANCSSuccess = @"notif.bind_ancs_success";
NSString * const QCSampleLocalizedKeyNotifANCSPhone = @"notif.ancs_phone";
NSString * const QCSampleLocalizedKeyNotifANCSSms = @"notif.ancs_sms";
NSString * const QCSampleLocalizedKeyNotifANCSQQ = @"notif.ancs_qq";
NSString * const QCSampleLocalizedKeyNotifANCSWechat = @"notif.ancs_wechat";
NSString * const QCSampleLocalizedKeyNotifBoolHint = @"notif.bool_hint";
NSString * const QCSampleLocalizedKeyNotifGetDND = @"notif.get_dnd";
NSString * const QCSampleLocalizedKeyNotifSetDND = @"notif.set_dnd";
NSString * const QCSampleLocalizedKeyNotifDNDEnable = @"notif.dnd_enable";
NSString * const QCSampleLocalizedKeyNotifDNDBeginHour = @"notif.dnd_begin_hour";
NSString * const QCSampleLocalizedKeyNotifDNDBeginMinute = @"notif.dnd_begin_minute";
NSString * const QCSampleLocalizedKeyNotifDNDEndHour = @"notif.dnd_end_hour";
NSString * const QCSampleLocalizedKeyNotifDNDEndMinute = @"notif.dnd_end_minute";
NSString * const QCSampleLocalizedKeyNotifHourHint = @"notif.hour_hint";
NSString * const QCSampleLocalizedKeyNotifMinuteHint = @"notif.minute_hint";
NSString * const QCSampleLocalizedKeyNotifSendLight = @"notif.send_light";
NSString * const QCSampleLocalizedKeyNotifSendVibration = @"notif.send_vibration";
NSString * const QCSampleLocalizedKeyNotifPriority = @"notif.priority";
NSString * const QCSampleLocalizedKeyNotifLightAction = @"notif.light_action";
NSString * const QCSampleLocalizedKeyNotifVibrationAction = @"notif.vibration_action";
NSString * const QCSampleLocalizedKeyNotifCycle = @"notif.cycle";
NSString * const QCSampleLocalizedKeyNotifOnDuration = @"notif.on_duration";
NSString * const QCSampleLocalizedKeyNotifVibrateDuration = @"notif.vibrate_duration";
NSString * const QCSampleLocalizedKeyNotifPauseDuration = @"notif.pause_duration";
NSString * const QCSampleLocalizedKeyNotifPriorityHint = @"notif.priority_hint";
NSString * const QCSampleLocalizedKeyNotifLightActionHint = @"notif.light_action_hint";
NSString * const QCSampleLocalizedKeyNotifVibrationActionHint = @"notif.vibration_action_hint";
NSString * const QCSampleLocalizedKeyNotifCycleHint = @"notif.cycle_hint";
NSString * const QCSampleLocalizedKeyNotifDurationHint = @"notif.duration_hint";
NSString * const QCSampleLocalizedKeyNotifPauseHint = @"notif.pause_hint";
NSString * const QCSampleLocalizedKeyNotifGetMusic = @"notif.get_music";
NSString * const QCSampleLocalizedKeyNotifSetMusic = @"notif.set_music";
NSString * const QCSampleLocalizedKeyNotifMusicEnable = @"notif.music_enable";

NSString * const QCSampleLocalizedKeyAdvSectionAGPS = @"adv.section_agps";
NSString * const QCSampleLocalizedKeyAdvSectionIntell = @"adv.section_intell";
NSString * const QCSampleLocalizedKeyAdvSectionMuslim = @"adv.section_muslim";
NSString * const QCSampleLocalizedKeyAdvSectionFeatures = @"adv.section_features";
NSString * const QCSampleLocalizedKeyAdvSectionPower = @"adv.section_power";
NSString * const QCSampleLocalizedKeyAdvGetAGPS = @"adv.get_agps";
NSString * const QCSampleLocalizedKeyAdvSetAGPS = @"adv.set_agps";
NSString * const QCSampleLocalizedKeyAdvGetIntell = @"adv.get_intell";
NSString * const QCSampleLocalizedKeyAdvSetIntell = @"adv.set_intell";
NSString * const QCSampleLocalizedKeyAdvGetMuslim = @"adv.get_muslim";
NSString * const QCSampleLocalizedKeyAdvSetMuslim = @"adv.set_muslim";
NSString * const QCSampleLocalizedKeyAdvGetPraise = @"adv.get_praise";
NSString * const QCSampleLocalizedKeyAdvClearPraise = @"adv.clear_praise";
NSString * const QCSampleLocalizedKeyAdvGetSupport = @"adv.get_support";
NSString * const QCSampleLocalizedKeyAdvGetFeatureConfig = @"adv.get_feature_config";
NSString * const QCSampleLocalizedKeyAdvGetPersonalization = @"adv.get_personalization";
NSString * const QCSampleLocalizedKeyAdvShutdown = @"adv.shutdown";
NSString * const QCSampleLocalizedKeyAdvEnable = @"adv.enable";
NSString * const QCSampleLocalizedKeyAdvBoolHint = @"adv.bool_hint";
NSString * const QCSampleLocalizedKeyAdvPxpDelay = @"adv.pxp_delay";
NSString * const QCSampleLocalizedKeyAdvPxpDelayHint = @"adv.pxp_delay_hint";
NSString * const QCSampleLocalizedKeyAdvTouchStrength = @"adv.touch_strength";
NSString * const QCSampleLocalizedKeyAdvTouchStrengthHint = @"adv.touch_strength_hint";
NSString * const QCSampleLocalizedKeyAdvHighRiskTitle = @"adv.high_risk_title";
NSString * const QCSampleLocalizedKeyAdvHighRiskConfirm = @"adv.high_risk_confirm";
NSString * const QCSampleLocalizedKeyAdvShutdownConfirm = @"adv.shutdown_confirm";
NSString * const QCSampleLocalizedKeyAdvShutdownSuccess = @"adv.shutdown_success";

static NSBundle *QCSampleBundleForLanguage(NSString *languageCode) {
    NSString *path = [[NSBundle mainBundle] pathForResource:languageCode ofType:@"lproj"];
    return path.length > 0 ? [NSBundle bundleWithPath:path] : [NSBundle mainBundle];
}

static NSBundle *QCSampleChineseBundle(void) {
    static NSBundle *bundle = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        bundle = QCSampleBundleForLanguage(@"zh-Hans");
        if (bundle == [NSBundle mainBundle]) {
            NSBundle *traditionalBundle = QCSampleBundleForLanguage(@"zh-Hant");
            if (traditionalBundle != [NSBundle mainBundle]) {
                bundle = traditionalBundle;
            }
        }
    });
    return bundle;
}

static NSBundle *QCSampleEnglishBundle(void) {
    static NSBundle *bundle = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        bundle = QCSampleBundleForLanguage(@"en");
    });
    return bundle;
}

BOOL QCSampleUsesChineseLanguage(void) {
    // Only the first preferred language decides UI language. Scanning the full
    // list wrongly treats English-primary devices that still have zh as a
    // secondary preferred language as Chinese.
    // 只看首选语言；遍历完整列表会在主语言为英文但偏好里仍有中文时误判为中文。
    NSString *language = [NSLocale preferredLanguages].firstObject;
    return language.length > 0 && [language hasPrefix:@"zh"];
}

NSString *QCSampleLocalizedString(NSString *key) {
    if (key.length == 0) {
        return @"";
    }

    NSBundle *bundle = QCSampleUsesChineseLanguage() ? QCSampleChineseBundle() : QCSampleEnglishBundle();
    NSString *value = [bundle localizedStringForKey:key value:nil table:@"Localizable"];
    if (value.length == 0 || [value isEqualToString:key]) {
        value = [QCSampleEnglishBundle() localizedStringForKey:key value:key table:@"Localizable"];
    }
    return value;
}

NSString *QCSampleLocalizedFormat(NSString *key, ...) {
    va_list args;
    va_start(args, key);
    NSString *format = QCSampleLocalizedString(key);
    NSString *result = [[NSString alloc] initWithFormat:format arguments:args];
    va_end(args);
    return result;
}
