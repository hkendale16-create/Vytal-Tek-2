//
//  QCSampleTouchGesturesViewController.h
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/28.
//
//  Touch / gesture SDK sample. SDK calls are in QCSampleTouchGesturesViewController.m
//  触摸/手势 SDK 示例。SDK 调用见 QCSampleTouchGesturesViewController.m
//
//  ═══════════════════════════════════════════════════════════════════════════════
//  Integration guide — recommended API call order (inform your integrators)
//  集成指南 — 推荐 API 调用顺序
//  ═══════════════════════════════════════════════════════════════════════════════
//
//  Phase 1 — Connect & register callbacks (once after BLE connected)
//  阶段 1 — 连接后注册回调（连接成功后执行一次）
//    1. QCSDKManager.shareInstance.watchDataUpdateReport = ^(type, value) { ... };
//       Use QCDeviceDataUpdateReportName(type) / ValueHint(type) for logging.
//    2. gestureAndTouchInfo  — 0x73/0x28 touch-gesture mode change
//    3. touchSleepInfo       — 0x73/0x2A touch sleep (0=awake, 1=sleeping)
//    4. flipWristInfo        — 0x73/0x11 raise-to-wake / wearing hand
//    5. currentBatteryInfo / currentStepInfo — if needed (dedicated 0x73 types)
//
//  Phase 2 — Feature check (before any touch/gesture API)
//  阶段 2 — 能力检查（任何触摸/手势 API 之前）
//    [QCSDKCmdCreator setTime:[NSDate date] success:^(NSDictionary *featureList) {
//        // QCBandFeatureTouchControl / GestureControl / FlipWrist / WearCalibration
//        // QCBandFeatureGestureControlMusic|Video|... — per-app type support
//    } failed:^{ ... }];
//
//  Phase 3 — Wearing setup (ring devices, before first use or after changing hand/finger)
//  阶段 3 — 佩戴设置（戒指首次使用或换手/换指后）
//    A. setFlipWristInfo: flipType 1=left, 2=right (must match actual wearing hand)
//       或 setFlipWristOn:flipType: — legacy API, same semantics
//    B. If feature.wear.calibration supported:
//       [QCSDKManager startToWearCalibrationWithCompletedHandle:^{ ... }];
//       // User keeps still ~30s; on success proceed; on fail retry
//       // stop: stopToWearCalibrationWithCompletedHandle:
//
//  Phase 4 — Configure touch OR gesture (not both fighting; pick one primary mode)
//  阶段 4 — 配置触摸或手势
//    Touch (HID tap):  setTouchControl:type strength:duration:  — duration=1~10 min sleep
//                      strength is reserved; duration controls auto-sleep
//    Gesture (IMU):    setGestureControl:type strength:        — strength 1~10, tune 5~7
//    RT11 screen:      setTouchControlOfScreenDevie:...
//    After set → getTouchControlFinshed / getGestureControlFinshed to verify
//
//  Phase 5 — Runtime (user interaction; no heavy BLE batch sync in parallel)
//  阶段 5 — 运行期
//    - Actual music/video control goes through BLE HID + iOS system (not SDK callback)
//    - If touch stops working: check touchSleepInfo / getTouchControl sleeping flag
//    - On 0x73 data update (HeartRate, Step, …): call corresponding get API to refresh UI
//
//  Anti-patterns — 避免
//    × set touch/gesture before setTime feature check
//    × wrong flipType vs actual hand → unstable gestures
//    × concurrent health batch sync + touch set (ChannelBusy 1001)
//    × expect gestureAndTouchInfo for every tap (it reports mode/type change, not each HID key)
//
//  See implementation in QCSampleTouchGesturesViewController.m
//  ═══════════════════════════════════════════════════════════════════════════════

#import "QCSampleHealthFunctionViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface QCSampleTouchGesturesViewController : QCSampleHealthFunctionViewController
@end

NS_ASSUME_NONNULL_END
