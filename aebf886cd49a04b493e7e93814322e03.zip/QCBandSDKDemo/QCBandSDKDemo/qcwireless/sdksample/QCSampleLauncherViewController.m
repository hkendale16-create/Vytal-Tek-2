//
//  QCSampleLauncherViewController.m
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//

#import "QCSampleLauncherViewController.h"
#import "QCSampleHomeViewController.h"
#import "QCSampleLocalization.h"
#import "ViewController.h"

#import <QCBandSDK/QCSDKManager.h>

static const CGFloat kQCSampleLauncherHorizontalInset = 24.f;
static const CGFloat kQCSampleLauncherButtonSpacing = 16.f;
static const CGFloat kQCSampleLauncherButtonHeight = 88.f;

@interface QCSampleLauncherEntryButton : UIControl

@property (nonatomic, strong, readonly) UILabel *titleLabel;
@property (nonatomic, strong, readonly) UILabel *subtitleLabel;

- (void)configureWithTitle:(NSString *)title subtitle:(NSString *)subtitle;

@end

@implementation QCSampleLauncherEntryButton

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor secondarySystemGroupedBackgroundColor];
        self.layer.cornerRadius = 12.f;
        self.layer.masksToBounds = YES;

        _titleLabel = [[UILabel alloc] init];
        _titleLabel.font = [UIFont boldSystemFontOfSize:17.f];
        _titleLabel.textColor = [UIColor labelColor];
        _titleLabel.numberOfLines = 0;
        _titleLabel.translatesAutoresizingMaskIntoConstraints = NO;

        _subtitleLabel = [[UILabel alloc] init];
        _subtitleLabel.font = [UIFont systemFontOfSize:13.f];
        _subtitleLabel.textColor = [UIColor secondaryLabelColor];
        _subtitleLabel.numberOfLines = 0;
        _subtitleLabel.translatesAutoresizingMaskIntoConstraints = NO;

        UIImageView *chevron = [[UIImageView alloc] initWithImage:[UIImage systemImageNamed:@"chevron.right"]];
        chevron.tintColor = [UIColor tertiaryLabelColor];
        chevron.translatesAutoresizingMaskIntoConstraints = NO;

        [self addSubview:_titleLabel];
        [self addSubview:_subtitleLabel];
        [self addSubview:chevron];

        [NSLayoutConstraint activateConstraints:@[
            [_titleLabel.topAnchor constraintEqualToAnchor:self.topAnchor constant:16.f],
            [_titleLabel.leadingAnchor constraintEqualToAnchor:self.leadingAnchor constant:16.f],
            [_titleLabel.trailingAnchor constraintEqualToAnchor:chevron.leadingAnchor constant:-12.f],

            [_subtitleLabel.topAnchor constraintEqualToAnchor:_titleLabel.bottomAnchor constant:6.f],
            [_subtitleLabel.leadingAnchor constraintEqualToAnchor:_titleLabel.leadingAnchor],
            [_subtitleLabel.trailingAnchor constraintEqualToAnchor:_titleLabel.trailingAnchor],
            [_subtitleLabel.bottomAnchor constraintEqualToAnchor:self.bottomAnchor constant:-16.f],

            [chevron.centerYAnchor constraintEqualToAnchor:self.centerYAnchor],
            [chevron.trailingAnchor constraintEqualToAnchor:self.trailingAnchor constant:-16.f],
            [chevron.widthAnchor constraintEqualToConstant:10.f],
            [chevron.heightAnchor constraintEqualToConstant:16.f],
        ]];
    }
    return self;
}

- (void)configureWithTitle:(NSString *)title subtitle:(NSString *)subtitle {
    self.titleLabel.text = title;
    self.subtitleLabel.text = subtitle;
}

- (void)setHighlighted:(BOOL)highlighted {
    [super setHighlighted:highlighted];
    self.alpha = highlighted ? 0.72f : 1.f;
}

@end

@interface QCSampleLauncherViewController ()

@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UILabel *hintLabel;
@property (nonatomic, strong) QCSampleLauncherEntryButton *legacyButton;
@property (nonatomic, strong) QCSampleLauncherEntryButton *sampleHomeButton;
@property (nonatomic, copy, nullable) NSString *currentLanguageBucket;

@end

@implementation QCSampleLauncherViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.edgesForExtendedLayout = UIRectEdgeNone;
    self.view.backgroundColor = [UIColor systemGroupedBackgroundColor];

    self.titleLabel = [[UILabel alloc] init];
    self.titleLabel.font = [UIFont boldSystemFontOfSize:22.f];
    self.titleLabel.textColor = [UIColor labelColor];
    self.titleLabel.numberOfLines = 0;
    self.titleLabel.textAlignment = NSTextAlignmentCenter;
    self.titleLabel.translatesAutoresizingMaskIntoConstraints = NO;

    self.hintLabel = [[UILabel alloc] init];
    self.hintLabel.font = [UIFont systemFontOfSize:14.f];
    self.hintLabel.textColor = [UIColor secondaryLabelColor];
    self.hintLabel.numberOfLines = 0;
    self.hintLabel.textAlignment = NSTextAlignmentCenter;
    self.hintLabel.translatesAutoresizingMaskIntoConstraints = NO;

    self.legacyButton = [[QCSampleLauncherEntryButton alloc] initWithFrame:CGRectZero];
    self.legacyButton.translatesAutoresizingMaskIntoConstraints = NO;
    [self.legacyButton addTarget:self action:@selector(openLegacyDemo) forControlEvents:UIControlEventTouchUpInside];

    self.sampleHomeButton = [[QCSampleLauncherEntryButton alloc] initWithFrame:CGRectZero];
    self.sampleHomeButton.translatesAutoresizingMaskIntoConstraints = NO;
    [self.sampleHomeButton addTarget:self action:@selector(openSampleHome) forControlEvents:UIControlEventTouchUpInside];

    [self.view addSubview:self.titleLabel];
    [self.view addSubview:self.hintLabel];
    [self.view addSubview:self.legacyButton];
    [self.view addSubview:self.sampleHomeButton];

    UILayoutGuide *guide = self.view.safeAreaLayoutGuide;
    [NSLayoutConstraint activateConstraints:@[
        [self.titleLabel.topAnchor constraintEqualToAnchor:guide.topAnchor constant:32.f],
        [self.titleLabel.leadingAnchor constraintEqualToAnchor:guide.leadingAnchor constant:kQCSampleLauncherHorizontalInset],
        [self.titleLabel.trailingAnchor constraintEqualToAnchor:guide.trailingAnchor constant:-kQCSampleLauncherHorizontalInset],

        [self.hintLabel.topAnchor constraintEqualToAnchor:self.titleLabel.bottomAnchor constant:8.f],
        [self.hintLabel.leadingAnchor constraintEqualToAnchor:self.titleLabel.leadingAnchor],
        [self.hintLabel.trailingAnchor constraintEqualToAnchor:self.titleLabel.trailingAnchor],

        [self.legacyButton.topAnchor constraintEqualToAnchor:self.hintLabel.bottomAnchor constant:32.f],
        [self.legacyButton.leadingAnchor constraintEqualToAnchor:self.titleLabel.leadingAnchor],
        [self.legacyButton.trailingAnchor constraintEqualToAnchor:self.titleLabel.trailingAnchor],
        [self.legacyButton.heightAnchor constraintGreaterThanOrEqualToConstant:kQCSampleLauncherButtonHeight],

        [self.sampleHomeButton.topAnchor constraintEqualToAnchor:self.legacyButton.bottomAnchor constant:kQCSampleLauncherButtonSpacing],
        [self.sampleHomeButton.leadingAnchor constraintEqualToAnchor:self.legacyButton.leadingAnchor],
        [self.sampleHomeButton.trailingAnchor constraintEqualToAnchor:self.legacyButton.trailingAnchor],
        [self.sampleHomeButton.heightAnchor constraintGreaterThanOrEqualToConstant:kQCSampleLauncherButtonHeight],
    ]];

    self.currentLanguageBucket = QCSampleUsesChineseLanguage() ? @"zh" : @"en";
    [self reloadLocalizedContent];

    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(reloadLocalizedContent)
                                                 name:NSCurrentLocaleDidChangeNotification
                                               object:nil];
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)reloadLocalizedContent {
    NSString *languageBucket = QCSampleUsesChineseLanguage() ? @"zh" : @"en";
    self.currentLanguageBucket = languageBucket;

    self.title = [NSString stringWithFormat:@"QCBandSDK Sample:%@", [QCSDKManager shareInstance].getVersionInfo];
    self.titleLabel.text = QCSampleLocalized(QCSampleLocalizedKeyLauncherTitle);
    self.hintLabel.text = QCSampleLocalized(QCSampleLocalizedKeyLauncherHint);
    [self.legacyButton configureWithTitle:QCSampleLocalized(QCSampleLocalizedKeyLauncherLegacyDemo)
                               subtitle:QCSampleLocalized(QCSampleLocalizedKeyLauncherLegacyDemoSubtitle)];
    [self.sampleHomeButton configureWithTitle:QCSampleLocalized(QCSampleLocalizedKeyLauncherModularHome)
                                     subtitle:QCSampleLocalized(QCSampleLocalizedKeyLauncherModularHomeSubtitle)];
}

- (void)openLegacyDemo {
    ViewController *vc = [[ViewController alloc] init];
    vc.title = QCSampleLocalized(QCSampleLocalizedKeyLauncherLegacyDemo);
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)openSampleHome {
    QCSampleHomeViewController *vc = [[QCSampleHomeViewController alloc] init];
    [self.navigationController pushViewController:vc animated:YES];
}

@end
