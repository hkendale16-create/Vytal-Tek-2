//
//  QCSampleResourceUpdateViewController.m
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/29.
//
//  Generic device resource update sample. 通用设备资源升级示例。
//
//  Integration flow / 集成流程：
//    1. setTime → read feature flags (e.g. QCBandFeatureTouchControl when needed)
//    2. getNeededFileListFinished → missing file names
//    3. load file data (server in production; demo uses bundle / picker) → syncResourceFileName
//
//  Demo bundled file: TP_resource/RT08_TP_FILE_0x1FD4_250106_01
//

#import "QCSampleResourceUpdateViewController.h"
#import "QCSampleLocalization.h"
#import <QCBandSDK/QCSDKCmdCreator.h>
#import <QCBandSDK/QCDFU_Utils.h>
#import <UniformTypeIdentifiers/UniformTypeIdentifiers.h>

static NSString * const kQCSampleDemoResourceFileName = @"RT08_TP_FILE_0x1FD4_250106_01";

@interface QCSampleResourceUpdateViewController () <UIDocumentPickerDelegate>
@property (nonatomic, assign) BOOL resourceUpdateInProgress;
@property (nonatomic, copy, nullable) NSString *pickedResourceFileName;
@property (nonatomic, strong, nullable) NSData *pickedResourceFileData;
@end

@implementation QCSampleResourceUpdateViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = QCSampleLocalized(QCSampleLocalizedKeyItemResourceUpdate);
}

- (void)setupActions {
    __weak typeof(self) weakSelf = self;

    [self beginActionSection:QCSampleLocalized(QCSampleLocalizedKeyResourceSectionStep1)];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyResourceCheckTouchFeature) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf checkTouchControlFeature];
    }];

    [self beginActionSection:QCSampleLocalized(QCSampleLocalizedKeyResourceSectionStep2)];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyResourceCheckMissingFiles) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf queryMissingResourceFiles:^(NSArray<NSString *> *fileList, NSError *error) {
            [weakSelf logMissingFileList:fileList error:error];
        }];
    }];

    [self beginActionSection:QCSampleLocalized(QCSampleLocalizedKeyResourceSectionStep3)];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyResourceStartUpdate) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf startResourceUpdateFlow];
    }];

    [self beginActionSection:QCSampleLocalized(QCSampleLocalizedKeyResourceSectionOptional)];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyResourcePickDeviceFile) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf presentResourceFilePicker];
    }];
}

#pragma mark - Step 1 · Touch feature

- (void)checkTouchControlFeature {
    [self appendLog:@"SDK setTime → QCBandFeatureTouchControl"];
    [self ensureTouchControl:^(BOOL supported) {
        if (supported) {
            [self appendLog:@"✅ touch control supported"];
            [self appendLog:@"   设备支持触摸控制，可继续检查缺失资源文件"];
        } else {
            [self appendLog:@"⚠️ no touch control; resource update may not be required"];
            [self appendLog:@"   设备不支持触摸控制，通常无需资源升级"];
        }
    }];
}

#pragma mark - Step 2 · Missing file list

- (void)queryMissingResourceFiles:(void (^)(NSArray<NSString *> *fileList, NSError *error))completion {
    [self appendLog:@"SDK setTime → getNeededFileListFinished"];
    __weak typeof(self) weakSelf = self;
    [self ensureTouchControl:^(BOOL supported) {
        if (!supported) {
            if (completion) { completion(@[], nil); }
            return;
        }
        [weakSelf fetchNeededFileListWithRetry:1 completion:completion];
    }];
}

- (void)logMissingFileList:(NSArray<NSString *> *)fileList error:(NSError *)error {
    if (error) {
        [self appendLogFormat:@"❌ getNeededFileListFinished failed: %@", error.localizedDescription ?: @"unknown"];
        return;
    }
    if (fileList.count == 0) {
        [self appendLog:@"✅ device has all resource files (list is empty)"];
        [self appendLog:@"   设备资源完整（缺失列表为空）"];
        return;
    }
    [self appendLogFormat:@"missing resource files (%lu):", (unsigned long)fileList.count];
    for (NSString *name in fileList) {
        [self appendLogFormat:@"  · %@", name];
    }
}

- (void)fetchNeededFileListWithRetry:(NSInteger)retryCount
                          completion:(void (^)(NSArray<NSString *> *fileList, NSError *error))completion {
    [self appendLog:@"SDK getNeededFileListFinished"];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator getNeededFileListFinished:^(NSArray<NSString *> *fileList, NSError *error) {
        if (error) {
            if (retryCount > 0) {
                [weakSelf appendLogFormat:@"retry in 1s (%ld left)", (long)retryCount];
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    [weakSelf fetchNeededFileListWithRetry:retryCount - 1 completion:completion];
                });
            } else if (completion) {
                completion(nil, error);
            }
            return;
        }
        if (completion) { completion(fileList ?: @[], nil); }
    }];
}

#pragma mark - Step 3 · Resource update flow

- (void)startResourceUpdateFlow {
    if (self.resourceUpdateInProgress) {
        [self appendLog:@"⚠️ resource update already in progress"];
        return;
    }

    [self appendLog:@"=== resource update flow ==="];
    __weak typeof(self) weakSelf = self;
    [self queryMissingResourceFiles:^(NSArray<NSString *> *fileList, NSError *error) {
        if (error) {
            [weakSelf appendLogFormat:@"❌ query missing files failed: %@", error.localizedDescription ?: @"unknown"];
            return;
        }
        if (fileList.count == 0) {
            [weakSelf appendLog:@"✅ no missing resource files, update not needed"];
            [weakSelf appendLog:@"   无缺失资源文件，无需升级"];
            return;
        }

        [weakSelf appendLogFormat:@"will sync %lu file(s)", (unsigned long)fileList.count];
        weakSelf.resourceUpdateInProgress = YES;
        [weakSelf syncResourceFilesSequentially:[fileList copy] index:0];
    }];
}

- (void)syncResourceFilesSequentially:(NSArray<NSString *> *)fileNames index:(NSUInteger)index {
    if (index >= fileNames.count) {
        self.resourceUpdateInProgress = NO;
        [self appendLog:@"✅ all resource files synced"];
        return;
    }

    __weak typeof(self) weakSelf = self;
    NSString *fileName = fileNames[index];
    NSData *data = [self resourceFileDataForFileName:fileName];
    if (!data.length) {
        self.resourceUpdateInProgress = NO;
        [self appendLogFormat:@"❌ no data for %@", fileName];
        [self appendLog:@"   integrator: download from server by fileName"];
        [self appendLog:@"   集成方：按 fileName 从服务端下载"];
        [self appendLogFormat:@"   demo bundle: %@ (TP_resource/)", kQCSampleDemoResourceFileName];
        [self appendLogFormat:@"   or use 「%@」 to pick a local copy",
         QCSampleLocalized(QCSampleLocalizedKeyResourcePickDeviceFile)];
        return;
    }

    [self syncResourceFileWithName:fileName binData:data completion:^{
        [weakSelf syncResourceFilesSequentially:fileNames index:index + 1];
    }];
}

- (void)syncResourceFileWithName:(NSString *)fileName
                         binData:(NSData *)data
                      completion:(nullable void (^)(void))completion {
    __weak typeof(self) weakSelf = self;
    [self appendLogFormat:@"SDK syncResourceFileName: %@ (%.1f KB)", fileName, data.length / 1024.0];
    __block int lastLoggedProgress = -1;
    [QCSDKCmdCreator syncResourceFileName:fileName
                                  binData:data
                                    start:^{
        [weakSelf appendLogFormat:@"sync started: %@", fileName];
    } percentage:^(int percentage) {
        if (lastLoggedProgress != percentage && (percentage == 0 || percentage % 10 == 0 || percentage == 100)) {
            lastLoggedProgress = percentage;
            [weakSelf appendLogFormat:@"  %@ progress: %d%%", fileName, percentage];
        }
    } success:^(int seconds) {
        [weakSelf appendLogFormat:@"✅ %@ success (%ds)", fileName, seconds];
        if (completion) { completion(); }
    } failed:^(NSError *error) {
        weakSelf.resourceUpdateInProgress = NO;
        [weakSelf logResourceUploadError:error fileName:fileName];
    }];
}

- (void)logResourceUploadError:(NSError *)error fileName:(NSString *)fileName {
    [self appendLogFormat:@"❌ %@ failed: %@", fileName, error.localizedDescription ?: @"unknown"];
    if (![error.domain isEqualToString:@"OdmDFUErrorDomain"]) { return; }

    [self appendLogFormat:@"   OdmDFUErrorDomain code=%ld (1003=InvalidParameter)", (long)error.code];
    NSString *message = error.userInfo[@"kOdmDFUErrorMessageKey"];
    if (message.length) {
        [self appendLogFormat:@"   detail: %@", message];
    }
    if (error.code == 1003) {
        [self appendLog:@"   only sync files returned by getNeededFileListFinished"];
        [self appendLog:@"   仅上传设备缺失列表返回的文件"];
    }
}

#pragma mark - Optional · Pick file (integrator: local / server download)

- (void)presentResourceFilePicker {
    if (self.resourceUpdateInProgress) {
        [self appendLog:@"⚠️ resource update already in progress"];
        return;
    }

    UIDocumentPickerViewController *picker = nil;
    if (@available(iOS 14.0, *)) {
        picker = [[UIDocumentPickerViewController alloc] initForOpeningContentTypes:@[UTTypeData, UTTypeItem]
                                                                            asCopy:YES];
    } else {
        picker = [[UIDocumentPickerViewController alloc] initWithDocumentTypes:@[@"public.data", @"public.item"]
                                                                        inMode:UIDocumentPickerModeImport];
    }
    picker.delegate = self;
    picker.allowsMultipleSelection = NO;
    picker.modalPresentationStyle = UIModalPresentationFormSheet;
    [self appendLog:@"open document picker (Files / iCloud / On My iPhone)"];
    [self appendLog:@"   production: replace with server download by fileName"];
    [self presentViewController:picker animated:YES completion:nil];
}

- (void)documentPicker:(UIDocumentPickerViewController *)controller didPickDocumentsAtURLs:(NSArray<NSURL *> *)urls {
    NSURL *url = urls.firstObject;
    if (!url) {
        [self appendLog:@"❌ no file selected"];
        return;
    }

    BOOL accessed = [url startAccessingSecurityScopedResource];
    NSData *data = [NSData dataWithContentsOfURL:url];
    if (accessed) {
        [url stopAccessingSecurityScopedResource];
    }

    NSString *fileName = url.lastPathComponent;
    if (!data.length) {
        [self appendLogFormat:@"❌ read file failed: %@", fileName];
        return;
    }

    self.pickedResourceFileName = fileName;
    self.pickedResourceFileData = data;
    [self appendLogFormat:@"picked: %@ (%.1f KB)", fileName, data.length / 1024.0];

    __weak typeof(self) weakSelf = self;
    [self queryMissingResourceFiles:^(NSArray<NSString *> *fileList, NSError *error) {
        if (error) {
            [weakSelf appendLog:@"⚠️ missing list query failed, skip sync"];
            return;
        }
        if (![fileList containsObject:fileName]) {
            [weakSelf appendLogFormat:@"⚠️ %@ not in missing list, abort", fileName];
            if (fileList.count == 0) {
                [weakSelf appendLog:@"   device resources are complete (empty list)"];
            } else {
                [weakSelf appendLog:@"   device expects:"];
                for (NSString *name in fileList) {
                    [weakSelf appendLogFormat:@"     · %@", name];
                }
            }
            return;
        }

        [weakSelf appendLogFormat:@"✅ %@ in missing list, start sync", fileName];
        weakSelf.resourceUpdateInProgress = YES;
        [weakSelf syncResourceFileWithName:fileName binData:data completion:^{
            weakSelf.resourceUpdateInProgress = NO;
        }];
    }];
}

- (void)documentPickerWasCancelled:(UIDocumentPickerViewController *)controller {
    [self appendLog:@"document picker cancelled"];
}

#pragma mark - File data

- (nullable NSData *)resourceFileDataForFileName:(NSString *)fileName {
    // Demo: bundled sample file under TP_resource/.
    NSData *bundled = [self bundledResourceDataForFileName:fileName];
    if (bundled.length) {
        [self appendLogFormat:@"use bundled file: %@ (%.1f KB)", fileName, bundled.length / 1024.0];
        return bundled;
    }

    // Demo fallback: user-picked local file (same role as server download in production).
    if (self.pickedResourceFileName.length && self.pickedResourceFileData.length &&
        [self.pickedResourceFileName isEqualToString:fileName]) {
        [self appendLogFormat:@"use picked file: %@ (%.1f KB)", fileName, self.pickedResourceFileData.length / 1024.0];
        return self.pickedResourceFileData;
    }

    // Integrators: download from server by exact fileName from getNeededFileListFinished.
    // NSURLSessionDataTask / your file CDN → NSData → syncResourceFileName
    return nil;
}

- (nullable NSData *)bundledResourceDataForFileName:(NSString *)fileName {
    NSString *path = [[NSBundle mainBundle] pathForResource:fileName ofType:nil];
    if (!path.length) { return nil; }

    NSError *readError = nil;
    NSData *data = [NSData dataWithContentsOfFile:path options:NSDataReadingUncached error:&readError];
    if (!data.length) {
        [self appendLogFormat:@"❌ read bundled resource failed: %@", readError.localizedDescription ?: @"unknown"];
    }
    return data;
}

#pragma mark - Helpers

- (void)ensureTouchControl:(void (^)(BOOL supported))completion {
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator setTime:[NSDate date] success:^(NSDictionary *featureList) {
        BOOL touchControl = [[featureList objectForKey:QCBandFeatureTouchControl] boolValue];
        if (completion) { completion(touchControl); }
    } failed:^{
        [weakSelf appendLog:@"❌ setTime failed"];
        if (completion) { completion(NO); }
    }];
}

@end
