//
//  QCSampleDisplayViewController.m
//  QCBandSDKDemo
//
//  Created by zhong on 2026/8/4.
//
//  Display SDK sample.
//  显示相关 SDK 示例。
//

#import "QCSampleDisplayViewController.h"
#import "QCSampleLocalization.h"
#import "QCSampleToast.h"
#import <QCBandSDK/QCSDKCmdCreator.h>
#import <QCBandSDK/QCDimingTimeInfo.h>

#pragma mark - Value ranges / 传值范围

static const NSInteger kQCSampleBoolMin = 0;
static const NSInteger kQCSampleBoolMax = 1;
/// Brightness protocol level: 1～10 => 10%～100%.
/// 亮度协议等级：1～10 => 10%～100%。
static const NSInteger kQCSampleBrightnessMin = 1;
static const NSInteger kQCSampleBrightnessMax = 10;
/// Homepage style common values: 1 / 2 (also accept 0 for some firmwares).
/// 首页样式常见取值：1 / 2（部分固件也接受 0）。
static const NSInteger kQCSampleStyleMin = 0;
static const NSInteger kQCSampleStyleMax = 2;
/// Default screen-on seconds when device does not report min/max.
/// 设备未回报最小/最大亮屏时长时的默认区间。
static const NSInteger kQCSampleLightingSecMinDefault = 4;
static const NSInteger kQCSampleLightingSecMaxDefault = 10;
static const NSInteger kQCSampleHomePageTypeMin = 0;
static const NSInteger kQCSampleHomePageTypeMax = 4;
static const NSInteger kQCSampleTransparencyMin = 0;
static const NSInteger kQCSampleTransparencyMax = 100;
/// Always-on screen: 1=off, 2=on.
/// 常亮屏：1=关，2=开。
static const NSInteger kQCSampleAllTimeScreenMin = 1;
static const NSInteger kQCSampleAllTimeScreenMax = 2;
/// Dial index: 0=wallpaper, then 1…N.
/// 表盘索引：0=壁纸，其后 1…N。
static const NSInteger kQCSampleDialIndexMin = 0;
static const NSInteger kQCSampleDialIndexMax = 31;
/// Flip / palm hand: 1=left, 2=right.
/// 抬腕/覆掌佩戴手：1=左，2=右。
static const NSInteger kQCSampleHandMin = 1;
static const NSInteger kQCSampleHandMax = 2;

@interface QCSampleDisplayViewController ()
@property (nonatomic, assign) NSInteger lastBrightness;
@property (nonatomic, assign) BOOL lastClockShowing;
@property (nonatomic, assign) BOOL lastPortrait;
@property (nonatomic, assign) BOOL lastLeftHand;
@property (nonatomic, assign) NSInteger lastStyle;
@property (nonatomic, assign) NSInteger lastLightingSeconds;
@property (nonatomic, assign) NSInteger lastHomePageType;
@property (nonatomic, assign) NSInteger lastTransparency;
@property (nonatomic, assign) NSInteger lastAllTimeScreen;
@property (nonatomic, assign) NSInteger lightingSecMin;
@property (nonatomic, assign) NSInteger lightingSecMax;
@property (nonatomic, assign) NSInteger lastDialIndex;
@property (nonatomic, assign) BOOL lastPalmEnable;
@property (nonatomic, assign) NSInteger lastPalmHand;
@end

@implementation QCSampleDisplayViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = QCSampleLocalized(QCSampleLocalizedKeyItemDisplay);
    self.lastBrightness = 3;
    self.lastClockShowing = YES;
    self.lastPortrait = YES;
    self.lastLeftHand = YES;
    self.lastStyle = 1;
    self.lastLightingSeconds = 5;
    self.lastHomePageType = 1;
    self.lastTransparency = 100;
    self.lastAllTimeScreen = 1;
    self.lightingSecMin = kQCSampleLightingSecMinDefault;
    self.lightingSecMax = kQCSampleLightingSecMaxDefault;
    self.lastDialIndex = 0;
    self.lastPalmEnable = YES;
    self.lastPalmHand = 1;
}

- (void)setupActions {
    __weak typeof(self) weakSelf = self;

    [self beginActionSection:QCSampleLocalized(QCSampleLocalizedKeyDisplaySectionBrightness)];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyDisplayGetBrightness) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf getBrightness];
    }];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyDisplaySetBrightness) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf presentSetBrightnessAlert];
    }];

    [self beginActionSection:QCSampleLocalized(QCSampleLocalizedKeyDisplaySectionClock)];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyDisplayGetClock) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf getDisplayClock];
    }];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyDisplaySetClock) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf presentSetClockAlert];
    }];

    [self beginActionSection:QCSampleLocalized(QCSampleLocalizedKeyDisplaySectionOrientation)];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyDisplayGetOrientation) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf getOrientation];
    }];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyDisplaySetOrientation) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf presentSetOrientationAlert];
    }];

    [self beginActionSection:QCSampleLocalized(QCSampleLocalizedKeyDisplaySectionStyle)];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyDisplayGetStyle) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf getStyle];
    }];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyDisplaySetStyle) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf presentSetStyleAlert];
    }];

    [self beginActionSection:QCSampleLocalized(QCSampleLocalizedKeyDisplaySectionTime)];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyDisplayGetTime) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf getDisplayTime];
    }];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyDisplaySetTime) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf presentSetDisplayTimeAlert];
    }];

    [self beginActionSection:QCSampleLocalized(QCSampleLocalizedKeyDisplaySectionDial)];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyDisplayGetDial) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf getDialIndex];
    }];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyDisplaySetDial) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf presentSetDialAlert];
    }];

    [self beginActionSection:QCSampleLocalized(QCSampleLocalizedKeyDisplaySectionPalm)];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyDisplayGetPalm) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf getPalmScreen];
    }];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyDisplaySetPalm) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf presentSetPalmAlert];
    }];
}

#pragma mark - Brightness / 亮度

- (void)getBrightness {
    [self appendLogFormat:@"SDK getDeviceLightLevelWithCurrentLevel hint=%ld", (long)self.lastBrightness];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator getDeviceLightLevelWithCurrentLevel:self.lastBrightness success:^(NSInteger lightLevel) {
        weakSelf.lastBrightness = lightLevel;
        [weakSelf appendLogFormat:@"[Brightness] get success level=%ld", (long)lightLevel];
    } fail:^{
        [weakSelf appendLog:@"[Brightness] get failed"];
    }];
}

- (void)presentSetBrightnessAlert {
    UIAlertController *alert =
    [UIAlertController alertControllerWithTitle:QCSampleLocalized(QCSampleLocalizedKeyDisplaySetBrightness)
                                        message:nil
                                 preferredStyle:UIAlertControllerStyleAlert];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyDisplayBrightness)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyDisplayBrightnessHint,
                                                        (long)kQCSampleBrightnessMin,
                                                        (long)kQCSampleBrightnessMax)
                           text:self.lastBrightness];
    __weak typeof(self) weakSelf = self;
    [alert addAction:[UIAlertAction actionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyCommonCancel)
                                              style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyCommonOK)
                                              style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction *action) {
        NSInteger level = alert.textFields.firstObject.text.integerValue;
        if (![weakSelf validateInputValue:level
                                      min:kQCSampleBrightnessMin
                                      max:kQCSampleBrightnessMax
                               fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyDisplayBrightness)]) {
            return;
        }
        [weakSelf setBrightness:level];
    }]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)setBrightness:(NSInteger)level {
    [self appendLogFormat:@"SDK setDeviceLightLevel %ld", (long)level];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator setDeviceLightLevel:level success:^(NSInteger lightLevel) {
        weakSelf.lastBrightness = lightLevel;
        [weakSelf appendLogFormat:@"[Brightness] set success level=%ld", (long)lightLevel];
    } fail:^{
        [weakSelf appendLog:@"[Brightness] set failed"];
    }];
}

#pragma mark - Clock / 钟表界面

- (void)getDisplayClock {
    [self appendLogFormat:@"SDK getScreenHomePageShowingClock hint=%@", self.lastClockShowing ? @"YES" : @"NO"];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator getScreenHomePageShowingClockWithCurrentState:self.lastClockShowing success:^(BOOL showing) {
        weakSelf.lastClockShowing = showing;
        [weakSelf appendLogFormat:@"[Clock] get success showing=%@", showing ? @"YES" : @"NO"];
    } fail:^{
        [weakSelf appendLog:@"[Clock] get failed"];
    }];
}

- (void)presentSetClockAlert {
    UIAlertController *alert =
    [UIAlertController alertControllerWithTitle:QCSampleLocalized(QCSampleLocalizedKeyDisplaySetClock)
                                        message:nil
                                 preferredStyle:UIAlertControllerStyleAlert];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyDisplayClockEnable)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyDisplayBoolHint,
                                                        (long)kQCSampleBoolMin,
                                                        (long)kQCSampleBoolMax)
                           text:self.lastClockShowing ? 1 : 0];
    __weak typeof(self) weakSelf = self;
    [alert addAction:[UIAlertAction actionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyCommonCancel)
                                              style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyCommonOK)
                                              style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction *action) {
        NSInteger enable = alert.textFields.firstObject.text.integerValue;
        if (![weakSelf validateInputValue:enable
                                      min:kQCSampleBoolMin
                                      max:kQCSampleBoolMax
                               fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyDisplayClockEnable)]) {
            return;
        }
        [weakSelf setDisplayClockShowing:(enable == 1)];
    }]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)setDisplayClockShowing:(BOOL)showing {
    [self appendLogFormat:@"SDK setScreenHomePageShowingClock %@", showing ? @"YES" : @"NO"];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator setScreenHomePageShowingClock:showing success:^(BOOL featureOn) {
        weakSelf.lastClockShowing = featureOn;
        [weakSelf appendLogFormat:@"[Clock] set success showing=%@", featureOn ? @"YES" : @"NO"];
    } fail:^{
        [weakSelf appendLog:@"[Clock] set failed"];
    }];
}

#pragma mark - Orientation / 横竖屏

- (void)getOrientation {
    [self appendLogFormat:@"SDK getScreenOrientationInfo hint portrait=%@ left=%@",
     self.lastPortrait ? @"YES" : @"NO",
     self.lastLeftHand ? @"YES" : @"NO"];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator getScreenOrientationInfoWithPortrait:self.lastPortrait
                                             leftHandWear:self.lastLeftHand
                                                  success:^(BOOL portrait, BOOL leftHand) {
        weakSelf.lastPortrait = portrait;
        weakSelf.lastLeftHand = leftHand;
        [weakSelf appendLogFormat:@"[Orientation] get success portrait=%@ leftHand=%@",
         portrait ? @"YES" : @"NO",
         leftHand ? @"YES" : @"NO"];
    } fail:^{
        [weakSelf appendLog:@"[Orientation] get failed"];
    }];
}

- (void)presentSetOrientationAlert {
    UIAlertController *alert =
    [UIAlertController alertControllerWithTitle:QCSampleLocalized(QCSampleLocalizedKeyDisplaySetOrientation)
                                        message:nil
                                 preferredStyle:UIAlertControllerStyleAlert];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyDisplayPortrait)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyDisplayPortraitHint,
                                                        (long)kQCSampleBoolMin,
                                                        (long)kQCSampleBoolMax)
                           text:self.lastPortrait ? 1 : 0];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyDisplayLeftHand)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyDisplayLeftHandHint,
                                                        (long)kQCSampleBoolMin,
                                                        (long)kQCSampleBoolMax)
                           text:self.lastLeftHand ? 1 : 0];
    __weak typeof(self) weakSelf = self;
    [alert addAction:[UIAlertAction actionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyCommonCancel)
                                              style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyCommonOK)
                                              style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction *action) {
        NSInteger portrait = alert.textFields[0].text.integerValue;
        NSInteger left = alert.textFields[1].text.integerValue;
        if (![weakSelf validateInputValue:portrait
                                      min:kQCSampleBoolMin
                                      max:kQCSampleBoolMax
                               fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyDisplayPortrait)] ||
            ![weakSelf validateInputValue:left
                                      min:kQCSampleBoolMin
                                      max:kQCSampleBoolMax
                               fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyDisplayLeftHand)]) {
            return;
        }
        [weakSelf setOrientationPortrait:(portrait == 1) leftHand:(left == 1)];
    }]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)setOrientationPortrait:(BOOL)portrait leftHand:(BOOL)leftHand {
    [self appendLogFormat:@"SDK setScreenOrientationInfo portrait=%@ left=%@",
     portrait ? @"YES" : @"NO",
     leftHand ? @"YES" : @"NO"];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator setScreenOrientationInfoWithPortrait:portrait
                                             leftHandWear:leftHand
                                                  success:^(BOOL p, BOOL left) {
        weakSelf.lastPortrait = p;
        weakSelf.lastLeftHand = left;
        [weakSelf appendLogFormat:@"[Orientation] set success portrait=%@ leftHand=%@",
         p ? @"YES" : @"NO",
         left ? @"YES" : @"NO"];
    } fail:^{
        [weakSelf appendLog:@"[Orientation] set failed"];
    }];
}

#pragma mark - Style / 首页样式

- (void)getStyle {
    [self appendLogFormat:@"SDK getScreenHomePageStyle hint=%ld", (long)self.lastStyle];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator getScreenHomePageStyleWithCurrentStyle:self.lastStyle success:^(NSInteger style) {
        weakSelf.lastStyle = style;
        [weakSelf appendLogFormat:@"[Style] get success style=%ld", (long)style];
    } fail:^{
        [weakSelf appendLog:@"[Style] get failed"];
    }];
}

- (void)presentSetStyleAlert {
    UIAlertController *alert =
    [UIAlertController alertControllerWithTitle:QCSampleLocalized(QCSampleLocalizedKeyDisplaySetStyle)
                                        message:nil
                                 preferredStyle:UIAlertControllerStyleAlert];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyDisplayStyle)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyDisplayStyleHint,
                                                        (long)kQCSampleStyleMin,
                                                        (long)kQCSampleStyleMax)
                           text:self.lastStyle];
    __weak typeof(self) weakSelf = self;
    [alert addAction:[UIAlertAction actionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyCommonCancel)
                                              style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyCommonOK)
                                              style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction *action) {
        NSInteger style = alert.textFields.firstObject.text.integerValue;
        if (![weakSelf validateInputValue:style
                                      min:kQCSampleStyleMin
                                      max:kQCSampleStyleMax
                               fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyDisplayStyle)]) {
            return;
        }
        [weakSelf setStyle:style];
    }]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)setStyle:(NSInteger)style {
    [self appendLogFormat:@"SDK setScreenHomePageStyle %ld", (long)style];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator setScreenHomePageStyle:style success:^(NSInteger homePageStyle) {
        weakSelf.lastStyle = homePageStyle;
        [weakSelf appendLogFormat:@"[Style] set success style=%ld", (long)homePageStyle];
    } fail:^{
        [weakSelf appendLog:@"[Style] set failed"];
    }];
}

#pragma mark - Display Time / 亮屏与首页参数

/// setHomePageScreenOpType (opType 1=read, 2=write).
/// setHomePageScreenOpType（1=读，2=写）。
- (void)getDisplayTime {
    [self appendLog:@"SDK setHomePageScreenOpType opType=1 (read)"];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator setHomePageScreenOpType:1 info:nil success:^(QCDimingTimeInfo *info) {
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf) { return; }
        [strongSelf applyDisplayTimeInfo:info];
        [strongSelf appendLogFormat:
         @"[DisplayTime] get success lighting=%ld type=%ld alpha=%ld picture=%ld allTime=%ld supportAOD=%@ min=%ld max=%ld",
         (long)info.lightingSeconds,
         (long)info.homePageType,
         (long)info.transparency,
         (long)info.pictureType,
         (long)info.allTimeScreen,
         info.allTimeScreenEnable ? @"YES" : @"NO",
         (long)info.minScreenTime,
         (long)info.maxScreenTime];
    } fail:^{
        [weakSelf appendLog:@"[DisplayTime] get failed"];
    }];
}

- (void)applyDisplayTimeInfo:(QCDimingTimeInfo *)info {
    if (!info) { return; }
    self.lastLightingSeconds = info.lightingSeconds;
    self.lastHomePageType = info.homePageType;
    self.lastTransparency = info.transparency;
    self.lastAllTimeScreen = info.allTimeScreen > 0 ? info.allTimeScreen : 1;
    if (info.minScreenTime > 0 && info.maxScreenTime >= info.minScreenTime) {
        self.lightingSecMin = info.minScreenTime;
        self.lightingSecMax = info.maxScreenTime;
    }
}

- (void)presentSetDisplayTimeAlert {
    UIAlertController *alert =
    [UIAlertController alertControllerWithTitle:QCSampleLocalized(QCSampleLocalizedKeyDisplaySetTime)
                                        message:nil
                                 preferredStyle:UIAlertControllerStyleAlert];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyDisplayLightingSec)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyDisplayLightingSecHint,
                                                        (long)self.lightingSecMin,
                                                        (long)self.lightingSecMax)
                           text:self.lastLightingSeconds];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyDisplayHomeType)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyDisplayHomeTypeHint,
                                                        (long)kQCSampleHomePageTypeMin,
                                                        (long)kQCSampleHomePageTypeMax)
                           text:self.lastHomePageType];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyDisplayTransparency)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyDisplayTransparencyHint,
                                                        (long)kQCSampleTransparencyMin,
                                                        (long)kQCSampleTransparencyMax)
                           text:self.lastTransparency];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyDisplayAllTimeScreen)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyDisplayAllTimeScreenHint,
                                                        (long)kQCSampleAllTimeScreenMin,
                                                        (long)kQCSampleAllTimeScreenMax)
                           text:self.lastAllTimeScreen];
    __weak typeof(self) weakSelf = self;
    [alert addAction:[UIAlertAction actionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyCommonCancel)
                                              style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyCommonOK)
                                              style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction *action) {
        NSInteger lighting = alert.textFields[0].text.integerValue;
        NSInteger type = alert.textFields[1].text.integerValue;
        NSInteger alpha = alert.textFields[2].text.integerValue;
        NSInteger aod = alert.textFields[3].text.integerValue;
        if (![weakSelf validateInputValue:lighting
                                      min:weakSelf.lightingSecMin
                                      max:weakSelf.lightingSecMax
                               fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyDisplayLightingSec)] ||
            ![weakSelf validateInputValue:type
                                      min:kQCSampleHomePageTypeMin
                                      max:kQCSampleHomePageTypeMax
                               fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyDisplayHomeType)] ||
            ![weakSelf validateInputValue:alpha
                                      min:kQCSampleTransparencyMin
                                      max:kQCSampleTransparencyMax
                               fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyDisplayTransparency)] ||
            ![weakSelf validateInputValue:aod
                                      min:kQCSampleAllTimeScreenMin
                                      max:kQCSampleAllTimeScreenMax
                               fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyDisplayAllTimeScreen)]) {
            return;
        }
        [weakSelf setDisplayTimeLighting:lighting homeType:type transparency:alpha allTimeScreen:aod];
    }]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)setDisplayTimeLighting:(NSInteger)lighting
                      homeType:(NSInteger)homeType
                  transparency:(NSInteger)transparency
                allTimeScreen:(NSInteger)allTimeScreen {
    QCDimingTimeInfo *info = [[QCDimingTimeInfo alloc] init];
    info.lightingSeconds = lighting;
    info.homePageType = homeType;
    info.transparency = transparency;
    info.allTimeScreen = allTimeScreen;
    [self appendLogFormat:@"SDK setHomePageScreenOpType opType=2 lighting=%ld type=%ld alpha=%ld aod=%ld",
     (long)lighting, (long)homeType, (long)transparency, (long)allTimeScreen];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator setHomePageScreenOpType:2 info:info success:^(QCDimingTimeInfo *result) {
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf) { return; }
        [strongSelf applyDisplayTimeInfo:result ?: info];
        [strongSelf appendLog:@"[DisplayTime] set success"];
    } fail:^{
        [weakSelf appendLog:@"[DisplayTime] set failed"];
    }];
}

#pragma mark - Dial Index / 表盘索引

- (void)getDialIndex {
    [self appendLog:@"SDK getDialIndexWithFinshed"];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator getDialIndexWithFinshed:^(NSInteger index, NSError * _Nullable error) {
        if (error) {
            [weakSelf appendLogFormat:@"[Dial] get failed error=%@", error.localizedDescription ?: @"unknown"];
            return;
        }
        weakSelf.lastDialIndex = index;
        [weakSelf appendLogFormat:@"[Dial] get success index=%ld", (long)index];
    }];
}

- (void)presentSetDialAlert {
    UIAlertController *alert =
    [UIAlertController alertControllerWithTitle:QCSampleLocalized(QCSampleLocalizedKeyDisplaySetDial)
                                        message:nil
                                 preferredStyle:UIAlertControllerStyleAlert];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyDisplayDialIndex)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyDisplayDialIndexHint,
                                                        (long)kQCSampleDialIndexMin,
                                                        (long)kQCSampleDialIndexMax)
                           text:self.lastDialIndex];
    __weak typeof(self) weakSelf = self;
    [alert addAction:[UIAlertAction actionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyCommonCancel)
                                              style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyCommonOK)
                                              style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction *action) {
        NSInteger index = alert.textFields.firstObject.text.integerValue;
        if (![weakSelf validateInputValue:index
                                      min:kQCSampleDialIndexMin
                                      max:kQCSampleDialIndexMax
                               fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyDisplayDialIndex)]) {
            return;
        }
        [weakSelf setDialIndex:index];
    }]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)setDialIndex:(NSInteger)index {
    [self appendLogFormat:@"SDK setDialIndexWith %ld", (long)index];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator setDialIndexWith:index finshed:^(NSError * _Nullable error) {
        if (error) {
            [weakSelf appendLogFormat:@"[Dial] set failed error=%@", error.localizedDescription ?: @"unknown"];
            return;
        }
        weakSelf.lastDialIndex = index;
        [weakSelf appendLogFormat:@"[Dial] set success index=%ld", (long)index];
    }];
}

#pragma mark - Palm Screen / 抬腕覆掌

/// Normalize SDK flipType to Demo hand input: 1=left, 2=right.
/// 将 SDK 返回值规整为 Demo 佩戴手输入：1=左，2=右。
- (NSInteger)palmHandFromFlipType:(NSUInteger)flipType {
    if (flipType & (1u << 1)) {
        return 2; // right
    }
    if (flipType & (1u << 0)) {
        return 1; // left
    }
    return 1;
}
 
/// Band raise-to-wake via getFlipWristInfo / setFlipWristOn. Ring uses getFlipWristInfoFinshed.
/// 手环抬腕亮屏用 getFlipWristInfo / setFlipWristOn；戒指用 getFlipWristInfoFinshed。
- (void)getPalmScreen {
    [self appendLog:@"SDK getFlipWristInfo"];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator getFlipWristInfo:^(BOOL isOn, NSUInteger flipType) {
        weakSelf.lastPalmEnable = isOn;
        weakSelf.lastPalmHand = [weakSelf palmHandFromFlipType:flipType];
        [weakSelf appendLogFormat:@"[Palm] get success enable=%@ hand=%ld (raw flipType=%lu)",
         isOn ? @"YES" : @"NO",
         (long)weakSelf.lastPalmHand,
         (unsigned long)flipType];
    } fail:^{
        [weakSelf appendLog:@"[Palm] get failed"];
    }];
}

- (void)presentSetPalmAlert {
    UIAlertController *alert =
    [UIAlertController alertControllerWithTitle:QCSampleLocalized(QCSampleLocalizedKeyDisplaySetPalm)
                                        message:nil
                                 preferredStyle:UIAlertControllerStyleAlert];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyDisplayPalmEnable)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyDisplayBoolHint,
                                                        (long)kQCSampleBoolMin,
                                                        (long)kQCSampleBoolMax)
                           text:self.lastPalmEnable ? 1 : 0];
    NSInteger handDefault = (self.lastPalmHand == 2) ? 2 : 1;
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyDisplayPalmHand)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyDisplayPalmHandHint,
                                                        (long)kQCSampleHandMin,
                                                        (long)kQCSampleHandMax)
                           text:handDefault];
    __weak typeof(self) weakSelf = self;
    [alert addAction:[UIAlertAction actionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyCommonCancel)
                                              style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyCommonOK)
                                              style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction *action) {
        NSInteger enable = alert.textFields[0].text.integerValue;
        NSInteger hand = alert.textFields[1].text.integerValue;
        if (![weakSelf validateInputValue:enable
                                      min:kQCSampleBoolMin
                                      max:kQCSampleBoolMax
                               fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyDisplayPalmEnable)] ||
            ![weakSelf validateInputValue:hand
                                      min:kQCSampleHandMin
                                      max:kQCSampleHandMax
                               fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyDisplayPalmHand)]) {
            return;
        }
        [weakSelf setPalmEnable:(enable == 1) hand:hand];
    }]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)setPalmEnable:(BOOL)enable hand:(NSInteger)hand {
    [self appendLogFormat:@"SDK setFlipWristOn enable=%@ hand=%ld", enable ? @"YES" : @"NO", (long)hand];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator setFlipWristOn:enable flipType:(NSUInteger)hand success:^(BOOL featureOn, NSUInteger flipType) {
        weakSelf.lastPalmEnable = featureOn;
        weakSelf.lastPalmHand = [weakSelf palmHandFromFlipType:flipType > 0 ? flipType : (NSUInteger)hand];
        [weakSelf appendLogFormat:@"[Palm] set success enable=%@ hand=%ld",
         featureOn ? @"YES" : @"NO",
         (long)weakSelf.lastPalmHand];
    } fail:^{
        [weakSelf appendLog:@"[Palm] set failed"];
    }];
}

@end
