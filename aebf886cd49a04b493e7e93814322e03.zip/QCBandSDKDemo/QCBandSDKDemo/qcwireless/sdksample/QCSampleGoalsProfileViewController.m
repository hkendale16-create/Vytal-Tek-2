//
//  QCSampleGoalsProfileViewController.m
//  QCBandSDKDemo
//
//  Created by zhong on 2026/8/4.
//
//  Goals & user profile SDK sample with explicit value-range validation.
//  目标与个人资料 SDK 示例，含明确传值范围校验。
//

#import "QCSampleGoalsProfileViewController.h"
#import "QCSampleLocalization.h"
#import "QCSampleToast.h"
#import <QCBandSDK/QCSDKCmdCreator.h>

#pragma mark - Value ranges / 传值范围

/// Protocol / product ranges for integrator reference.
/// 协议与业务传值范围，供集成方对照。
///
/// Target fields follow protocol encoding width:
/// step/calorie/distance = 3-byte LE (0..16,777,215); sport/sleep = 2-byte (0..65,535).
/// 目标字段按协议编码宽度：步数/卡路里/距离 3 字节；运动/睡眠时长 2 字节。
///
/// Profile numeric fields are 1-byte (0..255); age/height/weight use practical product ranges.
/// 个人资料数值字段为单字节；年龄/身高/体重采用业务常用区间。
static const NSInteger kQCSampleStepMin = 0;
static const NSInteger kQCSampleStepMax = 16777215;
static const NSInteger kQCSampleCalorieMin = 0;
static const NSInteger kQCSampleCalorieMax = 16777215;
static const NSInteger kQCSampleDistanceMin = 0;
static const NSInteger kQCSampleDistanceMax = 16777215;
static const NSInteger kQCSampleSportMinuteMin = 0;
static const NSInteger kQCSampleSportMinuteMax = 65535;
static const NSInteger kQCSampleSleepMinuteMin = 0;
static const NSInteger kQCSampleSleepMinuteMax = 65535;

static const NSInteger kQCSampleAgeMin = 1;
static const NSInteger kQCSampleAgeMax = 120;
static const NSInteger kQCSampleHeightMin = 50;
static const NSInteger kQCSampleHeightMax = 250;
static const NSInteger kQCSampleWeightMin = 10;
static const NSInteger kQCSampleWeightMax = 250;
static const NSInteger kQCSampleSbpMin = 0;
static const NSInteger kQCSampleSbpMax = 255;
static const NSInteger kQCSampleDbpMin = 0;
static const NSInteger kQCSampleDbpMax = 255;
static const NSInteger kQCSampleHrAlarmMin = 0;
static const NSInteger kQCSampleHrAlarmMax = 255;
static const NSInteger kQCSampleGenderMin = 0;
static const NSInteger kQCSampleGenderMax = 1;

@interface QCSampleGoalsProfileViewController ()
@property (nonatomic, assign) BOOL lastIsTwentyfour;
@property (nonatomic, assign) BOOL lastIsMetric;
@property (nonatomic, assign) NSInteger lastGender;
@property (nonatomic, assign) NSInteger lastAge;
@property (nonatomic, assign) NSInteger lastHeight;
@property (nonatomic, assign) NSInteger lastWeight;
@property (nonatomic, assign) NSInteger lastSbp;
@property (nonatomic, assign) NSInteger lastDbp;
@property (nonatomic, assign) NSInteger lastHrAlarm;

@property (nonatomic, assign) NSInteger lastStep;
@property (nonatomic, assign) NSInteger lastCalorie;
@property (nonatomic, assign) NSInteger lastDistance;
@property (nonatomic, assign) NSInteger lastSportMinute;
@property (nonatomic, assign) NSInteger lastSleepMinute;
@end

@implementation QCSampleGoalsProfileViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = QCSampleLocalized(QCSampleLocalizedKeyItemGoalsProfile);
    [self resetCachedDefaults];
}

- (void)resetCachedDefaults {
    self.lastIsTwentyfour = YES;
    self.lastIsMetric = YES;
    self.lastGender = 0;
    self.lastAge = 30;
    self.lastHeight = 170;
    self.lastWeight = 65;
    self.lastSbp = 115;
    self.lastDbp = 75;
    self.lastHrAlarm = 160;

    // 常规演示默认值（非协议上限）
    // Conventional demo defaults (not protocol maxima)
    self.lastStep = 8000;
    self.lastCalorie = 300;
    self.lastDistance = 2000;
    self.lastSportMinute = 30;
    self.lastSleepMinute = 480;
}

- (void)setupActions {
    __weak typeof(self) weakSelf = self;

    [self beginActionSection:QCSampleLocalized(QCSampleLocalizedKeyGoalsSectionTarget)];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyGoalsGetTarget) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf getStepTarget];
    }];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyGoalsSetTarget) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf presentSetTargetAlert];
    }];

    [self beginActionSection:QCSampleLocalized(QCSampleLocalizedKeyGoalsSectionProfile)];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyGoalsGetProfile) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf getUserProfile];
    }];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyGoalsSetProfile) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf presentSetProfileAlert];
    }];
}

#pragma mark - Target / 目标

- (void)getStepTarget {
    [self appendLog:@"SDK getStepTargetInfoWithSuccess"];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator getStepTargetInfoWithSuccess:^(NSInteger stepTarget,
                                                    NSInteger calorieTarget,
                                                    NSInteger distanceTarget,
                                                    NSInteger sportDuration,
                                                    NSInteger sleepDuration) {
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf) { return; }
        strongSelf.lastStep = stepTarget;
        strongSelf.lastCalorie = calorieTarget;
        strongSelf.lastDistance = distanceTarget;
        strongSelf.lastSportMinute = sportDuration;
        strongSelf.lastSleepMinute = sleepDuration;
        [strongSelf appendLogFormat:
         @"[Target] get success step=%ld calorie=%ld distance=%ld sportMinute=%ld sleepMinute=%ld",
         (long)stepTarget, (long)calorieTarget, (long)distanceTarget,
         (long)sportDuration, (long)sleepDuration];
    } fail:^{
        [weakSelf appendLog:@"[Target] get failed"];
    }];
}

- (void)presentSetTargetAlert {
    UIAlertController *alert =
    [UIAlertController alertControllerWithTitle:QCSampleLocalized(QCSampleLocalizedKeyGoalsSetTarget)
                                        message:nil
                                 preferredStyle:UIAlertControllerStyleAlert];

    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyGoalsStep)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyGoalsStepHint,
                                                        (long)kQCSampleStepMin,
                                                        (long)kQCSampleStepMax)
                           text:self.lastStep];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyGoalsCalorie)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyGoalsCalorieHint,
                                                        (long)kQCSampleCalorieMin,
                                                        (long)kQCSampleCalorieMax)
                           text:self.lastCalorie];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyGoalsDistance)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyGoalsDistanceHint,
                                                        (long)kQCSampleDistanceMin,
                                                        (long)kQCSampleDistanceMax)
                           text:self.lastDistance];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyGoalsSportMinute)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyGoalsSportMinuteHint,
                                                        (long)kQCSampleSportMinuteMin,
                                                        (long)kQCSampleSportMinuteMax)
                           text:self.lastSportMinute];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyGoalsSleepMinute)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyGoalsSleepMinuteHint,
                                                        (long)kQCSampleSleepMinuteMin,
                                                        (long)kQCSampleSleepMinuteMax)
                           text:self.lastSleepMinute];

    __weak typeof(self) weakSelf = self;
    [alert addAction:[UIAlertAction actionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyCommonCancel)
                                              style:UIAlertActionStyleCancel
                                            handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyCommonOK)
                                              style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction * _Nonnull action) {
        [weakSelf handleSetTargetFromAlert:alert];
    }]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)handleSetTargetFromAlert:(UIAlertController *)alert {
    NSInteger step = 0, calorie = 0, distance = 0, sportMinute = 0, sleepMinute = 0;
    if (![self parseIntFromField:alert.textFields[0] into:&step] ||
        ![self parseIntFromField:alert.textFields[1] into:&calorie] ||
        ![self parseIntFromField:alert.textFields[2] into:&distance] ||
        ![self parseIntFromField:alert.textFields[3] into:&sportMinute] ||
        ![self parseIntFromField:alert.textFields[4] into:&sleepMinute]) {
        [QCSampleToast showCenterWithText:QCSampleLocalized(QCSampleLocalizedKeyGoalsInvalidNumber)];
        return;
    }

    if (![self validateInputValue:step
                              min:kQCSampleStepMin
                              max:kQCSampleStepMax
                       fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyGoalsStep)] ||
        ![self validateInputValue:calorie
                              min:kQCSampleCalorieMin
                              max:kQCSampleCalorieMax
                       fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyGoalsCalorie)] ||
        ![self validateInputValue:distance
                              min:kQCSampleDistanceMin
                              max:kQCSampleDistanceMax
                       fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyGoalsDistance)] ||
        ![self validateInputValue:sportMinute
                              min:kQCSampleSportMinuteMin
                              max:kQCSampleSportMinuteMax
                       fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyGoalsSportMinute)] ||
        ![self validateInputValue:sleepMinute
                              min:kQCSampleSleepMinuteMin
                              max:kQCSampleSleepMinuteMax
                       fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyGoalsSleepMinute)]) {
        return;
    }

    self.lastStep = step;
    self.lastCalorie = calorie;
    self.lastDistance = distance;
    self.lastSportMinute = sportMinute;
    self.lastSleepMinute = sleepMinute;
    [self setStepTarget:step
                calorie:calorie
               distance:distance
            sportMinute:sportMinute
            sleepMinute:sleepMinute];
}

- (void)setStepTarget:(NSInteger)step
              calorie:(NSInteger)calorie
             distance:(NSInteger)distance
          sportMinute:(NSInteger)sportMinute
          sleepMinute:(NSInteger)sleepMinute {
    [self appendLogFormat:
     @"SDK setStepTarget step=%ld calorie=%ld distance=%ld sportMinute=%ld sleepMinute=%ld",
     (long)step, (long)calorie, (long)distance, (long)sportMinute, (long)sleepMinute];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator setStepTarget:step
                     calorieTarget:calorie
                    distanceTarget:distance
               sportDurationTarget:sportMinute
               sleepDurationTarget:sleepMinute
                           success:^{
        [weakSelf appendLog:@"[Target] set success"];
    } fail:^{
        [weakSelf appendLog:@"[Target] set failed"];
    }];
}

#pragma mark - Profile / 个人资料

- (void)getUserProfile {
    [self appendLog:@"SDK getTimeFormatInfo"];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator getTimeFormatInfo:^(BOOL isTwentyfour,
                                         BOOL isMetricSystem,
                                         NSInteger gender,
                                         NSInteger age,
                                         NSInteger height,
                                         NSInteger weight,
                                         NSInteger sbpBase,
                                         NSInteger dbpBase,
                                         NSInteger hrAlarmValue) {
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf) { return; }
        strongSelf.lastIsTwentyfour = isTwentyfour;
        strongSelf.lastIsMetric = isMetricSystem;
        strongSelf.lastGender = gender;
        strongSelf.lastAge = age;
        strongSelf.lastHeight = height;
        strongSelf.lastWeight = weight;
        strongSelf.lastSbp = sbpBase;
        strongSelf.lastDbp = dbpBase;
        strongSelf.lastHrAlarm = hrAlarmValue;
        [strongSelf appendLogFormat:
         @"[Profile] get success is24=%@ metric=%@ gender=%ld age=%ld height=%ld weight=%ld sbp=%ld dbp=%ld hrAlarm=%ld",
         isTwentyfour ? @"YES" : @"NO",
         isMetricSystem ? @"YES" : @"NO",
         (long)gender, (long)age, (long)height, (long)weight,
         (long)sbpBase, (long)dbpBase, (long)hrAlarmValue];
    } fail:^{
        [weakSelf appendLog:@"[Profile] get failed"];
    }];
}

- (void)presentSetProfileAlert {
    UIAlertController *alert =
    [UIAlertController alertControllerWithTitle:QCSampleLocalized(QCSampleLocalizedKeyGoalsSetProfile)
                                        message:nil
                                 preferredStyle:UIAlertControllerStyleAlert];

    // 0=is24(1/0), 1=metric(1/0), 2=gender(0/1), 3=age, 4=height, 5=weight, 6=sbp, 7=dbp, 8=hrAlarm
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyGoalsIs24)
                    placeholder:QCSampleLocalized(QCSampleLocalizedKeyGoalsIs24Hint)
                           text:self.lastIsTwentyfour ? 1 : 0];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyGoalsMetric)
                    placeholder:QCSampleLocalized(QCSampleLocalizedKeyGoalsMetricHint)
                           text:self.lastIsMetric ? 1 : 0];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyGoalsGender)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyGoalsGenderHint,
                                                        (long)kQCSampleGenderMin,
                                                        (long)kQCSampleGenderMax)
                           text:self.lastGender];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyGoalsAge)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyGoalsAgeHint,
                                                        (long)kQCSampleAgeMin,
                                                        (long)kQCSampleAgeMax)
                           text:self.lastAge];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyGoalsHeight)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyGoalsHeightHint,
                                                        (long)kQCSampleHeightMin,
                                                        (long)kQCSampleHeightMax)
                           text:self.lastHeight];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyGoalsWeight)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyGoalsWeightHint,
                                                        (long)kQCSampleWeightMin,
                                                        (long)kQCSampleWeightMax)
                           text:self.lastWeight];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyGoalsSbp)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyGoalsSbpHint,
                                                        (long)kQCSampleSbpMin,
                                                        (long)kQCSampleSbpMax)
                           text:self.lastSbp];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyGoalsDbp)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyGoalsDbpHint,
                                                        (long)kQCSampleDbpMin,
                                                        (long)kQCSampleDbpMax)
                           text:self.lastDbp];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyGoalsHrAlarm)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyGoalsHrAlarmHint,
                                                        (long)kQCSampleHrAlarmMin,
                                                        (long)kQCSampleHrAlarmMax)
                           text:self.lastHrAlarm];

    __weak typeof(self) weakSelf = self;
    [alert addAction:[UIAlertAction actionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyCommonCancel)
                                              style:UIAlertActionStyleCancel
                                            handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyCommonOK)
                                              style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction * _Nonnull action) {
        [weakSelf handleSetProfileFromAlert:alert];
    }]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)handleSetProfileFromAlert:(UIAlertController *)alert {
    NSInteger is24Flag = 0, metricFlag = 0, gender = 0, age = 0, height = 0, weight = 0, sbp = 0, dbp = 0, hrAlarm = 0;
    if (![self parseIntFromField:alert.textFields[0] into:&is24Flag] ||
        ![self parseIntFromField:alert.textFields[1] into:&metricFlag] ||
        ![self parseIntFromField:alert.textFields[2] into:&gender] ||
        ![self parseIntFromField:alert.textFields[3] into:&age] ||
        ![self parseIntFromField:alert.textFields[4] into:&height] ||
        ![self parseIntFromField:alert.textFields[5] into:&weight] ||
        ![self parseIntFromField:alert.textFields[6] into:&sbp] ||
        ![self parseIntFromField:alert.textFields[7] into:&dbp] ||
        ![self parseIntFromField:alert.textFields[8] into:&hrAlarm]) {
        [QCSampleToast showCenterWithText:QCSampleLocalized(QCSampleLocalizedKeyGoalsInvalidNumber)];
        return;
    }

    if (![self validateInputValue:is24Flag
                              min:0
                              max:1
                       fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyGoalsIs24)] ||
        ![self validateInputValue:metricFlag
                              min:0
                              max:1
                       fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyGoalsMetric)]) {
        return;
    }

    if (![self validateInputValue:gender
                              min:kQCSampleGenderMin
                              max:kQCSampleGenderMax
                       fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyGoalsGender)] ||
        ![self validateInputValue:age
                              min:kQCSampleAgeMin
                              max:kQCSampleAgeMax
                       fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyGoalsAge)] ||
        ![self validateInputValue:height
                              min:kQCSampleHeightMin
                              max:kQCSampleHeightMax
                       fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyGoalsHeight)] ||
        ![self validateInputValue:weight
                              min:kQCSampleWeightMin
                              max:kQCSampleWeightMax
                       fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyGoalsWeight)] ||
        ![self validateInputValue:sbp
                              min:kQCSampleSbpMin
                              max:kQCSampleSbpMax
                       fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyGoalsSbp)] ||
        ![self validateInputValue:dbp
                              min:kQCSampleDbpMin
                              max:kQCSampleDbpMax
                       fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyGoalsDbp)] ||
        ![self validateInputValue:hrAlarm
                              min:kQCSampleHrAlarmMin
                              max:kQCSampleHrAlarmMax
                       fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyGoalsHrAlarm)]) {
        return;
    }

    BOOL is24 = (is24Flag == 1);
    BOOL metric = (metricFlag == 1);
    self.lastIsTwentyfour = is24;
    self.lastIsMetric = metric;
    self.lastGender = gender;
    self.lastAge = age;
    self.lastHeight = height;
    self.lastWeight = weight;
    self.lastSbp = sbp;
    self.lastDbp = dbp;
    self.lastHrAlarm = hrAlarm;
    [self setUserProfileIs24:is24
                      metric:metric
                      gender:gender
                         age:age
                      height:height
                      weight:weight
                         sbp:sbp
                         dbp:dbp
                     hrAlarm:hrAlarm];
}

- (void)setUserProfileIs24:(BOOL)is24
                    metric:(BOOL)metric
                    gender:(NSInteger)gender
                       age:(NSInteger)age
                    height:(NSInteger)height
                    weight:(NSInteger)weight
                       sbp:(NSInteger)sbp
                       dbp:(NSInteger)dbp
                   hrAlarm:(NSInteger)hrAlarm {
    [self appendLogFormat:
     @"SDK setTimeFormatTwentyfourHourFormat is24=%@ metric=%@ gender=%ld age=%ld height=%ld weight=%ld sbp=%ld dbp=%ld hrAlarm=%ld",
     is24 ? @"YES" : @"NO",
     metric ? @"YES" : @"NO",
     (long)gender, (long)age, (long)height, (long)weight,
     (long)sbp, (long)dbp, (long)hrAlarm];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator setTimeFormatTwentyfourHourFormat:is24
                                          metricSystem:metric
                                                gender:gender
                                                   age:age
                                                height:height
                                                weight:weight
                                               sbpBase:sbp
                                               dbpBase:dbp
                                          hrAlarmValue:hrAlarm
                                               success:^(BOOL twentyfourHourFormat,
                                                         BOOL metricSystem,
                                                         NSInteger rspGender,
                                                         NSInteger rspAge,
                                                         NSInteger rspHeight,
                                                         NSInteger rspWeight,
                                                         NSInteger rspSbp,
                                                         NSInteger rspDbp,
                                                         NSInteger rspHrAlarm) {
        [weakSelf appendLogFormat:
         @"[Profile] set success is24=%@ metric=%@ gender=%ld age=%ld height=%ld weight=%ld sbp=%ld dbp=%ld hrAlarm=%ld",
         twentyfourHourFormat ? @"YES" : @"NO",
         metricSystem ? @"YES" : @"NO",
         (long)rspGender, (long)rspAge, (long)rspHeight, (long)rspWeight,
         (long)rspSbp, (long)rspDbp, (long)rspHrAlarm];
    } fail:^{
        [weakSelf appendLog:@"[Profile] set failed"];
    }];
}

#pragma mark - Validation helpers / 校验辅助

- (BOOL)parseIntFromField:(UITextField *)field into:(NSInteger *)outValue {
    if (!field || !outValue) {
        return NO;
    }
    NSString *text = [field.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if (text.length == 0) {
        return NO;
    }
    NSScanner *scanner = [NSScanner scannerWithString:text];
    long long value = 0;
    if (![scanner scanLongLong:&value] || !scanner.isAtEnd) {
        return NO;
    }
    *outValue = (NSInteger)value;
    return YES;
}

@end
