//
//  QCSampleDisplayViewController.h
//  QCBandSDKDemo
//
//  Created by zhong on 2026/8/4.
//
//  Display SDK sample (brightness, clock, orientation, style, screen-on, dial, palm).
//  显示相关 SDK 示例（亮度、钟表、方向、样式、亮屏、表盘、抬腕/覆掌）。
//
//  SDK APIs / 使用的 SDK API:
//  - getDeviceLightLevelWithCurrentLevel: / setDeviceLightLevel:
//  - get/setScreenHomePageShowingClock…
//  - get/setScreenOrientationInfoWithPortrait:leftHandWear:…
//  - get/setScreenHomePageStyle…
//  - setHomePageScreenOpType:info:… (Display Time)
//  - getDialIndexWithFinshed: / setDialIndexWith:finshed:
//  - getFlipWristInfo: / setFlipWristOn:flipType: (Palm / raise-to-wake, band)
//

#import "QCSampleHealthFunctionViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface QCSampleDisplayViewController : QCSampleHealthFunctionViewController

@end

NS_ASSUME_NONNULL_END
