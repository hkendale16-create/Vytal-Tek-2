//
//  QCSampleDeviceViewController.m
//  QCBandSDKDemo
//
//  Created by zhong on 2026/8/4.
//
//  Device control SDK sample.
//  设备控制 SDK 示例。
//

#import "QCSampleDeviceViewController.h"
#import "QCSampleLocalization.h"
#import "QCSampleToast.h"
#import <QCBandSDK/QCSDKCmdCreator.h>
#import <QCBandSDK/QCSDKManager.h>

#pragma mark - Value ranges / 传值范围

/// Weather enable & Celsius flags are boolean protocol fields (0/1).
/// 天气开关与摄氏度标志为协议布尔字段（0/1）。
static const NSInteger kQCSampleBoolMin = 0;
static const NSInteger kQCSampleBoolMax = 1;

@interface QCSampleDeviceViewController ()
@property (nonatomic, assign) BOOL lastWeatherEnable;
@property (nonatomic, assign) BOOL lastUsingCelsius;
@property (nonatomic, assign) BOOL cameraControlActive;
@property (nonatomic, assign) BOOL wearCalibrationActive;
@end

@implementation QCSampleDeviceViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = QCSampleLocalized(QCSampleLocalizedKeyItemDevice);
    self.lastWeatherEnable = YES;
    self.lastUsingCelsius = YES;
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    if (self.isMovingFromParentViewController || self.isBeingDismissed) {
        [self unregisterCameraCallbacks];
        if (self.wearCalibrationActive) {
            [self stopWearCalibrationSilently];
        }
    }
}

- (void)setupActions {
    __weak typeof(self) weakSelf = self;

    [self beginActionSection:QCSampleLocalized(QCSampleLocalizedKeyDeviceSectionInfo)];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyDeviceReadBattery) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf readBattery];
    }];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyDeviceReadMac) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf readMacAddress];
    }];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyDeviceReadVersion) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf readVersion];
    }];

    [self beginActionSection:QCSampleLocalized(QCSampleLocalizedKeyDeviceSectionDegree)];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyDeviceGetDegree) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf getDegreeSwitch];
    }];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyDeviceSetDegree) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf presentSetDegreeAlert];
    }];

    [self beginActionSection:QCSampleLocalized(QCSampleLocalizedKeyDeviceSectionBatterySaving)];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyDeviceGetBatterySaving) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf getBatterySaving];
    }];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyDeviceSetBatterySaving) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf presentSetBatterySavingAlert];
    }];

    [self beginActionSection:QCSampleLocalized(QCSampleLocalizedKeyDeviceSectionCamera)];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyDeviceStartCamera) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf startCameraControl];
    }];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyDeviceStopCamera) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf stopCameraControl];
    }];

    [self beginActionSection:QCSampleLocalized(QCSampleLocalizedKeyDeviceSectionWear)];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyDeviceStartWear) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf startWearCalibration];
    }];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyDeviceStopWear) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf stopWearCalibration];
    }];

    [self beginActionSection:QCSampleLocalized(QCSampleLocalizedKeyDeviceSectionPower)];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyDeviceShutdown) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf confirmHighRiskWithMessage:QCSampleLocalized(QCSampleLocalizedKeyDeviceShutdownConfirm)
                                    action:^{ [weakSelf shutdownDevice]; }];
    }];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyDeviceReboot) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf confirmHighRiskWithMessage:QCSampleLocalized(QCSampleLocalizedKeyDeviceRebootConfirm)
                                    action:^{ [weakSelf rebootDevice]; }];
    }];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyDeviceFactoryReset) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf confirmHighRiskWithMessage:QCSampleLocalized(QCSampleLocalizedKeyDeviceFactoryConfirm)
                                    action:^{ [weakSelf restoreFactory]; }];
    }];
    
    [QCSDKManager shareInstance].currentBatteryInfo = ^(NSInteger battery, BOOL charging) {
        NSLog(@"battery:%ld,charging:%d",(long)battery,charging);
    };
}

#pragma mark - Info / 设备信息

- (void)readBattery {
    [self appendLog:@"SDK readBatterySuccess"];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator readBatterySuccess:^(int battery, BOOL charging) {
        [weakSelf appendLogFormat:@"[Battery] %d%% charging=%@", battery, charging ? @"YES" : @"NO"];
    } failed:^{
        [weakSelf appendLog:@"[Battery] failed"];
    }];
}

- (void)readMacAddress {
    [self appendLog:@"SDK getDeviceMacAddressSuccess"];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator getDeviceMacAddressSuccess:^(NSString * _Nullable macAddress) {
        [weakSelf appendLogFormat:@"[MAC] %@", macAddress.length > 0 ? macAddress : @"(empty)"];
    } fail:^{
        [weakSelf appendLog:@"[MAC] failed"];
    }];
}

- (void)readVersion {
    [self appendLog:@"SDK getDeviceSoftAndHardVersionSuccess"];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator getDeviceSoftAndHardVersionSuccess:^(NSString *soft, NSString *hard) {
        [weakSelf appendLogFormat:@"[Version] soft=%@ hard=%@", soft ?: @"", hard ?: @""];
    } fail:^{
        [weakSelf appendLog:@"[Version] failed"];
    }];
}

#pragma mark - Degree / 温度单位

/// Weather temperature unit APIs.
/// 天气温度单位接口。
- (void)getDegreeSwitch {
    [self appendLogFormat:@"SDK getWeatherForecastStatus hint enable=%@ celsius=%@",
     self.lastWeatherEnable ? @"YES" : @"NO",
     self.lastUsingCelsius ? @"YES" : @"NO"];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator getWeatherForecastStatusWithCurrentState:self.lastWeatherEnable
                                     temperatureUsingCelsius:self.lastUsingCelsius
                                                     success:^(BOOL enable, BOOL usingCelsius) {
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf) { return; }
        strongSelf.lastWeatherEnable = enable;
        strongSelf.lastUsingCelsius = usingCelsius;
        [strongSelf appendLogFormat:@"[Degree] get success enable=%@ celsius=%@",
         enable ? @"YES" : @"NO",
         usingCelsius ? @"YES" : @"NO"];
    } fail:^{
        [weakSelf appendLog:@"[Degree] get failed"];
    }];
}

- (void)presentSetDegreeAlert {
    UIAlertController *alert =
    [UIAlertController alertControllerWithTitle:QCSampleLocalized(QCSampleLocalizedKeyDeviceSetDegree)
                                        message:nil
                                 preferredStyle:UIAlertControllerStyleAlert];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyDeviceDegreeEnable)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyDeviceBoolHint,
                                                        (long)kQCSampleBoolMin,
                                                        (long)kQCSampleBoolMax)
                           text:self.lastWeatherEnable ? 1 : 0];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyDeviceDegreeCelsius)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyDeviceCelsiusHint,
                                                        (long)kQCSampleBoolMin,
                                                        (long)kQCSampleBoolMax)
                           text:self.lastUsingCelsius ? 1 : 0];

    __weak typeof(self) weakSelf = self;
    [alert addAction:[UIAlertAction actionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyCommonCancel)
                                              style:UIAlertActionStyleCancel
                                            handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyCommonOK)
                                              style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction * _Nonnull action) {
        NSInteger enable = alert.textFields[0].text.integerValue;
        NSInteger celsius = alert.textFields[1].text.integerValue;
        if (![weakSelf validateInputValue:enable
                                      min:kQCSampleBoolMin
                                      max:kQCSampleBoolMax
                               fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyDeviceDegreeEnable)] ||
            ![weakSelf validateInputValue:celsius
                                      min:kQCSampleBoolMin
                                      max:kQCSampleBoolMax
                               fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyDeviceDegreeCelsius)]) {
            return;
        }
        [weakSelf setDegreeEnable:(enable == 1) usingCelsius:(celsius == 1)];
    }]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)setDegreeEnable:(BOOL)enable usingCelsius:(BOOL)usingCelsius {
    [self appendLogFormat:@"SDK setWeatherForecastStatus enable=%@ celsius=%@",
     enable ? @"YES" : @"NO",
     usingCelsius ? @"YES" : @"NO"];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator setWeatherForecastStatus:enable
                     temperatureUsingCelsius:usingCelsius
                                     success:^(BOOL featureOn, BOOL celsius) {
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf) { return; }
        strongSelf.lastWeatherEnable = featureOn;
        strongSelf.lastUsingCelsius = celsius;
        [strongSelf appendLogFormat:@"[Degree] set success enable=%@ celsius=%@",
         featureOn ? @"YES" : @"NO",
         celsius ? @"YES" : @"NO"];
    } fail:^{
        [weakSelf appendLog:@"[Degree] set failed"];
    }];
}

#pragma mark - Battery Saving / 省电

/// Low-power APIs.
/// 低电量/省电接口。
- (void)getBatterySaving {
    [self appendLog:@"SDK getLowPowerWithFinshed"];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator getLowPowerWithFinshed:^(BOOL isOn, NSError * _Nullable error) {
        if (error) {
            [weakSelf appendLogFormat:@"[BatterySaving] get failed error=%@", error.localizedDescription ?: @"unknown"];
            return;
        }
        [weakSelf appendLogFormat:@"[BatterySaving] get success on=%@", isOn ? @"YES" : @"NO"];
    }];
}

- (void)presentSetBatterySavingAlert {
    UIAlertController *alert =
    [UIAlertController alertControllerWithTitle:QCSampleLocalized(QCSampleLocalizedKeyDeviceSetBatterySaving)
                                        message:nil
                                 preferredStyle:UIAlertControllerStyleAlert];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyDeviceBatterySavingEnable)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyDeviceBoolHint,
                                                        (long)kQCSampleBoolMin,
                                                        (long)kQCSampleBoolMax)
                           text:1];

    __weak typeof(self) weakSelf = self;
    [alert addAction:[UIAlertAction actionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyCommonCancel)
                                              style:UIAlertActionStyleCancel
                                            handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyCommonOK)
                                              style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction * _Nonnull action) {
        NSInteger enable = alert.textFields.firstObject.text.integerValue;
        if (![weakSelf validateInputValue:enable
                                      min:kQCSampleBoolMin
                                      max:kQCSampleBoolMax
                               fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyDeviceBatterySavingEnable)]) {
            return;
        }
        [weakSelf setBatterySavingOn:(enable == 1)];
    }]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)setBatterySavingOn:(BOOL)on {
    [self appendLogFormat:@"SDK setLowPowerWith on=%@", on ? @"YES" : @"NO"];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator setLowPowerWith:on finshed:^(NSError * _Nullable error) {
        if (error) {
            [weakSelf appendLogFormat:@"[BatterySaving] set failed error=%@", error.localizedDescription ?: @"unknown"];
            return;
        }
        [weakSelf appendLogFormat:@"[BatterySaving] set success on=%@", on ? @"YES" : @"NO"];
    }];
}

#pragma mark - Camera / 拍照控制

- (void)startCameraControl {
    [self registerCameraCallbacks];
    [self appendLog:@"SDK switchToPhotoUISuccess"];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator switchToPhotoUISuccess:^{
        weakSelf.cameraControlActive = YES;
        [weakSelf appendLog:@"[Camera] started"];
        [QCSampleToast showCenterWithText:QCSampleLocalized(QCSampleLocalizedKeyDeviceCameraStarted)];
    } fail:^{
        [weakSelf unregisterCameraCallbacks];
        [weakSelf appendLog:@"[Camera] start failed"];
    }];
}

- (void)stopCameraControl {
    [self appendLog:@"SDK stopTakingPhotoSuccess"];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator stopTakingPhotoSuccess:^{
        weakSelf.cameraControlActive = NO;
        [weakSelf unregisterCameraCallbacks];
        [weakSelf appendLog:@"[Camera] stopped"];
        [QCSampleToast showCenterWithText:QCSampleLocalized(QCSampleLocalizedKeyDeviceCameraStopped)];
    } fail:^{
        [weakSelf appendLog:@"[Camera] stop failed"];
    }];
}

- (void)registerCameraCallbacks {
    __weak typeof(self) weakSelf = self;
    // Watch entered camera UI / 手表进入拍照界面
    [QCSDKManager shareInstance].switchToPicture = ^{
        [weakSelf appendLog:@"[Camera] notify switchToPicture"];
    };
    // Watch requests taking a photo / 手表请求拍照
    [QCSDKManager shareInstance].takePicture = ^{
        [weakSelf appendLog:@"[Camera] notify takePicture"];
        [QCSampleToast showCenterWithText:QCSampleLocalized(QCSampleLocalizedKeyDeviceCameraTakePhoto)];
    };
    // Watch ended camera session / 手表结束拍照会话
    [QCSDKManager shareInstance].stopTakePicture = ^{
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf) { return; }
        strongSelf.cameraControlActive = NO;
        [strongSelf appendLog:@"[Camera] notify stopTakePicture"];
        [QCSampleToast showCenterWithText:QCSampleLocalized(QCSampleLocalizedKeyDeviceCameraFinished)];
        [strongSelf unregisterCameraCallbacks];
    };
}

- (void)unregisterCameraCallbacks {
    [QCSDKManager shareInstance].switchToPicture = nil;
    [QCSDKManager shareInstance].takePicture = nil;
    [QCSDKManager shareInstance].stopTakePicture = nil;
}

#pragma mark - Wear Calibration / 佩戴校准

- (void)startWearCalibration {
    [self appendLog:@"SDK readBatterySuccess (pre-check charging)"];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator readBatterySuccess:^(int battery, BOOL charging) {
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf) { return; }
        [strongSelf appendLogFormat:@"[Wear] battery=%d%% charging=%@", battery, charging ? @"YES" : @"NO"];
        if (charging) {
            [QCSampleToast showCenterWithText:QCSampleLocalized(QCSampleLocalizedKeyDeviceWearCharging)];
            [strongSelf appendLog:@"[Wear] blocked: charging"];
            return;
        }
        [strongSelf appendLog:@"SDK startToWearCalibrationWithCompletedHandle (type=6 via manager)"];
        strongSelf.wearCalibrationActive = YES;
        [[QCSDKManager shareInstance] startToWearCalibrationWithCompletedHandle:^(BOOL isSuccess, NSError *error) {
            strongSelf.wearCalibrationActive = NO;
            if (isSuccess) {
                [strongSelf appendLog:@"[Wear] calibration success"];
                [QCSampleToast showCenterWithText:QCSampleLocalized(QCSampleLocalizedKeyDeviceWearSuccess)];
            } else {
                [strongSelf appendLogFormat:@"[Wear] calibration failed error=%@",
                 error.localizedDescription ?: @"timeout/unknown"];
                [QCSampleToast showCenterWithText:QCSampleLocalized(QCSampleLocalizedKeyDeviceWearFailed)];
            }
        }];
    } failed:^{
        [weakSelf appendLog:@"[Wear] battery pre-check failed"];
    }];
}

- (void)stopWearCalibration {
    [self appendLog:@"SDK stopToWearCalibrationWithCompletedHandle (type=2)"];
    __weak typeof(self) weakSelf = self;
    [[QCSDKManager shareInstance] stopToWearCalibrationWithCompletedHandle:^(BOOL isSuccess, NSError *error) {
        weakSelf.wearCalibrationActive = NO;
        if (isSuccess) {
            [weakSelf appendLog:@"[Wear] stop success"];
        } else {
            [weakSelf appendLogFormat:@"[Wear] stop failed error=%@", error.localizedDescription ?: @"unknown"];
        }
    }];
}

- (void)stopWearCalibrationSilently {
    self.wearCalibrationActive = NO;
    [[QCSDKManager shareInstance] stopToWearCalibrationWithCompletedHandle:^(BOOL isSuccess, NSError *error) {
        (void)isSuccess;
        (void)error;
    }];
}

#pragma mark - Power / 高风险操作

- (void)confirmHighRiskWithMessage:(NSString *)message action:(dispatch_block_t)action {
    UIAlertController *alert =
    [UIAlertController alertControllerWithTitle:QCSampleLocalized(QCSampleLocalizedKeyDeviceHighRiskTitle)
                                        message:message
                                 preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyCommonCancel)
                                              style:UIAlertActionStyleCancel
                                            handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyDeviceHighRiskConfirm)
                                              style:UIAlertActionStyleDestructive
                                            handler:^(UIAlertAction * _Nonnull alertAction) {
        if (action) { action(); }
    }]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)shutdownDevice {
    [self appendLog:@"SDK shutDownSuccess"];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator shutDownSuccess:^{
        [weakSelf appendLog:@"[Power] shutdown success"];
        [QCSampleToast showCenterWithText:QCSampleLocalizedFormat(QCSampleLocalizedKeyDeviceHighRiskSuccess,
                                                                  QCSampleLocalized(QCSampleLocalizedKeyDeviceShutdown))];
    } fail:^{
        [weakSelf appendLog:@"[Power] shutdown failed"];
    }];
}

- (void)rebootDevice {
    [self appendLog:@"SDK resetBandHardlySuccess"];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator resetBandHardlySuccess:^{
        [weakSelf appendLog:@"[Power] reboot success"];
        [QCSampleToast showCenterWithText:QCSampleLocalizedFormat(QCSampleLocalizedKeyDeviceHighRiskSuccess,
                                                                  QCSampleLocalized(QCSampleLocalizedKeyDeviceReboot))];
    } fail:^{
        [weakSelf appendLog:@"[Power] reboot failed"];
    }];
}

- (void)restoreFactory {
    [self appendLog:@"SDK resetBandToFacotrySuccess"];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator resetBandToFacotrySuccess:^{
        [weakSelf appendLog:@"[Power] factory reset success"];
        [QCSampleToast showCenterWithText:QCSampleLocalizedFormat(QCSampleLocalizedKeyDeviceHighRiskSuccess,
                                                                  QCSampleLocalized(QCSampleLocalizedKeyDeviceFactoryReset))];
    } fail:^{
        [weakSelf appendLog:@"[Power] factory reset failed"];
    }];
}

@end
