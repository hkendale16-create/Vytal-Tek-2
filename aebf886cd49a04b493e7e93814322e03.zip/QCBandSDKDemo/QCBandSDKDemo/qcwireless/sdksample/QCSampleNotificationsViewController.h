//
//  QCSampleNotificationsViewController.h
//  QCBandSDKDemo
//
//  Created by zhong on 2026/8/5.
//
//  Notification SDK sample (ANCS filter, DND, light/vibration, music).
//  通知相关 SDK 示例（ANCS 过滤、勿扰、亮灯/震动、音乐开关）。
//
//  SDK APIs / 使用的 SDK API:
//  - getFilterSuccess:failed: / setFilter:success:failed:
//  - setANCSFlagSuccess:fail:
//  - getDontDisturbInfo:fail: / setDontDisturbOn:beginTime:endTime:…
//  - sendCustomLightNotificationWithPriority:…
//  - sendCustomVibrationNotificationWithPriority:…
//  - getMusicControlStatusWithCurrentState:… / setMusicControlStatus:…
//

#import "QCSampleHealthFunctionViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface QCSampleNotificationsViewController : QCSampleHealthFunctionViewController

@end

NS_ASSUME_NONNULL_END
