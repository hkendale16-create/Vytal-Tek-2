//
//  QCSampleFirmwareUpdateViewController.m
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//
//  Firmware OTA sample. 固件 OTA 示例。
//  SDK: getDeviceSoftAndHardVersionSuccess / syncOtaBinData

#import "QCSampleFirmwareUpdateViewController.h"
#import "QCSampleLocalization.h"
#import <QCBandSDK/QCSDKCmdCreator.h>

@implementation QCSampleFirmwareUpdateViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = QCSampleLocalized(QCSampleLocalizedKeyItemFirmwareBLE);
}

- (void)setupActions {
    __weak typeof(self) weakSelf = self;

    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyFirmwareGetVersion) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf appendLog:@"SDK getDeviceSoftAndHardVersionSuccess"];
        [QCSDKCmdCreator getDeviceSoftAndHardVersionSuccess:^(NSString *hardVersion, NSString *softVersion) {
            [weakSelf appendLogFormat:@"hardware: %@", hardVersion ?: @"--"];
            [weakSelf appendLogFormat:@"firmware: %@", softVersion ?: @"--"];
            NSString *binName = [weakSelf otaBinResourceNameForHardwareVersion:hardVersion];
            if (binName.length > 0) {
                [weakSelf appendLogFormat:@"mapped bin: %@.bin", binName];
            } else {
                [weakSelf appendLogFormat:@"⚠️ no bin mapped for %@", hardVersion ?: @"--"];
            }
        } fail:^{
            [weakSelf appendLog:@"❌ getDeviceSoftAndHardVersion failed"];
        }];
    }];

    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyFirmwareStartOTA) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf startFirmwareUpgrade];
    }];
}

#pragma mark - OTA (from legacy ViewController)

- (NSString *)otaBinResourceNameForHardwareVersion:(NSString *)hardVersion {
    NSString *hardware = hardVersion.uppercaseString;
    if ([hardware hasPrefix:@"RT08LR"]) {
        return @"RT08LR_1.00.08_260430";
    }
    if ([hardware hasPrefix:@"R02A"]) {
        return @"R02A_2.06.06_240302";
    }
    return nil;
}

- (void)startFirmwareUpgrade {
    [self appendLog:@"SDK getDeviceSoftAndHardVersionSuccess → syncOtaBinData"];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator getDeviceSoftAndHardVersionSuccess:^(NSString *hardVersion, NSString *softVersion) {
        NSString *resourceName = [weakSelf otaBinResourceNameForHardwareVersion:hardVersion];
        if (!resourceName.length) {
            [weakSelf appendLogFormat:@"❌ no bin mapped for %@", hardVersion ?: @"--"];
            [weakSelf appendLog:@"   update otaBinResourceNameForHardwareVersion:"];
            return;
        }
        [weakSelf startOTAWithBinResourceName:resourceName hardVersion:hardVersion softVersion:softVersion];
    } fail:^{
        [weakSelf appendLog:@"❌ getDeviceSoftAndHardVersion failed, connect device first"];
    }];
}

- (void)startOTAWithBinResourceName:(NSString *)resourceName
                        hardVersion:(NSString *)hardVersion
                        softVersion:(NSString *)softVersion {
    NSString *filePath = [[NSBundle mainBundle] pathForResource:resourceName ofType:@"bin"];
    if (!filePath.length) {
        [self appendLogFormat:@"❌ bin not found: %@.bin", resourceName];
        [self appendLog:@"   add .bin to Copy Bundle Resources in Xcode"];
        return;
    }

    NSError *readError = nil;
    NSData *data = [NSData dataWithContentsOfFile:filePath options:NSDataReadingUncached error:&readError];
    if (!data.length) {
        [self appendLogFormat:@"❌ read bin failed: %@", readError.localizedDescription ?: @"unknown"];
        return;
    }

    [self appendLogFormat:@"OTA start: %@ / %@ → %@.bin (%.1f KB)",
     hardVersion ?: @"--", softVersion ?: @"--", resourceName, data.length / 1024.0];

    __block int lastLoggedProgress = -1;
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator syncOtaBinData:data start:^{
        [weakSelf appendLog:@"syncOtaBinData started"];
    } percentage:^(int percentage) {
        if (lastLoggedProgress != percentage && (percentage == 0 || percentage % 10 == 0 || percentage == 100)) {
            lastLoggedProgress = percentage;
            [weakSelf appendLogFormat:@"progress: %d%%", percentage];
        }
    } success:^(int seconds) {
        [weakSelf appendLogFormat:@"✅ OTA success, time: %ds", seconds];
    } failed:^(NSError *error) {
        [weakSelf appendLogFormat:@"❌ OTA failed: %@", error.localizedDescription ?: @"unknown"];
    }];
}

@end
