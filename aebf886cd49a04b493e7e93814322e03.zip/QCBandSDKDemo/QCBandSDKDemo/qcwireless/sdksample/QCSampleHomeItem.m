//
//  QCSampleHomeItem.m
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//

#import "QCSampleHomeItem.h"
#import "QCSampleLocalization.h"

@implementation QCSampleHomeItem

+ (instancetype)itemWithIdentifier:(QCSampleHomeItemIdentifier)identifier
                             title:(NSString *)title
                        actionType:(QCSampleHomeItemActionType)actionType
                  showsDisclosure:(BOOL)showsDisclosure
    existingViewControllerClassName:(NSString *)existingViewControllerClassName {
    QCSampleHomeItem *item = [[QCSampleHomeItem alloc] init];
    item->_identifier = identifier;
    item->_title = [title copy];
    item->_actionType = actionType;
    item->_showsDisclosure = showsDisclosure;
    item->_existingViewControllerClassName = [existingViewControllerClassName copy];
    return item;
}

@end

@implementation QCSampleHomeSection

+ (instancetype)sectionWithTitle:(NSString *)title items:(NSArray<QCSampleHomeItem *> *)items {
    QCSampleHomeSection *section = [[QCSampleHomeSection alloc] init];
    section->_title = [title copy];
    section->_items = [items copy];
    return section;
}

@end

@implementation QCSampleHomeDataSource

+ (NSArray<QCSampleHomeSection *> *)defaultSections {
    QCSampleHomeSection *connectSection = [QCSampleHomeSection sectionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyHomeSectionConnect) items:@[
        [QCSampleHomeItem itemWithIdentifier:QCSampleHomeItemIdentifierScan
                                       title:QCSampleLocalized(QCSampleLocalizedKeyItemScan)
                                  actionType:QCSampleHomeItemActionTypeNavigateExisting
                            showsDisclosure:YES
          existingViewControllerClassName:@"QCScanViewController"],

        [QCSampleHomeItem itemWithIdentifier:QCSampleHomeItemIdentifierReconnect
                                       title:QCSampleLocalized(QCSampleLocalizedKeyItemReconnect)
                                  actionType:QCSampleHomeItemActionTypeExecute
                            showsDisclosure:NO
          existingViewControllerClassName:nil],

        [QCSampleHomeItem itemWithIdentifier:QCSampleHomeItemIdentifierDisconnect
                                       title:QCSampleLocalized(QCSampleLocalizedKeyItemDisconnect)
                                  actionType:QCSampleHomeItemActionTypeExecute
                            showsDisclosure:NO
          existingViewControllerClassName:nil],

        [QCSampleHomeItem itemWithIdentifier:QCSampleHomeItemIdentifierUnbind
                                       title:QCSampleLocalized(QCSampleLocalizedKeyItemUnbind)
                                  actionType:QCSampleHomeItemActionTypeExecute
                            showsDisclosure:NO
          existingViewControllerClassName:nil],

        [QCSampleHomeItem itemWithIdentifier:QCSampleHomeItemIdentifierFindDevice
                                       title:QCSampleLocalized(QCSampleLocalizedKeyItemFindDevice)
                                  actionType:QCSampleHomeItemActionTypeExecute
                            showsDisclosure:NO
          existingViewControllerClassName:nil],
    ]];

    QCSampleHomeSection *settingsSection = [QCSampleHomeSection sectionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyHomeSectionSettings) items:@[
        [QCSampleHomeItem itemWithIdentifier:QCSampleHomeItemIdentifierHealthSettings
                                       title:QCSampleLocalized(QCSampleLocalizedKeyItemHealthSettings)
                                  actionType:QCSampleHomeItemActionTypeNavigateExisting
                            showsDisclosure:YES
          existingViewControllerClassName:@"QCSampleHealthSettingsViewController"],

        [QCSampleHomeItem itemWithIdentifier:QCSampleHomeItemIdentifierGoalsProfile
                                       title:QCSampleLocalized(QCSampleLocalizedKeyItemGoalsProfile)
                                  actionType:QCSampleHomeItemActionTypeNavigateExisting
                            showsDisclosure:YES
          existingViewControllerClassName:@"QCSampleGoalsProfileViewController"],

        [QCSampleHomeItem itemWithIdentifier:QCSampleHomeItemIdentifierDisplay
                                       title:QCSampleLocalized(QCSampleLocalizedKeyItemDisplay)
                                  actionType:QCSampleHomeItemActionTypeNavigateExisting
                            showsDisclosure:YES
          existingViewControllerClassName:@"QCSampleDisplayViewController"],

        [QCSampleHomeItem itemWithIdentifier:QCSampleHomeItemIdentifierDevice
                                       title:QCSampleLocalized(QCSampleLocalizedKeyItemDevice)
                                  actionType:QCSampleHomeItemActionTypeNavigateExisting
                            showsDisclosure:YES
          existingViewControllerClassName:@"QCSampleDeviceViewController"],

        [QCSampleHomeItem itemWithIdentifier:QCSampleHomeItemIdentifierNotifications
                                       title:QCSampleLocalized(QCSampleLocalizedKeyItemNotifications)
                                  actionType:QCSampleHomeItemActionTypeNavigateExisting
                            showsDisclosure:YES
          existingViewControllerClassName:@"QCSampleNotificationsViewController"],

        [QCSampleHomeItem itemWithIdentifier:QCSampleHomeItemIdentifierTouchGestures
                                       title:QCSampleLocalized(QCSampleLocalizedKeyItemTouchGestures)
                                  actionType:QCSampleHomeItemActionTypeNavigateExisting
                            showsDisclosure:YES
          existingViewControllerClassName:@"QCSampleTouchGesturesViewController"],

        [QCSampleHomeItem itemWithIdentifier:QCSampleHomeItemIdentifierAdvanced
                                       title:QCSampleLocalized(QCSampleLocalizedKeyItemAdvanced)
                                  actionType:QCSampleHomeItemActionTypeNavigateExisting
                            showsDisclosure:YES
          existingViewControllerClassName:@"QCSampleAdvancedViewController"],
    ]];

    QCSampleHomeSection *firmwareSection = [QCSampleHomeSection sectionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyHomeSectionFirmware) items:@[
        [QCSampleHomeItem itemWithIdentifier:QCSampleHomeItemIdentifierFirmwareUpdateBLE
                                       title:QCSampleLocalized(QCSampleLocalizedKeyItemFirmwareBLE)
                                  actionType:QCSampleHomeItemActionTypeNavigateExisting
                            showsDisclosure:YES
          existingViewControllerClassName:@"QCSampleFirmwareUpdateViewController"],

        [QCSampleHomeItem itemWithIdentifier:QCSampleHomeItemIdentifierResourceUpdate
                                       title:QCSampleLocalized(QCSampleLocalizedKeyItemResourceUpdate)
                                  actionType:QCSampleHomeItemActionTypeNavigateExisting
                            showsDisclosure:YES
          existingViewControllerClassName:@"QCSampleResourceUpdateViewController"],
    ]];

    return @[connectSection, settingsSection, firmwareSection];
}

@end
