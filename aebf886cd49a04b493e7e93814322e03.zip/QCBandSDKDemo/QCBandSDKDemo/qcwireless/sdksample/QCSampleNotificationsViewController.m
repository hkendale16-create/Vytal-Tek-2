//
//  QCSampleNotificationsViewController.m
//  QCBandSDKDemo
//
//  Created by zhong on 2026/8/5.
//
//  Notification SDK sample.
//  通知相关 SDK 示例。
//

#import "QCSampleNotificationsViewController.h"
#import "QCSampleLocalization.h"
#import "QCSampleToast.h"
#import <QCBandSDK/QCSDKCmdCreator.h>
#import <QCBandSDK/QCDFU_Utils.h>

#pragma mark - Value ranges / 传值范围

static const NSInteger kQCSampleBoolMin = 0;
static const NSInteger kQCSampleBoolMax = 1;
static const NSInteger kQCSampleHourMin = 0;
static const NSInteger kQCSampleHourMax = 23;
static const NSInteger kQCSampleMinuteMin = 0;
static const NSInteger kQCSampleMinuteMax = 59;
/// Demo priority samples: 0 / 1 / 3 / 5 / 10.
/// 演示优先级取值：0 / 1 / 3 / 5 / 10。
static const NSInteger kQCSamplePriorityMin = 0;
static const NSInteger kQCSamplePriorityMax = 10;
/// Light action: 0=NULL, 1=Stop, 2=Green, 3=Red.
/// 亮灯动作：0=空，1=停止，2=绿，3=红。
static const NSInteger kQCSampleLightActionMin = 0;
static const NSInteger kQCSampleLightActionMax = 3;
/// Vibration action: 0=NULL, 1=Stop, 2=Start.
/// 震动动作：0=空，1=停止，2=启动。
static const NSInteger kQCSampleVibrationActionMin = 0;
static const NSInteger kQCSampleVibrationActionMax = 2;
static const NSInteger kQCSampleCycleMin = 1;
static const NSInteger kQCSampleCycleMax = 10;
/// Duration unit = 100ms; protocol range 1～127 (pause may be 0).
/// 时长单位=100ms；协议范围 1～127（暂停可为 0）。
static const NSInteger kQCSampleDurationMin = 1;
static const NSInteger kQCSampleDurationMax = 127;
static const NSInteger kQCSamplePauseMin = 0;
static const NSInteger kQCSamplePauseMax = 127;
/// Classic ANCS filter length: indexes 0…15 (phone/sms/qq/wechat/…).
/// 经典 ANCS 过滤位长度：索引 0…15（电话/短信/QQ/微信…）。
static const NSInteger kQCSampleANCSFilterCount = 16;

@interface QCSampleNotificationsViewController ()
@property (nonatomic, copy) NSArray<NSNumber *> *lastFilters;
@property (nonatomic, assign) BOOL lastDndOn;
@property (nonatomic, assign) NSInteger lastDndBeginHour;
@property (nonatomic, assign) NSInteger lastDndBeginMinute;
@property (nonatomic, assign) NSInteger lastDndEndHour;
@property (nonatomic, assign) NSInteger lastDndEndMinute;
@property (nonatomic, assign) NSInteger lastLightPriority;
@property (nonatomic, assign) NSInteger lastLightAction;
@property (nonatomic, assign) NSInteger lastLightCycle;
@property (nonatomic, assign) NSInteger lastLightOnDuration;
@property (nonatomic, assign) NSInteger lastLightPause;
@property (nonatomic, assign) NSInteger lastVibPriority;
@property (nonatomic, assign) NSInteger lastVibAction;
@property (nonatomic, assign) NSInteger lastVibCycle;
@property (nonatomic, assign) NSInteger lastVibDuration;
@property (nonatomic, assign) NSInteger lastVibPause;
@property (nonatomic, assign) BOOL lastMusicEnable;
@end

@implementation QCSampleNotificationsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = QCSampleLocalized(QCSampleLocalizedKeyItemNotifications);
    // Default ANCS: phone/sms/qq/wechat on.
    // 默认 ANCS：电话/短信/QQ/微信开启。
    NSMutableArray<NSNumber *> *filters = [NSMutableArray arrayWithCapacity:kQCSampleANCSFilterCount];
    for (NSInteger i = 0; i < kQCSampleANCSFilterCount; i++) {
        [filters addObject:@(i <= 3 ? 1 : 0)];
    }
    self.lastFilters = filters;
    self.lastDndOn = YES;
    self.lastDndBeginHour = 22;
    self.lastDndBeginMinute = 0;
    self.lastDndEndHour = 7;
    self.lastDndEndMinute = 0;
    self.lastLightPriority = 1;
    self.lastLightAction = QCNotificationLightActionGreen;
    self.lastLightCycle = 3;
    self.lastLightOnDuration = 10;
    self.lastLightPause = 5;
    self.lastVibPriority = 1;
    self.lastVibAction = QCNotificationVibrationActionStart;
    self.lastVibCycle = 3;
    self.lastVibDuration = 10;
    self.lastVibPause = 5;
    self.lastMusicEnable = YES;
}

- (void)setupActions {
    __weak typeof(self) weakSelf = self;

    [self beginActionSection:QCSampleLocalized(QCSampleLocalizedKeyNotifSectionANCS)];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyNotifGetANCS) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf getANCS];
    }];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyNotifSetANCS) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf presentSetANCSAlert];
    }];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyNotifBindANCS) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf bindANCS];
    }];

    [self beginActionSection:QCSampleLocalized(QCSampleLocalizedKeyNotifSectionDND)];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyNotifGetDND) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf getDND];
    }];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyNotifSetDND) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf presentSetDNDAlert];
    }];

    [self beginActionSection:QCSampleLocalized(QCSampleLocalizedKeyNotifSectionLight)];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyNotifSendLight) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf presentSendLightAlert];
    }];

    [self beginActionSection:QCSampleLocalized(QCSampleLocalizedKeyNotifSectionVibration)];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyNotifSendVibration) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf presentSendVibrationAlert];
    }];

    [self beginActionSection:QCSampleLocalized(QCSampleLocalizedKeyNotifSectionMusic)];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyNotifGetMusic) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf getMusic];
    }];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyNotifSetMusic) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf presentSetMusicAlert];
    }];
}

#pragma mark - ANCS / 消息过滤

- (void)getANCS {
    [self appendLog:@"SDK getFilterSuccess"];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator getFilterSuccess:^(NSArray<NSNumber *> *filters) {
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf) { return; }
        strongSelf.lastFilters = [filters copy] ?: @[];
        [strongSelf appendLogFormat:@"[ANCS] get success count=%lu values=%@",
         (unsigned long)filters.count,
         [strongSelf filterSummary:filters]];
    } failed:^{
        [weakSelf appendLog:@"[ANCS] get failed"];
    }];
}

- (void)presentSetANCSAlert {
    UIAlertController *alert =
    [UIAlertController alertControllerWithTitle:QCSampleLocalized(QCSampleLocalizedKeyNotifSetANCS)
                                        message:nil
                                 preferredStyle:UIAlertControllerStyleAlert];
    NSInteger phone = [self filterValueAtIndex:0];
    NSInteger sms = [self filterValueAtIndex:1];
    NSInteger qq = [self filterValueAtIndex:2];
    NSInteger wechat = [self filterValueAtIndex:3];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyNotifANCSPhone)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyNotifBoolHint,
                                                        (long)kQCSampleBoolMin,
                                                        (long)kQCSampleBoolMax)
                           text:phone];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyNotifANCSSms)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyNotifBoolHint,
                                                        (long)kQCSampleBoolMin,
                                                        (long)kQCSampleBoolMax)
                           text:sms];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyNotifANCSQQ)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyNotifBoolHint,
                                                        (long)kQCSampleBoolMin,
                                                        (long)kQCSampleBoolMax)
                           text:qq];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyNotifANCSWechat)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyNotifBoolHint,
                                                        (long)kQCSampleBoolMin,
                                                        (long)kQCSampleBoolMax)
                           text:wechat];
    __weak typeof(self) weakSelf = self;
    [alert addAction:[UIAlertAction actionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyCommonCancel)
                                              style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyCommonOK)
                                              style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction *action) {
        NSInteger v0 = alert.textFields[0].text.integerValue;
        NSInteger v1 = alert.textFields[1].text.integerValue;
        NSInteger v2 = alert.textFields[2].text.integerValue;
        NSInteger v3 = alert.textFields[3].text.integerValue;
        if (![weakSelf validateInputValue:v0 min:kQCSampleBoolMin max:kQCSampleBoolMax
                               fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyNotifANCSPhone)] ||
            ![weakSelf validateInputValue:v1 min:kQCSampleBoolMin max:kQCSampleBoolMax
                               fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyNotifANCSSms)] ||
            ![weakSelf validateInputValue:v2 min:kQCSampleBoolMin max:kQCSampleBoolMax
                               fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyNotifANCSQQ)] ||
            ![weakSelf validateInputValue:v3 min:kQCSampleBoolMin max:kQCSampleBoolMax
                               fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyNotifANCSWechat)]) {
            return;
        }
        [weakSelf setANCSPhone:v0 sms:v1 qq:v2 wechat:v3];
    }]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)setANCSPhone:(NSInteger)phone sms:(NSInteger)sms qq:(NSInteger)qq wechat:(NSInteger)wechat {
    NSMutableArray<NSNumber *> *filters = [NSMutableArray arrayWithCapacity:kQCSampleANCSFilterCount];
    for (NSInteger i = 0; i < kQCSampleANCSFilterCount; i++) {
        NSInteger value = 0;
        if (i == 0) { value = phone; }
        else if (i == 1) { value = sms; }
        else if (i == 2) { value = qq; }
        else if (i == 3) { value = wechat; }
        else if (i < (NSInteger)self.lastFilters.count) { value = self.lastFilters[i].integerValue ? 1 : 0; }
        [filters addObject:@(value)];
    }
    [self appendLogFormat:@"SDK setFilter phone=%ld sms=%ld qq=%ld wechat=%ld",
     (long)phone, (long)sms, (long)qq, (long)wechat];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator setFilter:filters success:^{
        weakSelf.lastFilters = filters;
        [weakSelf appendLog:@"[ANCS] set success"];
    } failed:^{
        [weakSelf appendLog:@"[ANCS] set failed"];
    }];
}

- (void)bindANCS {
    [self appendLog:@"SDK setANCSFlagSuccess"];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator setANCSFlagSuccess:^{
        [weakSelf appendLog:@"[ANCS] bind flag success"];
        [QCSampleToast showCenterWithText:QCSampleLocalized(QCSampleLocalizedKeyNotifBindANCSSuccess)];
    } fail:^{
        [weakSelf appendLog:@"[ANCS] bind flag failed"];
    }];
}

- (NSInteger)filterValueAtIndex:(NSInteger)index {
    if (index < 0 || index >= (NSInteger)self.lastFilters.count) { return 0; }
    return self.lastFilters[index].integerValue ? 1 : 0;
}

- (NSString *)filterSummary:(NSArray<NSNumber *> *)filters {
    NSMutableArray<NSString *> *parts = [NSMutableArray array];
    NSArray<NSString *> *names = @[@"phone", @"sms", @"qq", @"wechat"];
    for (NSInteger i = 0; i < names.count && i < (NSInteger)filters.count; i++) {
        [parts addObject:[NSString stringWithFormat:@"%@=%@", names[i], filters[i].integerValue ? @"1" : @"0"]];
    }
    return [parts componentsJoinedByString:@" "];
}

#pragma mark - DND / 勿扰

- (void)getDND {
    [self appendLog:@"SDK getDontDisturbInfo"];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator getDontDisturbInfo:^(BOOL isOn, NSString *begin, NSString *end) {
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf) { return; }
        strongSelf.lastDndOn = isOn;
        NSInteger bh = strongSelf.lastDndBeginHour, bm = strongSelf.lastDndBeginMinute;
        NSInteger eh = strongSelf.lastDndEndHour, em = strongSelf.lastDndEndMinute;
        [strongSelf parseTime:begin hour:&bh minute:&bm];
        [strongSelf parseTime:end hour:&eh minute:&em];
        strongSelf.lastDndBeginHour = bh;
        strongSelf.lastDndBeginMinute = bm;
        strongSelf.lastDndEndHour = eh;
        strongSelf.lastDndEndMinute = em;
        [strongSelf appendLogFormat:@"[DND] get success on=%@ begin=%@ end=%@",
         isOn ? @"YES" : @"NO", begin ?: @"", end ?: @""];
    } fail:^{
        [weakSelf appendLog:@"[DND] get failed"];
    }];
}

- (void)presentSetDNDAlert {
    UIAlertController *alert =
    [UIAlertController alertControllerWithTitle:QCSampleLocalized(QCSampleLocalizedKeyNotifSetDND)
                                        message:nil
                                 preferredStyle:UIAlertControllerStyleAlert];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyNotifDNDEnable)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyNotifBoolHint,
                                                        (long)kQCSampleBoolMin,
                                                        (long)kQCSampleBoolMax)
                           text:self.lastDndOn ? 1 : 0];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyNotifDNDBeginHour)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyNotifHourHint,
                                                        (long)kQCSampleHourMin,
                                                        (long)kQCSampleHourMax)
                           text:self.lastDndBeginHour];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyNotifDNDBeginMinute)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyNotifMinuteHint,
                                                        (long)kQCSampleMinuteMin,
                                                        (long)kQCSampleMinuteMax)
                           text:self.lastDndBeginMinute];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyNotifDNDEndHour)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyNotifHourHint,
                                                        (long)kQCSampleHourMin,
                                                        (long)kQCSampleHourMax)
                           text:self.lastDndEndHour];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyNotifDNDEndMinute)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyNotifMinuteHint,
                                                        (long)kQCSampleMinuteMin,
                                                        (long)kQCSampleMinuteMax)
                           text:self.lastDndEndMinute];
    __weak typeof(self) weakSelf = self;
    [alert addAction:[UIAlertAction actionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyCommonCancel)
                                              style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyCommonOK)
                                              style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction *action) {
        NSInteger on = alert.textFields[0].text.integerValue;
        NSInteger bh = alert.textFields[1].text.integerValue;
        NSInteger bm = alert.textFields[2].text.integerValue;
        NSInteger eh = alert.textFields[3].text.integerValue;
        NSInteger em = alert.textFields[4].text.integerValue;
        if (![weakSelf validateInputValue:on min:kQCSampleBoolMin max:kQCSampleBoolMax
                               fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyNotifDNDEnable)] ||
            ![weakSelf validateInputValue:bh min:kQCSampleHourMin max:kQCSampleHourMax
                               fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyNotifDNDBeginHour)] ||
            ![weakSelf validateInputValue:bm min:kQCSampleMinuteMin max:kQCSampleMinuteMax
                               fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyNotifDNDBeginMinute)] ||
            ![weakSelf validateInputValue:eh min:kQCSampleHourMin max:kQCSampleHourMax
                               fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyNotifDNDEndHour)] ||
            ![weakSelf validateInputValue:em min:kQCSampleMinuteMin max:kQCSampleMinuteMax
                               fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyNotifDNDEndMinute)]) {
            return;
        }
        [weakSelf setDNDOn:(on == 1) beginHour:bh beginMinute:bm endHour:eh endMinute:em];
    }]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)setDNDOn:(BOOL)on
       beginHour:(NSInteger)beginHour
     beginMinute:(NSInteger)beginMinute
         endHour:(NSInteger)endHour
       endMinute:(NSInteger)endMinute {
    NSString *begin = [NSString stringWithFormat:@"%02ld:%02ld", (long)beginHour, (long)beginMinute];
    NSString *end = [NSString stringWithFormat:@"%02ld:%02ld", (long)endHour, (long)endMinute];
    [self appendLogFormat:@"SDK setDontDisturbOn on=%@ begin=%@ end=%@", on ? @"YES" : @"NO", begin, end];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator setDontDisturbOn:on beginTime:begin endTime:end success:^(BOOL featureOn, NSString *b, NSString *e) {
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf) { return; }
        strongSelf.lastDndOn = featureOn;
        NSInteger bh = strongSelf.lastDndBeginHour, bm = strongSelf.lastDndBeginMinute;
        NSInteger eh = strongSelf.lastDndEndHour, em = strongSelf.lastDndEndMinute;
        [strongSelf parseTime:b hour:&bh minute:&bm];
        [strongSelf parseTime:e hour:&eh minute:&em];
        strongSelf.lastDndBeginHour = bh;
        strongSelf.lastDndBeginMinute = bm;
        strongSelf.lastDndEndHour = eh;
        strongSelf.lastDndEndMinute = em;
        [strongSelf appendLogFormat:@"[DND] set success on=%@ begin=%@ end=%@",
         featureOn ? @"YES" : @"NO", b ?: @"", e ?: @""];
    } fail:^{
        [weakSelf appendLog:@"[DND] set failed"];
    }];
}

- (void)parseTime:(NSString *)time hour:(NSInteger *)hour minute:(NSInteger *)minute {
    if (time.length < 3 || !hour || !minute) { return; }
    NSArray<NSString *> *parts = [time componentsSeparatedByString:@":"];
    if (parts.count < 2) { return; }
    *hour = parts[0].integerValue;
    *minute = parts[1].integerValue;
}

#pragma mark - Light / 自定义亮灯

- (void)presentSendLightAlert {
    UIAlertController *alert =
    [UIAlertController alertControllerWithTitle:QCSampleLocalized(QCSampleLocalizedKeyNotifSendLight)
                                        message:nil
                                 preferredStyle:UIAlertControllerStyleAlert];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyNotifPriority)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyNotifPriorityHint,
                                                        (long)kQCSamplePriorityMin,
                                                        (long)kQCSamplePriorityMax)
                           text:self.lastLightPriority];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyNotifLightAction)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyNotifLightActionHint,
                                                        (long)kQCSampleLightActionMin,
                                                        (long)kQCSampleLightActionMax)
                           text:self.lastLightAction];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyNotifCycle)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyNotifCycleHint,
                                                        (long)kQCSampleCycleMin,
                                                        (long)kQCSampleCycleMax)
                           text:self.lastLightCycle];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyNotifOnDuration)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyNotifDurationHint,
                                                        (long)kQCSampleDurationMin,
                                                        (long)kQCSampleDurationMax)
                           text:self.lastLightOnDuration];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyNotifPauseDuration)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyNotifPauseHint,
                                                        (long)kQCSamplePauseMin,
                                                        (long)kQCSamplePauseMax)
                           text:self.lastLightPause];
    __weak typeof(self) weakSelf = self;
    [alert addAction:[UIAlertAction actionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyCommonCancel)
                                              style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyCommonOK)
                                              style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction *action) {
        NSInteger priority = alert.textFields[0].text.integerValue;
        NSInteger mode = alert.textFields[1].text.integerValue;
        NSInteger cycle = alert.textFields[2].text.integerValue;
        NSInteger onDur = alert.textFields[3].text.integerValue;
        NSInteger pause = alert.textFields[4].text.integerValue;
        if (![weakSelf validateInputValue:priority min:kQCSamplePriorityMin max:kQCSamplePriorityMax
                               fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyNotifPriority)] ||
            ![weakSelf validateInputValue:mode min:kQCSampleLightActionMin max:kQCSampleLightActionMax
                               fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyNotifLightAction)] ||
            ![weakSelf validateInputValue:cycle min:kQCSampleCycleMin max:kQCSampleCycleMax
                               fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyNotifCycle)] ||
            ![weakSelf validateInputValue:onDur min:kQCSampleDurationMin max:kQCSampleDurationMax
                               fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyNotifOnDuration)] ||
            ![weakSelf validateInputValue:pause min:kQCSamplePauseMin max:kQCSamplePauseMax
                               fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyNotifPauseDuration)]) {
            return;
        }
        [weakSelf sendLightPriority:priority action:mode cycle:cycle onDuration:onDur pause:pause];
    }]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)sendLightPriority:(NSInteger)priority
                   action:(NSInteger)action
                    cycle:(NSInteger)cycle
               onDuration:(NSInteger)onDuration
                    pause:(NSInteger)pause {
    self.lastLightPriority = priority;
    self.lastLightAction = action;
    self.lastLightCycle = cycle;
    self.lastLightOnDuration = onDuration;
    self.lastLightPause = pause;
    [self appendLogFormat:@"SDK sendCustomLightNotification priority=%ld action=%ld cycle=%ld on=%ld pause=%ld",
     (long)priority, (long)action, (long)cycle, (long)onDuration, (long)pause];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator sendCustomLightNotificationWithPriority:priority
                                                      action:(QCNotificationLightAction)action
                                                  cycleCount:cycle
                                                  onDuration:onDuration
                                               pauseDuration:pause
                                                     success:^{
        [weakSelf appendLog:@"[Light] send success"];
    } fail:^{
        [weakSelf appendLog:@"[Light] send failed"];
    }];
}

#pragma mark - Vibration / 自定义震动

- (void)presentSendVibrationAlert {
    UIAlertController *alert =
    [UIAlertController alertControllerWithTitle:QCSampleLocalized(QCSampleLocalizedKeyNotifSendVibration)
                                        message:nil
                                 preferredStyle:UIAlertControllerStyleAlert];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyNotifPriority)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyNotifPriorityHint,
                                                        (long)kQCSamplePriorityMin,
                                                        (long)kQCSamplePriorityMax)
                           text:self.lastVibPriority];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyNotifVibrationAction)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyNotifVibrationActionHint,
                                                        (long)kQCSampleVibrationActionMin,
                                                        (long)kQCSampleVibrationActionMax)
                           text:self.lastVibAction];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyNotifCycle)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyNotifCycleHint,
                                                        (long)kQCSampleCycleMin,
                                                        (long)kQCSampleCycleMax)
                           text:self.lastVibCycle];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyNotifVibrateDuration)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyNotifDurationHint,
                                                        (long)kQCSampleDurationMin,
                                                        (long)kQCSampleDurationMax)
                           text:self.lastVibDuration];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyNotifPauseDuration)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyNotifPauseHint,
                                                        (long)kQCSamplePauseMin,
                                                        (long)kQCSamplePauseMax)
                           text:self.lastVibPause];
    __weak typeof(self) weakSelf = self;
    [alert addAction:[UIAlertAction actionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyCommonCancel)
                                              style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyCommonOK)
                                              style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction *action) {
        NSInteger priority = alert.textFields[0].text.integerValue;
        NSInteger mode = alert.textFields[1].text.integerValue;
        NSInteger cycle = alert.textFields[2].text.integerValue;
        NSInteger vibDur = alert.textFields[3].text.integerValue;
        NSInteger pause = alert.textFields[4].text.integerValue;
        if (![weakSelf validateInputValue:priority min:kQCSamplePriorityMin max:kQCSamplePriorityMax
                               fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyNotifPriority)] ||
            ![weakSelf validateInputValue:mode min:kQCSampleVibrationActionMin max:kQCSampleVibrationActionMax
                               fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyNotifVibrationAction)] ||
            ![weakSelf validateInputValue:cycle min:kQCSampleCycleMin max:kQCSampleCycleMax
                               fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyNotifCycle)] ||
            ![weakSelf validateInputValue:vibDur min:kQCSampleDurationMin max:kQCSampleDurationMax
                               fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyNotifVibrateDuration)] ||
            ![weakSelf validateInputValue:pause min:kQCSamplePauseMin max:kQCSamplePauseMax
                               fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyNotifPauseDuration)]) {
            return;
        }
        [weakSelf sendVibrationPriority:priority action:mode cycle:cycle vibrateDuration:vibDur pause:pause];
    }]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)sendVibrationPriority:(NSInteger)priority
                       action:(NSInteger)action
                        cycle:(NSInteger)cycle
              vibrateDuration:(NSInteger)vibrateDuration
                        pause:(NSInteger)pause {
    self.lastVibPriority = priority;
    self.lastVibAction = action;
    self.lastVibCycle = cycle;
    self.lastVibDuration = vibrateDuration;
    self.lastVibPause = pause;
    [self appendLogFormat:@"SDK sendCustomVibrationNotification priority=%ld action=%ld cycle=%ld vib=%ld pause=%ld",
     (long)priority, (long)action, (long)cycle, (long)vibrateDuration, (long)pause];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator sendCustomVibrationNotificationWithPriority:priority
                                                          action:(QCNotificationVibrationAction)action
                                                      cycleCount:cycle
                                                 vibrateDuration:vibrateDuration
                                                   pauseDuration:pause
                                                         success:^{
        [weakSelf appendLog:@"[Vibration] send success"];
    } fail:^{
        [weakSelf appendLog:@"[Vibration] send failed"];
    }];
}

#pragma mark - Music / 音乐开关

- (void)getMusic {
    [self appendLogFormat:@"SDK getMusicControlStatus hint=%@", self.lastMusicEnable ? @"YES" : @"NO"];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator getMusicControlStatusWithCurrentState:self.lastMusicEnable success:^(BOOL enable) {
        weakSelf.lastMusicEnable = enable;
        [weakSelf appendLogFormat:@"[Music] get success on=%@", enable ? @"YES" : @"NO"];
    } fail:^{
        [weakSelf appendLog:@"[Music] get failed"];
    }];
}

- (void)presentSetMusicAlert {
    UIAlertController *alert =
    [UIAlertController alertControllerWithTitle:QCSampleLocalized(QCSampleLocalizedKeyNotifSetMusic)
                                        message:nil
                                 preferredStyle:UIAlertControllerStyleAlert];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyNotifMusicEnable)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyNotifBoolHint,
                                                        (long)kQCSampleBoolMin,
                                                        (long)kQCSampleBoolMax)
                           text:self.lastMusicEnable ? 1 : 0];
    __weak typeof(self) weakSelf = self;
    [alert addAction:[UIAlertAction actionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyCommonCancel)
                                              style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyCommonOK)
                                              style:UIAlertActionStyleDefault
                                            handler:^(UIAlertAction *action) {
        NSInteger enable = alert.textFields.firstObject.text.integerValue;
        if (![weakSelf validateInputValue:enable min:kQCSampleBoolMin max:kQCSampleBoolMax
                               fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyNotifMusicEnable)]) {
            return;
        }
        [weakSelf setMusicOn:(enable == 1)];
    }]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)setMusicOn:(BOOL)on {
    [self appendLogFormat:@"SDK setMusicControlStatus %@", on ? @"YES" : @"NO"];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator setMusicControlStatus:on success:^(BOOL enable) {
        weakSelf.lastMusicEnable = enable;
        [weakSelf appendLogFormat:@"[Music] set success on=%@", enable ? @"YES" : @"NO"];
    } fail:^{
        [weakSelf appendLog:@"[Music] set failed"];
    }];
}

@end
