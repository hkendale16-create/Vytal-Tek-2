//
//  QCSampleDeviceStatus.h
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//

#import <Foundation/Foundation.h>
#import "QCCentralManager.h"

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, QCSampleConnectionPresentation) {
    QCSampleConnectionPresentationDisconnected = 0,
    QCSampleConnectionPresentationConnecting,
    QCSampleConnectionPresentationConnected,
};

/// Device status snapshot for the home header; binds easily to UI and debugging. 首页头部展示用的设备状态快照，便于调试与 UI 绑定
@interface QCSampleDeviceStatus : NSObject

@property (nonatomic, copy, readonly) NSString *deviceName;
@property (nonatomic, copy, readonly) NSString *bluetoothStatusText;
@property (nonatomic, assign, readonly) QCSampleConnectionPresentation connectionState;
@property (nonatomic, copy, readonly) NSString *macAddress;
@property (nonatomic, copy, readonly) NSString *batteryText;
@property (nonatomic, copy, readonly) NSString *firmwareVersion;

- (BOOL)isConnected;

@end

@protocol QCSampleDeviceStatusObserver <NSObject>
- (void)deviceStatusDidChange:(QCSampleDeviceStatus *)status;
@end

/// Encapsulates connection monitoring and device info fetching; home screens only need to subscribe. 封装连接状态监听与设备信息拉取，首页只需订阅即可
@interface QCSampleDeviceStatusProvider : NSObject <QCCentralManagerDelegate>

@property (nonatomic, strong, readonly) QCSampleDeviceStatus *currentStatus;

+ (instancetype)shared;

- (void)addObserver:(id<QCSampleDeviceStatusObserver>)observer;
- (void)removeObserver:(id<QCSampleDeviceStatusObserver>)observer;

/// Refreshes battery, MAC, firmware, etc. when connected. 主动刷新电量、Mac、固件等信息（已连接时有效）
- (void)refreshConnectedDeviceInfo;

/// Updates display according to BLE connection state. 根据蓝牙连接状态刷新展示
- (void)updateForDeviceState:(QCState)state;

@end

NS_ASSUME_NONNULL_END
