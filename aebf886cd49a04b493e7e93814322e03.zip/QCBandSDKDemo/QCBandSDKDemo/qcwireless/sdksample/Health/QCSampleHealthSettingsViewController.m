//
//  QCSampleHealthSettingsViewController.m
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//
//  Health settings menu: navigates to each feature sample page.
//  健康设置菜单：跳转各功能演示页。

#import "QCSampleHealthSettingsViewController.h"
#import "QCSampleLocalization.h"
#import "QCSampleStepsViewController.h"
#import "QCSampleSleepViewController.h"
#import "QCSampleSportRecordViewController.h"
#import "QCSampleHeartRateViewController.h"
#import "QCSampleBloodPressureViewController.h"
#import "QCSampleBloodOxygenViewController.h"
#import "QCSampleHRVViewController.h"
#import "QCSamplePressureViewController.h"
#import "QCSampleTemperatureViewController.h"
#import "QCSampleSugarLipidsViewController.h"
#import "QCSampleEmotionViewController.h"
#import "QCSampleDrinkReminderViewController.h"
#import "QCSampleSedentaryReminderViewController.h"
#import "QCSampleHealthBatchSyncViewController.h"
#import "QCCentralManager.h"
#import "QCSampleToast.h"

typedef NS_ENUM(NSInteger, QCSampleHealthMenuItemType) {
    QCSampleHealthMenuItemTypeBatchSync = 0,
    QCSampleHealthMenuItemTypeSteps,
    QCSampleHealthMenuItemTypeSleep,
    QCSampleHealthMenuItemTypeSportRecord,
    QCSampleHealthMenuItemTypeHeartRate,
    QCSampleHealthMenuItemTypeBloodPressure,
    QCSampleHealthMenuItemTypeBloodOxygen,
    QCSampleHealthMenuItemTypeHRV,
    QCSampleHealthMenuItemTypePressure,
    QCSampleHealthMenuItemTypeTemperature,
    QCSampleHealthMenuItemTypeSugarLipids,
    QCSampleHealthMenuItemTypeEmotion,
    QCSampleHealthMenuItemTypeDrinkReminder,
    QCSampleHealthMenuItemTypeSedentaryReminder,
};

@interface QCSampleHealthMenuRow : NSObject
@property (nonatomic, assign) QCSampleHealthMenuItemType type;
@property (nonatomic, copy) NSString *title;
@property (nonatomic, assign) BOOL showsDisclosure;
@end
@implementation QCSampleHealthMenuRow
@end

static NSString * const kQCSampleHealthSettingsCellIdentifier = @"QCSampleHealthSettingsCell";

@interface QCSampleHealthSettingsViewController () <UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, copy) NSArray<QCSampleHealthMenuRow *> *rows;
@property (nonatomic, strong) UITableView *tableView;

@end

@implementation QCSampleHealthSettingsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.edgesForExtendedLayout = UIRectEdgeNone;
    self.rows = [self buildRows];

    self.tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStyleGrouped];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.backgroundColor = [UIColor groupTableViewBackgroundColor];
    if (@available(iOS 15.0, *)) {
        self.tableView.sectionHeaderTopPadding = 0;
    }
    [self.view addSubview:self.tableView];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.title = QCSampleLocalized(QCSampleLocalizedKeyItemHealthSettings);
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    self.tableView.frame = self.view.bounds;
}

- (NSArray<QCSampleHealthMenuRow *> *)buildRows {
    NSArray *specs = @[
        @[@(QCSampleHealthMenuItemTypeBatchSync), QCSampleLocalizedKeyHealthBatchSync, @NO],
        @[@(QCSampleHealthMenuItemTypeSteps), QCSampleLocalizedKeyHealthActivitySteps, @YES],
        @[@(QCSampleHealthMenuItemTypeSleep), QCSampleLocalizedKeyHealthSleep, @YES],
        @[@(QCSampleHealthMenuItemTypeSportRecord), QCSampleLocalizedKeyHealthSportRecords, @YES],
        @[@(QCSampleHealthMenuItemTypeHeartRate), QCSampleLocalizedKeyHealthHeartRate, @YES],
        @[@(QCSampleHealthMenuItemTypeBloodPressure), QCSampleLocalizedKeyHealthBloodPressure, @YES],
        @[@(QCSampleHealthMenuItemTypeBloodOxygen), QCSampleLocalizedKeyHealthBloodOxygen, @YES],
        @[@(QCSampleHealthMenuItemTypeHRV), QCSampleLocalizedKeyHealthHRV, @YES],
        @[@(QCSampleHealthMenuItemTypePressure), QCSampleLocalizedKeyHealthStress, @YES],
        @[@(QCSampleHealthMenuItemTypeTemperature), QCSampleLocalizedKeyHealthBodyTemperature, @YES],
        @[@(QCSampleHealthMenuItemTypeSugarLipids), QCSampleLocalizedKeyHealthBloodGlucoseLipids, @YES],
        @[@(QCSampleHealthMenuItemTypeEmotion), QCSampleLocalizedKeyHealthEmotion, @YES],
        @[@(QCSampleHealthMenuItemTypeDrinkReminder), QCSampleLocalizedKeyHealthWaterReminder, @YES],
        @[@(QCSampleHealthMenuItemTypeSedentaryReminder), QCSampleLocalizedKeyHealthSedentaryReminder, @YES],
    ];
    NSMutableArray *rows = [NSMutableArray arrayWithCapacity:specs.count];
    for (NSArray *spec in specs) {
        QCSampleHealthMenuRow *row = [[QCSampleHealthMenuRow alloc] init];
        row.type = [spec[0] integerValue];
        row.title = QCSampleLocalized(spec[1]);
        row.showsDisclosure = [spec[2] boolValue];
        [rows addObject:row];
    }
    return [rows copy];
}

#pragma mark - Navigation

- (UIViewController *)viewControllerForMenuType:(QCSampleHealthMenuItemType)type {
    switch (type) {
        case QCSampleHealthMenuItemTypeSteps: return [[QCSampleStepsViewController alloc] init];
        case QCSampleHealthMenuItemTypeSleep: return [[QCSampleSleepViewController alloc] init];
        case QCSampleHealthMenuItemTypeSportRecord: return [[QCSampleSportRecordViewController alloc] init];
        case QCSampleHealthMenuItemTypeHeartRate: return [[QCSampleHeartRateViewController alloc] init];
        case QCSampleHealthMenuItemTypeBloodPressure: return [[QCSampleBloodPressureViewController alloc] init];
        case QCSampleHealthMenuItemTypeBloodOxygen: return [[QCSampleBloodOxygenViewController alloc] init];
        case QCSampleHealthMenuItemTypeHRV: return [[QCSampleHRVViewController alloc] init];
        case QCSampleHealthMenuItemTypePressure: return [[QCSamplePressureViewController alloc] init];
        case QCSampleHealthMenuItemTypeTemperature: return [[QCSampleTemperatureViewController alloc] init];
        case QCSampleHealthMenuItemTypeSugarLipids: return [[QCSampleSugarLipidsViewController alloc] init];
        case QCSampleHealthMenuItemTypeEmotion: return [[QCSampleEmotionViewController alloc] init];
        case QCSampleHealthMenuItemTypeDrinkReminder: return [[QCSampleDrinkReminderViewController alloc] init];
        case QCSampleHealthMenuItemTypeSedentaryReminder: return [[QCSampleSedentaryReminderViewController alloc] init];
        default: return nil;
    }
}

- (void)startBatchSync {
    if ([QCCentralManager shared].deviceState != QCStateConnected) {
        [QCSampleToast showCenterWithText:QCSampleLocalized(QCSampleLocalizedKeyHealthNotConnected)];
        return;
    }
    [self.navigationController pushViewController:[[QCSampleHealthBatchSyncViewController alloc] init] animated:YES];
}

#pragma mark - UITableView

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.rows.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:kQCSampleHealthSettingsCellIdentifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:kQCSampleHealthSettingsCellIdentifier];
        cell.textLabel.font = [UIFont systemFontOfSize:16.0];
    }
    QCSampleHealthMenuRow *row = self.rows[indexPath.row];
    cell.textLabel.text = row.title;
    cell.accessoryType = row.showsDisclosure ? UITableViewCellAccessoryDisclosureIndicator : UITableViewCellAccessoryNone;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    QCSampleHealthMenuRow *row = self.rows[indexPath.row];
    if (row.type == QCSampleHealthMenuItemTypeBatchSync) {
        [self startBatchSync];
        return;
    }
    UIViewController *vc = [self viewControllerForMenuType:row.type];
    if (vc) {
        [self.navigationController pushViewController:vc animated:YES];
    }
}

@end
