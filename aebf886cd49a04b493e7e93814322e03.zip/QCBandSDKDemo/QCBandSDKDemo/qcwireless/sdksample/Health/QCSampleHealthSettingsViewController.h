//
//  QCSampleHealthSettingsViewController.h
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//
//  Health settings menu sample: lists health feature entries and pushes each SDK demo page.
//  健康设置菜单示例：列出各健康功能入口，并跳转对应 SDK 演示页。

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/// Health settings hub for integrators; each row opens a feature sample (steps, sleep, HR, etc.). 集成方健康设置入口，每行跳转对应功能示例（步数、睡眠、心率等）。
@interface QCSampleHealthSettingsViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
