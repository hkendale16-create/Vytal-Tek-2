//
//  QCSampleSportRecordViewController.h
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//
//  Sport records SDK sample. SDK calls are in QCSampleSportRecordViewController.m
//  运动记录 SDK 示例。SDK 调用见 QCSampleSportRecordViewController.m

#import "QCSampleHealthFunctionViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface QCSampleSportRecordViewController : QCSampleHealthFunctionViewController
@end

NS_ASSUME_NONNULL_END
