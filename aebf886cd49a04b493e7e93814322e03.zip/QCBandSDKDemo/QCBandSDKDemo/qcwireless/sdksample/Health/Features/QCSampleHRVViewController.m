//
//  QCSampleHRVViewController.m
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//
//  HRV SDK sample. HRV SDK 示例。

#import "QCSampleHRVViewController.h"
#import "QCSampleLocalization.h"
#import <QCBandSDK/QCSDKCmdCreator.h>
#import <QCBandSDK/QCSDKManager.h>
#import <QCBandSDK/QCHRVDayModel.h>
#import <QCBandSDK/QCHRVSampleModel.h>

@interface QCSampleHRVViewController ()
@property (nonatomic, assign) BOOL isHRVMeasuring;
@end

@implementation QCSampleHRVViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = QCSampleLocalized(QCSampleLocalizedKeyHealthHRV);
}

- (void)setupActions {
    __weak typeof(self) weakSelf = self;
    NSString *title = QCSampleLocalized(QCSampleLocalizedKeyHealthHRV);

    [self beginActionSection:QCSampleLocalized(QCSampleLocalizedKeyHealthHRVSectionSettings)];
    [self addSwitchWithTitle:QCSampleLocalized(QCSampleLocalizedKeyHealthHRVSwitch) readHandler:^(QCSampleHealthSwitchCompletion completion) {
        [QCSDKCmdCreator getSchedualHRVWithFinshed:^(BOOL isOn, NSError * _Nullable error) {
            if (error) {
                [weakSelf appendLogFormat:@"❌ getSchedualHRVWithFinshed failed: %@", error.localizedDescription];
            } else {
                [weakSelf appendLogFormat:@"Scheduled HRV switch: %@", isOn ? @"ON" : @"OFF"];
            }
            completion(isOn, error);
        }];
    } writeHandler:^(BOOL enabled, QCSampleHealthSwitchCompletion completion) {
        [QCSDKCmdCreator setSchedualHRVStatus:enabled finshed:^(NSError * _Nullable error) {
            if (error) {
                [weakSelf appendLogFormat:@"❌ setSchedualHRVStatus failed: %@", error.localizedDescription];
            } else {
                [weakSelf appendLogFormat:@"✅ scheduled HRV switch → %@", enabled ? @"ON" : @"OFF"];
            }
            completion(enabled, error);
        }];
    }];

    [self beginActionSection:QCSampleLocalized(QCSampleLocalizedKeyHealthHRVSectionHistory)];
    [self bindHealthQueryWithTitle:title
                      todayHandler:^{
        [weakSelf fetchHRVForDayIndexes:@[@(0)]];
    } singleDayHandler:^(NSInteger dayIndex) {
        [weakSelf fetchHRVForDayIndexes:@[@(dayIndex)]];
    } rangeHandler:^(NSInteger startDayIndex, NSInteger count) {
        NSMutableArray *days = [NSMutableArray arrayWithCapacity:count];
        for (NSInteger i = 0; i < count; i++) {
            [days addObject:@(startDayIndex + i)];
        }
        [weakSelf fetchHRVForDayIndexes:days];
    }];

    [self beginActionSection:QCSampleLocalized(QCSampleLocalizedKeyHealthHRVSectionMeasure)];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyHealthHRVMeasureStart) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf startHRVMeasure];
    }];

    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyHealthHRVMeasureStop) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf stopHRVMeasure];
    }];
}

- (void)fetchHRVForDayIndexes:(NSArray<NSNumber *> *)dayIndexes {
    [self appendLog:@"Get scheduled HRV data"];
    [self appendLogFormat:@"SDK getSchedualHRVWithFinshed → getHRVSamplesWithDayIndexes:%@", dayIndexes];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator getSchedualHRVWithFinshed:^(BOOL isOn, NSError * _Nullable error) {
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf) { return; }
        if (error) {
            [strongSelf appendLogFormat:@"❌ getSchedualHRVWithFinshed failed: %@", error.localizedDescription];
            return;
        }
        [strongSelf appendLogFormat:@"📊 schedual HRV switch: %@", isOn ? @"ON" : @"OFF"];
        [QCSDKCmdCreator getHRVSamplesWithDayIndexes:dayIndexes finished:^(NSArray<QCHRVDayModel *> * _Nullable days, NSError * _Nullable err) {
            __strong typeof(weakSelf) innerSelf = weakSelf;
            if (!innerSelf) { return; }
            if (err) {
                [innerSelf appendLogFormat:@"❌ getHRVSamplesWithDayIndexes failed: %@", err.localizedDescription];
                return;
            }
            [innerSelf appendLogFormat:@"✅ getHRVSamplesWithDayIndexes success, dayCount:%ld", (long)days.count];
            for (QCHRVDayModel *day in days) {
                NSInteger valid = 0;
                NSMutableArray *validPoints = [NSMutableArray array];
                for (QCHRVSampleModel *sample in day.samples) {
                    if (sample.value <= 0) {
                        continue;
                    }
                    valid += 1;
                    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
                    formatter.dateFormat = @"HH:mm";
                    [validPoints addObject:@{
                        @"time": [formatter stringFromDate:sample.time],
                        @"hrv": @(sample.value)
                    }];
                }
                [innerSelf appendLogFormat:@"date:%@ timeline:%ldmin device:%ldmin total:%ld valid:%ld points:%@",
                 day.date,
                 (long)day.intervalMinutes,
                 (long)day.deviceIntervalMinutes,
                 (long)day.samples.count,
                 (long)valid,
                 validPoints];
            }
        }];
    }];
}

- (void)startHRVMeasure {
    __weak typeof(self) weakSelf = self;
    self.isHRVMeasuring = YES;
    [self appendLog:@"Start HRV measurement"];
    [QCSDKCmdCreator setTime:[NSDate date] success:^(NSDictionary * _Nonnull info) {
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf) { return; }
        if (![[info objectForKey:QCBandFeatureAppManual] boolValue]) {
            strongSelf.isHRVMeasuring = NO;
            [strongSelf appendLog:@"Not Support App Manual Measuring"];
            return;
        }
        if ([[info objectForKey:QCBandFeatureHRV] boolValue] == NO) {
            [strongSelf appendLog:@"QCBandFeatureHRV not marked; still trying manual HRV measure"];
        }
        [[QCSDKManager shareInstance] startToMeasuringWithOperateType:QCMeasuringTypeHRV
                                                              timeout:80
                                                      measuringHandle:^(id _Nullable result) {
            __strong typeof(weakSelf) innerSelf = weakSelf;
            if (!innerSelf) { return; }
            if ([result isKindOfClass:[NSNumber class]]) {
                NSInteger hrv = [(NSNumber *)result integerValue];
                if (hrv > 0 && hrv != 141) {
                    [innerSelf appendLogFormat:@"HRV realtime: %ld ms", (long)hrv];
                } else {
                    [innerSelf appendLogFormat:@"HRV realtime invalid placeholder: %@", result];
                }
            }
        } completedHandle:^(BOOL isSuccess, id _Nonnull result, NSError * _Nonnull error) {
            __strong typeof(weakSelf) innerSelf = weakSelf;
            if (!innerSelf) { return; }
            innerSelf.isHRVMeasuring = NO;
            NSInteger hrv = [result isKindOfClass:[NSNumber class]] ? [(NSNumber *)result integerValue] : 0;
            BOOL valid = isSuccess && hrv > 0 && hrv != 141;
            if (valid) {
                [innerSelf appendLogFormat:@"HRV measuring success: %ld ms", (long)hrv];
            } else {
                [innerSelf appendLogFormat:@"HRV measuring failed: %@, result:%@ (0/141 = invalid placeholder)",
                 error.localizedDescription ?: @"no valid value", result];
            }
        }];
    } failed:^{
        weakSelf.isHRVMeasuring = NO;
        [weakSelf appendLog:@"Failed to set time before HRV measuring"];
    }];
}

- (void)stopHRVMeasure {
    [self appendLog:@"Stop HRV measurement"];
    __weak typeof(self) weakSelf = self;
    [[QCSDKManager shareInstance] stopToMeasuringWithOperateType:QCMeasuringTypeHRV completedHandle:^(BOOL isSuccess, NSError * _Nonnull error) {
        weakSelf.isHRVMeasuring = NO;
        if (isSuccess) {
            [weakSelf appendLog:@"Stop success"];
        } else {
            [weakSelf appendLogFormat:@"Stop failed: %@", error.localizedDescription ?: @""];
        }
    }];
}

@end
