//
//  QCSampleSedentaryReminderViewController.m
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//
//  Sedentary reminder SDK sample. Log format follows legacy ViewController -getSedentaryReminderFromDay.

#import "QCSampleSedentaryReminderViewController.h"
#import "QCSampleLocalization.h"
#import <QCBandSDK/QCSDKCmdCreator.h>
#import <QCBandSDK/QCSedentaryModel.h>

@implementation QCSampleSedentaryReminderViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = QCSampleLocalized(QCSampleLocalizedKeyHealthSedentaryReminder);
}

- (void)setupActions {
    __weak typeof(self) weakSelf = self;
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyHealthFetchSedentaryData) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf appendLog:@"Get Sedentary Reminder"];
        [weakSelf appendLog:@"SDK getSedentaryReminderFromDay:1"];
        [QCSDKCmdCreator getSedentaryReminderFromDay:1 finished:^(NSDictionary<NSString *,NSArray<QCSedentaryModel *> *> * _Nullable datas, NSError * _Nullable error) {
            if (error) {
                [weakSelf appendLog:@"Failed to get Sedentary Reminder"];
                return;
            }
            [weakSelf appendLog:@"Get Sedentary Reminder data successfully"];
            for (NSString *dayText in datas.allKeys) {
                [weakSelf appendLogFormat:@"Sedentary Reminder date:%@", dayText];
                NSArray *dayDatas = [datas valueForKey:dayText];
                NSInteger total = 0;
                for (QCSedentaryModel *sedentary in dayDatas) {
                    [weakSelf appendLogFormat:@"Start Time: %@, End Time: %@, Duration: %ld, Type: %ld",
                     sedentary.date, sedentary.endTime, sedentary.duration, (long)sedentary.type];
                    total += sedentary.duration;
                }
                [weakSelf appendLogFormat:@"total duration：%ldh%ldm", total / 60, total % 60];
            }
        }];
    }];
}

@end
