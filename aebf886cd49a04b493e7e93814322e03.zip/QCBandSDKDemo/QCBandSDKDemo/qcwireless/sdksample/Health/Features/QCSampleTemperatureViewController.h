//
//  QCSampleTemperatureViewController.h
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//
//  Body temperature SDK sample. SDK calls are in QCSampleTemperatureViewController.m
//  体温 SDK 示例。SDK 调用见 QCSampleTemperatureViewController.m

#import "QCSampleHealthFunctionViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface QCSampleTemperatureViewController : QCSampleHealthFunctionViewController
@end

NS_ASSUME_NONNULL_END
