//
//  QCSampleTemperatureViewController.m
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//
//  Body temperature SDK sample. 体温 SDK 示例。
//
//  SDK 体温 API：
//  - 定时体温历史：getSchedualTemperatureDataByDayIndex → QCTemperatureModel
//  - 手动体温历史：getManualTemperatureDataByDayIndex → QCTemperatureModel
//  - 间隔三值体温：getTemperatureDataWithIntervalByDayIndex → QCThreeValueTemperatureModel
//  - App 单次三值测量：startToMeasuringWithOperateType:QCMeasuringTypeThreeValueBodyTemperature
//  - 开关设置：getSchedualInfoType / setSchedualInfoType (SchedualInfoTypeBodyTemperator)

#import "QCSampleTemperatureViewController.h"
#import "QCSampleLocalization.h"
#import <QCBandSDK/QCSDKCmdCreator.h>
#import <QCBandSDK/QCSDKManager.h>
#import <QCBandSDK/QCTemperatureModel.h>
#import <QCBandSDK/QCThreeValueTemperatureModel.h>
#import <QCBandSDK/QCDFU_Utils.h>

static NSString * const kQCSampleTemperatureLogScheduled = @"schedual";
static NSString * const kQCSampleTemperatureLogManual = @"manual";
static NSString * const kQCSampleTemperatureLogInterval = @"interval";

@implementation QCSampleTemperatureViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = QCSampleLocalized(QCSampleLocalizedKeyHealthBodyTemperature);
}

- (void)setupActions {
    __weak typeof(self) weakSelf = self;

    [self addSwitchWithTitle:QCSampleLocalized(QCSampleLocalizedKeyHealthTemperatureSwitch) readHandler:^(QCSampleHealthSwitchCompletion completion) {
        [weakSelf appendLog:@"SDK getSchedualInfoType:SchedualInfoTypeBodyTemperator"];
        [QCSDKCmdCreator getSchedualInfoType:SchedualInfoTypeBodyTemperator success:^(BOOL isOn, NSInteger calibrate) {
            [weakSelf appendLogFormat:@"get schedual Temperature is %@", isOn ? @"On" : @"Off"];
            completion(isOn, nil);
        } fail:^{
            [weakSelf appendLog:@"❌ getSchedualInfoType failed"];
            completion(NO, [NSError errorWithDomain:@"QCSampleHealthSwitch" code:-1 userInfo:nil]);
        }];
    } writeHandler:^(BOOL enabled, QCSampleHealthSwitchCompletion completion) {
        [weakSelf appendLogFormat:@"SDK setSchedualInfoType:BodyTemperator %@", enabled ? @"ON" : @"OFF"];
        if (!enabled) {
            [QCSDKCmdCreator setSchedualInfoType:SchedualInfoTypeBodyTemperator
                                       featureOn:NO
                                       calibrate:0
                                         success:^{
                [weakSelf appendLog:@"✅ setSchedualInfoType OFF success"];
                completion(NO, nil);
            } fail:^{
                [weakSelf appendLog:@"❌ setSchedualInfoType OFF failed"];
                completion(NO, [NSError errorWithDomain:@"QCSampleHealthSwitch" code:-1 userInfo:nil]);
            }];
            return;
        }
        [QCSDKCmdCreator setSchedualInfoType:SchedualInfoTypeBodyTemperator
                                   featureOn:YES
                                   calibrate:0
                                    interval:1
                                     success:^{
            [weakSelf appendLog:@"✅ setSchedualInfoType ON success"];
            completion(YES, nil);
        } fail:^{
            [weakSelf appendLog:@"❌ setSchedualInfoType ON failed"];
            completion(YES, [NSError errorWithDomain:@"QCSampleHealthSwitch" code:-1 userInfo:nil]);
        }];
    }];

    [self bindHealthQueryWithTitle:QCSampleLocalized(QCSampleLocalizedKeyHealthTemperatureScheduledQuery)
                      todayHandler:^{
        [weakSelf fetchScheduledTemperatureForDayIndexes:@[@(0)]];
    } singleDayHandler:^(NSInteger dayIndex) {
        [weakSelf fetchScheduledTemperatureForDayIndexes:@[@(dayIndex)]];
    } rangeHandler:^(NSInteger startDayIndex, NSInteger count) {
        NSMutableArray<NSNumber *> *dayIndexes = [NSMutableArray arrayWithCapacity:count];
        for (NSInteger i = 0; i < count; i++) {
            [dayIndexes addObject:@(startDayIndex + i)];
        }
        [weakSelf fetchScheduledTemperatureForDayIndexes:dayIndexes];
    }];

    [self bindHealthQueryWithTitle:QCSampleLocalized(QCSampleLocalizedKeyHealthTemperatureManualQuery)
                      todayHandler:^{
        [weakSelf fetchManualTemperatureForDayIndexes:@[@(0)]];
    } singleDayHandler:^(NSInteger dayIndex) {
        [weakSelf fetchManualTemperatureForDayIndexes:@[@(dayIndex)]];
    } rangeHandler:^(NSInteger startDayIndex, NSInteger count) {
        NSMutableArray<NSNumber *> *dayIndexes = [NSMutableArray arrayWithCapacity:count];
        for (NSInteger i = 0; i < count; i++) {
            [dayIndexes addObject:@(startDayIndex + i)];
        }
        [weakSelf fetchManualTemperatureForDayIndexes:dayIndexes];
    }];

    [self bindHealthQueryWithTitle:QCSampleLocalized(QCSampleLocalizedKeyHealthTemperatureIntervalQuery)
                      todayHandler:^{
        [weakSelf fetchIntervalTemperatureForDayIndexes:@[@(0)]];
    } singleDayHandler:^(NSInteger dayIndex) {
        [weakSelf fetchIntervalTemperatureForDayIndexes:@[@(dayIndex)]];
    } rangeHandler:^(NSInteger startDayIndex, NSInteger count) {
        NSMutableArray<NSNumber *> *dayIndexes = [NSMutableArray arrayWithCapacity:count];
        for (NSInteger i = 0; i < count; i++) {
            [dayIndexes addObject:@(startDayIndex + i)];
        }
        [weakSelf fetchIntervalTemperatureForDayIndexes:dayIndexes];
    }];

    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyHealthTemperatureAppMeasure) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf startAppThreeValueTemperatureMeasure];
    }];
}

#pragma mark - Scheduled

- (void)fetchScheduledTemperatureForDayIndexes:(NSArray<NSNumber *> *)dayIndexes {
    if (![self ensureConnected]) { return; }
    __weak typeof(self) weakSelf = self;
    [self fetchDayIndexes:dayIndexes sequentially:^(NSInteger dayIndex, void (^next)(void)) {
        [weakSelf fetchScheduledTemperatureForDayIndex:dayIndex completion:next];
    }];
}

- (void)fetchScheduledTemperatureForDayIndex:(NSInteger)dayIndex completion:(void (^)(void))completion {
    [self appendLogFormat:@"SDK getSchedualTemperatureDataByDayIndex:%ld", (long)dayIndex];
    [QCSDKCmdCreator getSchedualTemperatureDataByDayIndex:dayIndex finished:^(NSArray *list, NSError *error) {
        if (error) {
            [self appendLogFormat:@"❌ dayIndex=%ld getSchedualTemperatureDataByDayIndex failed: %@", (long)dayIndex, error.localizedDescription];
        } else {
            [self logTemperatureModels:list tag:kQCSampleTemperatureLogScheduled dayIndex:dayIndex];
        }
        if (completion) {
            completion();
        }
    }];
}

#pragma mark - Manual

- (void)fetchManualTemperatureForDayIndexes:(NSArray<NSNumber *> *)dayIndexes {
    if (![self ensureConnected]) { return; }
    __weak typeof(self) weakSelf = self;
    [self fetchDayIndexes:dayIndexes sequentially:^(NSInteger dayIndex, void (^next)(void)) {
        [weakSelf fetchManualTemperatureForDayIndex:dayIndex completion:next];
    }];
}

- (void)fetchManualTemperatureForDayIndex:(NSInteger)dayIndex completion:(void (^)(void))completion {
    [self appendLogFormat:@"SDK getManualTemperatureDataByDayIndex:%ld", (long)dayIndex];
    [QCSDKCmdCreator getManualTemperatureDataByDayIndex:dayIndex finished:^(NSArray *list, NSError *error) {
        if (error) {
            [self appendLogFormat:@"❌ dayIndex=%ld getManualTemperatureDataByDayIndex failed: %@", (long)dayIndex, error.localizedDescription];
        } else {
            [self logTemperatureModels:list tag:kQCSampleTemperatureLogManual dayIndex:dayIndex];
        }
        if (completion) {
            completion();
        }
    }];
}

#pragma mark - Interval 3-Value

- (void)fetchIntervalTemperatureForDayIndexes:(NSArray<NSNumber *> *)dayIndexes {
    if (![self ensureConnected]) { return; }
    __weak typeof(self) weakSelf = self;
    [self fetchDayIndexes:dayIndexes sequentially:^(NSInteger dayIndex, void (^next)(void)) {
        [weakSelf fetchIntervalTemperatureForDayIndex:dayIndex completion:next];
    }];
}

- (void)fetchIntervalTemperatureForDayIndex:(NSInteger)dayIndex completion:(void (^)(void))completion {
    if (dayIndex == 0) {
        [self appendLog:@"🌟开始获取温度数据🌟"];
    }
    [self appendLogFormat:@"SDK getTemperatureDataWithIntervalByDayIndex:%ld", (long)dayIndex];
    [QCSDKCmdCreator getTemperatureDataWithIntervalByDayIndex:dayIndex finished:^(NSInteger interval, NSArray<QCThreeValueTemperatureModel *> *temperatureList, NSError *error) {
        if (error) {
            [self appendLogFormat:@"❌ 获取温度数据失败: %@", error.localizedDescription];
        } else {
            [self appendLog:@"✅ 获取温度数据成功"];
            [self appendLogFormat:@"📊 温度数据间隔: %ld 分钟", (long)interval];
            [self appendLogFormat:@"📊 温度数据数量: %ld", (long)temperatureList.count];
            for (NSInteger i = 0; i < temperatureList.count; i++) {
                [self appendLogFormat:@"🌡️ %ld 温度数据: %@", (long)i, temperatureList[i]];
            }
        }
        if (completion) {
            completion();
        }
    }];
}

#pragma mark - App Single Measure

- (void)startAppThreeValueTemperatureMeasure {
    __weak typeof(self) weakSelf = self;
    [self appendLog:@"🌟Start measurement🌟"];

    [QCSDKCmdCreator setTime:[NSDate date] success:^(NSDictionary *info) {
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf) { return; }

        if (![info[QCBandFeatureAppManual] boolValue]) {
            [strongSelf appendLog:@"Not Supperort "];
            return;
        }
        [strongSelf appendLog:@"Supperort "];

        [[QCSDKManager shareInstance] startToMeasuringWithOperateType:QCMeasuringTypeThreeValueBodyTemperature
                                                      measuringHandle:^(id result) {
            __strong typeof(weakSelf) innerSelf = weakSelf;
            if (!innerSelf) { return; }
            if ([result isKindOfClass:[QCThreeValueTemperatureModel class]]) {
                [innerSelf appendLogFormat:@"measuringHandle:res: %@ ", result];
            }
        } completedHandle:^(BOOL isSuccess, id result, NSError *error) {
            __strong typeof(weakSelf) innerSelf = weakSelf;
            if (!innerSelf) { return; }
            if (isSuccess) {
                [innerSelf appendLog:@"completedHandle isSuccess"];
            } else {
                [innerSelf appendLog:@"completedHandle failed"];
            }
            if ([result isKindOfClass:[QCThreeValueTemperatureModel class]]) {
                [innerSelf appendLogFormat:@"completedHandle:res: %@ ", result];
            }
        }];
    } failed:^{
        [weakSelf appendLog:@"Failed to set time"];
    }];
}

#pragma mark - Log Helpers

- (void)logTemperatureModels:(NSArray *)list tag:(NSString *)tag dayIndex:(NSInteger)dayIndex {
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    formatter.dateFormat = @"yyyy-MM-dd HH:mm:ss";
    if ([tag isEqualToString:kQCSampleTemperatureLogScheduled]) {
        [self appendLogFormat:@"Schedual Body Temperature datas:%ld", (long)list.count];
    } else {
        [self appendLogFormat:@"%@ dayIndex=%ld count=%ld", tag, (long)dayIndex, (long)list.count];
    }
    NSInteger validCount = 0;
    for (NSInteger i = 0; i < list.count; i++) {
        QCTemperatureModel *model = list[i];
        if (model.temperature <= 0) {
            continue;
        }
        validCount++;
        if ([tag isEqualToString:kQCSampleTemperatureLogScheduled]) {
            [self appendLogFormat:@"🌡️ [%ld] %@ → %.1f℃",
             (long)i, [formatter stringFromDate:model.time], model.temperature];
        } else {
            [self appendLogFormat:@"%@ %@ → %.1f℃",
             tag, [formatter stringFromDate:model.time], model.temperature];
        }
    }
    if ([tag isEqualToString:kQCSampleTemperatureLogScheduled]) {
        [self appendLogFormat:@"有效体温数据: %ld / %ld", (long)validCount, (long)list.count];
    }
}

@end
