//
//  QCSampleEmotionViewController.h
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//
//  Emotion SDK sample. SDK calls are in QCSampleEmotionViewController.m
//  情绪 SDK 示例。SDK 调用见 QCSampleEmotionViewController.m

#import "QCSampleHealthFunctionViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface QCSampleEmotionViewController : QCSampleHealthFunctionViewController
@end

NS_ASSUME_NONNULL_END
