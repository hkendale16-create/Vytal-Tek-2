//
//  QCSampleBloodPressureViewController.h
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//
//  Blood pressure SDK sample. SDK calls are in QCSampleBloodPressureViewController.m
//  血压 SDK 示例。SDK 调用见 QCSampleBloodPressureViewController.m

#import "QCSampleHealthFunctionViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface QCSampleBloodPressureViewController : QCSampleHealthFunctionViewController
@end

NS_ASSUME_NONNULL_END
