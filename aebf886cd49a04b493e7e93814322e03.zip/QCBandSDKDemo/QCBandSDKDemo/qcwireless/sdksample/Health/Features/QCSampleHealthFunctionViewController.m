//
//  QCSampleHealthFunctionViewController.m
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//

#import "QCSampleHealthFunctionViewController.h"
#import "QCSampleLogRecorder.h"
#import "QCSampleLogCell.h"
#import "QCSampleLocalization.h"
#import "QCSampleToast.h"
#import "QCCentralManager.h"

static NSString * const kQCSampleHealthActionCellID = @"QCSampleHealthActionCell";
static NSString * const kQCSampleHealthSwitchCellID = @"QCSampleHealthSwitchCell";
static NSString * const kQCSampleLogCellID = @"QCSampleLogCell";
static NSTimeInterval const kQCSampleHealthSwitchReadTimeout = 8.0;

@interface QCSampleHealthActionItem : NSObject
@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) QCSampleHealthActionHandler handler;
@property (nonatomic, assign) BOOL switchItem;
@property (nonatomic, assign) BOOL switchEnabled;
@property (nonatomic, assign) BOOL switchHasValue;
@property (nonatomic, assign) BOOL switchBusy;
@property (nonatomic, copy, nullable) NSString *switchStatusKey;
@property (nonatomic, copy, nullable) NSString *switchUnavailableStatusKey;
@property (nonatomic, assign) NSUInteger switchReadToken;
@property (nonatomic, copy) QCSampleHealthSwitchReadHandler readHandler;
@property (nonatomic, copy) QCSampleHealthSwitchWriteHandler writeHandler;
@end
@implementation QCSampleHealthActionItem
@end

@interface QCSampleHealthSwitchControl : UISwitch
@property (nonatomic, weak) QCSampleHealthActionItem *item;
@end
@implementation QCSampleHealthSwitchControl
@end

@interface QCSampleHealthActionSection : NSObject
@property (nonatomic, copy) NSString *title;
@property (nonatomic, strong) NSMutableArray<QCSampleHealthActionItem *> *items;
@end
@implementation QCSampleHealthActionSection
@end

@interface QCSampleHealthFunctionViewController () <UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) QCSampleLogRecorder *logger;
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSMutableArray<QCSampleHealthActionSection *> *actionSections;
@property (nonatomic, assign) BOOL hasLoadedSwitchStates;

@end

@implementation QCSampleHealthFunctionViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.edgesForExtendedLayout = UIRectEdgeNone;
    self.actionSections = [NSMutableArray array];

    self.logger = [[QCSampleLogRecorder alloc] init];
    __weak typeof(self) weakSelf = self;
    self.logger.updateHandler = ^(NSString *logText) {
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf) { return; }
        NSIndexPath *logIndexPath = [NSIndexPath indexPathForRow:0 inSection:strongSelf.actionSections.count];
        [strongSelf.tableView beginUpdates];
        [strongSelf.tableView reloadRowsAtIndexPaths:@[logIndexPath] withRowAnimation:UITableViewRowAnimationNone];
        [strongSelf.tableView endUpdates];
    };

    self.tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStyleGrouped];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.estimatedRowHeight = 44.0;
    self.tableView.estimatedSectionHeaderHeight = 28.0;
    self.tableView.rowHeight = 44.0;
    if (@available(iOS 15.0, *)) {
        self.tableView.sectionHeaderTopPadding = 8.0;
    }
    [self.view addSubview:self.tableView];

    [self setupActions];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    self.tableView.frame = self.view.bounds;
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    if (!self.hasLoadedSwitchStates) {
        self.hasLoadedSwitchStates = YES;
        [self refreshHealthSwitchStates];
    }
}

- (void)setupActions {
    // 子类覆写
}

#pragma mark - Actions

- (void)beginActionSection:(NSString *)title {
    QCSampleHealthActionSection *section = [[QCSampleHealthActionSection alloc] init];
    section.title = title;
    section.items = [NSMutableArray array];
    [self.actionSections addObject:section];
}

- (void)ensureDefaultActionSection {
    if (self.actionSections.count == 0) {
        [self beginActionSection:QCSampleLocalized(QCSampleLocalizedKeyHealthActionsSection)];
    }
}

- (void)addActionWithTitle:(NSString *)title handler:(QCSampleHealthActionHandler)handler {
    [self ensureDefaultActionSection];
    QCSampleHealthActionItem *item = [[QCSampleHealthActionItem alloc] init];
    item.title = title;
    item.handler = handler;
    [self.actionSections.lastObject.items addObject:item];
}

- (void)addSwitchWithTitle:(NSString *)title
               readHandler:(QCSampleHealthSwitchReadHandler)readHandler
              writeHandler:(QCSampleHealthSwitchWriteHandler)writeHandler {
    [self addSwitchWithTitle:title
       unavailableStatusKey:nil
                readHandler:readHandler
               writeHandler:writeHandler];
}

- (void)addSwitchWithTitle:(NSString *)title
      unavailableStatusKey:(nullable NSString *)unavailableStatusKey
               readHandler:(QCSampleHealthSwitchReadHandler)readHandler
              writeHandler:(QCSampleHealthSwitchWriteHandler)writeHandler {
    [self ensureDefaultActionSection];
    QCSampleHealthActionItem *item = [[QCSampleHealthActionItem alloc] init];
    item.title = title;
    item.switchItem = YES;
    item.switchUnavailableStatusKey = unavailableStatusKey;
    item.readHandler = readHandler;
    item.writeHandler = writeHandler;
    [self.actionSections.lastObject.items addObject:item];
}

- (NSIndexPath *)indexPathForActionItem:(QCSampleHealthActionItem *)targetItem {
    for (NSInteger section = 0; section < self.actionSections.count; section++) {
        NSArray<QCSampleHealthActionItem *> *items = self.actionSections[section].items;
        NSInteger row = [items indexOfObjectIdenticalTo:targetItem];
        if (row != NSNotFound) {
            return [NSIndexPath indexPathForRow:row inSection:section];
        }
    }
    return nil;
}

- (void)reloadActionItem:(QCSampleHealthActionItem *)item {
    NSIndexPath *indexPath = [self indexPathForActionItem:item];
    if (!indexPath || ![self.tableView cellForRowAtIndexPath:indexPath]) {
        return;
    }
    [self.tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationNone];
}

- (void)refreshHealthSwitchStates {
    NSMutableArray<QCSampleHealthActionItem *> *switchItems = [NSMutableArray array];
    for (QCSampleHealthActionSection *section in self.actionSections) {
        for (QCSampleHealthActionItem *item in section.items) {
            if (item.switchItem) {
                [switchItems addObject:item];
            }
        }
    }
    [self refreshSwitchItems:switchItems atIndex:0];
}

- (void)refreshSwitchItems:(NSArray<QCSampleHealthActionItem *> *)items atIndex:(NSInteger)index {
    if (index >= items.count) {
        return;
    }
    __weak typeof(self) weakSelf = self;
    [self readSwitchItem:items[index] completion:^{
        [weakSelf refreshSwitchItems:items atIndex:index + 1];
    }];
}

- (void)readSwitchItem:(QCSampleHealthActionItem *)item {
    [self readSwitchItem:item completion:nil];
}

- (void)readSwitchItem:(QCSampleHealthActionItem *)item completion:(void (^ _Nullable)(void))completion {
    if (!item.readHandler || item.switchBusy || ![self ensureConnected]) {
        if (completion) { completion(); }
        return;
    }
    item.switchBusy = YES;
    item.switchStatusKey = QCSampleLocalizedKeyHealthSwitchReading;
    NSUInteger readToken = ++item.switchReadToken;
    [self reloadActionItem:item];

    __weak typeof(self) weakSelf = self;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(kQCSampleHealthSwitchReadTimeout * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf || !item.switchBusy || item.switchReadToken != readToken) {
            return;
        }
        item.switchBusy = NO;
        item.switchStatusKey = item.switchUnavailableStatusKey ?: QCSampleLocalizedKeyHealthSwitchReadFailed;
        [strongSelf reloadActionItem:item];
        if (completion) { completion(); }
    });

    item.readHandler(^(BOOL enabled, NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            __strong typeof(weakSelf) strongSelf = weakSelf;
            if (!strongSelf || !item.switchBusy || item.switchReadToken != readToken) { return; }
            item.switchBusy = NO;
            if (error) {
                item.switchStatusKey = item.switchUnavailableStatusKey ?: QCSampleLocalizedKeyHealthSwitchReadFailed;
            } else {
                item.switchEnabled = enabled;
                item.switchHasValue = YES;
                item.switchStatusKey = enabled ? QCSampleLocalizedKeyHealthSwitchOn : QCSampleLocalizedKeyHealthSwitchOff;
            }
            [strongSelf reloadActionItem:item];
            if (completion) { completion(); }
        });
    });
}

- (void)switchValueChanged:(QCSampleHealthSwitchControl *)control {
    QCSampleHealthActionItem *item = control.item;
    if (!item || item.switchBusy || !item.writeHandler) {
        return;
    }
    BOOL previousValue = item.switchEnabled;
    BOOL targetValue = control.isOn;
    if (![self ensureConnected]) {
        [control setOn:previousValue animated:YES];
        return;
    }

    item.switchEnabled = targetValue;
    item.switchHasValue = YES;
    item.switchBusy = YES;
    item.switchStatusKey = QCSampleLocalizedKeyHealthSwitchUpdating;
    [self reloadActionItem:item];

    __weak typeof(self) weakSelf = self;
    item.writeHandler(targetValue, ^(BOOL enabled, NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            __strong typeof(weakSelf) strongSelf = weakSelf;
            if (!strongSelf) { return; }
            item.switchBusy = NO;
            if (error) {
                item.switchEnabled = previousValue;
                item.switchStatusKey = item.switchUnavailableStatusKey ?: QCSampleLocalizedKeyHealthSwitchUpdateFailed;
                [strongSelf reloadActionItem:item];
                return;
            }
            item.switchEnabled = enabled;
            item.switchStatusKey = enabled ? QCSampleLocalizedKeyHealthSwitchOn : QCSampleLocalizedKeyHealthSwitchOff;
            [strongSelf reloadActionItem:item];
            [strongSelf readSwitchItem:item];
        });
    });
}

- (NSString *)healthQueryActionTitleForKey:(NSString *)queryKey groupTitle:(NSString *)groupTitle {
    NSString *queryTitle = QCSampleLocalized(queryKey);
    if (groupTitle.length == 0) {
        return queryTitle;
    }
    return [NSString stringWithFormat:@"%@ · %@", groupTitle, queryTitle];
}

- (void)bindHealthQueryWithTitle:(NSString *)title
                    todayHandler:(QCSampleHealthActionHandler)todayHandler
               singleDayHandler:(void (^)(NSInteger))singleDayHandler
                   rangeHandler:(void (^)(NSInteger, NSInteger))rangeHandler {
    __weak typeof(self) weakSelf = self;
    [self addActionWithTitle:[self healthQueryActionTitleForKey:QCSampleLocalizedKeyHealthQueryToday groupTitle:title] handler:^{
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf || ![strongSelf ensureConnected]) { return; }
        [strongSelf appendLogFormat:@"[%@] %@ dayIndex=0", title, QCSampleLocalized(QCSampleLocalizedKeyHealthQueryToday)];
        todayHandler();
    }];
    [self addActionWithTitle:[self healthQueryActionTitleForKey:QCSampleLocalizedKeyHealthQuerySingleDay groupTitle:title] handler:^{
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf) { return; }
        [strongSelf presentDayIndexAlertWithTitle:[NSString stringWithFormat:@"%@ - %@", title, QCSampleLocalized(QCSampleLocalizedKeyHealthQuerySingleDay)]
                                       completion:^(NSInteger dayIndex) {
            if (![strongSelf ensureConnected]) { return; }
            [strongSelf appendLogFormat:@"[%@] %@ dayIndex=%ld", title, QCSampleLocalized(QCSampleLocalizedKeyHealthQuerySingleDay), (long)dayIndex];
            singleDayHandler(dayIndex);
        }];
    }];
    [self addActionWithTitle:[self healthQueryActionTitleForKey:QCSampleLocalizedKeyHealthQueryDayRange groupTitle:title] handler:^{
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf) { return; }
        [strongSelf presentRangeAlertWithTitle:[NSString stringWithFormat:@"%@ - %@", title, QCSampleLocalized(QCSampleLocalizedKeyHealthQueryDayRange)]
                                    completion:^(NSInteger startDay, NSInteger count) {
            if (![strongSelf ensureConnected]) { return; }
            [strongSelf appendLogFormat:@"[%@] %@ start=%ld count=%ld", title, QCSampleLocalized(QCSampleLocalizedKeyHealthQueryDayRange), (long)startDay, (long)count];
            rangeHandler(startDay, count);
        }];
    }];
}

- (void)clearLog {
    [self.logger clear];
}

- (void)appendLog:(NSString *)line {
    [self.logger appendLine:line];
}

- (void)appendLogFormat:(NSString *)format, ... {
    va_list args;
    va_start(args, format);
    NSString *text = [[NSString alloc] initWithFormat:format arguments:args];
    va_end(args);
    [self.logger appendLine:text];
}

- (BOOL)ensureConnected {
    if ([QCCentralManager shared].deviceState == QCStateConnected) {
        return YES;
    }
    [QCSampleToast showCenterWithText:QCSampleLocalized(QCSampleLocalizedKeyHealthNotConnected)];
    return NO;
}

#pragma mark - Dialogs

/// Historical day index supported by most health APIs: 0=today … 6=6 days ago.
/// 多数健康 API 支持的历史日索引：0=今天 … 6=6 天前。
static const NSInteger kQCSampleDayIndexMin = 0;
static const NSInteger kQCSampleDayIndexMax = 6;
static const NSInteger kQCSampleDayCountMin = 1;

- (void)presentDayIndexAlertWithTitle:(NSString *)title completion:(void (^)(NSInteger dayIndex))completion {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:nil preferredStyle:UIAlertControllerStyleAlert];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyHealthQueryDayIndexTitle)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyHealthQueryDayIndexHint,
                                                        (long)kQCSampleDayIndexMin,
                                                        (long)kQCSampleDayIndexMax)
                           text:0];
    __weak typeof(self) weakSelf = self;
    [alert addAction:[UIAlertAction actionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyCommonCancel) style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyCommonOK) style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        NSInteger value = alert.textFields.firstObject.text.integerValue;
        if (![weakSelf validateInputValue:value
                                      min:kQCSampleDayIndexMin
                                      max:kQCSampleDayIndexMax
                               fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyHealthQueryDayIndexTitle)]) {
            return;
        }
        if (completion) { completion(value); }
    }]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)presentRangeAlertWithTitle:(NSString *)title completion:(void (^)(NSInteger startDayIndex, NSInteger count))completion {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:nil preferredStyle:UIAlertControllerStyleAlert];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyHealthQueryStartDayTitle)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyHealthQueryStartDayHint,
                                                        (long)kQCSampleDayIndexMin,
                                                        (long)kQCSampleDayIndexMax)
                           text:0];
    // Max count when start=0 is 7 days covering indexes 0…6.
    // start=0 时最大数量为 7，覆盖索引 0…6。
    NSInteger maxCount = kQCSampleDayIndexMax - kQCSampleDayIndexMin + 1;
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyHealthQueryCountTitle)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyHealthQueryCountHint,
                                                        (long)kQCSampleDayCountMin,
                                                        (long)maxCount)
                           text:3];
    __weak typeof(self) weakSelf = self;
    [alert addAction:[UIAlertAction actionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyCommonCancel) style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyCommonOK) style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        NSInteger start = alert.textFields[0].text.integerValue;
        NSInteger count = alert.textFields[1].text.integerValue;
        if (![weakSelf validateInputValue:start
                                      min:kQCSampleDayIndexMin
                                      max:kQCSampleDayIndexMax
                               fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyHealthQueryStartDayTitle)]) {
            return;
        }
        NSInteger remain = kQCSampleDayIndexMax - start + 1;
        if (![weakSelf validateInputValue:count
                                      min:kQCSampleDayCountMin
                                      max:remain
                               fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyHealthQueryCountTitle)]) {
            return;
        }
        if (completion) { completion(start, count); }
    }]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)addNumberFieldToAlert:(UIAlertController *)alert
                        title:(NSString *)title
                  placeholder:(NSString *)placeholder
                         text:(NSInteger)text {
    [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        UILabel *titleLabel = [[UILabel alloc] init];
        titleLabel.text = [NSString stringWithFormat:@"%@ ", title ?: @""];
        titleLabel.font = [UIFont systemFontOfSize:15.0];
        if (@available(iOS 13.0, *)) {
            titleLabel.textColor = [UIColor secondaryLabelColor];
        } else {
            // Fallback on earlier versions
        }
        [titleLabel sizeToFit];
        textField.leftView = titleLabel;
        textField.leftViewMode = UITextFieldViewModeAlways;
        textField.placeholder = placeholder;
        textField.font = [UIFont systemFontOfSize:15.0];
        textField.keyboardType = UIKeyboardTypeNumberPad;
        textField.text = [NSString stringWithFormat:@"%ld", (long)text];
        textField.clearButtonMode = UITextFieldViewModeWhileEditing;
    }];
}

- (BOOL)validateInputValue:(NSInteger)value
                       min:(NSInteger)min
                       max:(NSInteger)max
                fieldTitle:(NSString *)fieldTitle {
    if (value >= min && value <= max) {
        return YES;
    }
    NSString *message = QCSampleLocalizedFormat(QCSampleLocalizedKeyInputOutOfRange,
                                                fieldTitle ?: @"",
                                                (long)min,
                                                (long)max);
    [QCSampleToast showCenterWithText:message];
    [self appendLogFormat:@"[VALIDATE] rejected: %@", message];
    return NO;
}

- (void)fetchDayIndexes:(NSArray<NSNumber *> *)dayIndexes
           sequentially:(void (^)(NSInteger, void (^)(void)))block {
    [self fetchDayIndexes:dayIndexes atIndex:0 sequentially:block];
}

- (void)fetchDayIndexes:(NSArray<NSNumber *> *)dayIndexes
                atIndex:(NSInteger)index
           sequentially:(void (^)(NSInteger, void (^)(void)))block {
    if (index >= dayIndexes.count || !block) {
        return;
    }
    NSInteger dayIndex = dayIndexes[index].integerValue;
    __weak typeof(self) weakSelf = self;
    block(dayIndex, ^{
        [weakSelf fetchDayIndexes:dayIndexes atIndex:index + 1 sequentially:block];
    });
}

#pragma mark - UITableView

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return self.actionSections.count + 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section < (NSInteger)self.actionSections.count) {
        return self.actionSections[section].items.count;
    }
    return 1;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    if (section < (NSInteger)self.actionSections.count) {
        return self.actionSections[section].title;
    }
    return QCSampleLocalized(QCSampleLocalizedKeyHealthLogSection);
}

- (QCSampleHealthActionItem *)actionItemAtIndexPath:(NSIndexPath *)indexPath {
    return self.actionSections[indexPath.section].items[indexPath.row];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section < (NSInteger)self.actionSections.count) {
        QCSampleHealthActionItem *item = [self actionItemAtIndexPath:indexPath];
        NSString *cellIdentifier = item.switchItem ? kQCSampleHealthSwitchCellID : kQCSampleHealthActionCellID;
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        if (!cell) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
            cell.textLabel.font = [UIFont systemFontOfSize:14.0];
            cell.textLabel.numberOfLines = 0;
        }
        cell.textLabel.text = item.title;
        cell.selectionStyle = UITableViewCellSelectionStyleDefault;
        cell.accessoryType = item.switchItem ? UITableViewCellAccessoryNone : UITableViewCellAccessoryDisclosureIndicator;
        if (item.switchItem) {
            UIView *accessory = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 150.0, 32.0)];
            UILabel *statusLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 90.0, 32.0)];
            statusLabel.font = [UIFont systemFontOfSize:12.0];
            statusLabel.textColor = [UIColor grayColor];
            statusLabel.textAlignment = NSTextAlignmentRight;
            statusLabel.text = item.switchStatusKey.length > 0 ? QCSampleLocalized(item.switchStatusKey) : @"--";
            [accessory addSubview:statusLabel];

            QCSampleHealthSwitchControl *switchControl = [[QCSampleHealthSwitchControl alloc] initWithFrame:CGRectMake(98.0, 0, 52.0, 32.0)];
            switchControl.item = item;
            switchControl.on = item.switchEnabled;
            switchControl.enabled = item.switchHasValue && !item.switchBusy;
            [switchControl addTarget:self action:@selector(switchValueChanged:) forControlEvents:UIControlEventValueChanged];
            [accessory addSubview:switchControl];
            cell.accessoryView = accessory;
        } else {
            cell.accessoryView = nil;
        }
        return cell;
    }

    QCSampleLogCell *cell = [tableView dequeueReusableCellWithIdentifier:kQCSampleLogCellID];
    if (!cell) {
        cell = [[QCSampleLogCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:kQCSampleLogCellID];
    }
    [cell configureWithText:self.logger.text];
    __weak typeof(self) weakSelf = self;
    cell.copyHandler = ^{
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf) { return; }
        NSString *text = strongSelf.logger.text;
        if (text.length == 0) {
            [QCSampleToast showCenterWithText:QCSampleLocalized(QCSampleLocalizedKeyHealthCopyEmpty)];
            return;
        }
        [UIPasteboard generalPasteboard].string = text;
        [QCSampleToast showCenterWithText:QCSampleLocalized(QCSampleLocalizedKeyHealthCopySuccess)];
    };
    cell.clearHandler = ^{
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf) { return; }
        [strongSelf clearLog];
    };
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.section >= (NSInteger)self.actionSections.count) {
        return;
    }
    QCSampleHealthActionItem *item = [self actionItemAtIndexPath:indexPath];
    if (item.switchItem) {
        [self readSwitchItem:item];
        return;
    }
    if (item.handler) {
        item.handler();
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section >= (NSInteger)self.actionSections.count) {
        CGFloat width = CGRectGetWidth(tableView.bounds);
        if (width <= 0) {
            width = CGRectGetWidth(self.view.bounds);
        }
        return [QCSampleLogCell heightForText:self.logger.text width:width];
    }

    NSString *title = [self actionItemAtIndexPath:indexPath].title;
    CGFloat contentWidth = CGRectGetWidth(tableView.bounds) - 56.0;
    if (contentWidth <= 0) {
        contentWidth = CGRectGetWidth(self.view.bounds) - 56.0;
    }
    CGRect rect = [title boundingRectWithSize:CGSizeMake(contentWidth, CGFLOAT_MAX)
                                        options:NSStringDrawingUsesLineFragmentOrigin
                                     attributes:@{NSFontAttributeName: [UIFont systemFontOfSize:14.0]}
                                        context:nil];
    return MAX(44.0, ceil(rect.size.height) + 20.0);
}

@end
