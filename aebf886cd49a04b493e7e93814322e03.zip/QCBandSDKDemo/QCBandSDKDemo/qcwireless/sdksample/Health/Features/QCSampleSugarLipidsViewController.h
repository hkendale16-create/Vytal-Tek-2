//
//  QCSampleSugarLipidsViewController.h
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//
//  Blood glucose & lipids SDK sample. SDK calls are in QCSampleSugarLipidsViewController.m
//  血糖血脂 SDK 示例。SDK 调用见 QCSampleSugarLipidsViewController.m

#import "QCSampleHealthFunctionViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface QCSampleSugarLipidsViewController : QCSampleHealthFunctionViewController
@end

NS_ASSUME_NONNULL_END
