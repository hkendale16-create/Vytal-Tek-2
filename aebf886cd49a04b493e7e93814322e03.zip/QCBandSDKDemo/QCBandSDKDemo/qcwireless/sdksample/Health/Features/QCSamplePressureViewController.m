//
//  QCSamplePressureViewController.m
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//
//  Stress SDK sample. 压力 SDK 示例。

#import "QCSamplePressureViewController.h"
#import "QCSampleLocalization.h"
#import <QCBandSDK/QCSDKCmdCreator.h>
#import <QCBandSDK/QCPressureDayModel.h>
#import <QCBandSDK/QCPressureSampleModel.h>

@interface QCSamplePressureViewController ()
@property (nonatomic, assign) NSInteger currentStressInterval;
@end

@implementation QCSamplePressureViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = QCSampleLocalized(QCSampleLocalizedKeyHealthStress);
}

- (void)setupActions {
    __weak typeof(self) weakSelf = self;
    NSString *title = QCSampleLocalized(QCSampleLocalizedKeyHealthStress);

    [self addSwitchWithTitle:QCSampleLocalized(QCSampleLocalizedKeyHealthStressSwitch) readHandler:^(QCSampleHealthSwitchCompletion completion) {
        [QCSDKCmdCreator getSchedualStressStatusWithIntervalFinshed:^(BOOL isOn, NSInteger minInterval, NSInteger currentInterval, NSError * _Nullable error) {
            if (error) {
                [weakSelf appendLogFormat:@"❌ failed: %@", error.localizedDescription];
            } else {
                weakSelf.currentStressInterval = currentInterval > 0 ? currentInterval : MAX(minInterval, 10);
                [weakSelf appendLogFormat:@"stress switch: %@ interval=%ldmin", isOn ? @"ON" : @"OFF", (long)weakSelf.currentStressInterval];
            }
            completion(isOn, error);
        }];
    } writeHandler:^(BOOL enabled, QCSampleHealthSwitchCompletion completion) {
        NSInteger interval = weakSelf.currentStressInterval > 0 ? weakSelf.currentStressInterval : 10;
        [QCSDKCmdCreator setSchedualStressStatus:enabled interval:interval finshed:^(NSError * _Nullable error) {
            if (error) {
                [weakSelf appendLogFormat:@"❌ setSchedualStressStatus failed: %@", error.localizedDescription];
            } else {
                [weakSelf appendLogFormat:@"✅ stress switch → %@ interval=%ldmin", enabled ? @"ON" : @"OFF", (long)interval];
            }
            completion(enabled, error);
        }];
    }];

    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyHealthStressStatusInterval) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf appendLog:@"SDK getSchedualStressStatusWithIntervalFinshed"];
        [QCSDKCmdCreator getSchedualStressStatusWithIntervalFinshed:^(BOOL enable, NSInteger minInteger, NSInteger currentInteger, NSError * _Nullable error) {
            if (error) {
                [weakSelf appendLogFormat:@"getSchedualStressStatusWithInterval failed: %@", error.localizedDescription];
                return;
            }
            weakSelf.currentStressInterval = currentInteger > 0 ? currentInteger : MAX(minInteger, 10);
            [weakSelf appendLogFormat:@"getSchedualStressStatusWithInterval success: enable=%@, min=%ld, current=%ld",
             enable ? @"ON" : @"OFF", (long)minInteger, (long)currentInteger];
        }];
    }];

    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyHealthStressSetInterval) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf setSchedualStressStatusWithInterval];
    }];

    [self bindHealthQueryWithTitle:title
                      todayHandler:^{
        [weakSelf fetchPressureForDayIndexes:@[@(0)]];
    } singleDayHandler:^(NSInteger dayIndex) {
        [weakSelf fetchPressureForDayIndexes:@[@(dayIndex)]];
    } rangeHandler:^(NSInteger startDayIndex, NSInteger count) {
        NSMutableArray *days = [NSMutableArray arrayWithCapacity:count];
        for (NSInteger i = 0; i < count; i++) {
            [days addObject:@(startDayIndex + i)];
        }
        [weakSelf fetchPressureForDayIndexes:days];
    }];
}

- (void)fetchPressureForDayIndexes:(NSArray<NSNumber *> *)dayIndexes {
    [self appendLogFormat:@"SDK getPressureSamplesWithDayIndexes:%@", dayIndexes];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator getPressureSamplesWithDayIndexes:dayIndexes finished:^(NSArray<QCPressureDayModel *> * _Nullable days, NSError * _Nullable error) {
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf) { return; }
        if (error) {
            [strongSelf appendLogFormat:@"[Pressure] failed: %@", error.localizedDescription];
            return;
        }
        [strongSelf appendLog:@"[Pressure] success"];
        for (QCPressureDayModel *day in days) {
            NSInteger valid = 0;
            for (QCPressureSampleModel *sample in day.samples) {
                if (sample.value != 0) {
                    valid += 1;
                }
            }
            [strongSelf appendLogFormat:@"  ├ %@  interval=%ldmin  samples=%zd  valid=%ld%@",
             day.date,
             (long)day.intervalMinutes,
             day.samples.count,
             (long)valid,
             valid == 0 ? @"  (no data)" : @""];
        }
    }];
}

- (void)setSchedualStressStatusWithInterval {
    __weak typeof(self) weakSelf = self;
    [self appendLog:@"SDK getSchedualStressStatusWithIntervalFinshed → setSchedualStressStatus"];
    [QCSDKCmdCreator getSchedualStressStatusWithIntervalFinshed:^(BOOL enable, NSInteger minInteger, NSInteger currentInteger, NSError * _Nullable error) {
        if (error) {
            [weakSelf appendLogFormat:@"setSchedualStressStatusWithInterval failed: %@", error.localizedDescription];
            return;
        }
        NSInteger targetInterval = currentInteger > 0 ? currentInteger : (minInteger > 0 ? minInteger : 10);
        if (minInteger > 0 && targetInterval < minInteger) {
            targetInterval = minInteger;
        }
        [QCSDKCmdCreator setSchedualStressStatus:YES interval:targetInterval finshed:^(NSError * _Nullable setError) {
            if (setError) {
                [weakSelf appendLogFormat:@"setSchedualStressStatusWithInterval failed: %@", setError.localizedDescription];
                return;
            }
            [QCSDKCmdCreator getSchedualStressStatusWithIntervalFinshed:^(BOOL enableAfter, NSInteger minAfter, NSInteger currentAfter, NSError * _Nullable getError) {
                if (getError) {
                    [weakSelf appendLogFormat:@"setSchedualStressStatusWithInterval failed: %@", getError.localizedDescription];
                    return;
                }
                [weakSelf appendLogFormat:@"setSchedualStressStatusWithInterval success: enable=%@, min=%ld, current=%ld",
                 enableAfter ? @"ON" : @"OFF", (long)minAfter, (long)currentAfter];
                [weakSelf refreshHealthSwitchStates];
            }];
        }];
    }];
}

@end
