//
//  QCSampleHeartRateViewController.m
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//
//  Heart rate SDK sample. Log format follows legacy ViewController HR demos.
//  BLE commands are chained sequentially to avoid ChannelBusy (1001).

#import "QCSampleHeartRateViewController.h"
#import "QCSampleLocalization.h"
#import <QCBandSDK/QCSDKCmdCreator.h>
#import <QCBandSDK/QCSDKManager.h>
#import <QCBandSDK/QCManualHeartRateModel.h>
#import <QCBandSDK/QCSchedualHeartRateModel.h>
#import <QCBandSDK/QCDFU_Utils.h>

static NSInteger const kQCSampleHoldRealTimeHeartRateTimeout = 20;

@interface QCSampleHeartRateViewController ()
@property (nonatomic, strong, nullable) NSTimer *realTimeHRTimer;
@property (nonatomic, assign) BOOL isHeartRateMeasuring;
@end

@implementation QCSampleHeartRateViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = QCSampleLocalized(QCSampleLocalizedKeyHealthHeartRate);
}

- (void)dealloc {
    [self stopRealTimeHRTimer];
}

- (void)setupActions {
    __weak typeof(self) weakSelf = self;
    NSString *title = QCSampleLocalized(QCSampleLocalizedKeyHealthHeartRate);

    [self beginActionSection:QCSampleLocalized(QCSampleLocalizedKeyHealthHRSectionHistory)];
    [self bindHealthQueryWithTitle:title
                      todayHandler:^{
        [weakSelf fetchSchedualAndManualHeartRateForDayIndexes:@[@(0)]];
    } singleDayHandler:^(NSInteger dayIndex) {
        [weakSelf fetchSchedualAndManualHeartRateForDayIndexes:@[@(dayIndex)]];
    } rangeHandler:^(NSInteger startDayIndex, NSInteger count) {
        NSMutableArray<NSNumber *> *dayIndexes = [NSMutableArray arrayWithCapacity:count];
        for (NSInteger i = 0; i < count; i++) {
            [dayIndexes addObject:@(startDayIndex + i)];
        }
        [weakSelf fetchSchedualAndManualHeartRateForDayIndexes:dayIndexes];
    }];

    [self beginActionSection:QCSampleLocalized(QCSampleLocalizedKeyHealthHRSectionSettings)];
    [self addSwitchWithTitle:QCSampleLocalized(QCSampleLocalizedKeyHealthHRSwitch) readHandler:^(QCSampleHealthSwitchCompletion completion) {
        [QCSDKCmdCreator getSchedualHeartRateStatusWithSuccess:^(BOOL enable) {
            [weakSelf appendLogFormat:@"Scheduled heart rate switch: %@", enable ? @"ON" : @"OFF"];
            completion(enable, nil);
        } fail:^{
            [weakSelf appendLog:@"❌ getSchedualHeartRateStatus failed"];
            completion(NO, [NSError errorWithDomain:@"QCSampleHealthSwitch" code:-1 userInfo:nil]);
        }];
    } writeHandler:^(BOOL enabled, QCSampleHealthSwitchCompletion completion) {
        [QCSDKCmdCreator setSchedualHeartRateStatus:enabled success:^(BOOL result) {
            [weakSelf appendLogFormat:@"✅ scheduled heart rate switch → %@", result ? @"ON" : @"OFF"];
            completion(result, nil);
        } fail:^{
            [weakSelf appendLog:@"❌ setSchedualHeartRateStatus failed"];
            completion(enabled, [NSError errorWithDomain:@"QCSampleHealthSwitch" code:-1 userInfo:nil]);
        }];
    }];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyHealthHRStatusInterval) handler:^{
        [weakSelf readSchedualHeartRateStatusAndInterval];
    }];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyHealthHRInfo) handler:^{
        [weakSelf readSchedualHeartRateInfo];
    }];
    [self addSwitchWithTitle:QCSampleLocalized(QCSampleLocalizedKeyHealthRRISwitch)
       unavailableStatusKey:QCSampleLocalizedKeyHealthSwitchUnsupported
                readHandler:^(QCSampleHealthSwitchCompletion completion) {
        [QCSDKCmdCreator getRRIAutoMeasureStatusWithSuccess:^(BOOL isOpen) {
            [weakSelf appendLogFormat:@"RRI auto-measure switch: %@", isOpen ? @"ON" : @"OFF"];
            completion(isOpen, nil);
        } fail:^{
            [weakSelf appendLog:@"❌ getRRIAutoMeasureStatus failed"];
            completion(NO, [NSError errorWithDomain:@"QCSampleHealthSwitch" code:-1 userInfo:nil]);
        }];
    } writeHandler:^(BOOL enabled, QCSampleHealthSwitchCompletion completion) {
        [QCSDKCmdCreator setRRIAutoMeasureStatus:enabled suc:^{
            [weakSelf appendLogFormat:@"✅ RRI auto-measure switch → %@", enabled ? @"ON" : @"OFF"];
            completion(enabled, nil);
        } fail:^{
            [weakSelf appendLog:@"❌ setRRIAutoMeasureStatus failed"];
            completion(enabled, [NSError errorWithDomain:@"QCSampleHealthSwitch" code:-1 userInfo:nil]);
        }];
    }];

    [self beginActionSection:QCSampleLocalized(QCSampleLocalizedKeyHealthHRSectionLive)];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyHealthHROneMinute) handler:^{
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf) { return; }
        [strongSelf presentDayIndexAlertWithTitle:QCSampleLocalized(QCSampleLocalizedKeyHealthHROneMinute)
                                      completion:^(NSInteger dayIndex) {
            if (![strongSelf ensureConnected]) { return; }
            [strongSelf fetchOneMinuteHeartRateForDayIndex:dayIndex];
        }];
    }];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyHealthHRRealtimeStart) handler:^{
        [weakSelf startRealTimeHeartRate];
    }];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyHealthHRRealtimeStop) handler:^{
        [weakSelf endRealTimeHeartRate];
    }];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyHealthHRMeasureStart) handler:^{
        [weakSelf startHeartRateMeasuring];
    }];
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyHealthHRMeasureStop) handler:^{
        [weakSelf stopHeartRateMeasuring];
    }];
}

#pragma mark - Log helpers (legacy ViewController style)

- (void)logHeartRateSamplesSummary:(NSArray<NSNumber *> *)heartRates label:(NSString *)label {
    if (heartRates.count == 0) {
        [self appendLogFormat:@"%@ samples=0", label];
        return;
    }
    NSInteger nonZeroCount = 0;
    NSInteger minValue = NSIntegerMax;
    NSInteger maxValue = 0;
    NSMutableArray<NSString *> *preview = [NSMutableArray array];
    for (NSInteger i = 0; i < heartRates.count; i++) {
        NSInteger value = heartRates[i].integerValue;
        if (value <= 0) {
            continue;
        }
        nonZeroCount++;
        minValue = MIN(minValue, value);
        maxValue = MAX(maxValue, value);
        if (preview.count < 8) {
            [preview addObject:[NSString stringWithFormat:@"idx%ld=%ld", (long)i, (long)value]];
        }
    }
    if (nonZeroCount == 0) {
        [self appendLogFormat:@"%@ valid=0/%ld (all zero)", label, (long)heartRates.count];
        return;
    }
    [self appendLogFormat:@"%@ valid=%ld/%ld min=%ld max=%ld preview=[%@]",
     label, (long)nonZeroCount, (long)heartRates.count, (long)minValue, (long)maxValue,
     [preview componentsJoinedByString:@", "]];
}

- (NSString *)expectedDateStringForDayIndex:(NSInteger)dayIndex {
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSDate *today = [calendar startOfDayForDate:[NSDate date]];
    NSDateComponents *components = [[NSDateComponents alloc] init];
    components.day = -dayIndex;
    NSDate *targetDate = [calendar dateByAddingComponents:components toDate:today options:0];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    formatter.dateFormat = @"yyyy-MM-dd";
    formatter.locale = [NSLocale localeWithLocaleIdentifier:@"en_US_POSIX"];
    return [formatter stringFromDate:targetDate];
}

- (NSInteger)dayIndexForDateString:(NSString *)dateString inDayIndexes:(NSArray<NSNumber *> *)dayIndexes {
    for (NSNumber *dayIndex in dayIndexes) {
        if ([[self expectedDateStringForDayIndex:dayIndex.integerValue] isEqualToString:dateString]) {
            return dayIndex.integerValue;
        }
    }
    return NSNotFound;
}

- (void)logSchedualHeartRateModels:(NSArray<QCSchedualHeartRateModel *> *)models
                      forDayIndexes:(NSArray<NSNumber *> *)dayIndexes {
    [self appendLogFormat:@"Schedual HeartRate data count:%ld (requested %ld days)",
     (long)models.count, (long)dayIndexes.count];

    NSMutableSet<NSString *> *returnedDates = [NSMutableSet set];
    for (NSInteger i = 0; i < models.count; i++) {
        QCSchedualHeartRateModel *model = models[i];
        NSString *date = model.date ?: @"";
        [returnedDates addObject:date];
        NSInteger dayIndex = [self dayIndexForDateString:date inDayIndexes:dayIndexes];
        NSString *dayIndexText = dayIndex == NSNotFound ? @"?" : [NSString stringWithFormat:@"%ld", (long)dayIndex];
        [self appendLogFormat:@"[dayIndex=%@] date=%@ interval=%lds samples=%ld",
         dayIndexText, date, (long)model.secondInterval, (long)model.heartRates.count];
        [self logHeartRateSamplesSummary:model.heartRates
                                   label:[NSString stringWithFormat:@"[dayIndex=%@] schedual", dayIndexText]];
    }

    for (NSNumber *dayIndexNumber in dayIndexes) {
        NSInteger dayIndex = dayIndexNumber.integerValue;
        NSString *expectedDate = [self expectedDateStringForDayIndex:dayIndex];
        if (![returnedDates containsObject:expectedDate]) {
            [self appendLogFormat:@"[dayIndex=%ld] date=%@ no schedual data on device",
             (long)dayIndex, expectedDate];
        }
    }
}

- (void)logManualHeartRateModels:(NSArray<QCManualHeartRateModel *> *)models {
    [self appendLogFormat:@"Manual HeartRate data count:%ld", (long)models.count];
    for (NSInteger i = 0; i < models.count; i++) {
        QCManualHeartRateModel *model = models[i];
        [self appendLogFormat:@"[%ld] date=%@ samples=%ld hrTimes=%ld",
         (long)i, model.date ?: @"", (long)model.heartRates.count, (long)model.hrTimes.count];
        [self logHeartRateSamplesSummary:model.heartRates
                                   label:[NSString stringWithFormat:@"[%ld] manual", (long)i]];
        if (model.heartRates.count > 0 && model.hrTimes.count == model.heartRates.count) {
            NSMutableArray<NSString *> *pairs = [NSMutableArray array];
            for (NSInteger j = 0; j < model.heartRates.count && pairs.count < 8; j++) {
                if (model.heartRates[j].integerValue > 0) {
                    [pairs addObject:[NSString stringWithFormat:@"%@min=%@", model.hrTimes[j], model.heartRates[j]]];
                }
            }
            if (pairs.count > 0) {
                [self appendLogFormat:@"[%ld] manual detail: %@", (long)i, [pairs componentsJoinedByString:@", "]];
            }
        }
    }
}

- (void)logOneMinuteHeartRateModels:(NSArray *)models {
    [self appendLog:@"✅ 获取每分钟心率数据成功"];
    [self appendLogFormat:@"📊 心率数据总数: %ld", (long)models.count];
    for (NSInteger i = 0; i < models.count; i++) {
        QCSchedualHeartRateModel *model = models[i];
        if (![model isKindOfClass:[QCSchedualHeartRateModel class]]) {
            continue;
        }
        [self appendLogFormat:@"❤️ %ld date=%@ heartRates length: %ld", (long)i, model.date ?: @"", (long)model.heartRates.count];
        [self logHeartRateSamplesSummary:model.heartRates
                                   label:[NSString stringWithFormat:@"❤️ %ld one-minute", (long)i]];
    }
}

- (void)logManualHeartRateError:(NSError *)error dayIndex:(NSInteger)dayIndex {
    if (error.code == ODM_DFU_Error_Code_NotifyTimeOut) {
        [self appendLogFormat:@"Manual HeartRate data count:0 (dayIndex=%ld, timeout — likely no manual records)",
         (long)dayIndex];
        return;
    }
    if (error.code == ODM_DFU_Error_Code_ChannelBusy) {
        [self appendLogFormat:@"❌ manual HR dayIndex=%ld ChannelBusy(1001), retry after other BLE ops finish", (long)dayIndex];
        return;
    }
    [self appendLogFormat:@"❌ manual HR dayIndex=%ld failed: %@ (code=%ld)",
     (long)dayIndex, error.localizedDescription, (long)error.code];
}

- (BOOL)warnIfHeartRateMeasuring {
    if (!self.isHeartRateMeasuring) {
        return NO;
    }
    [self appendLog:@"⚠️ HeartRateRaw measuring in progress — historical query may fail, stop measuring first"];
    return YES;
}

- (NSString *)dayIndexesDescription:(NSArray<NSNumber *> *)dayIndexes {
    return [[dayIndexes valueForKey:@"description"] componentsJoinedByString:@","];
}

#pragma mark - Settings / info (legacy getHeartRate helpers)

- (void)readSchedualHeartRateStatusAndInterval {
    if (![self ensureConnected]) { return; }
    [self appendLog:@"SDK getSchedualHeartRateStatusAndIntervalWithSuccess"];
    [QCSDKCmdCreator getSchedualHeartRateStatusAndIntervalWithSuccess:^(BOOL enable, NSInteger interval) {
        [self appendLogFormat:@"schedual HeartRate Status:%d,timeInterval:%ld", enable, (long)interval];
    } fail:^{
        [self appendLog:@"❌ getSchedualHeartRateStatusAndInterval failed"];
    }];
}

- (void)readSchedualHeartRateInfo {
    if (![self ensureConnected]) { return; }
    [self appendLog:@"SDK getSchedualHeartRateInfoWithSuccess"];
    [QCSDKCmdCreator getSchedualHeartRateInfoWithSuccess:^(BOOL enable, NSInteger interval, NSInteger minInterval, NSInteger minHrTip, NSInteger maxHrTip) {
        [self appendLogFormat:@"schedual HeartRate Status:%d, timeInterval:%ld, minInterval:%ld, minHrTip:%ld, maxHrTip:%ld",
         enable, (long)interval, (long)minInterval, (long)minHrTip, (long)maxHrTip];
    } fail:^{
        [self appendLog:@"❌ getSchedualHeartRateInfo failed"];
    }];
}

#pragma mark - Historical data (sequential BLE)

- (void)fetchSchedualAndManualHeartRateForDayIndexes:(NSArray<NSNumber *> *)dayIndexes {
    if (![self ensureConnected]) { return; }
    [self warnIfHeartRateMeasuring];
    [self appendLogFormat:@"SDK getSchedualHeartRateDataWithDayIndexs:[%@]", [self dayIndexesDescription:dayIndexes]];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator getSchedualHeartRateDataWithDayIndexs:dayIndexes success:^(NSArray<QCSchedualHeartRateModel *> * _Nonnull schedualData) {
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf) { return; }
        [strongSelf logSchedualHeartRateModels:schedualData forDayIndexes:dayIndexes];
        [strongSelf fetchManualHeartRateForDayIndexes:dayIndexes index:0];
    } fail:^{
        [weakSelf appendLog:@"❌ getSchedualHeartRateData failed"];
    }];
}

- (void)fetchManualHeartRateForDayIndexes:(NSArray<NSNumber *> *)dayIndexes index:(NSInteger)index {
    if (index >= dayIndexes.count) {
        return;
    }
    NSInteger dayIndex = dayIndexes[index].integerValue;
    [self appendLogFormat:@"SDK getManualHeartRateDataByDayIndex:%ld", (long)dayIndex];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator getManualHeartRateDataByDayIndex:dayIndex finished:^(NSArray<QCManualHeartRateModel *> * _Nullable manualData, NSError * _Nullable err) {
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf) { return; }
        if (err) {
            [strongSelf logManualHeartRateError:err dayIndex:dayIndex];
        } else if ((manualData ?: @[]).count == 0) {
            [strongSelf appendLogFormat:@"Manual HeartRate data count:0 (dayIndex=%ld)", (long)dayIndex];
        } else {
            [strongSelf logManualHeartRateModels:manualData];
        }
        [strongSelf fetchManualHeartRateForDayIndexes:dayIndexes index:index + 1];
    }];
}

- (void)fetchOneMinuteHeartRateForDayIndex:(NSInteger)dayIndex {
    if (![self ensureConnected]) { return; }
    [self appendLog:@"🌟开始获取每分钟心率数据🌟"];
    [self appendLogFormat:@"SDK getOneMinuHeartRateDataWithIntervalByDayIndex:%ld", (long)dayIndex];
    [QCSDKCmdCreator getOneMinuHeartRateDataWithIntervalByDayIndex:dayIndex finished:^(NSArray * _Nullable heartRateList, NSError * _Nullable error) {
        if (error) {
            [self appendLogFormat:@"❌ 获取每分钟心率数据失败: %@", error.localizedDescription];
            return;
        }
        [self logOneMinuteHeartRateModels:heartRateList ?: @[]];
    }];
}

#pragma mark - Real-time HR (legacy startToRealTimeHR)

- (void)startRealTimeHeartRate {
    if (![self ensureConnected]) { return; }
    [self appendLog:@"start RealTime HeartRate"];
    [self appendLog:@"SDK realTimeHeartRateWithCmd:QCBandRealTimeHeartRateCmdTypeStart"];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator realTimeHeartRateWithCmd:QCBandRealTimeHeartRateCmdTypeStart finished:nil];
    [QCSDKManager shareInstance].realTimeHeartRate = ^(NSInteger hr) {
        [weakSelf appendLogFormat:@"The RealTime HeartRate is :%ld", (long)hr];
    };
    [self startRealTimeHRHoldTimer];
    [self appendLogFormat:@"auto stop after %lds", (long)(kQCSampleHoldRealTimeHeartRateTimeout * 6)];
    [self performSelector:@selector(endRealTimeHeartRate) withObject:nil afterDelay:kQCSampleHoldRealTimeHeartRateTimeout * 6];
}

- (void)endRealTimeHeartRate {
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(endRealTimeHeartRate) object:nil];
    [self stopRealTimeHRTimer];
    [self appendLog:@"end RealTime HeartRate"];
    [self appendLog:@"SDK realTimeHeartRateWithCmd:QCBandRealTimeHeartRateCmdTypeEnd"];
    [QCSDKCmdCreator realTimeHeartRateWithCmd:QCBandRealTimeHeartRateCmdTypeEnd finished:nil];
    [QCSDKManager shareInstance].realTimeHeartRate = nil;
}

- (void)holdRealTimeHeartRate {
    [self appendLog:@"hold RealTime HeartRate"];
    [self appendLog:@"SDK realTimeHeartRateWithCmd:QCBandRealTimeHeartRateCmdTypeHold"];
    [QCSDKCmdCreator realTimeHeartRateWithCmd:QCBandRealTimeHeartRateCmdTypeHold finished:nil];
}

- (void)startRealTimeHRHoldTimer {
    [self stopRealTimeHRTimer];
    __weak typeof(self) weakSelf = self;
    self.realTimeHRTimer = [NSTimer scheduledTimerWithTimeInterval:kQCSampleHoldRealTimeHeartRateTimeout repeats:YES block:^(NSTimer * _Nonnull timer) {
        [weakSelf holdRealTimeHeartRate];
    }];
}

- (void)stopRealTimeHRTimer {
    [self.realTimeHRTimer invalidate];
    self.realTimeHRTimer = nil;
}

#pragma mark - App measurement (legacy hrMeasuringAction)

- (void)startHeartRateMeasuring {
    if (![self ensureConnected]) { return; }
    self.isHeartRateMeasuring = YES;
    [self appendLog:@"[Measure] 🌟Start measurement🌟"];
    [self appendLog:@"[Measure] SDK setTime → startToMeasuringWithOperateType:QCMeasuringTypeHeartRateRaw"];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator setTime:[NSDate date] success:^(NSDictionary * _Nonnull info) {
        if ([[info objectForKey:QCBandFeatureAppManual] boolValue] == NO) {
            weakSelf.isHeartRateMeasuring = NO;
            [weakSelf appendLog:@"[Measure] Not Supperort QCBandFeatureAppManual"];
            return;
        }
        [weakSelf appendLog:@"[Measure] Supperort"];
        [[QCSDKManager shareInstance] startToMeasuringWithOperateType:QCMeasuringTypeHeartRateRaw
                                                              timeout:100
                                                      measuringHandle:^(id  _Nullable result) {
            if ([result isKindOfClass:[NSNumber class]]) {
                [weakSelf appendLogFormat:@"[Measure] measuringHandle:res: %@", result];
            }
        } completedHandle:^(BOOL isSuccess, id  _Nonnull result, NSError * _Nonnull error) {
            weakSelf.isHeartRateMeasuring = NO;
            if (isSuccess) {
                [weakSelf appendLog:@"[Measure] completedHandle isSuccess"];
            } else {
                [weakSelf appendLogFormat:@"[Measure] completedHandle failed: %@", error.localizedDescription ?: @""];
            }
            if ([result isKindOfClass:[NSArray class]]) {
                [weakSelf appendLogFormat:@"[Measure] completedHandle:result.length: %ld", (long)[(NSArray *)result count]];
            }
        }];
    } failed:^{
        weakSelf.isHeartRateMeasuring = NO;
        [weakSelf appendLog:@"[Measure] Failed to set time"];
    }];
}

- (void)stopHeartRateMeasuring {
    [self appendLog:@"[Measure] 🌟Stop measurement🌟"];
    [self appendLog:@"[Measure] SDK stopToMeasuringWithOperateType:QCMeasuringTypeHeartRate"];
    __weak typeof(self) weakSelf = self;
    [[QCSDKManager shareInstance] stopToMeasuringWithOperateType:QCMeasuringTypeHeartRate completedHandle:^(BOOL isSuccess, NSError * _Nonnull error) {
        weakSelf.isHeartRateMeasuring = NO;
        if (isSuccess) {
            [weakSelf appendLog:@"[Measure] Stop success"];
        } else {
            [weakSelf appendLogFormat:@"[Measure] Stop failed: %@", error.localizedDescription ?: @""];
        }
    }];
}

@end
