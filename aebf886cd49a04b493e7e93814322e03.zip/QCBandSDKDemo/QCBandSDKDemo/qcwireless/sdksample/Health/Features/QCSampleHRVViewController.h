//
//  QCSampleHRVViewController.h
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//
//  HRV SDK sample. SDK calls are in QCSampleHRVViewController.m
//  HRV SDK 示例。SDK 调用见 QCSampleHRVViewController.m

#import "QCSampleHealthFunctionViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface QCSampleHRVViewController : QCSampleHealthFunctionViewController
@end

NS_ASSUME_NONNULL_END
