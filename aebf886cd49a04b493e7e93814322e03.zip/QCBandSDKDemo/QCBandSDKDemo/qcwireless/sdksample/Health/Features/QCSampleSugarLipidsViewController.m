//
//  QCSampleSugarLipidsViewController.m
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//
//  Blood glucose & lipids SDK sample. 血糖血脂 SDK 示例。

#import "QCSampleSugarLipidsViewController.h"
#import "QCSampleLocalization.h"
#import <QCBandSDK/QCSDKCmdCreator.h>
#import <QCBandSDK/QCBloodGlucoseModel.h>

@implementation QCSampleSugarLipidsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = QCSampleLocalized(QCSampleLocalizedKeyHealthBloodGlucoseLipids);
}

- (void)setupActions {
    __weak typeof(self) weakSelf = self;
    NSString *title = QCSampleLocalized(QCSampleLocalizedKeyHealthBloodGlucoseLipids);

    [self bindHealthQueryWithTitle:title
                      todayHandler:^{
        [weakSelf fetchBloodGlucoseForDayIndexes:@[@(0)]];
    } singleDayHandler:^(NSInteger dayIndex) {
        [weakSelf fetchBloodGlucoseForDayIndexes:@[@(dayIndex)]];
    } rangeHandler:^(NSInteger startDayIndex, NSInteger count) {
        NSMutableArray<NSNumber *> *dayIndexes = [NSMutableArray arrayWithCapacity:count];
        for (NSInteger i = 0; i < count; i++) {
            [dayIndexes addObject:@(startDayIndex + i)];
        }
        [weakSelf fetchBloodGlucoseForDayIndexes:dayIndexes];
    }];
}

#pragma mark - Log helpers

- (BOOL)isValidBloodGlucoseModel:(QCBloodGlucoseModel *)model {
    return model.maxGlu > 0 || model.minGlu > 0 || model.glu > 0;
}

- (NSString *)bloodGlucoseModeDescription:(QCBloodGlucoseModeType)type {
    switch (type) {
        case QCBloodGlucoseSourceTypeContinue: return @"scheduled";
        case QCBloodGlucoseSourceTypeRandom: return @"random";
        default: return @"unknown";
    }
}

- (NSString *)bloodGlucoseMealTypeDescription:(QCBloodGlucoseType)type {
    switch (type) {
        case QCBloodGlucoseTypeBeforeMeals: return @"beforeMeals";
        case QCBloodGlucoseTypeNormal: return @"normal";
        case QCBloodGlucoseTypeAfterMeals: return @"afterMeals";
        default: return @"unknown";
    }
}

- (void)logBloodGlucoseModels:(NSArray<QCBloodGlucoseModel *> *)models dayIndex:(NSInteger)dayIndex {
    [self appendLogFormat:@"Schedual Blood Glucose datas:%ld", (long)models.count];

    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    formatter.dateFormat = @"yyyy-MM-dd HH:mm:ss";
    formatter.locale = [NSLocale localeWithLocaleIdentifier:@"en_US_POSIX"];

    NSMutableArray *validPoints = [NSMutableArray arrayWithCapacity:models.count];
    for (QCBloodGlucoseModel *model in models) {
        if (![self isValidBloodGlucoseModel:model]) {
            continue;
        }
        [validPoints addObject:@{
            @"time": model.date ? [formatter stringFromDate:model.date] : @"",
            @"glu": @(model.glu),
            @"max": @(model.maxGlu),
            @"min": @(model.minGlu),
            @"mode": [self bloodGlucoseModeDescription:model.type],
            @"meal": [self bloodGlucoseMealTypeDescription:model.gluType],
        }];
    }

    [self appendLogFormat:@"dayIndex=%ld interval=60min total=%ld valid=%ld points:%@",
     (long)dayIndex,
     (long)models.count,
     (long)validPoints.count,
     validPoints];

    NSInteger previewLimit = MIN(validPoints.count, 5);
    for (NSInteger i = 0; i < previewLimit; i++) {
        NSDictionary *point = validPoints[i];
        [self appendLogFormat:@"  %@ glu=%.1f max=%.0f min=%.0f mode=%@ meal=%@",
         point[@"time"],
         [point[@"glu"] doubleValue],
         [point[@"max"] doubleValue],
         [point[@"min"] doubleValue],
         point[@"mode"],
         point[@"meal"]];
    }
    if (validPoints.count > previewLimit) {
        [self appendLogFormat:@"  ... %ld more valid points", (long)(validPoints.count - previewLimit)];
    }
}

- (void)fetchBloodGlucoseForDayIndexes:(NSArray<NSNumber *> *)dayIndexes {
    if (![self ensureConnected]) { return; }
    [self appendLog:@"SDK setTime → getBloodGlucoseDataByDayIndex (sequential)"];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator setTime:[NSDate date] success:^(NSDictionary * _Nonnull info) {
        if (![[info objectForKey:QCBandFeatureBloodGlucose] boolValue]) {
            [weakSelf appendLog:@"Not Supperort Blood Glucose"];
            return;
        }
        [weakSelf appendLog:@"Supperort Blood Glucose"];
        [weakSelf fetchDayIndexes:dayIndexes sequentially:^(NSInteger dayIndex, void (^next)(void)) {
            [weakSelf appendLogFormat:@"SDK getBloodGlucoseDataByDayIndex:%ld", (long)dayIndex];
            [QCSDKCmdCreator getBloodGlucoseDataByDayIndex:dayIndex finished:^(NSArray * _Nullable data, NSError * _Nullable err) {
                if (err) {
                    [weakSelf appendLogFormat:@"❌ dayIndex=%ld failed: %@", (long)dayIndex, err.localizedDescription];
                } else {
                    NSMutableArray<QCBloodGlucoseModel *> *models = [NSMutableArray arrayWithCapacity:data.count];
                    for (id item in data ?: @[]) {
                        if ([item isKindOfClass:[QCBloodGlucoseModel class]]) {
                            [models addObject:item];
                        }
                    }
                    [weakSelf logBloodGlucoseModels:models dayIndex:dayIndex];
                }
                if (next) {
                    next();
                }
            }];
        }];
    } failed:^{
        [weakSelf appendLog:@"❌ setTime failed"];
    }];
}

- (void)fetchBloodGlucoseForDayIndex:(NSInteger)dayIndex {
    [self fetchBloodGlucoseForDayIndexes:@[@(dayIndex)]];
}

@end
