//
//  QCSampleHealthFunctionViewController.h
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//
//  Health function sample base: action buttons + shared demo log panel.
//  健康功能示例基类：功能按钮 + 共用演示日志面板。
//  Health sample subclasses only add buttons in -setupActions; put SDK calls inside handlers.
//  各健康示例子类只需在 -setupActions 里添加按钮，SDK 调用写在 handler 内即可。

#import <UIKit/UIKit.h>

@class QCSampleLogRecorder;

NS_ASSUME_NONNULL_BEGIN

typedef void (^QCSampleHealthActionHandler)(void);
typedef void (^QCSampleHealthSwitchCompletion)(BOOL enabled, NSError * _Nullable error);
typedef void (^QCSampleHealthSwitchReadHandler)(QCSampleHealthSwitchCompletion completion);
typedef void (^QCSampleHealthSwitchWriteHandler)(BOOL enabled, QCSampleHealthSwitchCompletion completion);

@interface QCSampleHealthFunctionViewController : UIViewController

@property (nonatomic, strong, readonly) QCSampleLogRecorder *logger;

/// Subclass override to add action buttons (put SDK calls in handlers for easy copy). 子类覆写，添加本页功能按钮（SDK 调用写在 handler 里，便于集成方复制）
- (void)setupActions;

/// Adds a new action section; subsequent -addActionWithTitle: rows go into this section. 新建操作分组，之后添加的行归入该组
- (void)beginActionSection:(NSString *)title;

/// Adds a single action row. 添加单个操作行
- (void)addActionWithTitle:(NSString *)title handler:(QCSampleHealthActionHandler)handler;

/// Adds a switch row that reads device state on entry and verifies it after each change.
/// 添加开关行：进入页面自动读取设备状态，设置后再次读取并校验。
- (void)addSwitchWithTitle:(NSString *)title
               readHandler:(QCSampleHealthSwitchReadHandler)readHandler
              writeHandler:(QCSampleHealthSwitchWriteHandler)writeHandler;

/// Adds a firmware-dependent switch with a specific unavailable status.
/// 添加依赖固件支持的开关；读取失败或超时时显示指定状态。
- (void)addSwitchWithTitle:(NSString *)title
      unavailableStatusKey:(nullable NSString *)unavailableStatusKey
               readHandler:(QCSampleHealthSwitchReadHandler)readHandler
              writeHandler:(QCSampleHealthSwitchWriteHandler)writeHandler;

/// Re-reads all switch rows after another action changes device settings.
/// 其他操作修改设备设置后，重新读取全部开关状态。
- (void)refreshHealthSwitchStates;

/// Binds today / single-day / date-range query actions. 添加「今日 / 指定日 / 日期范围」三组查询
- (void)bindHealthQueryWithTitle:(NSString *)title
                    todayHandler:(QCSampleHealthActionHandler)todayHandler
               singleDayHandler:(void (^)(NSInteger dayIndex))singleDayHandler
                   rangeHandler:(void (^)(NSInteger startDayIndex, NSInteger count))rangeHandler;

/// Clears the log panel. 清空日志
- (void)clearLog;

- (void)appendLog:(NSString *)line;
- (void)appendLogFormat:(NSString *)format, ... NS_FORMAT_FUNCTION(1, 2);

/// Checks BLE connection before SDK calls; shows a toast when disconnected. 调用 SDK 前检查蓝牙连接，未连接时 Toast 提示
- (BOOL)ensureConnected;

/// Prompts for day index (0=today, range 0～6). 弹出日期索引输入框（0=今天，范围 0～6）
- (void)presentDayIndexAlertWithTitle:(NSString *)title completion:(void (^)(NSInteger dayIndex))completion;

/// Runs fetch blocks one dayIndex at a time to avoid BLE ChannelBusy. 按 dayIndex 串行执行，避免 BLE 通道占用
- (void)fetchDayIndexes:(NSArray<NSNumber *> *)dayIndexes
           sequentially:(void (^)(NSInteger dayIndex, void (^next)(void)))block;

/// Adds a numeric alert field with a leading title and range hint placeholder.
/// 添加带行前标题与范围提示的数字输入框。
- (void)addNumberFieldToAlert:(UIAlertController *)alert
                        title:(NSString *)title
                  placeholder:(NSString *)placeholder
                         text:(NSInteger)text;

/// Validates value in [min, max]; toasts and logs on failure.
/// 校验值是否在 [min, max]；失败时 Toast 并写日志。
- (BOOL)validateInputValue:(NSInteger)value
                       min:(NSInteger)min
                       max:(NSInteger)max
                fieldTitle:(NSString *)fieldTitle;

@end

NS_ASSUME_NONNULL_END
