//
//  QCSamplePressureViewController.h
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//
//  Stress SDK sample. SDK calls are in QCSamplePressureViewController.m
//  压力 SDK 示例。SDK 调用见 QCSamplePressureViewController.m

#import "QCSampleHealthFunctionViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface QCSamplePressureViewController : QCSampleHealthFunctionViewController
@end

NS_ASSUME_NONNULL_END
