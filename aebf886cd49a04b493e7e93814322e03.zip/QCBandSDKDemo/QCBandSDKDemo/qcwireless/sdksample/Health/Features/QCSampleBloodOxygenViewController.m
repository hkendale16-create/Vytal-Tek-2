//
//  QCSampleBloodOxygenViewController.m
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//
//  Blood oxygen SDK sample. 血氧 SDK 示例。

#import "QCSampleBloodOxygenViewController.h"
#import "QCSampleLocalization.h"
#import <QCBandSDK/QCSDKCmdCreator.h>

@interface QCSampleBloodOxygenViewController ()
@property (nonatomic, assign) NSInteger currentInterval;
@end

@implementation QCSampleBloodOxygenViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = QCSampleLocalized(QCSampleLocalizedKeyHealthBloodOxygen);
}

- (void)setupActions {
    __weak typeof(self) weakSelf = self;
    NSString *title = QCSampleLocalized(QCSampleLocalizedKeyHealthBloodOxygen);

    [self addSwitchWithTitle:QCSampleLocalized(QCSampleLocalizedKeyHealthBOSwitch) readHandler:^(QCSampleHealthSwitchCompletion completion) {
        [weakSelf appendLog:@"SDK getSchedualBOInfoWithIntervalSuccess"];
        [QCSDKCmdCreator getSchedualBOInfoWithIntervalSuccess:^(BOOL isOn, NSInteger interval) {
            weakSelf.currentInterval = interval > 0 ? interval : 10;
            [weakSelf appendLogFormat:@"BO switch=%@ interval=%ldmin", isOn ? @"ON" : @"OFF", (long)interval];
            completion(isOn, nil);
        } fail:^{
            [weakSelf appendLog:@"❌ getSchedualBOInfo failed"];
            completion(NO, [NSError errorWithDomain:@"QCSampleHealthSwitch" code:-1 userInfo:nil]);
        }];
    } writeHandler:^(BOOL enabled, QCSampleHealthSwitchCompletion completion) {
        NSInteger interval = weakSelf.currentInterval > 0 ? weakSelf.currentInterval : 10;
        [QCSDKCmdCreator setSchedualBOInfoOn:enabled timeInterval:interval success:^{
            [weakSelf appendLogFormat:@"✅ BO switch → %@ interval=%ldmin", enabled ? @"ON" : @"OFF", (long)interval];
            completion(enabled, nil);
        } fail:^{
            [weakSelf appendLog:@"❌ setSchedualBOInfo failed"];
            completion(enabled, [NSError errorWithDomain:@"QCSampleHealthSwitch" code:-1 userInfo:nil]);
        }];
    }];

    [self bindHealthQueryWithTitle:title
                      todayHandler:^{
        [weakSelf fetchBloodOxygenForDayIndex:0];
    } singleDayHandler:^(NSInteger dayIndex) {
        [weakSelf fetchBloodOxygenForDayIndex:dayIndex];
    } rangeHandler:^(NSInteger startDayIndex, NSInteger count) {
        NSMutableArray<NSNumber *> *dayIndexes = [NSMutableArray arrayWithCapacity:count];
        for (NSInteger i = 0; i < count; i++) {
            [dayIndexes addObject:@(startDayIndex + i)];
        }
        [weakSelf fetchBloodOxygenForDayIndexes:dayIndexes];
    }];
}

- (void)fetchBloodOxygenForDayIndexes:(NSArray<NSNumber *> *)dayIndexes {
    if (![self ensureConnected]) { return; }
    __weak typeof(self) weakSelf = self;
    [self fetchDayIndexes:dayIndexes sequentially:^(NSInteger dayIndex, void (^next)(void)) {
        [weakSelf fetchBloodOxygenForDayIndex:dayIndex completion:next];
    }];
}

- (void)fetchBloodOxygenForDayIndex:(NSInteger)dayIndex {
    [self fetchBloodOxygenForDayIndex:dayIndex completion:nil];
}

- (void)fetchBloodOxygenForDayIndex:(NSInteger)dayIndex completion:(void (^)(void))completion {
    [self appendLogFormat:@"SDK getBloodOxygenDataWithIntervalByDayIndex:%ld", (long)dayIndex];
    [QCSDKCmdCreator getBloodOxygenDataWithIntervalByDayIndex:dayIndex finished:^(NSInteger intervalMinutes, NSArray * _Nullable datas, NSError * _Nullable err) {
        if (err) {
            [self appendLogFormat:@"get (%zd) blood oxygen datas with interval fail", (NSInteger)dayIndex];
        } else {
            [self appendLogFormat:@"get (%zd) blood oxygen datas with interval success,interval:%zd, count:%zd,datas:%@",
             (NSInteger)dayIndex, (NSInteger)intervalMinutes, (NSInteger)datas.count,
             [datas componentsJoinedByString:@","] ?: @""];
        }
        if (completion) {
            completion();
        }
    }];
}

@end
