//
//  QCSampleHealthBatchSyncViewController.m
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//

#import "QCSampleHealthBatchSyncViewController.h"
#import "QCSampleLocalization.h"
#import <QCBandSDK/QCSDKCmdCreator.h>
#import <QCBandSDK/QCSleepModel.h>
#import <QCBandSDK/QCSportModel.h>

@implementation QCSampleHealthBatchSyncViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = QCSampleLocalized(QCSampleLocalizedKeyHealthBatchSync);
}

- (void)setupActions {
    __weak typeof(self) weakSelf = self;
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyHealthBatchSyncStart) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf clearLog];
        [weakSelf appendLog:QCSampleLocalized(QCSampleLocalizedKeyHealthRunning)];
        [weakSelf syncTodaySteps];
    }];
}

- (void)syncTodaySteps {
    [self appendLine:@"--- activity_today ---"];
    [QCSDKCmdCreator getSportDetailDataByDay:0 sportDatas:^(NSArray<QCSportModel *> * _Nonnull sports) {
        [self appendLogFormat:@"steps records=%ld", (long)sports.count];
        [self syncTodaySleep];
    } fail:^{
        [self appendLog:@"❌ steps failed"];
        [self syncTodaySleep];
    }];
}

- (void)syncTodaySleep {
    [self appendLine:@"--- sleep_today ---"];
    [QCSDKCmdCreator getFulldaySleepDetailDataByDay:0 sleepDatas:^(NSArray<QCSleepModel *> * _Nullable sleeps, NSArray<QCSleepModel *> * _Nullable naps) {
        NSInteger total = [QCSleepModel sleepDuration:sleeps];
        [self appendLogFormat:@"sleep total=%ldh%ldm naps=%ld", total / 60, total % 60, (long)naps.count];
        [self syncTodayHeartRate];
    } fail:^{
        [self appendLog:@"❌ sleep failed"];
        [self syncTodayHeartRate];
    }];
}

- (void)syncTodayHeartRate {
    [self appendLine:@"--- heart_rate_today ---"];
    [QCSDKCmdCreator getOneMinuHeartRateDataWithIntervalByDayIndex:0 finished:^(NSArray * _Nullable heartRateList, NSError * _Nullable error) {
        if (error) {
            [self appendLogFormat:@"❌ hr failed: %@", error.localizedDescription];
        } else {
            [self appendLogFormat:@"hr models=%ld", (long)heartRateList.count];
        }
        [self appendLine:QCSampleLocalized(QCSampleLocalizedKeyHealthBatchSyncDone)];
    }];
}

- (void)appendLine:(NSString *)line {
    [self appendLog:line];
}

@end
