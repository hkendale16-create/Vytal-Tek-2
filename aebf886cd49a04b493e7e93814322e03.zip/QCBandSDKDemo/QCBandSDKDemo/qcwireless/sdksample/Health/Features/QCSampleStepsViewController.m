//
//  QCSampleStepsViewController.m
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//
//  Activity & steps SDK sample. 活动步数 SDK 示例。
//  SDK: getSportDetailDataByDay / getCurrentSportSucess

#import "QCSampleStepsViewController.h"
#import "QCSampleLocalization.h"
#import "QCSampleToast.h"
#import "QCSampleHealthScoreUtils.h"
#import <QCBandSDK/QCSDKCmdCreator.h>
#import <QCBandSDK/QCSportModel.h>

@implementation QCSampleStepsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = QCSampleLocalized(QCSampleLocalizedKeyHealthActivitySteps);
}

- (void)setupActions {
    __weak typeof(self) weakSelf = self;
    NSString *title = QCSampleLocalized(QCSampleLocalizedKeyHealthActivitySteps);

    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyHealthSyncTodaySteps) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf presentAgeInputWithCompletion:^(NSInteger age) {
            if (![weakSelf ensureConnected]) { return; }
            [weakSelf fetchCurrentSportWithAge:age];
        }];
    }];

    [self bindHealthQueryWithTitle:title
                      todayHandler:^{
        [weakSelf fetchStepsForDayIndex:0];
    } singleDayHandler:^(NSInteger dayIndex) {
        [weakSelf fetchStepsForDayIndex:dayIndex];
    } rangeHandler:^(NSInteger startDayIndex, NSInteger count) {
        NSMutableArray<NSNumber *> *dayIndexes = [NSMutableArray arrayWithCapacity:count];
        for (NSInteger i = 0; i < count; i++) {
            [dayIndexes addObject:@(startDayIndex + i)];
        }
        [weakSelf fetchStepsForDayIndexes:dayIndexes];
    }];
}

- (void)fetchStepsForDayIndexes:(NSArray<NSNumber *> *)dayIndexes {
    if (![self ensureConnected]) { return; }
    __weak typeof(self) weakSelf = self;
    [self fetchDayIndexes:dayIndexes sequentially:^(NSInteger dayIndex, void (^next)(void)) {
        [weakSelf fetchStepsForDayIndex:dayIndex completion:next];
    }];
}

- (void)fetchStepsForDayIndex:(NSInteger)dayIndex {
    [self fetchStepsForDayIndex:dayIndex completion:nil];
}

- (void)fetchStepsForDayIndex:(NSInteger)dayIndex completion:(void (^)(void))completion {
    if (dayIndex == 0) {
        [self appendLog:@"🌟Get pedometer data🌟"];
    }
    [self appendLogFormat:@"SDK getSportDetailDataByDay:%ld", (long)dayIndex];
    [QCSDKCmdCreator getSportDetailDataByDay:dayIndex sportDatas:^(NSArray<QCSportModel *> * _Nonnull sports) {
        [self appendLog:@"Get step count data details"];
        NSInteger totalStepCount = 0;
        double calories = 0;
        NSInteger distance = 0;
        for (QCSportModel *model in sports) {
            totalStepCount += model.totalStepCount;
            calories += model.calories;
            distance += model.distance;
            [self appendLogFormat:@"Pedometer data details:%@,totalStepCount：%zd,calories:%lf,distance：%zd",
             model.happenDate, model.totalStepCount, model.calories, model.distance];
        }
        [self appendLogFormat:@"Pedometer data details result:totalStepCount：%zd,calories:%lf,distance：%zd",
         totalStepCount, calories, distance];
        if (completion) {
            completion();
        }
    } fail:^{
        [self appendLogFormat:@"❌ getSportDetailDataByDay:%ld failed", (long)dayIndex];
        if (completion) {
            completion();
        }
    }];
}

- (void)fetchCurrentSportWithAge:(NSInteger)age {
    [self appendLog:@"SDK getCurrentSportSucess"];
    [QCSDKCmdCreator getCurrentSportSucess:^(QCSportModel * _Nonnull sport) {
        [self appendLogFormat:@"Pedometer data summary:totalStepCount：%zd,calories:%lf,distance：%zd",
         sport.totalStepCount, sport.calories, sport.distance];
        NSInteger score = [QCSampleHealthScoreUtils activityScoreForSteps:sport.totalStepCount age:age];
        NSString *level = [self localizedActivityLevelForScore:score];
        [self appendLog:QCSampleLocalizedFormat(QCSampleLocalizedKeyHealthActivityScoreResult,
                                                (long)age,
                                                (long)sport.totalStepCount,
                                                (long)score,
                                                level)];
    } failed:^{
        [self appendLog:@"❌ getCurrentSport failed"];
    }];
}

- (void)presentAgeInputWithCompletion:(void (^)(NSInteger age))completion {
    static const NSInteger kAgeMin = 1;
    static const NSInteger kAgeMax = 120;
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:QCSampleLocalized(QCSampleLocalizedKeyHealthActivityScoreAgeTitle)
                                                                   message:nil
                                                            preferredStyle:UIAlertControllerStyleAlert];
    [self addNumberFieldToAlert:alert
                          title:QCSampleLocalized(QCSampleLocalizedKeyHealthActivityScoreAgeField)
                    placeholder:QCSampleLocalizedFormat(QCSampleLocalizedKeyHealthActivityScoreAgeHint,
                                                        (long)kAgeMin,
                                                        (long)kAgeMax)
                           text:30];
    __weak typeof(self) weakSelf = self;
    [alert addAction:[UIAlertAction actionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyCommonCancel)
                                             style:UIAlertActionStyleCancel
                                           handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyCommonOK)
                                             style:UIAlertActionStyleDefault
                                           handler:^(UIAlertAction *action) {
        NSInteger age = alert.textFields.firstObject.text.integerValue;
        if (![weakSelf validateInputValue:age
                                      min:kAgeMin
                                      max:kAgeMax
                               fieldTitle:QCSampleLocalized(QCSampleLocalizedKeyHealthActivityScoreAgeField)]) {
            return;
        }
        if (completion) {
            completion(age);
        }
    }]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (NSString *)localizedActivityLevelForScore:(NSInteger)score {
    switch ([QCSampleHealthScoreUtils activityLevelForScore:score]) {
        case QCSampleActivityScoreLevelExcellent:
            return QCSampleLocalized(QCSampleLocalizedKeyHealthActivityScoreExcellent);
        case QCSampleActivityScoreLevelGood:
            return QCSampleLocalized(QCSampleLocalizedKeyHealthActivityScoreGood);
        case QCSampleActivityScoreLevelFair:
            return QCSampleLocalized(QCSampleLocalizedKeyHealthActivityScoreFair);
        case QCSampleActivityScoreLevelLow:
        default:
            return QCSampleLocalized(QCSampleLocalizedKeyHealthActivityScoreLow);
    }
}

@end
