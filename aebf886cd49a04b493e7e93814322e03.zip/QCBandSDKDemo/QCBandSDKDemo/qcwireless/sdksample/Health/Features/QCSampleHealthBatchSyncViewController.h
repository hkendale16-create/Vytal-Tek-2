//
//  QCSampleHealthBatchSyncViewController.h
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//
//  Batch sync all health data sample. SDK calls are in QCSampleHealthBatchSyncViewController.m
//  批量同步全部健康数据示例。SDK 调用见 QCSampleHealthBatchSyncViewController.m

#import "QCSampleHealthFunctionViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface QCSampleHealthBatchSyncViewController : QCSampleHealthFunctionViewController
@end

NS_ASSUME_NONNULL_END
