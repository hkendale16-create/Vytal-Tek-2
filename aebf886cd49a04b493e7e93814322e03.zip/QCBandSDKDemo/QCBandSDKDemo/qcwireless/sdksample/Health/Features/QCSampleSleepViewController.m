//
//  QCSampleSleepViewController.m
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//
//  Sleep SDK sample. 睡眠 SDK 示例。
//  Log format follows legacy ViewController -getSleep / -getSleepFromDay.

#import "QCSampleSleepViewController.h"
#import "QCSampleLocalization.h"
#import "QCSampleHealthScoreUtils.h"
#import <QCBandSDK/QCSDKCmdCreator.h>
#import <QCBandSDK/QCSleepModel.h>

@implementation QCSampleSleepViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = QCSampleLocalized(QCSampleLocalizedKeyHealthSleep);
}

- (void)setupActions {
    __weak typeof(self) weakSelf = self;
    NSString *title = QCSampleLocalized(QCSampleLocalizedKeyHealthSleep);

    [self bindHealthQueryWithTitle:title
                      todayHandler:^{
        [weakSelf fetchSleepForDayIndex:0];
    } singleDayHandler:^(NSInteger dayIndex) {
        [weakSelf fetchSleepForDayIndex:dayIndex];
    } rangeHandler:^(NSInteger startDayIndex, NSInteger count) {
        [weakSelf fetchSleepForDayRangeFromIndex:startDayIndex count:count];
    }];

    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyHealthSleepFromDay) handler:^{
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf) { return; }
        [strongSelf presentDayIndexAlertWithTitle:QCSampleLocalized(QCSampleLocalizedKeyHealthSleepFromDay)
                                     completion:^(NSInteger fromDayIndex) {
            if (![strongSelf ensureConnected]) { return; }
            [strongSelf fetchSleepFromDayIndex:fromDayIndex];
        }];
    }];

    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyHealthSleepScoreToday) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf fetchTodaySleepScore];
    }];
}

#pragma mark - Log (legacy ViewController style)

/// Legacy -getSleep output for night sleep + naps.
- (void)logGetSleepStyleWithSleeps:(NSArray<QCSleepModel *> *)sleeps naps:(NSArray<QCSleepModel *> *)naps {
    for (QCSleepModel *sleep in sleeps) {
        [self appendLogFormat:@"Start Time:%@,End Tile:%@,duration:%ld,type:%ld",
         sleep.happenDate, sleep.endTime, sleep.total, (long)sleep.type];
    }
    NSInteger fallAsleepDuration = [QCSleepModel fallAsleepDuration:sleeps];
    [self appendLogFormat:@"fall Asleep Duration:%ld", (long)fallAsleepDuration];
    NSInteger total = [QCSleepModel sleepDuration:sleeps];
    [self appendLogFormat:@"total duration：%ldh%ldm", total / 60, total % 60];

    for (QCSleepModel *sleep in naps) {
        [self appendLogFormat:@"Start Time:%@,End Tile:%@,duration:%ld,type:%ld",
         sleep.happenDate, sleep.endTime, sleep.total, (long)sleep.type];
    }
    NSInteger totalNaps = [QCSleepModel sleepDuration:naps];
    [self appendLogFormat:@"total duration：%ldh%ldm", totalNaps / 60, totalNaps % 60];
}

/// Legacy -getSleepFromDay output for one day bucket.
- (void)logGetSleepFromDayStyleForDayKey:(NSString *)dayKey segments:(NSArray<QCSleepModel *> *)segments {
    [self appendLogFormat:@"sleep date:%@", dayKey];
    for (QCSleepModel *sleep in segments) {
        [self appendLogFormat:@"Start Time: %@, End Time: %@, Duration: %ld, Type: %ld",
         sleep.happenDate, sleep.endTime, sleep.total, (long)sleep.type];
    }
    NSInteger total = [QCSleepModel sleepDuration:segments];
    [self appendLogFormat:@"total duration：%ldh%ldm", total / 60, total % 60];
}

#pragma mark - SDK calls

- (void)fetchSleepForDayIndex:(NSInteger)dayIndex {
    [self appendLog:@"Get sleep data"];
    [self appendLogFormat:@"SDK getFulldaySleepDetailDataByDay:%ld", (long)dayIndex];
    [QCSDKCmdCreator getFulldaySleepDetailDataByDay:dayIndex sleepDatas:^(NSArray<QCSleepModel *> * _Nullable sleeps, NSArray<QCSleepModel *> * _Nullable naps) {
        [self logGetSleepStyleWithSleeps:sleeps ?: @[] naps:naps ?: @[]];
    } fail:^{
        [self appendLog:@"Failed to get sleep"];
    }];
}

- (void)fetchSleepForDayRangeFromIndex:(NSInteger)startDayIndex count:(NSInteger)count {
    [self appendLog:@"Get sleep data"];
    [self appendLogFormat:@"SDK getFulldaySleepDetailDataFromDay:%ld (range count=%ld)", (long)startDayIndex, (long)count];
    [QCSDKCmdCreator getFulldaySleepDetailDataFromDay:startDayIndex sleepDatas:^(NSDictionary<NSString *, NSArray<QCSleepModel *> *> * _Nonnull sleeps, NSDictionary<NSString *, NSArray<QCSleepModel *> *> * _Nonnull naps) {
        for (NSInteger i = 0; i < count; i++) {
            NSInteger dayIndex = startDayIndex + i;
            NSString *dayKey = [NSString stringWithFormat:@"%ld", (long)dayIndex];
            [self appendLogFormat:@"sleep date:%@", dayKey];
            [self logGetSleepStyleWithSleeps:sleeps[dayKey] ?: @[] naps:naps[dayKey] ?: @[]];
        }
    } fail:^{
        [self appendLog:@"Failed to get sleep"];
    }];
}

- (void)fetchSleepFromDayIndex:(NSInteger)fromDayIndex {
    [self appendLog:@"Get sleep data"];
    [self appendLogFormat:@"SDK getSleepDetailDataFromDay:%ld", (long)fromDayIndex];
    [QCSDKCmdCreator getSleepDetailDataFromDay:fromDayIndex sleepDatas:^(NSDictionary<NSString *, NSArray<QCSleepModel *> *> * _Nonnull sleeps) {
        [self appendLog:@"Get sleep data successfully"];
        for (NSString *dayText in sleeps.allKeys) {
            NSArray *daySleeps = [sleeps valueForKey:dayText];
            [self logGetSleepFromDayStyleForDayKey:dayText segments:daySleeps ?: @[]];
        }
    } fail:^{
        [self appendLog:@"Failed to get sleep"];
    }];
}

- (void)fetchTodaySleepScore {
    [self appendLog:@"SDK getFulldaySleepDetailDataByDay:0 → sleep score"];
    [QCSDKCmdCreator getFulldaySleepDetailDataByDay:0 sleepDatas:^(NSArray<QCSleepModel *> * _Nullable sleeps,
                                                                   NSArray<QCSleepModel *> * _Nullable naps) {
        (void)naps;
        QCSampleSleepScoreResult *result = [QCSampleHealthScoreUtils sleepScoreForSegments:sleeps ?: @[]];
        if (result.totalMinutes <= 0) {
            [self appendLog:QCSampleLocalized(QCSampleLocalizedKeyHealthSleepScoreNoData)];
            return;
        }
        [self appendLog:QCSampleLocalizedFormat(QCSampleLocalizedKeyHealthSleepScoreResult,
                                                (long)result.score,
                                                (long)result.efficiency,
                                                (long)result.totalMinutes,
                                                (long)result.deepMinutes,
                                                (long)result.lightMinutes,
                                                (long)result.remMinutes,
                                                (long)result.awakeMinutes)];
    } fail:^{
        [self appendLog:@"❌ getFulldaySleepDetailDataByDay:0 failed"];
    }];
}

@end
