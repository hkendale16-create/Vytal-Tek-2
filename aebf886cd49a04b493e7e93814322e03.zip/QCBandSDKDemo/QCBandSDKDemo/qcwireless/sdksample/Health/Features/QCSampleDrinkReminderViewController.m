//
//  QCSampleDrinkReminderViewController.m
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//
//  Water reminder SDK sample. 饮水提醒 SDK 示例。

#import "QCSampleDrinkReminderViewController.h"
#import "QCSampleLocalization.h"
#import "QCSampleSystemTimePickerView.h"
#import <QCBandSDK/QCSDKCmdCreator.h>

@interface QCSampleDrinkReminderViewController ()
@property (nonatomic, copy) NSString *lastRemindTime;
@end

@implementation QCSampleDrinkReminderViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = QCSampleLocalized(QCSampleLocalizedKeyHealthWaterReminder);
    self.lastRemindTime = @"10:00";
}

- (void)setupActions {
    __weak typeof(self) weakSelf = self;
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyHealthReadDrinkReminder) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf appendLog:@"SDK getDrinkWaterRemindWithIndex:0"];
        [QCSDKCmdCreator getDrinkWaterRemindWithIndex:0 remind:^(NSUInteger index, ALARMTYPE type, NSString *time, NSArray<NSNumber *> *cycle) {
            if (time.length > 0) {
                weakSelf.lastRemindTime = time;
            }
            [weakSelf appendLogFormat:@"✅ index=%lu type=%ld time=%@ cycle=%@", (unsigned long)index, (long)type, time, cycle];
        } fail:^{
            [weakSelf appendLog:@"❌ getDrinkWaterRemind failed"];
        }];
    }];

    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyHealthSetDrinkReminder) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf presentSetDrinkReminderTimePicker];
    }];
}

- (void)presentSetDrinkReminderTimePicker {
    __weak typeof(self) weakSelf = self;
    [QCSampleSystemTimePickerView showInViewController:self
                                                 title:QCSampleLocalized(QCSampleLocalizedKeyHealthSetDrinkReminder)
                                         initialTimer:self.lastRemindTime ?: @"10:00"
                                            completion:^(NSString *selectedTimer) {
        [weakSelf setDrinkWaterRemindWithTime:selectedTimer];
    }];
}

- (void)setDrinkWaterRemindWithTime:(NSString *)time {
    NSUInteger index = 0;
    // Align with Pubu: enable drink reminder with ALARMSLEEP (BB=1), not ALARMOTHER (BB=2).
    // 与 Pubu 一致：开启饮水提醒用 ALARMSLEEP（BB=1），不要用 ALARMOTHER（BB=2）。
    ALARMTYPE type = ALARMSLEEP;
    // Sunday→Saturday; every day
    NSArray<NSNumber *> *cycle = @[@1, @1, @1, @1, @1, @1, @1];
    self.lastRemindTime = time;
    [self appendLogFormat:@"SDK setDrinkWaterRemindIndex:%lu type:%ld time:%@ cycle:%@",
     (unsigned long)index, (long)type, time, cycle];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator setDrinkWaterRemindIndex:index
                                         type:type
                                         time:time
                                        cycle:cycle
                                      success:^{
        [weakSelf appendLog:@"✅ setDrinkWaterRemind success"];
    } failed:^{
        [weakSelf appendLog:@"❌ setDrinkWaterRemind failed"];
    }];
}

@end
