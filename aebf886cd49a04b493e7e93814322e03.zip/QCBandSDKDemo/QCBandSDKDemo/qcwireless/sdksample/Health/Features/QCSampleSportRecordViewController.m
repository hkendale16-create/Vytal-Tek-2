//
//  QCSampleSportRecordViewController.m
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//
//  Sport records SDK sample. Log format follows legacy ViewController -getSportRecords.

#import "QCSampleSportRecordViewController.h"
#import "QCSampleLocalization.h"
#import <QCBandSDK/QCSDKCmdCreator.h>
#import <QCBandSDK/OdmSportPlusModels.h>

@implementation QCSampleSportRecordViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = QCSampleLocalized(QCSampleLocalizedKeyHealthSportRecords);
}

- (void)setupActions {
    __weak typeof(self) weakSelf = self;
    [self addActionWithTitle:QCSampleLocalized(QCSampleLocalizedKeyHealthFetchSportRecords) handler:^{
        if (![weakSelf ensureConnected]) { return; }
        [weakSelf appendLog:@"SDK getSportRecordsFromLastTimeStamp:0"];
        [QCSDKCmdCreator getSportRecordsFromLastTimeStamp:0 finish:^(NSArray<OdmGeneralExerciseSummaryModel *> * _Nullable summaries, NSError * _Nullable error) {
            if (error) {
                [weakSelf appendLogFormat:@"❌ failed: %@", error.localizedDescription];
                return;
            }
            [weakSelf appendLog:@"getSportRecords Finish"];
            NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
            formatter.dateFormat = @"yyyy-MM-dd HH:mm:ss";
            for (OdmGeneralExerciseSummaryModel *model in summaries) {
                NSDate *startDate = [NSDate dateWithTimeIntervalSince1970:model.startTime];
                startDate = [weakSelf convertTimeZone:startDate];
                [weakSelf appendLogFormat:@"date:%@,steps:%zd,hr count:%zd",
                 [formatter stringFromDate:startDate], model.steps, model.detail.hrs.count];
            }
        }];
    }];
}

- (NSDate *)convertTimeZone:(NSDate *)date {
    NSTimeZone *shanghai = [[NSTimeZone alloc] initWithName:@"Asia/Shanghai"];
    NSTimeInterval offset = shanghai.secondsFromGMT - [[NSTimeZone systemTimeZone] secondsFromGMT];
    return [date dateByAddingTimeInterval:offset];
}

@end
