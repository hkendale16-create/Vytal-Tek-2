//
//  QCSampleStepsViewController.h
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//
//  Activity & steps SDK sample. SDK calls are in QCSampleStepsViewController.m
//  活动步数 SDK 示例。SDK 调用见 QCSampleStepsViewController.m

#import "QCSampleHealthFunctionViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface QCSampleStepsViewController : QCSampleHealthFunctionViewController
@end

NS_ASSUME_NONNULL_END
