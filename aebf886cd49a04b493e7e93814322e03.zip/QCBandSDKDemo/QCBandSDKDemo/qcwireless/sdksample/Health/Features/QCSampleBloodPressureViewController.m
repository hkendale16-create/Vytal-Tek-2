//
//  QCSampleBloodPressureViewController.m
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//
//  Blood pressure SDK sample. Legacy -getBloodPressure uses one setTime + sequential history fetch.
//  BP history API has no per-dayIndex param; demo filters results by dayIndex after fetch.

#import "QCSampleBloodPressureViewController.h"
#import "QCSampleLocalization.h"
#import <QCBandSDK/QCSDKCmdCreator.h>
#import <QCBandSDK/QCBloodPressureModel.h>

@interface QCSampleBloodPressureViewController ()
@property (nonatomic, copy) NSString *settingBeginTime;
@property (nonatomic, copy) NSString *settingEndTime;
@property (nonatomic, assign) NSInteger settingInterval;
@end

@implementation QCSampleBloodPressureViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = QCSampleLocalized(QCSampleLocalizedKeyHealthBloodPressure);
}

- (void)setupActions {
    __weak typeof(self) weakSelf = self;
    NSString *title = QCSampleLocalized(QCSampleLocalizedKeyHealthBloodPressure);

    [self addSwitchWithTitle:QCSampleLocalized(QCSampleLocalizedKeyHealthBPSwitch) readHandler:^(QCSampleHealthSwitchCompletion completion) {
        [QCSDKCmdCreator getSchedualBPInfo:^(BOOL featureOn, NSString *beginTime, NSString *endTime, NSInteger minuteInterval) {
            weakSelf.settingBeginTime = beginTime;
            weakSelf.settingEndTime = endTime;
            weakSelf.settingInterval = minuteInterval;
            [weakSelf appendLogFormat:@"Scheduled blood pressure: %@, window %@~%@ interval=%ldmin",
             featureOn ? @"ON" : @"OFF", beginTime, endTime, (long)minuteInterval];
            completion(featureOn, nil);
        } fail:^{
            [weakSelf appendLog:@"❌ getSchedualBPInfo failed"];
            completion(NO, [NSError errorWithDomain:@"QCSampleHealthSwitch" code:-1 userInfo:nil]);
        }];
    } writeHandler:^(BOOL enabled, QCSampleHealthSwitchCompletion completion) {
        NSString *beginTime = weakSelf.settingBeginTime ?: @"00:00";
        NSString *endTime = weakSelf.settingEndTime ?: @"23:59";
        NSInteger interval = weakSelf.settingInterval > 0 ? weakSelf.settingInterval : 10;
        [QCSDKCmdCreator setSchedualBPInfoOn:enabled
                                  beginTime:beginTime
                                    endTime:endTime
                             minuteInterval:interval
                                    success:^(BOOL featureOn, NSString *resultBeginTime, NSString *resultEndTime, NSInteger resultInterval) {
            weakSelf.settingBeginTime = resultBeginTime;
            weakSelf.settingEndTime = resultEndTime;
            weakSelf.settingInterval = resultInterval;
            [weakSelf appendLogFormat:@"✅ scheduled blood pressure → %@", featureOn ? @"ON" : @"OFF"];
            completion(featureOn, nil);
        } fail:^{
            [weakSelf appendLog:@"❌ setSchedualBPInfo failed"];
            completion(enabled, [NSError errorWithDomain:@"QCSampleHealthSwitch" code:-1 userInfo:nil]);
        }];
    }];

    [self bindHealthQueryWithTitle:title
                      todayHandler:^{
        [weakSelf fetchBloodPressureForDayIndexes:@[@(0)]];
    } singleDayHandler:^(NSInteger dayIndex) {
        [weakSelf fetchBloodPressureForDayIndexes:@[@(dayIndex)]];
    } rangeHandler:^(NSInteger startDayIndex, NSInteger count) {
        NSMutableArray<NSNumber *> *dayIndexes = [NSMutableArray arrayWithCapacity:count];
        for (NSInteger i = 0; i < count; i++) {
            [dayIndexes addObject:@(startDayIndex + i)];
        }
        [weakSelf fetchBloodPressureForDayIndexes:dayIndexes];
    }];
}

#pragma mark - Helpers

- (NSDate *)startOfDayForDayIndex:(NSInteger)dayIndex {
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSDate *today = [calendar startOfDayForDate:[NSDate date]];
    NSDateComponents *components = [[NSDateComponents alloc] init];
    components.day = -dayIndex;
    return [calendar dateByAddingComponents:components toDate:today options:0];
}

- (BOOL)bloodPressureModel:(QCBloodPressureModel *)model matchesDayIndex:(NSInteger)dayIndex {
    if (!model.date) {
        return NO;
    }
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSDate *dayStart = [self startOfDayForDayIndex:dayIndex];
    NSDateComponents *oneDay = [[NSDateComponents alloc] init];
    oneDay.day = 1;
    NSDate *dayEnd = [calendar dateByAddingComponents:oneDay toDate:dayStart options:0];
    return ([model.date compare:dayStart] != NSOrderedAscending &&
            [model.date compare:dayEnd] == NSOrderedAscending);
}

- (NSArray<QCBloodPressureModel *> *)filterBloodPressureModels:(NSArray<QCBloodPressureModel *> *)models
                                                    forDayIndex:(NSInteger)dayIndex {
    NSMutableArray<QCBloodPressureModel *> *filtered = [NSMutableArray array];
    for (QCBloodPressureModel *model in models) {
        if ([self bloodPressureModel:model matchesDayIndex:dayIndex]) {
            [filtered addObject:model];
        }
    }
    return filtered;
}

- (void)logBloodPressureModels:(NSArray<QCBloodPressureModel *> *)models
                         label:(NSString *)label
                      dayIndex:(NSInteger)dayIndex {
    [self appendLogFormat:@"%@ dayIndex=%ld count=%ld", label, (long)dayIndex, (long)models.count];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    formatter.dateFormat = @"yyyy-MM-dd HH:mm:ss";
    formatter.locale = [NSLocale localeWithLocaleIdentifier:@"en_US_POSIX"];
    NSInteger limit = MIN(models.count, 5);
    for (NSInteger i = 0; i < limit; i++) {
        QCBloodPressureModel *model = models[i];
        [self appendLogFormat:@"  %@ sbp=%ld dbp=%ld",
         [formatter stringFromDate:model.date], (long)model.systolicPressure, (long)model.diastolicPressure];
    }
    if (models.count > limit) {
        [self appendLogFormat:@"  ... %ld more", (long)(models.count - limit)];
    }
}

- (void)logBloodPressureForDayIndexes:(NSArray<NSNumber *> *)dayIndexes
                     schedualRecords:(NSArray<QCBloodPressureModel *> *)schedualRecords
                       manualRecords:(NSArray<QCBloodPressureModel *> *)manualRecords {
    for (NSNumber *dayIndexNumber in dayIndexes) {
        NSInteger dayIndex = dayIndexNumber.integerValue;
        [self logBloodPressureModels:[self filterBloodPressureModels:schedualRecords forDayIndex:dayIndex]
                               label:@"Schedual Blood Pressure datas"
                            dayIndex:dayIndex];
        [self logBloodPressureModels:[self filterBloodPressureModels:manualRecords forDayIndex:dayIndex]
                               label:@"Manual Blood Pressure datas"
                            dayIndex:dayIndex];
    }
}

#pragma mark - SDK

- (void)fetchBloodPressureForDayIndexes:(NSArray<NSNumber *> *)dayIndexes {
    if (![self ensureConnected]) { return; }
    [self appendLog:@"SDK setTime → getSchedualBPHistoryData → getManualBloodPressureData"];
    [self appendLogFormat:@"query dayIndexes=[%@]", [[dayIndexes valueForKey:@"description"] componentsJoinedByString:@","]];
    [self appendLog:@"(BP API returns recent history; results filtered by dayIndex locally)"];

    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator setTime:[NSDate date] success:^(NSDictionary * _Nonnull info) {
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf) { return; }
        if (![[info objectForKey:QCBandFeatureBloodPressure] boolValue]) {
            [strongSelf appendLog:@"Not Supperort Blood Pressure"];
            return;
        }
        [strongSelf appendLog:@"Supperort Blood Pressure"];
        [QCSDKCmdCreator getSchedualBPHistoryDataWithSuccess:^(NSArray<QCBloodPressureModel *> * _Nonnull data) {
            __strong typeof(weakSelf) innerSelf = weakSelf;
            if (!innerSelf) { return; }
            [innerSelf appendLogFormat:@"Schedual Blood Pressure datas:%ld", (long)data.count];
            [QCSDKCmdCreator getManualBloodPressureDataWithLastUnixSeconds:0 success:^(NSArray<QCBloodPressureModel *> * _Nonnull manualData) {
                __strong typeof(weakSelf) manualSelf = weakSelf;
                if (!manualSelf) { return; }
                [manualSelf appendLogFormat:@"Manual Blood Pressure datas:%ld", (long)manualData.count];
                [manualSelf logBloodPressureForDayIndexes:dayIndexes schedualRecords:data manualRecords:manualData];
            } fail:^{
                [weakSelf appendLog:@"❌ getManualBloodPressure failed"];
            }];
        } fail:^{
            [weakSelf appendLog:@"❌ getSchedualBPHistoryData failed"];
        }];
    } failed:^{
        [weakSelf appendLog:@"❌ setTime failed"];
    }];
}

@end
