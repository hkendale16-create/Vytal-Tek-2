//
//  QCSampleDrinkReminderViewController.h
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//
//  Water reminder SDK sample. SDK calls are in QCSampleDrinkReminderViewController.m
//  饮水提醒 SDK 示例。SDK 调用见 QCSampleDrinkReminderViewController.m

#import "QCSampleHealthFunctionViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface QCSampleDrinkReminderViewController : QCSampleHealthFunctionViewController
@end

NS_ASSUME_NONNULL_END
