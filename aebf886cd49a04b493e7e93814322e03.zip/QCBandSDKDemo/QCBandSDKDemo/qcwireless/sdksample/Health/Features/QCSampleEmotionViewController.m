//
//  QCSampleEmotionViewController.m
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//
//  Emotion SDK sample. Log format follows legacy ViewController -setSchedualEmotionStatus / -getOtherDataEmotion.
//  Switch APIs use 0x3A (SchedualInfoTypeEmotion). Data API uses 0x7B long packet (AA=2).

#import "QCSampleEmotionViewController.h"
#import "QCSampleLocalization.h"
#import <QCBandSDK/QCSDKCmdCreator.h>
#import <QCBandSDK/QCOtherDataEmotionModel.h>
#import <QCBandSDK/QCEmotionItemModel.h>

@implementation QCSampleEmotionViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = QCSampleLocalized(QCSampleLocalizedKeyHealthEmotion);
}

- (void)setupActions {
    __weak typeof(self) weakSelf = self;
    NSString *title = QCSampleLocalized(QCSampleLocalizedKeyHealthEmotion);

    [self addSwitchWithTitle:QCSampleLocalized(QCSampleLocalizedKeyHealthEmotionSwitch)
       unavailableStatusKey:QCSampleLocalizedKeyHealthSwitchUnsupported
                readHandler:^(QCSampleHealthSwitchCompletion completion) {
        [QCSDKCmdCreator getSchedualEmotionStatusWithFinshed:^(BOOL isOn, NSError * _Nullable error) {
            if (error) {
                [weakSelf appendEmotionSwitchError:error action:@"get"];
            } else {
                [weakSelf appendLogFormat:@"[Emotion] switch %@", isOn ? @"ON" : @"OFF"];
            }
            completion(isOn, error);
        }];
    } writeHandler:^(BOOL enabled, QCSampleHealthSwitchCompletion completion) {
        [QCSDKCmdCreator setSchedualEmotionStatus:enabled finshed:^(NSError * _Nullable error) {
            if (error) {
                [weakSelf appendEmotionSwitchError:error action:@"set"];
            } else {
                [weakSelf appendLogFormat:@"[Emotion] switch → %@", enabled ? @"ON" : @"OFF"];
            }
            completion(enabled, error);
        }];
    }];

    [self bindHealthQueryWithTitle:title
                      todayHandler:^{
        [weakSelf fetchEmotionForDayIndexes:@[@(0)]];
    } singleDayHandler:^(NSInteger dayIndex) {
        [weakSelf fetchEmotionForDayIndexes:@[@(dayIndex)]];
    } rangeHandler:^(NSInteger startDayIndex, NSInteger count) {
        NSMutableArray *days = [NSMutableArray arrayWithCapacity:count];
        for (NSInteger i = 0; i < count; i++) {
            [days addObject:@(startDayIndex + i)];
        }
        [weakSelf fetchEmotionForDayIndexes:days];
    }];
}

#pragma mark - Log helpers

- (BOOL)isEmotionSwitchUnsupportedError:(NSError *)error {
    if (!error) {
        return NO;
    }
    return error.code == -1 && ([error.domain isEqualToString:@"get fail"] || [error.domain isEqualToString:@"set fail"]);
}

- (void)appendEmotionSwitchError:(NSError *)error action:(NSString *)action {
    [self appendLogFormat:@"[Emotion] %@ switch failed: %@", action, error.localizedDescription ?: @""];
    if ([self isEmotionSwitchUnsupportedError:error]) {
        [self appendLog:@"[Emotion] device/firmware may not support 0x3A emotion switch (SchedualInfoTypeEmotion)"];
    }
}

- (void)logEmotionModels:(NSArray<QCOtherDataEmotionModel *> *)models {
    [self appendLog:@"[Emotion] success"];
    if (models.count == 0) {
        [self appendLog:@"[Emotion] no day data returned (switch off or no samples yet)"];
    }
    for (QCOtherDataEmotionModel *model in models) {
        NSInteger valid = 0;
        for (QCEmotionItemModel *item in model.emotions) {
            if (item.value != 0) {
                valid += 1;
            }
        }
        [self appendLogFormat:@"  ├ %@  interval=%ldmin  items=%zd  valid=%ld%@",
         model.date,
         (long)model.interval,
         model.emotions.count,
         (long)valid,
         valid == 0 ? @"  (no data)" : @""];
    }
}

#pragma mark - SDK

- (void)fetchEmotionDataWithDayIndexes:(NSArray<NSNumber *> *)dayIndexes {
    [self appendLogFormat:@"SDK getOtherDataEmotionWithDayIndexes:%@", dayIndexes];
    __weak typeof(self) weakSelf = self;
    [QCSDKCmdCreator getOtherDataEmotionWithDayIndexes:dayIndexes finished:^(NSArray<QCOtherDataEmotionModel *> * _Nullable models, NSError * _Nullable error) {
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf) { return; }
        if (error) {
            [strongSelf appendLogFormat:@"[Emotion] failed: %@", error.localizedDescription];
            if ([strongSelf isEmotionSwitchUnsupportedError:error]) {
                [strongSelf appendLog:@"[Emotion] device may not support 0x7B emotion data"];
            }
            [strongSelf refreshHealthSwitchStates];
            return;
        }
        [strongSelf logEmotionModels:models ?: @[]];
        [strongSelf refreshHealthSwitchStates];
    }];
}

- (void)fetchEmotionForDayIndexes:(NSArray<NSNumber *> *)dayIndexes {
    __weak typeof(self) weakSelf = self;
    [self appendLog:@"SDK setSchedualEmotionStatus:YES → getOtherDataEmotionWithDayIndexes (legacy flow)"];
    [QCSDKCmdCreator setSchedualEmotionStatus:YES finshed:^(NSError * _Nullable switchError) {
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf) { return; }
        if (switchError) {
            [strongSelf appendLogFormat:@"[Emotion] enable switch failed: %@", switchError.localizedDescription];
            if ([strongSelf isEmotionSwitchUnsupportedError:switchError]) {
                [strongSelf appendLog:@"[Emotion] switch unsupported — still try getOtherDataEmotionWithDayIndexes"];
            }
        }
        [strongSelf fetchEmotionDataWithDayIndexes:dayIndexes];
    }];
}

@end
