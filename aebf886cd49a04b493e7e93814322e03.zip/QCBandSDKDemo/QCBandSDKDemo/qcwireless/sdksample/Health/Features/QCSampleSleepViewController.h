//
//  QCSampleSleepViewController.h
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//
//  Sleep SDK sample. SDK calls are in QCSampleSleepViewController.m
//  睡眠 SDK 示例。SDK 调用见 QCSampleSleepViewController.m

#import "QCSampleHealthFunctionViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface QCSampleSleepViewController : QCSampleHealthFunctionViewController
@end

NS_ASSUME_NONNULL_END
