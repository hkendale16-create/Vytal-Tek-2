//
//  QCSampleBloodOxygenViewController.h
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//
//  Blood oxygen SDK sample. SDK calls are in QCSampleBloodOxygenViewController.m
//  血氧 SDK 示例。SDK 调用见 QCSampleBloodOxygenViewController.m

#import "QCSampleHealthFunctionViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface QCSampleBloodOxygenViewController : QCSampleHealthFunctionViewController
@end

NS_ASSUME_NONNULL_END
