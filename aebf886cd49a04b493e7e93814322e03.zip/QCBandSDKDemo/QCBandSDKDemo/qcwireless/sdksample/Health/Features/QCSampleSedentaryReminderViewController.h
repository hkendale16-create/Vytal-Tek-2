//
//  QCSampleSedentaryReminderViewController.h
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//
//  Sedentary reminder SDK sample. SDK calls are in QCSampleSedentaryReminderViewController.m
//  久坐提醒 SDK 示例。SDK 调用见 QCSampleSedentaryReminderViewController.m

#import "QCSampleHealthFunctionViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface QCSampleSedentaryReminderViewController : QCSampleHealthFunctionViewController
@end

NS_ASSUME_NONNULL_END
