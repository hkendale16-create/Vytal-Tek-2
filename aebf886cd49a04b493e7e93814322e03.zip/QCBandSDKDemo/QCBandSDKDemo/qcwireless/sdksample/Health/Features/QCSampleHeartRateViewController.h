//
//  QCSampleHeartRateViewController.h
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//
//  Heart rate SDK sample. SDK calls are in QCSampleHeartRateViewController.m
//  心率 SDK 示例。SDK 调用见 QCSampleHeartRateViewController.m

#import "QCSampleHealthFunctionViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface QCSampleHeartRateViewController : QCSampleHealthFunctionViewController
@end

NS_ASSUME_NONNULL_END
