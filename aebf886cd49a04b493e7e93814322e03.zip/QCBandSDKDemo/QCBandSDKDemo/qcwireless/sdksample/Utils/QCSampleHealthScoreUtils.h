//
//  QCSampleHealthScoreUtils.h
//  QCBandSDKDemo
//
//  Created by zhong on 2026/8/4.
//
//  Demo-only health score calculations shared by activity and sleep pages.
//  Demo 健康评分工具，供活动和睡眠页面复用。
//

#import <Foundation/Foundation.h>

@class QCSleepModel;

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, QCSampleActivityScoreLevel) {
    QCSampleActivityScoreLevelLow = 0,
    QCSampleActivityScoreLevelFair,
    QCSampleActivityScoreLevelGood,
    QCSampleActivityScoreLevelExcellent
};

@interface QCSampleSleepScoreResult : NSObject

@property (nonatomic, assign, readonly) NSInteger score;
@property (nonatomic, assign, readonly) NSInteger efficiency;
@property (nonatomic, assign, readonly) NSInteger totalMinutes;
@property (nonatomic, assign, readonly) NSInteger deepMinutes;
@property (nonatomic, assign, readonly) NSInteger lightMinutes;
@property (nonatomic, assign, readonly) NSInteger remMinutes;
@property (nonatomic, assign, readonly) NSInteger awakeMinutes;

@end

@interface QCSampleHealthScoreUtils : NSObject

/// Calculates a 0...100 activity score using the age-based step coefficients.
/// 按年龄对应的步数系数计算 0～100 的活动得分。
+ (NSInteger)activityScoreForSteps:(NSInteger)steps age:(NSInteger)age;

/// Maps an activity score to the four display levels used by the reference app.
/// 将活动得分映射为四档展示等级。
+ (QCSampleActivityScoreLevel)activityLevelForScore:(NSInteger)score;

/// Aggregates sleep segments and returns the score and UI efficiency mapping.
/// 汇总睡眠分段并返回睡眠评分及 UI 效率映射。
+ (QCSampleSleepScoreResult *)sleepScoreForSegments:(NSArray<QCSleepModel *> *)segments;

@end

NS_ASSUME_NONNULL_END
