//
//  QCSampleHealthScoreUtils.m
//  QCBandSDKDemo
//
//  Created by zhong on 2026/8/4.
//

#import "QCSampleHealthScoreUtils.h"
#import <QCBandSDK/QCSleepModel.h>
#import <math.h>

@interface QCSampleSleepScoreResult ()
@property (nonatomic, assign, readwrite) NSInteger score;
@property (nonatomic, assign, readwrite) NSInteger efficiency;
@property (nonatomic, assign, readwrite) NSInteger totalMinutes;
@property (nonatomic, assign, readwrite) NSInteger deepMinutes;
@property (nonatomic, assign, readwrite) NSInteger lightMinutes;
@property (nonatomic, assign, readwrite) NSInteger remMinutes;
@property (nonatomic, assign, readwrite) NSInteger awakeMinutes;
@end

@implementation QCSampleSleepScoreResult
@end

@implementation QCSampleHealthScoreUtils

+ (NSInteger)activityScoreForSteps:(NSInteger)steps age:(NSInteger)age {
    if (steps <= 0 || age <= 0) {
        return 0;
    }

    NSInteger divisor;
    if (age <= 12) {
        divisor = 150;
    } else if (age <= 18) {
        divisor = 160;
    } else if (age <= 35) {
        divisor = 187;
    } else if (age <= 59) {
        divisor = 125;
    } else {
        divisor = 100;
    }
    return MIN(steps / divisor, 100);
}

+ (QCSampleActivityScoreLevel)activityLevelForScore:(NSInteger)score {
    if (score >= 85) {
        return QCSampleActivityScoreLevelExcellent;
    }
    if (score >= 75) {
        return QCSampleActivityScoreLevelGood;
    }
    if (score >= 60) {
        return QCSampleActivityScoreLevelFair;
    }
    return QCSampleActivityScoreLevelLow;
}

+ (QCSampleSleepScoreResult *)sleepScoreForSegments:(NSArray<QCSleepModel *> *)segments {
    QCSampleSleepScoreResult *result = [[QCSampleSleepScoreResult alloc] init];
    for (QCSleepModel *segment in segments) {
        NSInteger minutes = segment.total > 0 ? segment.total : [segment realEffectiveMinutes];
        if (minutes <= 0) {
            continue;
        }
        switch (segment.type) {
            case SLEEPTYPEDEEP:
                result.deepMinutes += minutes;
                break;
            case SLEEPTYPELIGHT:
                result.lightMinutes += minutes;
                break;
            case SLEEPTYPEREM:
                result.remMinutes += minutes;
                break;
            case SLEEPTYPESOBER:
                result.awakeMinutes += minutes;
                break;
            default:
                break;
        }
    }

    result.totalMinutes = result.deepMinutes + result.lightMinutes + result.remMinutes + result.awakeMinutes;
    if (result.totalMinutes <= 0) {
        return result;
    }

    // Keep the established weighted score for consistent client-side display.
    // 沿用既有加权评分规则，确保客户端展示结果一致。
    const float referenceValues[] = {0.2f, 0.5f, 100.0f, 250.0f, 500.0f};
    const float sectionScores[] = {2.5f, 2.5f, 5.0f, 5.0f, 70.0f};
    float values[] = {
        (float)result.deepMinutes / (float)result.totalMinutes,
        (float)result.lightMinutes / (float)result.totalMinutes,
        (float)result.deepMinutes,
        (float)result.lightMinutes,
        (float)result.totalMinutes
    };

    float score = 15.0f;
    for (NSInteger index = 0; index < 5; index++) {
        float difference = fabsf(values[index] - referenceValues[index]);
        float section = sectionScores[index] * (1.0f - difference / referenceValues[index]);
        score += MAX(section, 0.0f);
    }
    result.score = MIN(MAX((NSInteger)lroundf(score), 0), 100);
    result.efficiency = [self sleepEfficiencyForScore:result.score];
    return result;
}

+ (NSInteger)sleepEfficiencyForScore:(NSInteger)score {
    if (score < 60) {
        return 80;
    }
    if (score < 70) {
        return 82;
    }
    if (score < 80) {
        return 85;
    }
    if (score < 85) {
        return 90;
    }
    if (score < 90) {
        return 95;
    }
    if (score < 95) {
        return 99;
    }
    return 100;
}

@end
