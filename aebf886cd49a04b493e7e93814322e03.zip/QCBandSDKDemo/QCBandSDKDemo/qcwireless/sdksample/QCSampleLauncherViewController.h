//
//  QCSampleLauncherViewController.h
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//
//  Outer entry screen: integrators choose legacy ViewController or modular QCSampleHomeViewController.
//  外层入口页：集成方可选择进入旧版 ViewController 或新版 QCSampleHomeViewController。

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface QCSampleLauncherViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
