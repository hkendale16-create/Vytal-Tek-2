//
//  QCSampleResourceUpdateViewController.h
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/29.
//
//  Generic device resource update sample (syncResourceFileName / getNeededFileListFinished).
//  通用设备资源升级示例（syncResourceFileName / getNeededFileListFinished）。
//  Demo file: TP_resource/RT08_TP_FILE_0x1FD4_250106_01
//

#import "QCSampleHealthFunctionViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface QCSampleResourceUpdateViewController : QCSampleHealthFunctionViewController

@end

NS_ASSUME_NONNULL_END
