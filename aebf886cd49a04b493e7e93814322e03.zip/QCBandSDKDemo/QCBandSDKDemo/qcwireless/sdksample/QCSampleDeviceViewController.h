//
//  QCSampleDeviceViewController.h
//  QCBandSDKDemo
//
//  Created by zhong on 2026/8/4.
//
//  Device control SDK sample (temperature unit, low-power, camera, calibration, power).
//  设备控制 SDK 示例（温度单位、省电、拍照、佩戴校准、开关机/复位）。
//
//  SDK APIs / 使用的 SDK API:
//  - getWeatherForecastStatusWithCurrentState:… / setWeatherForecastStatus:…
//  - getLowPowerWithFinshed: / setLowPowerWith:finshed:
//  - switchToPhotoUISuccess:fail: / stopTakingPhotoSuccess:fail:
//  - QCSDKManager switchToPicture / takePicture / stopTakePicture
//  - startToWearCalibrationWithCompletedHandle: / stopToWearCalibrationWithCompletedHandle:
//  - readBatterySuccess:failed:
//  - shutDownSuccess:fail: / resetBandHardlySuccess:fail: / resetBandToFacotrySuccess:fail:
//  - getDeviceMacAddressSuccess:fail: / getDeviceSoftAndHardVersionSuccess:fail:
//

#import "QCSampleHealthFunctionViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface QCSampleDeviceViewController : QCSampleHealthFunctionViewController

@end

NS_ASSUME_NONNULL_END
