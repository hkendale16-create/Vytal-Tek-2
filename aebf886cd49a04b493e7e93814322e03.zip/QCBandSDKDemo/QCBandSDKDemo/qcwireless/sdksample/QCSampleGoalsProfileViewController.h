//
//  QCSampleGoalsProfileViewController.h
//  QCBandSDKDemo
//
//  Created by zhong on 2026/8/4.
//
//  Goals & user profile SDK sample.
//  目标与个人资料 SDK 示例。
//
//  SDK APIs / 使用的 SDK API:
//  - getStepTargetInfoWithSuccess:fail: / setStepTarget:...
//  - getTimeFormatInfo:fail: / setTimeFormatTwentyfourHourFormat:...
//
//  Value ranges are validated before sending so integrators see clear limits.
//  发送前校验传值范围，便于集成方明确合法区间。
//

#import "QCSampleHealthFunctionViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface QCSampleGoalsProfileViewController : QCSampleHealthFunctionViewController

@end

NS_ASSUME_NONNULL_END
