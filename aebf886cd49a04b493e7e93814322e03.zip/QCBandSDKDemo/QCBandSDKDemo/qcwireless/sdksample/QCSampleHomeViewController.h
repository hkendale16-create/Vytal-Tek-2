//
//  QCSampleHomeViewController.h
//  QCBandSDKDemo
//
//  Created by zhong on 2026/7/27.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface QCSampleHomeViewController : UIViewController

@end

@interface QCSampleHomeSectionHeaderView : UITableViewHeaderFooterView
- (void)configureWithTitle:(NSString *)title;
@end

@interface AxcNavigationController : UINavigationController
+ (void)axc_applyDefaultAppearanceToNavigationBar:(UINavigationBar *)navigationBar;
@end

@interface AxcNavigationTitleView : UIView
+ (instancetype)viewWithTitle:(NSString *)title subtitle:(NSString *)subtitle;
@end

NS_ASSUME_NONNULL_END
